import { CityMap } from './ui/map';
import './ui/styles.css';
import type { GameState } from './sim/state';
import { playerBusinesses } from './sim/state';
import { Engine } from './sim/engine';
import { unreadAlerts } from './sim/alerts';
import { GRADES } from './sim/skills';
import { App } from './ui/app';
import { showWelcome } from './ui/welcome';
import { dashboardView } from './ui/views/dashboard';
import { mapView } from './ui/views/mapView';
import { progressView } from './ui/views/progress';
import { headOfficeView } from './ui/views/headOffice';
import { holdingView } from './ui/views/holding';
import { founderView } from './ui/views/founder';
import { contractsView } from './ui/views/contracts';
import { researchView } from './ui/views/research';
import { newsView } from './ui/views/news';
import { marketView } from './ui/views/market';
import { businessesView } from './ui/views/businesses';
import { employeesView } from './ui/views/employees';
import { inventoryView } from './ui/views/inventory';
import { logisticsView } from './ui/views/logistics';
import { marketingView } from './ui/views/marketing';
import { financeView } from './ui/views/finance';
import { propertyView } from './ui/views/property';
import { reportsView } from './ui/views/reports';
import { settingsView } from './ui/views/settings';

const root = document.getElementById('app');
if (!root) throw new Error('#app is missing from the page');

let app: App | null = null;

function boot(state: GameState): void {
  app?.stop();
  const engine = new Engine(state);
  app = new App(root as HTMLElement, engine);

  // A handle for automated tests, which need to drive the clock without
  // waiting in real time. It exposes the engine that is already running the
  // game — no shortcuts, no extra powers.
  // The test handle. `grades` is here so a harness can assert that every rung
  // the game defines is the number the interface draws, rather than pinning a
  // count in the test that goes stale the moment the ladder grows.
  (globalThis as unknown as { __BM__?: unknown }).__BM__ = {
    engine,
    state,
    app,
    grades: GRADES.length,
    map: () => CityMap.current,
  };

  // Grouped by the job rather than by the screen: what you look at, who works
  // for you, what it costs, how you grow, and the world you do it in. Every
  // entry carries the line the header prints under the title, so a screen can
  // never be opened without saying what it is for.
  app.register({
    route: 'dashboard', label: 'Dashboard', icon: 'dashboard', group: 'Overview',
    blurb: 'How the company is doing, and what wants doing about it.',
    factory: dashboardView,
  });
  app.register({
    route: 'founder', label: 'You', icon: 'you', group: 'Overview',
    blurb: 'What you are good at, and what each of those is worth right now.',
    factory: founderView,
  });
  app.register({
    route: 'news', label: 'Newsroom', icon: 'news', group: 'Overview',
    blurb: 'Everything that has happened, and everything waiting on a decision.',
    factory: newsView,
    badge: (s) => s.decisions.length,
  });

  app.register({
    route: 'businesses', label: 'Businesses', icon: 'shop', group: 'The company',
    blurb: 'Every location you run, and how each one is trading.',
    factory: businessesView,
    badge: (s) => playerBusinesses(s).filter((b) => b.status === 'setup').length,
  });
  app.register({
    route: 'employees', label: 'Employees', icon: 'people', group: 'The company',
    blurb: 'Your team. Who they are, what they can do, and how they are getting on.',
    factory: employeesView,
  });
  app.register({
    route: 'inventory', label: 'Inventory', icon: 'inventory', group: 'The company',
    blurb: 'What is on the shelves, what it cost, and what to order next.',
    factory: inventoryView,
  });
  app.register({
    route: 'logistics', label: 'Distribution', icon: 'truck', group: 'The company',
    blurb: 'Warehouses, deliveries and what it costs to move a pallet.',
    factory: logisticsView,
  });

  app.register({
    route: 'headoffice', label: 'Head office', icon: 'hq', group: 'Management',
    blurb: 'Central functions, systems and how much of the company runs itself.',
    factory: headOfficeView,
  });
  app.register({
    route: 'holding', label: 'Holding', icon: 'holding', group: 'Management',
    blurb: 'The company as a structure: divisions, who runs them, and mergers.',
    factory: holdingView,
    // A division nobody is answerable for is the thing this screen exists to
    // fix, so it says how many there are without being opened.
    badge: (s) => s.divisions.filter((d) => d.headEmployeeId === null).length,
  });
  app.register({
    route: 'contracts', label: 'Contracts', icon: 'contracts', group: 'Management',
    blurb: 'Supply agreements you are committed to, and offers on the table.',
    factory: contractsView,
    badge: (s) => s.contractOffers.length,
  });

  app.register({
    route: 'finance', label: 'Finance', icon: 'finance', group: 'Money',
    blurb: 'Cash, borrowing, and where every euro went.',
    factory: financeView,
  });
  app.register({
    route: 'reports', label: 'Reports', icon: 'reports', group: 'Money',
    blurb: 'Management accounts, month by month, and what they say.',
    factory: reportsView,
    badge: (s) => unreadAlerts(s).filter((a) => a.priority !== 'info').length,
  });
  app.register({
    route: 'marketing', label: 'Marketing', icon: 'marketing', group: 'Money',
    blurb: 'What you are spending to be known, and what it is buying.',
    factory: marketingView,
  });

  app.register({
    route: 'property', label: 'Real estate', icon: 'property', group: 'Growth',
    blurb: 'Units to rent or buy, and what the buildings you hold are worth.',
    factory: propertyView,
  });
  app.register({
    route: 'research', label: 'Research', icon: 'research', group: 'Growth',
    blurb: 'What the company is learning to do better, and what it costs.',
    factory: researchView,
  });
  app.register({
    route: 'progress', label: 'Progress', icon: 'progress', group: 'Growth',
    blurb: 'Where you are on the ladder, what is next, and what it unlocks.',
    factory: progressView,
  });

  app.register({
    route: 'market', label: 'Competition', icon: 'competition', group: 'The world',
    blurb: 'Who else is out there, what share they hold, and where the gaps are.',
    factory: marketView,
  });
  app.register({
    route: 'map', label: 'Map', icon: 'map', group: 'The world',
    blurb: 'The city, its districts, and where the trade actually is.',
    factory: mapView,
  });
  app.register({
    route: 'settings', label: 'Settings', icon: 'settings', group: 'The world',
    blurb: 'Saves, display and how the game plays.',
    factory: settingsView,
  });

  app.start();
}

showWelcome(root as HTMLElement, boot);
