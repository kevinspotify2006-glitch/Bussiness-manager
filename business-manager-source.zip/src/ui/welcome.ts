import type { GameState } from '../sim/state';
import { DEFAULT_SETTINGS, SETTINGS_KEY } from '../sim/state';
import { startGame } from '../sim/scenario';
import { deleteSave, listSaves, loadGame } from '../sim/save';
import { CITY_NAME, CITY_POPULATION } from '../data/districts';
import { DIFFICULTY_LABELS, SCENARIOS, scenario } from '../data/scenarios';
import type { ScenarioDef } from '../data/scenarios';
import { FOUNDER_SKILLS, FOUNDER_TRAITS, founderTrait, startingSkills } from '../data/founders';
import { count, money } from '../sim/format';
import { bar, button, clear, h, icon, numberInput, toast } from './dom';

/**
 * Everything before the game.
 *
 * The player used to be dropped straight into a company with a name box and
 * nothing else to decide. This is the decision that shapes the whole run: which
 * problem you want — surviving alone, optimising something you inherited, or
 * letting go of something too big to watch — and who you are while you solve it.
 *
 * The screen is built as a small stack of steps rather than a single wall,
 * because the choices depend on each other and a wall of them tells the player
 * nothing about which matters.
 */

type Screen = 'title' | 'scenario' | 'founder' | 'howto' | 'about' | 'settings';

export function showWelcome(root: HTMLElement, onStart: (state: GameState) => void): void {
  // What the player has picked so far. It lives here rather than in game state
  // because none of it is a game yet.
  let screen: Screen = 'title';
  let scenarioId = 'entrepreneur';
  let traitId = 'allrounder';
  let companyName = 'Newco';
  let founderName = 'You';
  const custom: Partial<ScenarioDef> = {};

  const render = (): void => {
    clear(root);
    const shell = h('div', { class: 'welcome-shell' });
    const card = h('div', { class: 'welcome' });
    shell.appendChild(card);
    root.appendChild(shell);

    card.appendChild(
      h(
        'div',
        { class: 'welcome-brand' },
        mark(),
        h(
          'div',
          {},
          h('h1', { class: 'welcome-title', text: 'Business Manager' }),
          h('p', { class: 'welcome-sub', text: 'Build · Manage · Expand · Dominate' }),
          h('p', {
            class: 'tiny muted',
            style: 'margin:6px 0 0',
            text: `${CITY_NAME}, population ${count(CITY_POPULATION)}. Somebody is about to open something.`,
          }),
        ),
      ),
    );

    if (screen === 'title') renderTitle(card);
    else if (screen === 'scenario') renderScenario(card);
    else if (screen === 'founder') renderFounder(card);
    else if (screen === 'howto') renderHowTo(card);
    else if (screen === 'about') renderAbout(card);
    else renderSettings(card);
  };

  const go = (next: Screen): void => {
    screen = next;
    render();
  };

  // ------------------------------------------------------------- the title
  function renderTitle(card: HTMLElement): void {
    const saves = listSaves();
    const menu = h('div', { class: 'welcome-menu' });

    menu.appendChild(
      menuItem('New game', 'Pick where you want to start from, and who you are.', () => go('scenario'), true),
    );

    if (saves.length > 0) {
      const latest = saves[0];
      menu.appendChild(
        menuItem(
          'Continue',
          `${latest.company} · day ${latest.day} · ${money(latest.netWorth)}`,
          () => {
            const loaded = loadGame(latest.id);
            if (!loaded) {
              toast('That save could not be read.', 'bad');
              return;
            }
            onStart(loaded);
          },
        ),
      );
    } else {
      // A dead control would be worse than an honest one that says why.
      const item = menuItem('Continue', 'No saved game yet.', () => {});
      item.classList.add('disabled');
      (item as HTMLButtonElement).disabled = true;
      menu.appendChild(item);
    }

    menu.appendChild(menuItem('How to play', 'What the game is, in about a minute.', () => go('howto')));
    menu.appendChild(menuItem('Settings', 'Autosave, number format, confirmations.', () => go('settings')));
    menu.appendChild(menuItem('About', 'What this is and how it works underneath.', () => go('about')));
    card.appendChild(menu);

    if (saves.length > 1) {
      const list = h('div', { class: 'welcome-saves' });
      list.appendChild(h('div', { class: 'welcome-heading', text: 'Other saved games' }));
      for (const slot of saves.slice(1, 7)) {
        list.appendChild(
          h(
            'div',
            { class: 'save-row' },
            h(
              'div',
              { style: 'flex:1;min-width:0' },
              h('div', { text: slot.name + (slot.auto ? ' (auto)' : '') }),
              h('div', { class: 'save-meta', text: `${slot.company} · day ${slot.day} · ${money(slot.netWorth)}` }),
            ),
            button(
              'Load',
              () => {
                const loaded = loadGame(slot.id);
                if (!loaded) {
                  toast('That save could not be read.', 'bad');
                  return;
                }
                onStart(loaded);
              },
              'btn small primary',
            ),
            button(
              'Delete',
              () => {
                deleteSave(slot.id);
                render();
              },
              'btn small',
            ),
          ),
        );
      }
      card.appendChild(list);
    }
  }

  // ---------------------------------------------------------- the scenario
  function renderScenario(card: HTMLElement): void {
    card.appendChild(heading('Where do you want to start?', 'Each of these is a different problem, not a difficulty setting.'));

    const grid = h('div', { class: 'scenario-grid' });
    for (const def of SCENARIOS) {
      const chosen = def.id === scenarioId;
      grid.appendChild(
        h(
          'button',
          {
            class: `scenario-card${chosen ? ' chosen' : ''}`,
            on: {
              click: () => {
                scenarioId = def.id;
                render();
              },
            },
          },
          h(
            'div',
            { class: 'scenario-head' },
            h('span', { class: 'scenario-name', text: def.name }),
            h('span', { class: `tag ${difficultyTone(def)}`, text: DIFFICULTY_LABELS[def.difficulty] }),
          ),
          h('div', { class: 'scenario-tagline', text: def.tagline }),
          h('div', { class: 'sub', text: def.detail }),
          h('div', { class: 'scenario-focus', text: def.focus }),
          // What you are actually handed. Read off the scenario itself, so a
          // card can never promise something the game does not then build.
          fact('cash', money(def.cash), 'starting capital'),
          fact(
            'shop',
            def.locations === 0 ? 'Nothing trading yet' : `${def.locations} location${def.locations === 1 ? '' : 's'}`,
            def.locations === 0 ? 'the whole city to choose from' : 'open on day one',
          ),
          fact(
            'people',
            def.locations === 0 ? 'Just you' : `${def.locations * def.staffPerLocation} on the payroll`,
            def.locations === 0 ? 'nobody to pay yet' : `${def.staffPerLocation} to a location`,
          ),
          def.headOffice || def.debtShare > 0 || def.extraRivals > 0
            ? fact(
                'warning',
                [
                  def.headOffice ? 'head office' : null,
                  def.debtShare > 0 ? 'inherited debt' : null,
                  def.extraRivals > 0 ? 'a crowded city' : null,
                ]
                  .filter(Boolean)
                  .join(' · '),
                'comes with it',
              )
            : fact('good', 'A clean slate', 'no debt, no history'),
        ),
      );
    }
    card.appendChild(grid);

    if (scenarioId === 'custom') card.appendChild(renderCustom());

    card.appendChild(
      h(
        'div',
        { class: 'welcome-actions' },
        button('Back', () => go('title')),
        button('Next — who are you?', () => go('founder'), 'btn primary'),
      ),
    );
  }

  /** Every figure, for the player who wants to set the board themselves. */
  function renderCustom(): HTMLElement {
    const base = scenario('custom');
    const panel = h('div', { class: 'custom-panel' });
    panel.appendChild(h('div', { class: 'welcome-heading', text: 'Set it up yourself' }));

    const field = (
      label: string,
      hint: string,
      key: keyof ScenarioDef,
      min: number,
      max: number,
      step: number,
    ): HTMLElement => {
      const value = (custom[key] as number | undefined) ?? (base[key] as number);
      return h(
        'label',
        { class: 'field custom-field' },
        h('span', { text: label }),
        numberInput(
          value,
          (next) => {
            (custom as Record<string, number>)[key] = Math.max(min, Math.min(max, next));
          },
          { min: String(min), max: String(max), step: String(step) },
        ),
        h('span', { class: 'tiny muted', text: hint }),
      );
    };

    const grid = h('div', { class: 'grid cols-3' });
    grid.appendChild(field('Starting cash', 'What is in the bank on day one.', 'cash', 5_000, 5_000_000, 5_000));
    grid.appendChild(field('Locations', 'Opened and trading before you arrive.', 'locations', 0, 12, 1));
    grid.appendChild(field('Staff per location', 'Hired into each of them.', 'staffPerLocation', 0, 10, 1));
    grid.appendChild(field('Reputation', 'What customers already think, 0–100.', 'reputation', 0, 100, 5));
    grid.appendChild(field('Awareness', 'How many people have heard of you, 0–100.', 'awareness', 0, 100, 5));
    grid.appendChild(field('Credit rating', 'What the bank thinks, 0–100.', 'creditRating', 0, 100, 5));
    grid.appendChild(field('Days of history', 'Trading run before you take over.', 'warmUpDays', 0, 120, 5));
    grid.appendChild(field('Extra rivals', 'How crowded the city already is.', 'extraRivals', 0, 10, 1));
    grid.appendChild(field('Level reached', 'What the company counts as having earned.', 'levelReached', 1, 8, 1));
    panel.appendChild(grid);
    panel.appendChild(
      h('p', {
        class: 'tiny muted',
        text: 'Everything you set here is built by the game itself — leases taken, people hired, doors opened, then the clock run forward. A custom company behaves exactly like one you built by hand.',
      }),
    );
    return panel;
  }

  // ------------------------------------------------------------ the founder
  function renderFounder(card: HTMLElement): void {
    card.appendChild(
      heading('And who are you?', 'What you did before this decides what you are good at — and what you will have to learn the hard way.'),
    );

    const grid = h('div', { class: 'scenario-grid' });
    for (const def of FOUNDER_TRAITS) {
      const chosen = def.id === traitId;
      const skills = startingSkills(def.id);
      const bars = h('div', { class: 'trait-skills' });
      for (const skill of FOUNDER_SKILLS) {
        const value = skills[skill.id];
        bars.appendChild(
          h(
            'div',
            { class: 'trait-skill' },
            h('span', { class: 'trait-skill-name', text: skill.name }),
            bar(value / 100, value >= 60 ? 'good' : value <= 25 ? 'bad' : ''),
            h('span', { class: 'trait-skill-value', text: String(value) }),
          ),
        );
      }
      grid.appendChild(
        h(
          'button',
          {
            class: `scenario-card${chosen ? ' chosen' : ''}`,
            on: {
              click: () => {
                traitId = def.id;
                render();
              },
            },
          },
          h('div', { class: 'scenario-head' }, h('span', { class: 'scenario-name', text: def.name })),
          h('div', { class: 'scenario-tagline', text: def.detail }),
          h('div', { class: 'sub', text: def.plays }),
          bars,
        ),
      );
    }
    card.appendChild(grid);

    const names = h('div', { class: 'grid cols-2', style: 'margin-top:14px' });
    const companyInput = h('input', { type: 'text', value: companyName, maxlength: 40, placeholder: 'Company name' });
    const founderInput = h('input', { type: 'text', value: founderName, maxlength: 40, placeholder: 'Your name' });
    companyInput.addEventListener('input', () => {
      companyName = companyInput.value;
    });
    founderInput.addEventListener('input', () => {
      founderName = founderInput.value;
    });
    names.appendChild(h('label', { class: 'field' }, h('span', { text: 'Company name' }), companyInput));
    names.appendChild(h('label', { class: 'field' }, h('span', { text: 'Your name' }), founderInput));
    card.appendChild(names);

    const def = scenario(scenarioId);
    card.appendChild(
      h('p', {
        class: 'tiny muted',
        text: `${def.name} · ${founderTrait(traitId).name}. ${def.focus}`,
      }),
    );

    const begin = (): void => {
      const state = startGame({
        companyName: companyInput.value.trim() || 'Newco',
        founderName: founderInput.value.trim() || 'You',
        traitId,
        scenarioId,
        overrides: scenarioId === 'custom' ? custom : undefined,
      });
      onStart(state);
    };
    for (const input of [companyInput, founderInput]) {
      input.addEventListener('keydown', (event) => {
        if ((event as KeyboardEvent).key === 'Enter') begin();
      });
    }

    card.appendChild(
      h(
        'div',
        { class: 'welcome-actions' },
        button('Back', () => go('scenario')),
        button('Start the company', begin, 'btn primary'),
      ),
    );
  }

  // ------------------------------------------------------------ the reading
  function renderHowTo(card: HTMLElement): void {
    card.appendChild(heading('How to play', 'The whole game in about a minute.'));
    const steps: [string, string][] = [
      ['Take a lease', 'Find a unit on the map or in Real estate. Busy pitches cost more and are worth more — for a shop. A repair business draws on the people who live nearby, not the ones walking past.'],
      ['Open something', 'Choose a trade that suits the unit, stock it, hire somebody, open the doors. Nothing sells until they are open.'],
      ['Watch the first week', 'The dashboard tells you what needs you today and what is worth doing. Both come from the same figures every other screen shows.'],
      ['Mind the cash, not the profit', 'A profitable company can still run out of money. The cash forecast is the screen that tells you before it happens.'],
      ['Hire, then manage', 'People have skills, a personality and a career. A brilliant technician is not automatically a manager — that takes leadership, and leadership is trained.'],
      ['Grow, then let go', 'Past about four locations you cannot see them all. That is when a head office, divisions and somebody senior to run them stop being optional.'],
    ];
    const list = h('div', { class: 'howto' });
    steps.forEach(([title, detail], index) => {
      list.appendChild(
        h(
          'div',
          { class: 'howto-step' },
          h('span', { class: 'howto-number', text: String(index + 1) }),
          h('div', {}, h('div', { class: 'howto-title', text: title }), h('div', { class: 'sub', text: detail })),
        ),
      );
    });
    card.appendChild(list);
    card.appendChild(h('div', { class: 'welcome-actions' }, button('Back', () => go('title'), 'btn primary')));
  }

  function renderAbout(card: HTMLElement): void {
    card.appendChild(heading('About', 'What this is, and what is underneath it.'));
    card.appendChild(
      h(
        'div',
        { class: 'about' },
        para(
          `${CITY_NAME} is generated once and stays put: about 390 units across fifteen districts, every one with its own footfall, rent, income and appetite for different trades. The map is drawn rather than pictured, and the traffic on it is routed along a real road graph.`,
        ),
        para(
          'Everything the game shows you is derived from one set of numbers. The share on the dashboard is the share the demand model hands out; the performance on a profile page is the figure the simulation multiplies by; the accounts are closed from the same ledger the transactions list shows. Nothing on any screen is decorative.',
        ),
        para(
          'The clock runs an hour at a time and produces the same result at every speed. A day is settled before the date changes, so rent, wages and every closing entry land in the right day.',
        ),
        para('Saves are versioned and migrated. A game started on an older build keeps playing.'),
      ),
    );
    card.appendChild(h('div', { class: 'welcome-actions' }, button('Back', () => go('title'), 'btn primary')));
  }

  function renderSettings(card: HTMLElement): void {
    card.appendChild(heading('Settings', 'These apply to every game, saved or new.'));
    const current = readSettings();
    const rows: [keyof typeof current, string, string][] = [
      ['autosave', 'Autosave', 'Save automatically at the end of each day.'],
      ['showTutorial', 'Show the tutorial', 'The prompts that walk you through the first few steps.'],
      ['compactNumbers', 'Short numbers', 'Write €1.2m rather than €1,200,000.'],
      ['confirmLargeSpend', 'Confirm large spending', 'Ask before anything that costs a lot.'],
    ];
    const list = h('div', {});
    for (const [key, label, detail] of rows) {
      const input = h('input', { type: 'checkbox' });
      (input as HTMLInputElement).checked = current[key];
      input.addEventListener('change', () => {
        current[key] = (input as HTMLInputElement).checked;
        writeSettings(current);
      });
      list.appendChild(
        h(
          'label',
          { class: 'switch' },
          input,
          h('div', {}, h('div', { text: label }), h('div', { class: 'sub', text: detail })),
        ),
      );
    }
    card.appendChild(list);
    card.appendChild(h('div', { class: 'welcome-actions' }, button('Back', () => go('title'), 'btn primary')));
  }

  render();
}

// -------------------------------------------------------------- small parts

/** The brand mark, drawn from the icon set rather than set as two letters. */
function mark(): HTMLElement {
  const el = h('div', { class: 'welcome-mark' });
  el.appendChild(icon('brand', 28));
  return el;
}

/** One line of "what this start hands you", with the picture that goes with it. */
function fact(name: string, value: string, detail: string): HTMLElement {
  const row = h('div', { class: 'scenario-fact' });
  row.appendChild(icon(name, 13));
  row.appendChild(h('span', {}, h('strong', { text: value }), h('span', { class: 'muted', text: ` — ${detail}` })));
  return row;
}

function heading(title: string, detail: string): HTMLElement {
  return h('div', { class: 'welcome-step-head' }, h('h2', { text: title }), h('p', { class: 'sub', text: detail }));
}

function para(text: string): HTMLElement {
  return h('p', { class: 'sub', text });
}

function menuItem(label: string, detail: string, onClick: () => void, primary = false): HTMLElement {
  return h(
    'button',
    { class: `menu-item${primary ? ' primary' : ''}`, on: { click: onClick } },
    h('span', { class: 'menu-label', text: label }),
    h('span', { class: 'menu-detail', text: detail }),
  );
}

function difficultyTone(def: ScenarioDef): string {
  if (def.difficulty === 'hard') return 'bad';
  if (def.difficulty === 'sandbox') return '';
  return 'good';
}

/**
 * Settings live outside any one save, because they are about the person playing
 * rather than the company they are running.
 */
function readSettings(): typeof DEFAULT_SETTINGS {
  try {
    const raw = window.localStorage.getItem(SETTINGS_KEY);
    if (!raw) return { ...DEFAULT_SETTINGS };
    const parsed = JSON.parse(raw) as Partial<typeof DEFAULT_SETTINGS>;
    return { ...DEFAULT_SETTINGS, ...parsed };
  } catch {
    return { ...DEFAULT_SETTINGS };
  }
}

function writeSettings(settings: typeof DEFAULT_SETTINGS): void {
  try {
    window.localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
  } catch {
    /* storage blocked; the game still plays, it just will not remember */
  }
}
