import type { Ctx, View } from '../app';
import {
  BRANCHES,
  RESEARCH,
  RESEARCH_BY_ID,
  canStart,
  isDone,
  openBranches,
  researchProgress,
  startResearch,
} from '../../sim/research';
import { levelOf, researchUnlocked } from '../../sim/progress';
import { money } from '../../sim/format';
import { bar, button, empty, h, keepingScroll, section, stat, toast } from '../dom';

/**
 * Research and development.
 *
 * Every project on this screen changes a number the simulation already uses,
 * and says which one in the same words the effect works in — "staff serve 8%
 * more customers an hour", not "operations improved". One project runs at a
 * time, so what to work on is a decision.
 */
export function researchView(ctx: Ctx): View {
  const el = h('div', { class: 'view' });

  const render = (): void => {
    el.replaceChildren();
    const state = ctx.state;

    el.appendChild(
      h(
        'div',
        { class: 'view-head' },
        h('h1', { text: 'Research and development' }),
        h('p', { text: 'Money spent now against a cost that never comes back.' }),
      ),
    );

    if (!researchUnlocked(state)) {
      el.appendChild(
        h(
          'section',
          { class: 'panel panel-danger' },
          h('h3', { class: 'panel-title', text: 'Not open to you yet' }),
          h('p', {
            text: `R&D needs a company large enough to carry it. You are a ${levelOf(
              state,
            ).name.toLowerCase()}; the first branches open at regional company, and the tree widens from there. The whole tree is below so you can see what you are working towards.`,
          }),
          button('What would it take?', () => ctx.go('progress'), 'btn primary'),
        ),
      );
    }

    const active = state.research.active;
    if (active) {
      const node = RESEARCH_BY_ID.get(active.id);
      el.appendChild(
        section(
          'In progress',
          h('h4', { text: node?.name ?? active.id }),
          h('p', { class: 'sub', text: node?.says ?? '' }),
          bar(researchProgress(state)),
          h('p', { class: 'sub', text: `Finishes on day ${active.endsOnDay} — ${active.endsOnDay - state.day} days to go.` }),
        ),
      );
    }

    const open = openBranches(state);
    const isOpen = (id: string): boolean => open.some((branch) => branch.id === id);
    for (const branch of BRANCHES) {
      const nodes = RESEARCH.filter((node) => node.branch === branch.id);
      const rows = h('div', {});
      for (const node of nodes) {
        const done = isDone(state, node.id);
        const check = canStart(state, node.id);
        rows.appendChild(
          h(
            'div',
            { class: `research-node${done ? ' done' : ''}` },
            h(
              'div',
              { class: 'research-head' },
              h('span', { class: 'research-name', text: node.name }),
              h('span', { class: 'research-says', text: node.says }),
            ),
            h('p', { class: 'sub', text: node.detail }),
            done
              ? h('span', { class: 'good', text: 'Done — the effect is live.' })
              : h(
                  'div',
                  { class: 'row' },
                  h('span', { class: 'sub', text: `${money(node.cost)} · ${node.days} days` }),
                  button(
                    'Start',
                    () => {
                      const result = startResearch(state, node.id);
                      toast(result.message);
                      render();
                    },
                    check.ok ? 'btn primary' : 'btn',
                  ),
                  check.ok ? null : h('span', { class: 'sub muted', text: check.reason }),
                ),
          ),
        );
      }
      const panel = section(
        `${branch.name} — ${branch.detail}`,
        isOpen(branch.id) ? null : h('p', { class: 'sub muted', text: 'Closed to a company this size.' }),
        rows,
      );
      if (!isOpen(branch.id)) panel.classList.add('locked');
      el.appendChild(panel);
    }

    const done = state.research.done.length;
    el.appendChild(
      section(
        'What you have bought',
        done === 0
          ? empty('Nothing finished yet.')
          : h(
              'div',
              {},
              ...state.research.done.map((id) => {
                const node = RESEARCH_BY_ID.get(id);
                return stat(node?.name ?? id, node?.says ?? '', 'good');
              }),
            ),
      ),
    );
  };

  /** What this screen is showing, so it only repaints when that changes. */
  function signature(): string {
    const state = ctx.state;
    return `${state.day}|${state.research.done.length}|${state.research.active?.id ?? ''}`;
  }

  render();
  // Repainting three times a second would throw the reader back to the top of
  // the page three times a second. It only repaints when what it shows has
  // actually changed, and then without moving them.
  let shown = signature();
  return {
    el,
    update: () => {
      const now = signature();
      if (now === shown) return;
      shown = now;
      keepingScroll(render);
    },
  };
}
