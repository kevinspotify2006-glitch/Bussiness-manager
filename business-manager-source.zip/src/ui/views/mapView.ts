import type { Ctx, View } from '../app';
import type { Building, DistrictId } from '../../sim/types';
import { CityMap, MAP_MODES, type MapMode } from '../map';
import { DISTRICTS, district } from '../../data/districts';
import { CATEGORY_NAMES, businessTypeOrThrow } from '../../data/businessTypes';
import { buyBuilding, endLease, renovate, renovationCost, rentBuilding, sellBuilding } from '../../sim/business';
import { count, money, moneyShort, pct } from '../../sim/format';
import { playerBusinesses } from '../../sim/state';
import { drift, pending, pendingIn } from '../../sim/cityChange';

import { button, clear, confirmDialog, empty, h, kpi, meter, section, stat, table, tag, toast } from '../dom';
import { openFoundBusinessDialog } from './newBusiness';

export function mapView(ctx: Ctx): View {
  const el = h('div', { class: 'view' });
  const panelHost = h('div', {});
  const districtHost = h('div', {});
  const map = new CityMap(ctx.state, persistentCamera);

  const modeRow = h('div', { class: 'map-modes' });
  const legend = h('div', { class: 'map-legend' });

  const setMode = (mode: MapMode): void => {
    map.setMode(mode);
    for (const child of Array.from(modeRow.children)) {
      const el2 = child as HTMLElement;
      el2.className = `map-mode${el2.dataset.mode === mode ? ' active' : ''}`;
    }
    renderLegend(legend, mode);
  };

  for (const mode of MAP_MODES) {
    modeRow.appendChild(
      h(
        'button',
        { class: 'map-mode', data: { mode: mode.id }, on: { click: () => setMode(mode.id) } },
        mode.label,
      ),
    );
  }

  const checkButton = h('button', { class: 'icon-btn', title: 'Check the map: footprints, junctions, routes and anything wrong' }, '⌗');
  checkButton.addEventListener('click', () => {
    const on = !map.getDebug();
    map.setDebug(on);
    checkButton.classList.toggle('active', on);
    if (!on) return;
    const report = map.checkMap();
    toast(
      report.problems.length === 0
        ? `Map checked: ${report.counts.structures} buildings, ${report.counts.nodes} junctions, no problems.`
        : `Map checked: ${report.problems.length} problems found.`,
    );
  });

  const controls = h(
    'div',
    { class: 'map-controls' },
    h('button', { class: 'icon-btn', title: 'Zoom in', on: { click: () => map.zoomBy(1.35) } }, '＋'),
    h('button', { class: 'icon-btn', title: 'Zoom out', on: { click: () => map.zoomBy(1 / 1.35) } }, '−'),
    h(
      'button',
      {
        class: 'icon-btn',
        title: 'Back to your businesses',
        on: {
          click: () => {
            const mine = ctx.state.buildings.find((b) => b.occupantCompanyId === ctx.state.playerCompanyId);
            if (mine) map.focus(mine, 5);
            else toast('You do not have any premises yet.');
          },
        },
      },
      '◎',
    ),
    checkButton,
  );

  const shell = h('div', { class: 'map-shell' }, map.canvas, modeRow, controls, legend);

  map.onSelect = (building) => {
    renderBuildingPanel(ctx, panelHost, building, map);
    if (building) renderDistrictPanel(ctx, districtHost, building.district);
  };

  el.appendChild(
    h(
      'div',
      { class: 'view-head' },
      h('h1', { text: 'Northgate' }),
      h('p', { text: 'Tap a unit to inspect it. Drag to pan, pinch or scroll to zoom.' }),
    ),
  );
  el.appendChild(cityHeader(ctx));
  el.appendChild(shell);
  el.appendChild(panelHost);
  el.appendChild(districtHost);
  el.appendChild(cityPlans(ctx));
  el.appendChild(districtTable(ctx, (id) => renderDistrictPanel(ctx, districtHost, id)));

  // The canvas needs a layout pass before it can measure itself.
  requestAnimationFrame(() => {
    map.resize();
    setMode('standard');
    const preselect = ctx.params.building;
    if (preselect) {
      const building = ctx.state.buildings.find((b) => b.id === preselect);
      if (building) {
        map.focus(building, 6);
        map.select(building.id);
        renderBuildingPanel(ctx, panelHost, building, map);
      }
    }
  });

  return {
    el,
    update: () => map.setState(ctx.state),
    destroy: () => map.destroy(),
  };
}

/** The map remembers where the player was looking between visits. */
const persistentCamera = { x: 0.5, y: 0.46, zoom: 1 };

function renderLegend(host: HTMLElement, mode: MapMode): void {
  const def = MAP_MODES.find((m) => m.id === mode);
  clear(host);
  host.appendChild(h('strong', { text: def?.label ?? '' }));
  host.appendChild(h('div', { class: 'tiny muted', text: def?.legend ?? '' }));
  const rows: [string, string][] =
    mode === 'standard' || mode === 'commercial'
      ? [
          ['#4bbf87', 'Yours'],
          ['#e2686d', 'Competitor'],
          ['#6f9bd0', 'Available'],
        ]
      : [
          ['rgb(58,110,180)', 'Low'],
          ['rgb(150,170,140)', 'Medium'],
          ['rgb(240,80,50)', 'High'],
        ];
  for (const [colour, label] of rows) {
    host.appendChild(
      h(
        'div',
        { class: 'legend-row' },
        h('span', { class: 'legend-swatch', style: `background:${colour}` }),
        h('span', { text: label }),
      ),
    );
  }
}

function renderBuildingPanel(ctx: Ctx, host: HTMLElement, building: Building | null, map: CityMap): void {
  clear(host);
  if (!building) return;
  const state = ctx.state;
  const def = district(building.district);
  const business = building.businessId ? state.businesses.find((b) => b.id === building.businessId) : undefined;
  const rivals = state.buildings.filter((b) => b.district === building.district && b.status === 'competitor').length;
  const total = state.buildings.filter((b) => b.district === building.district).length;
  const competition = rivals / Math.max(1, total);
  const competitionLabel = competition > 0.4 ? 'High' : competition > 0.18 ? 'Medium' : 'Low';

  const isMine = building.occupantCompanyId === state.playerCompanyId;
  const suitable = building.suitableFor.map((category) => CATEGORY_NAMES[category]).join(', ');

  const actions = h('div', { class: 'btn-row', style: 'margin-top:12px' });

  if (building.status === 'available') {
    actions.appendChild(
      button(
        `Rent — ${money(building.rent)}/mo`,
        async () => {
          const ok = await confirmDialog(
            'Sign the lease?',
            `${building.address} costs ${money(building.rent)} per month. You pay ${money(building.rent * 3)} now: the first month plus a two-month deposit.`,
            'Sign lease',
          );
          if (!ok) return;
          const result = rentBuilding(state, building.id);
          toast(result.message, result.ok ? 'good' : 'bad');
          if (result.ok) ctx.refresh();
        },
        'btn primary',
      ),
    );
    actions.appendChild(
      button(`Buy — ${money(building.value)}`, async () => {
        const ok = await confirmDialog(
          'Buy this building?',
          `${building.address} is on the market for ${money(building.value)}. You keep the asset and pay no rent, but it is a large amount of cash.`,
          'Buy building',
        );
        if (!ok) return;
        const result = buyBuilding(state, building.id);
        toast(result.message, result.ok ? 'good' : 'bad');
        if (result.ok) ctx.refresh();
      }),
    );
  }

  if (isMine && !business) {
    actions.appendChild(
      button(
        'Create a business here',
        () => openFoundBusinessDialog(ctx, building),
        'btn primary',
      ),
    );
    if (building.status === 'rented') {
      actions.appendChild(
        button('End lease', async () => {
          const ok = await confirmDialog('End the lease?', `You get ${money(building.rent * 1.5)} of the deposit back.`, 'End lease');
          if (!ok) return;
          const result = endLease(state, building.id);
          toast(result.message, result.ok ? 'good' : 'bad');
          if (result.ok) ctx.refresh();
        }, 'btn ghost'),
      );
    }
    if (building.status === 'owned') {
      actions.appendChild(
        button('Sell building', async () => {
          const ok = await confirmDialog(
            'Sell this building?',
            `You would receive about ${money(Math.round(building.value * 0.94))} after agent fees.`,
            'Sell',
          );
          if (!ok) return;
          const result = sellBuilding(state, building.id);
          toast(result.message, result.ok ? 'good' : 'bad');
          if (result.ok) ctx.refresh();
        }, 'btn ghost'),
      );
    }
  }

  if (isMine && building.condition < 97 && building.renovationEndsOnDay === null) {
    actions.appendChild(
      button(`Renovate — ${money(renovationCost(building))}`, async () => {
        const ok = await confirmDialog(
          'Start renovation?',
          `Six days of work brings ${building.address} back to full condition. Customers notice a tired unit.`,
          'Start work',
        );
        if (!ok) return;
        const result = renovate(state, building.id);
        toast(result.message, result.ok ? 'good' : 'bad');
        if (result.ok) ctx.refresh();
      }),
    );
  }

  if (business && business.companyId === state.playerCompanyId) {
    actions.appendChild(button('Manage business', () => ctx.go('businesses', { business: business.id }), 'btn primary'));
  }

  actions.appendChild(
    button('Focus on map', () => {
      map.focus(building, 6);
      map.select(building.id);
    }, 'btn ghost'),
  );

  const statusTag =
    building.occupantCompanyId === state.playerCompanyId
      ? h('span', { class: 'tag good', text: building.status === 'owned' ? 'Owned' : 'Leased' })
      : building.status === 'competitor'
        ? h('span', { class: 'tag bad', text: 'Competitor' })
        : h('span', { class: 'tag accent', text: 'Available' });

  const panel = section(
    'Building',
    h(
      'div',
      { class: 'card-head' },
      h(
        'div',
        {},
        h('div', { class: 'card-title', text: building.address }),
        h('div', { class: 'card-sub', text: `${def.name} · ${building.size} m² · ${building.floors} floor${building.floors > 1 ? 's' : ''}` }),
      ),
      statusTag,
    ),
    h(
      'div',
      { class: 'grid cols-2' },
      h(
        'div',
        {},
        stat('Rent', `${money(building.rent)}/mo`),
        stat('Purchase price', money(building.value)),
        stat('Condition', `${Math.round(building.condition)}/100`, building.condition < 50 ? 'bad' : undefined),
        stat('Storage', `${count(building.storageCapacity)} units`),
        stat('Customer capacity', count(building.customerCapacity)),
        stat('Parking', count(building.parking)),
      ),
      h(
        'div',
        {},
        stat('Foot traffic', `${count(building.footTraffic)}/day`),
        stat('Average income', `${money(def.averageIncome)}/yr`),
        stat('District population', count(def.population)),
        stat('Competition', competitionLabel, competition > 0.4 ? 'bad' : undefined),
        stat('Growth', pct(def.growth * 100, 1)),
        stat('Suitable for', suitable || '—'),
      ),
    ),
    business
      ? h('p', {
          class: 'tiny muted',
          text:
            business.companyId === state.playerCompanyId
              ? `Your business "${business.name}" trades here.`
              : `Occupied by ${state.companies.find((c) => c.id === business.companyId)?.name ?? 'a competitor'}.`,
        })
      : null,
    building.renovationEndsOnDay !== null
      ? h('p', { class: 'tiny muted', text: `Renovation finishes on day ${building.renovationEndsOnDay}.` })
      : null,
    h('p', { class: 'tiny muted', text: def.description }),
    comingHere(ctx, building.district),
    actions,
  );

  host.appendChild(panel);
}


/**
 * What the city has announced for this district, on the unit's own panel.
 *
 * A player looking at a lease wants to know what the street is going to be
 * like, not only what it is like — and that is exactly the decision the notice
 * period exists to make possible.
 */
function comingHere(ctx: Ctx, districtId: Building['district']): HTMLElement | null {
  const rows = pendingIn(ctx.state, districtId);
  if (rows.length === 0) return null;
  const wrap = h('div', { class: 'coming-here' });
  for (const row of rows) {
    wrap.appendChild(
      h(
        'div',
        { class: 'coming-row' },
        h(
          'div',
          { class: 'coming-head' },
          h('strong', { text: row.def.name }),
          tag(monthsAway(row.daysAway), row.def.tone === 'good' ? 'good' : 'bad'),
        ),
        h('div', { class: 'tiny muted', text: row.def.means }),
      ),
    );
  }
  return wrap;
}

function monthsAway(days: number): string {
  if (days <= 0) return 'any day now';
  if (days < 45) return `in ${days} days`;
  return `in about ${Math.round(days / 30)} months`;
}

/**
 * The city's own plans.
 *
 * Northgate builds things too, and when it does, the district is permanently
 * different — busier or quieter, dearer or cheaper. Everything here has been
 * announced and not yet happened, which is the window in which a player can do
 * something about it: take a lease in front of a metro station, or get out of a
 * district whose largest employer has given notice.
 */
function cityPlans(ctx: Ctx): HTMLElement {
  const rows = pending(ctx.state);
  const list = h('div', { class: 'plan-list' });
  for (const row of rows) {
    list.appendChild(
      h(
        'div',
        { class: `plan-row${row.yours > 0 ? ' mine' : ''}` },
        h(
          'div',
          { class: 'plan-main' },
          h(
            'div',
            { class: 'plan-head' },
            h('strong', { text: row.def.name }),
            h('span', { class: 'tiny muted', text: row.districtName }),
            row.yours > 0
              ? tag(`${row.yours} of yours`, row.def.tone === 'good' ? 'good' : 'bad')
              : null,
          ),
          h('div', { class: 'tiny muted', text: row.def.detail }),
          h('div', { class: 'tiny', text: row.def.means }),
        ),
        h(
          'div',
          { class: 'plan-when' },
          h('strong', { text: monthsAway(row.daysAway) }),
          h('span', { class: 'tiny muted', text: row.def.tone === 'good' ? 'Rents will follow' : 'And it will not come back' }),
        ),
      ),
    );
  }

  return section(
    'What the city is about to do',
    rows.length === 0
      ? empty('Nothing has been announced. When the city commits to something — a metro line, a shopping centre, an employer leaving — it appears here months before it happens.', {
          title: 'No developments announced',
          icon: 'map',
        })
      : list,
    rows.length === 0
      ? null
      : h('p', {
          class: 'tiny muted',
          text: 'These are permanent. Once one lands the district stays changed, so a lease taken before it is a lease taken at the old rent.',
        }),
  );
}


/**
 * Northgate in four figures.
 *
 * Summed from the districts themselves rather than written anywhere, so it is
 * the city as it currently is — including everything the city has done to
 * itself since the game began.
 */
function cityHeader(ctx: Ctx): HTMLElement {
  const state = ctx.state;
  const population = DISTRICTS.reduce((total, def) => total + def.population, 0);
  const income =
    DISTRICTS.reduce((total, def) => total + def.averageIncome * def.population, 0) / Math.max(1, population);
  const trading = state.businesses.filter((b) => b.status === 'open').length;
  const mine = playerBusinesses(state).filter((b) => b.status === 'open').length;
  // Growth is the districts' own rate, weighted by how many people live in
  // each and lifted or held back by what has actually happened to demand there.
  const growth =
    DISTRICTS.reduce(
      (total, def) => total + def.growth * def.population * (state.districts[def.id]?.demandIndex ?? 1),
      0,
    ) / Math.max(1, population);

  return h(
    'div',
    { class: 'grid cols-4' },
    kpi({ label: 'People', value: count(population), icon: 'people', tone: 'accent', sub: 'living in Northgate' }),
    kpi({ label: 'Average income', value: moneyShort(income), icon: 'cash', sub: 'a household, a year' }),
    kpi({
      label: 'Businesses trading', value: count(trading), icon: 'shop',
      tone: mine > 0 ? 'good' : undefined,
      sub: mine > 0 ? `${mine} of them yours` : 'none of them yours yet',
      subTone: mine > 0 ? 'good' : undefined,
    }),
    kpi({
      label: 'Growth', value: pct(growth * 100, 1), icon: 'revenue',
      tone: growth > 0.02 ? 'good' : growth > 0 ? 'warn' : 'bad',
      sub: 'a year, across the city',
    }),
  );
}

/**
 * One district, in the three things a person wants to know about it: what it is
 * like, who is trading there, and who lives there.
 *
 * Everything on it is read from the district and from the buildings in it. The
 * tabs exist because these are three different questions and answering all of
 * them at once produces a wall nobody reads.
 */
function renderDistrictPanel(ctx: Ctx, host: HTMLElement, districtId: DistrictId): void {
  clear(host);
  const state = ctx.state;
  const def = district(districtId);
  const here = state.buildings.filter((b) => b.district === districtId);
  const moved = drift(state, districtId);

  const body = h('div', {});
  const tabs = h('div', { class: 'tab-row' });
  const panes: Record<string, () => HTMLElement> = {
    Overview: () =>
      h(
        'div',
        {},
        h(
          'div',
          { class: 'grid cols-4' },
          stat('Foot traffic', count(def.footTraffic)),
          stat('Average income', moneyShort(def.averageIncome)),
          stat('Rent', `${money(def.rentPerSqm)}/m²`),
          stat('To buy', `${money(def.pricePerSqm)}/m²`),
        ),
        h(
          'div',
          { class: 'grid cols-3', style: 'margin-top:10px' },
          stat(
            'Demand, since you started',
            `${moved.demand > 0 ? '+' : ''}${moved.demand.toFixed(0)}%`,
            moved.demand > 1 ? 'good' : moved.demand < -1 ? 'bad' : 'muted',
          ),
          stat(
            'Rent, since you started',
            `${moved.rent > 0 ? '+' : ''}${moved.rent.toFixed(0)}%`,
            moved.rent > 1 ? 'bad' : moved.rent < -1 ? 'good' : 'muted',
          ),
          stat(
            'Property, since you started',
            `${moved.property > 0 ? '+' : ''}${moved.property.toFixed(0)}%`,
            moved.property > 1 ? 'good' : moved.property < -1 ? 'bad' : 'muted',
          ),
        ),
        h('p', { class: 'tiny muted', text: def.description }),
        comingHere(ctx, districtId) ?? h('p', { class: 'tiny muted', text: 'The city has announced nothing for this district.' }),
      ),
    Businesses: () => {
      const trading = here
        .filter((b) => b.businessId !== null)
        .map((b) => state.businesses.find((x) => x.id === b.businessId))
        .filter((b): b is NonNullable<typeof b> => Boolean(b));
      if (trading.length === 0) return empty('Nothing is trading in this district yet.');
      return table(
        ['Business', 'Company', 'Type', 'Address'],
        trading.map((business) => {
          const owner = state.companies.find((c) => c.id === business.companyId);
          const where = here.find((b) => b.id === business.buildingId);
          return [
            business.companyId === state.playerCompanyId
              ? h('span', { class: 'tag good', text: business.name })
              : business.name,
            owner?.name ?? '—',
            CATEGORY_NAMES[businessTypeOrThrow(business.typeId).category] ?? '—',
            where?.address ?? '—',
          ];
        }),
      );
    },
    Demographics: () =>
      h(
        'div',
        {},
        h(
          'div',
          { class: 'grid cols-3' },
          stat('Population', count(def.population)),
          stat('Density', `${count(def.density)}/km²`),
          stat('Tourism', def.tourism > 1.3 ? 'High' : def.tourism > 0.7 ? 'Some' : 'Little'),
        ),
        meter('Under 30', def.ageMix.young, pct(def.ageMix.young * 100, 0), 'tech'),
        meter('30 to 60', def.ageMix.adult, pct(def.ageMix.adult * 100, 0)),
        meter('Over 60', def.ageMix.senior, pct(def.ageMix.senior * 100, 0), 'warn'),
        h('p', {
          class: 'tiny muted',
          text: `Incomes here are ${def.incomeSpread > 0.45 ? 'spread wide — the rich and the poor live on the same streets' : 'fairly even across the district'}.`,
        }),
      ),
  };

  let current = 'Overview';
  const draw = (): void => {
    for (const child of Array.from(tabs.children)) {
      const button = child as HTMLElement;
      button.classList.toggle('active', button.dataset.tab === current);
    }
    clear(body);
    body.appendChild(panes[current]());
  };
  for (const name of Object.keys(panes)) {
    tabs.appendChild(
      h('button', { class: 'tab', data: { tab: name }, on: { click: () => { current = name; draw(); } } }, name),
    );
  }

  const free = here.filter((b) => b.status === 'available').length;
  const rivals = here.filter((b) => b.status === 'competitor').length;
  const yours = here.filter((b) => b.occupantCompanyId === state.playerCompanyId).length;

  host.appendChild(
    section(
      def.name,
      h(
        'div',
        { class: 'pill-row' },
        tag(`${free} free`, free > 0 ? 'good' : 'muted'),
        tag(`${rivals} rivals`, rivals > 4 ? 'bad' : 'muted'),
        yours > 0 ? tag(`${yours} yours`, 'accent') : null,
      ),
      tabs,
      body,
    ),
  );
  draw();
}

/** District comparison table — the fastest way to choose where to trade. */
function districtTable(ctx: Ctx, onPick: (id: DistrictId) => void): HTMLElement {
  const state = ctx.state;
  const rows = [...state.buildings.reduce((acc, building) => {
    const entry = acc.get(building.district) ?? { available: 0, competitors: 0, mine: 0, rent: 0, count: 0 };
    entry.count += 1;
    entry.rent += building.rent;
    if (building.status === 'available') entry.available += 1;
    if (building.status === 'competitor') entry.competitors += 1;
    if (building.occupantCompanyId === state.playerCompanyId) entry.mine += 1;
    acc.set(building.district, entry);
    return acc;
  }, new Map<string, { available: number; competitors: number; mine: number; rent: number; count: number }>())];

  return section(
    'Districts',
    table(
      ['District', 'Population', 'Income', 'Foot traffic', 'Avg rent', 'Since you started', 'Free units', 'Rivals', 'Yours'],
      rows.map(([id, entry]) => {
        const def = district(id as never);
        const row = [
          def.name,
          count(def.population),
          moneyShort(def.averageIncome),
          count(def.footTraffic),
          money(entry.rent / Math.max(1, entry.count)),
          driftCell(ctx, id as never),
          String(entry.available),
          String(entry.competitors),
          entry.mine > 0 ? h('span', { class: 'tag good', text: String(entry.mine) }) : '—',
        ];
        return row;
      }),
      { onRowClick: (index) => onPick(rows[index][0] as DistrictId) },
    ),
    h('p', {
      class: 'tiny muted',
      text: 'Cheap rent usually means low foot traffic. The trick is finding the district where what you sell matches what people there can afford.',
    }),
    rows.length === 0 ? empty('No districts loaded.') : null,
  );
}

/**
 * How far a district has moved since the game began.
 *
 * Read off the district's own demand index rather than kept as a separate
 * running total, so it describes the city as it actually is.
 */
function driftCell(ctx: Ctx, districtId: Parameters<typeof drift>[1]): HTMLElement | string {
  const moved = drift(ctx.state, districtId).demand;
  if (Math.abs(moved) < 1.5) return '—';
  return tag(`${moved > 0 ? '+' : ''}${moved.toFixed(0)}% demand`, moved > 0 ? 'good' : 'bad');
}
