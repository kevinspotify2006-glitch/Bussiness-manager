import type { Ctx, View } from '../app';
import { buildingById, playerBusinesses, playerCompany } from '../../sim/state';
import { businessTypeOrThrow } from '../../data/businessTypes';
import { district } from '../../data/districts';
import {
  appointHead,
  assignToDivision,
  attentionFactor,
  createDivision,
  divisionBusinesses,
  divisionHead,
  eligibleHeads,
  groupStructure,
  ownerAttention,
  renameDivision,
  unassignedBusinesses,
} from '../../sim/holding';
import { companyTargets, makeCompanyOffer } from '../../sim/acquisitions';
import {
  GROUPED_BY_HAND,
  MERGER_STYLES,
  abandonMerger,
  activeMerger,
  mergerCandidates,
  mergerFor,
  mergerHistory,
  mergerPlan,
  mergerStyle,
  redundancyPay,
  startMerger,
} from '../../sim/mergers';
import { attentionSpan } from '../../sim/founder';
import { gradeOf, performanceOf, titleOf } from '../../sim/skills';
import { locationCap, unlockedLevel } from '../../sim/progress';
import { money, moneySigned } from '../../sim/format';
import {
  bar,
  button,
  empty,
  h,
  keepingScroll,
  modal,
  numberInput,
  section,
  select,
  stat,
  table,
  toast,
} from '../dom';

/**
 * The holding.
 *
 * The company as a structure rather than a list. It exists for one reason: past
 * about four locations the person at the top stops being able to hold them all,
 * and everything starts quietly costing more. This screen shows exactly how far
 * past that line the company is, and the only two things that move it — putting
 * somebody senior over a group, or buying a rival whole so it arrives as one.
 */
export function holdingView(ctx: Ctx): View {
  const el = h('div', { class: 'view' });

  const render = (): void => {
    el.replaceChildren();
    const state = ctx.state;
    const company = playerCompany(state);
    const attention = ownerAttention(state);
    const trading = playerBusinesses(state).filter((b) => b.status !== 'closed');

    el.appendChild(
      h(
        'div',
        { class: 'view-head' },
        h('h1', { text: company.name }),
        h('p', {
          text: `${trading.length} location${trading.length === 1 ? '' : 's'} · ${state.divisions.length} division${
            state.divisions.length === 1 ? '' : 's'
          } · ${state.employees.length} people`,
        }),
      ),
    );

    // ------------------------------------------------------- your attention
    const attentionPanel = section('What you can actually keep an eye on');
    attentionPanel.appendChild(bar(attention, attention >= 1 ? 'good' : attention > 0.75 ? 'warn' : 'bad'));
    attentionPanel.appendChild(
      h('p', {
        class: attention >= 1 ? 'sub' : 'warn',
        style: 'margin:8px 0 0',
        text:
          attention >= 1
            ? `Comfortable. You carry about ${attentionSpan(state).toFixed(
                1,
              )} locations before anything starts slipping, and you are inside that.`
            : `Stretched. You carry about ${attentionSpan(state).toFixed(
                1,
              )} locations; past that everything still happens and every location pays about ${Math.round(
                (attentionFactor(state) - 1) * 100,
              )}% more in coordination for the privilege. Putting somebody senior over a group is the only thing that fixes it.`,
      }),
    );
    const delegated = state.divisions
      .filter((division) => division.headEmployeeId !== null)
      .reduce((total, division) => total + divisionBusinesses(state, division.id).filter((b) => b.status !== 'closed').length, 0);
    attentionPanel.appendChild(
      h('div', { class: 'grid cols-3', style: 'margin-top:12px' },
        stat('Reporting to you directly', String(unassignedBusinesses(state).filter((b) => b.status !== 'closed').length)),
        stat('Run by somebody else', String(delegated), delegated > 0 ? 'good' : 'muted'),
        stat('Location ceiling', locationCap(state) === Infinity ? 'no limit' : `${trading.length} of ${locationCap(state)}`),
      ),
    );
    el.appendChild(attentionPanel);

    // ------------------------------------------------------- the structure
    const structure = section('The structure');
    const rows = groupStructure(state);
    if (rows.length === 0) {
      structure.appendChild(empty('Nothing trading yet. Open a business and it will appear here.'));
    }
    for (const row of rows) {
      const head = row.division ? divisionHead(state, row.division) : null;
      const card = h('div', { class: 'division-card' });
      card.appendChild(
        h(
          'div',
          { class: 'division-head' },
          h('span', { class: 'division-name', text: row.division ? row.division.name : 'Reports to you directly' }),
          h('span', {
            class: `division-lead ${head ? 'good' : row.division ? 'bad' : 'muted'}`,
            text: head
              ? `${head.name} · ${titleOf(head)} · covers ${gradeOf(head).span}`
              : row.division
                ? 'nobody running it'
                : `${row.businesses.length} on your own desk`,
          }),
        ),
      );
      card.appendChild(
        h('div', {
          class: 'sub',
          text: `${row.businesses.length} location${row.businesses.length === 1 ? '' : 's'} · ${row.headcount} people · ${money(
            row.revenue,
          )} revenue yesterday · ${moneySigned(row.profit)} profit`,
        }),
      );

      for (const business of row.businesses) {
        const building = buildingById(state, business.buildingId);
        const type = businessTypeOrThrow(business.typeId);
        card.appendChild(
          h(
            'div',
            { class: 'division-row' },
            h(
              'button',
              {
                class: 'division-link',
                on: { click: () => ctx.go('businesses', { business: business.id }) },
              },
              `${type.icon} ${business.name}`,
            ),
            h('span', { class: 'sub', text: building ? district(building.district).name : '—' }),
            // Moving a location between groups is a reorganisation, and it is
            // the same act whichever direction it goes in.
            select(
              [
                { value: '', label: 'Reports to you' },
                ...state.divisions.map((d) => ({ value: d.id, label: d.name })),
              ],
              business.divisionId ?? '',
              (value) => {
                const result = assignToDivision(state, business.id, value || null);
                toast(result.message, result.ok ? 'good' : 'bad');
                keepingScroll(render);
              },
            ),
          ),
        );
      }

      if (row.division) {
        const division = row.division;
        const actions = h('div', { class: 'btn-row' });
        actions.appendChild(
          button(head ? 'Change who runs it' : 'Put somebody over it', () => openHeadPicker(ctx, division.id, render), head ? 'btn small' : 'btn small primary'),
        );
        actions.appendChild(
          button('Rename', () => {
            askForName('Rename this division', division.name, (name) => {
              const result = renameDivision(state, division.id, name);
              toast(result.message, result.ok ? 'good' : 'bad');
              keepingScroll(render);
            });
          }, 'btn small'),
        );
        card.appendChild(actions);
      }
      structure.appendChild(card);
    }

    // A division can be made by hand too, not only by buying somebody.
    if (trading.length >= 2) {
      structure.appendChild(
        h(
          'div',
          { class: 'btn-row' },
          button('Start a new division', () => {
            askForName('Name the new division', 'New division', (name) => {
              const made = createDivision(state, name, GROUPED_BY_HAND);
              toast(`${made.name} created. Move locations into it from the lists above.`, 'good');
              keepingScroll(render);
            });
          }, 'btn small'),
        ),
      );
    }
    el.appendChild(structure);

    // ------------------------------------------------------------ integration
    el.appendChild(mergerPanel(ctx, render));

    // ------------------------------------------------- buying a whole company
    const targets = companyTargets(state);
    const buying = section('Rivals you could buy whole');
    buying.appendChild(
      h('p', {
        class: 'sub',
        style: 'margin:-4px 0 10px',
        text: 'Four approaches to four owners is four negotiations. Buying the company behind them is one — and it costs more, because you are paying for a going concern rather than four leases. What arrives stays together as a division.',
      }),
    );
    if (unlockedLevel(state) < 5) {
      buying.appendChild(
        empty('Buying a company whole is something a national company does. Keep growing — it opens at level 5.'),
      );
    } else if (targets.length === 0) {
      buying.appendChild(empty('Nobody out there runs more than one location right now.'));
    } else {
      buying.appendChild(
        table(
          ['Company', 'Locations', 'Parts', 'As a going concern', ''],
          targets.slice(0, 8).map((row) => [
            h('div', {}, h('div', { text: row.company.name }), h('div', { class: 'tiny muted', text: row.blocked ?? '' })),
            String(row.businesses.length),
            money(row.parts),
            money(row.fair),
            button(
              'Make an offer',
              () => openCompanyOffer(ctx, row.company.id, render),
              row.blocked ? 'btn small' : 'btn small primary',
            ),
          ]),
        ),
      );
    }
    el.appendChild(buying);
  };

  const signature = (): string => {
    const state = ctx.state;
    return [
      state.day,
      state.divisions.map((d) => `${d.id}:${d.headEmployeeId ?? ''}:${d.mergedOnDay ?? ''}`).join(','),
      playerBusinesses(state).map((b) => `${b.id}:${b.divisionId ?? ''}`).join(','),
      state.employees.length,
      state.mergers.map((m) => `${m.id}:${m.letGo}:${Math.round(m.progress * 100)}`).join(','),
    ].join('|');
  };

  render();
  let shown = signature();
  return {
    el,
    update: () => {
      const now = signature();
      if (now === shown) return;
      shown = now;
      keepingScroll(render);
    },
  };
}

/**
 * Two companies becoming one.
 *
 * Buying a company is the easy half and it is already on this screen. This is
 * the other half: what it costs to stop running two companies, what it saves
 * once you have, and every one of the four things that go wrong while it is
 * happening — the bill, the duplicated jobs, the two sides discovering they are
 * paid differently, and the fact that somebody has to carry the whole thing.
 */
function mergerPanel(ctx: Ctx, rerender: () => void): HTMLElement {
  const state = ctx.state;
  const panel = section('Becoming one company');
  panel.appendChild(
    h('p', {
      class: 'sub',
      style: 'margin:-4px 0 10px',
      text: 'A company you bought is still their company with your name on the cheque: their systems, their back office, their way of doing things. Merging is the work of making it one — expensive while it happens, and the only thing that makes a group cheaper to run than the same shops apart.',
    }),
  );

  const running = activeMerger(state);
  if (running) {
    const division = state.divisions.find((d) => d.id === running.divisionId);
    const style = mergerStyle(running.style);
    const left = Math.max(0, running.days - (state.day - running.startedOnDay));
    const card = h('div', { class: 'division-card' });
    card.appendChild(
      h(
        'div',
        { class: 'division-head' },
        h('span', { class: 'division-name', text: `${division?.name ?? 'Integration'} — ${style.name.toLowerCase()}` }),
        h('span', { class: 'division-lead warn', text: `${Math.round(running.progress * 100)}% through` }),
      ),
    );
    card.appendChild(bar(running.progress, running.progress > 0.7 ? 'good' : 'warn'));
    card.appendChild(
      h(
        'div',
        { class: 'grid cols-4', style: 'margin-top:12px' },
        stat('Days left', String(left)),
        stat('Spent so far', money(running.spent + running.severanceSpent)),
        stat('Made redundant', `${running.letGo} of ${running.duplicateIds.length}`),
        stat(
          'Culture gap',
          `${Math.round(running.cultureGap)}/100`,
          running.cultureGap > 45 ? 'bad' : running.cultureGap > 20 ? 'muted' : 'good',
        ),
      ),
    );
    card.appendChild(
      h('p', {
        class: running.cultureGap > 35 ? 'warn' : 'sub',
        style: 'margin:10px 0 0',
        text:
          running.cultureGap > 35
            ? 'Morale is down on both sides while this runs, and hardest on the side being merged in. Watch for resignations — the people you most want to keep are the ones with somewhere else to go.'
            : 'Morale is down while this runs and will come back when it is done. Nothing here is permanent except the saving.',
      }),
    );
    card.appendChild(
      h(
        'div',
        { class: 'btn-row' },
        button(
          'Call it off',
          () => {
            const result = abandonMerger(state, running.id);
            toast(result.message, result.ok ? 'info' : 'bad');
            keepingScroll(rerender);
          },
          'btn small',
        ),
      ),
    );
    panel.appendChild(card);
  }

  const candidates = mergerCandidates(state).filter((division) => !mergerFor(state, division.id));
  if (candidates.length === 0 && !running) {
    panel.appendChild(
      empty(
        'Nothing to merge with. A merger needs a division that was once somebody else’s company — buy one whole, and the decision about what to do with it appears here.',
      ),
    );
  }

  for (const division of candidates) {
    const plan = mergerPlan(state, division.id, 'blend');
    if (!plan) continue;
    const card = h('div', { class: 'division-card' });
    card.appendChild(
      h(
        'div',
        { class: 'division-head' },
        h('span', { class: 'division-name', text: division.name }),
        h('span', { class: 'division-lead muted', text: `was ${division.acquiredFrom}` }),
      ),
    );
    card.appendChild(
      h('div', {
        class: 'sub',
        text: `${plan.locations} location${plan.locations === 1 ? '' : 's'} · ${plan.headcount} people · ${
          plan.duplicates.length
        } job${plan.duplicates.length === 1 ? '' : 's'} that exist twice · culture gap ${plan.culture.gap}/100`,
      }),
    );
    for (const reason of plan.culture.reasons.slice(0, 2)) {
      card.appendChild(h('div', { class: 'tiny muted', text: `· ${reason}` }));
    }
    card.appendChild(
      h(
        'div',
        { class: 'btn-row' },
        button(
          'Look at merging it in',
          () => openMergerPlan(ctx, division.id, rerender),
          plan.blocked ? 'btn small' : 'btn small primary',
        ),
      ),
    );
    if (plan.blocked) card.appendChild(h('div', { class: 'tiny warn', text: plan.blocked }));
    panel.appendChild(card);
  }

  const done = mergerHistory(state);
  if (done.length > 0) {
    panel.appendChild(
      table(
        ['Merged in', 'How', 'Took', 'Cost', 'Off the coordination bill'],
        done.slice(0, 6).map((merger) => [
          merger.fromCompany,
          mergerStyle(merger.style).name,
          `${(merger.completedOnDay ?? 0) - merger.startedOnDay} days`,
          money(merger.spent + merger.severanceSpent),
          `−${(merger.savingLockedIn * 100).toFixed(1)}%`,
        ]),
      ),
    );
  }
  return panel;
}

/** The three ways of doing it, each with its own bill and its own casualties. */
function openMergerPlan(ctx: Ctx, divisionId: string, rerender: () => void): void {
  const state = ctx.state;
  const { body, close } = modal({ title: 'Merging two companies into one', width: 640 });

  let chosen = MERGER_STYLES[1].id;
  const detail = h('div', {});

  const paint = (): void => {
    detail.replaceChildren();
    const plan = mergerPlan(state, divisionId, chosen);
    if (!plan) {
      detail.appendChild(h('p', { text: 'That division no longer exists.' }));
      return;
    }
    detail.appendChild(h('p', { class: 'sub', text: plan.style.detail }));
    detail.appendChild(
      h(
        'div',
        { class: 'grid cols-4' },
        stat('How long', `${plan.days} days`),
        stat('To run it', money(plan.integrationCost)),
        stat('Redundancies', `${plan.cuts} of ${plan.duplicates.length}`),
        stat('Severance', money(plan.severance)),
      ),
    );
    detail.appendChild(
      h(
        'div',
        { class: 'grid cols-3', style: 'margin-top:10px' },
        stat('Wages saved', `${money(plan.wageSaving)}/mo`, plan.wageSaving > 0 ? 'good' : 'muted'),
        stat('Shared overhead', `${money(plan.overheadSaving)}/mo`, plan.overheadSaving > 0 ? 'good' : 'muted'),
        stat(
          'Pays for itself in',
          plan.payback === null ? 'never' : `${plan.payback} months`,
          plan.payback === null ? 'bad' : plan.payback <= 18 ? 'good' : 'muted',
        ),
      ),
    );

    // Who is carrying it, which is the thing that decides how long it takes.
    detail.appendChild(
      h('p', {
        class: plan.head ? 'sub' : 'warn',
        text: plan.head
          ? `${plan.head.name} runs ${plan.division.name} and will carry the integration. That is most of it off your desk, and it is why this takes ${plan.days} days rather than longer.`
          : `Nobody runs ${plan.division.name}, so this lands on you — it takes longer, and it counts against your attention like another two locations would. Put somebody senior over the division first if you can.`,
      }),
    );

    const culture = h('div', { style: 'margin-top:8px' });
    culture.appendChild(
      h('div', {
        class: plan.culture.gap > 45 ? 'bad' : plan.culture.gap > 20 ? 'warn' : 'good',
        text: `Culture gap ${plan.culture.gap}/100`,
      }),
    );
    for (const reason of plan.culture.reasons) {
      culture.appendChild(h('div', { class: 'tiny muted', text: `· ${reason}` }));
    }
    detail.appendChild(culture);

    if (plan.duplicates.length > 0) {
      detail.appendChild(
        h('p', {
          class: 'sub',
          style: 'margin-top:10px',
          text: `${plan.duplicates.length} job${plan.duplicates.length === 1 ? '' : 's'} exist twice once the two are one. Nobody is ever counted as spare if their location cannot do its trade without them — these are central functions the head office already covers, and the cover a shop stops needing when it shares systems with everywhere else.`,
        }),
      );
      detail.appendChild(
        table(
          ['Whose job exists twice', 'Where', 'Redundancy'],
          plan.duplicates.slice(0, 6).map((person) => [
            h('div', {}, h('div', { text: person.name }), h('div', { class: 'tiny muted', text: titleOf(person) })),
            state.businesses.find((b) => b.id === person.businessId)?.name ?? '—',
            money(redundancyPay(state, person)),
          ]),
        ),
      );
    } else {
      detail.appendChild(
        h('p', {
          class: 'sub',
          style: 'margin-top:10px',
          text: 'Nobody is spare. What you bought was already lean, so this merger is about overhead and coherence rather than headcount — which also means it is a far easier one to live through.',
        }),
      );
    }

    if (plan.blocked) {
      detail.appendChild(h('p', { class: 'bad', text: plan.blocked }));
      return;
    }
    detail.appendChild(
      h(
        'div',
        { class: 'btn-row' },
        button(
          `Start the integration — ${plan.style.name.toLowerCase()}`,
          () => {
            const result = startMerger(state, divisionId, chosen);
            toast(result.message, result.ok ? 'good' : 'bad');
            if (result.ok) close();
            rerender();
          },
          'btn primary',
        ),
        button('Not yet', () => close()),
      ),
    );
  };

  const choices = h('div', { class: 'btn-row' });
  for (const style of MERGER_STYLES) {
    choices.appendChild(
      button(
        style.name,
        () => {
          chosen = style.id;
          for (const child of Array.from(choices.children)) child.classList.remove('primary');
          const index = MERGER_STYLES.findIndex((s) => s.id === style.id);
          choices.children[index]?.classList.add('primary');
          paint();
        },
        `btn small${style.id === chosen ? ' primary' : ''}`,
      ),
    );
  }
  body.appendChild(h('p', { class: 'sub', text: 'Three ways to do it, and the difference between them is how much of it the people go through.' }));
  body.appendChild(choices);
  body.appendChild(detail);
  paint();
}

/** A one-field dialog, in the game's own furniture rather than the browser's. */
function askForName(title: string, current: string, done: (name: string) => void): void {
  const { body, close } = modal({ title, width: 420 });
  const input = h('input', { type: 'text', value: current, maxlength: 40 });
  body.appendChild(h('label', { class: 'field' }, h('span', { text: 'Name' }), input));
  body.appendChild(
    h(
      'div',
      { class: 'btn-row' },
      button(
        'Save',
        () => {
          const name = input.value.trim();
          if (!name) {
            toast('A division needs a name.', 'bad');
            return;
          }
          close();
          done(name);
        },
        'btn primary',
      ),
      button('Cancel', () => close()),
    ),
  );
  input.focus();
  input.select();
}

/** Who could take this on — and why most people cannot. */
function openHeadPicker(ctx: Ctx, divisionId: string, rerender: () => void): void {
  const state = ctx.state;
  const { body, close } = modal({ title: 'Who runs this division', width: 560 });
  const candidates = eligibleHeads(state);

  if (candidates.length === 0) {
    body.appendChild(
      h('p', {
        text: 'Nobody in the company is senior enough. Running a division takes a Senior Manager at least, and the only way there is leadership — a brilliant cook with no leadership will never reach it, however good the cooking gets. Send somebody on a leadership course.',
      }),
    );
    const near = state.employees
      .filter((person) => person.companyId === state.playerCompanyId && gradeOf(person).n >= 3)
      .sort((a, b) => b.skills.leadership - a.skills.leadership)
      .slice(0, 3);
    if (near.length > 0) {
      body.appendChild(h('p', { class: 'sub', text: 'Closest to it:' }));
      for (const person of near) {
        body.appendChild(
          h(
            'div',
            { class: 'stat' },
            h('span', { class: 'stat-label', text: `${person.name} — ${titleOf(person)}` }),
            h('span', { class: 'stat-value muted', text: `leadership ${Math.round(person.skills.leadership)}` }),
          ),
        );
      }
    }
    body.appendChild(h('div', { class: 'btn-row' }, button('Go to the people', () => { close(); ctx.go('employees'); }, 'btn primary')));
    return;
  }

  for (const person of candidates) {
    body.appendChild(
      h(
        'div',
        { class: 'staff-row' },
        h(
          'div',
          { style: 'flex:1;min-width:0' },
          h('div', { class: 'staff-name', text: person.name }),
          h('div', {
            class: 'sub',
            text: `${titleOf(person)} · covers ${gradeOf(person).span} · performance ${Math.round(performanceOf(person))}`,
          }),
        ),
        button(
          'Hand it to them',
          () => {
            const result = appointHead(state, divisionId, person.id);
            toast(result.message, result.ok ? 'good' : 'bad');
            close();
            rerender();
          },
          'btn small primary',
        ),
      ),
    );
  }
  body.appendChild(
    h(
      'div',
      { class: 'btn-row' },
      button('Take it back on your own desk', () => {
        const result = appointHead(state, divisionId, null);
        toast(result.message, result.ok ? 'good' : 'bad');
        close();
        rerender();
      }),
    ),
  );
}

/** The negotiation, which is the same one as for a single shop, at scale. */
function openCompanyOffer(ctx: Ctx, companyId: string, rerender: () => void): void {
  const state = ctx.state;
  const { body, close } = modal({ title: 'Offer for a whole company', width: 560 });
  const targets = companyTargets(state);
  const row = targets.find((entry) => entry.company.id === companyId);
  if (!row) {
    body.appendChild(h('p', { text: 'That company is no longer available.' }));
    return;
  }

  body.appendChild(
    h(
      'div',
      {},
      stat('Company', row.company.name),
      stat('Locations', String(row.businesses.length)),
      stat('Sum of the parts', money(row.parts)),
      stat('As a going concern', money(row.fair)),
      stat('Your cash', money(playerCompany(state).cash)),
    ),
  );
  body.appendChild(
    h('p', {
      class: 'sub',
      text: 'They will not say what they would accept. Offer too little and they stop talking for three weeks; an owner losing money will take less than one who is not.',
    }),
  );
  if (row.blocked) {
    body.appendChild(h('p', { class: 'bad', text: row.blocked }));
    return;
  }

  let amount = row.fair;
  body.appendChild(
    h('label', { class: 'field' }, h('span', { text: 'Your offer' }), numberInput(amount, (value) => { amount = value; }, { min: "0" })),
  );
  body.appendChild(
    h(
      'div',
      { class: 'btn-row' },
      button(
        'Make the offer',
        () => {
          const result = makeCompanyOffer(state, companyId, amount);
          toast(result.message, result.accepted ? 'good' : result.ok ? 'info' : 'bad');
          close();
          if (result.accepted) ctx.refresh();
          else rerender();
        },
        'btn primary',
      ),
    ),
  );
}
