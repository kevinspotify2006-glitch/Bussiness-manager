import type { Ctx, View } from '../app';
import { playerBusinesses, playerCompany } from '../../sim/state';
import { debtTotal, inventoryValue, netWorth, propertyValue } from '../../sim/finance';
import { currentTier } from '../../sim/achievements';
import { economyLabel } from '../../sim/economy';
import { distinctAlerts } from '../../sim/alerts';
import { cityEvent } from '../../data/events';
import { businessType } from '../../data/businessTypes';
import { groupShare, marketShare } from '../../sim/demand';
import { calendar, clockLabel, count, money, moneySigned, moneyShort, pct } from '../../sim/format';
import { sum } from '../../sim/util';
import { bar, button, empty, h, kpi, section, severityTile, stat, statWithHint, table } from '../dom';
import { NEWS_ICONS, recentNews } from '../../sim/news';
import type { Advice } from '../../sim/advice';
import { topOpportunities, topProblems } from '../../sim/advice';
import { forecast } from '../../sim/cashflow';
import { groupStructure, ownerAttention } from '../../sim/holding';
import { staffingSummary } from '../../sim/staffing';
import { performanceOf } from '../../sim/skills';
import { goalProgress, readMetric } from '../../sim/goals';
import { showDecision } from '../decisionModal';
import { SERIES_COLORS, chartLegend, multiChart } from '../chart';
import { levelOf, levelProgress, nextLevel, nextStep } from '../../sim/progress';
import { standingRows } from '../../sim/standing';

/** People on the payroll, used in the cash card's fallback line. */
function staffCount(state: Ctx['state']): number {
  return state.employees.length;
}

export function dashboardView(ctx: Ctx): View {
  const el = h('div', { class: 'view' });
  const state = ctx.state;
  const company = playerCompany(state);
  const businesses = playerBusinesses(state);
  const open = businesses.filter((b) => b.status === 'open');
  const cal = calendar(state.day);

  const todayRevenue = sum(businesses, (b) => b.today.revenue);
  const todayCosts = sum(
    businesses,
    (b) => b.today.cogs + b.today.wages + b.today.rent + b.today.marketing + b.today.otherCosts,
  );
  const last30 = state.dayHistory.slice(-30);
  const monthRevenue = sum(last30, (d) => d.revenue);
  const monthProfit = sum(last30, (d) => d.profit);
  const worth = netWorth(state);
  const tier = currentTier(state);
  const economy = economyLabel(state);

  // ------------------------------------------------------------- the four
  // The first thing on the screen, and the only four figures that belong in
  // that position: what you have, what you take, what you keep, and who you
  // pay. Every trend beside them is measured against the same window a month
  // earlier — no figure here is decorative and none of it is invented.
  const prev30 = state.dayHistory.slice(-60, -30);
  const prevRevenue = sum(prev30, (d) => d.revenue);
  const prevProfit = sum(prev30, (d) => d.profit);
  const cashAMonthAgo = state.dayHistory.length >= 30 ? state.dayHistory[state.dayHistory.length - 30].cash : null;
  const hiredRecently = state.employees.filter((e) => e.hiredOnDay > state.day - 30).length;
  const change = (now: number, before: number): string => {
    if (before === 0) return 'no month to compare with yet';
    const move = ((now - before) / Math.abs(before)) * 100;
    // The sign is the point, so it is always written, including the plus.
    return `${move >= 0 ? '+' : ''}${pct(move, 1)} on last month`;
  };

  el.appendChild(
    h(
      'div',
      { class: 'grid cols-4' },
      kpi({
        label: 'Total cash', value: money(company.cash), icon: 'cash',
        tone: company.cash < 0 ? 'bad' : 'accent',
        valueTone: company.cash < 0 ? 'bad' : undefined,
        sub: cashAMonthAgo === null ? `${open.length} trading · ${staffCount(state)} on the payroll` : change(company.cash, cashAMonthAgo),
        subTone: cashAMonthAgo === null ? undefined : company.cash >= cashAMonthAgo ? 'good' : 'bad',
      }),
      kpi({
        label: 'Revenue, 30 days', value: moneyShort(monthRevenue), icon: 'revenue', tone: 'info',
        sub: prevRevenue === 0 ? 'first month of trading' : change(monthRevenue, prevRevenue),
        subTone: prevRevenue === 0 ? undefined : monthRevenue >= prevRevenue ? 'good' : 'bad',
      }),
      kpi({
        label: 'Profit, 30 days', value: moneySigned(monthProfit), icon: 'profit',
        tone: monthProfit >= 0 ? 'tech' : 'bad',
        valueTone: monthProfit >= 0 ? 'good' : 'bad',
        sub: prevProfit === 0 ? 'first month of trading' : change(monthProfit, prevProfit),
        subTone: prevProfit === 0 ? undefined : monthProfit >= prevProfit ? 'good' : 'bad',
      }),
      kpi({
        label: 'Employees', value: String(state.employees.length), icon: 'people', tone: 'warn',
        sub: hiredRecently > 0 ? `${hiredRecently} joined this month` : 'nobody new this month',
        subTone: hiredRecently > 0 ? 'good' : undefined,
      }),
    ),
  );

  el.appendChild(
    h('p', {
      class: 'tiny muted',
      style: 'margin:-6px 0 0',
      text: `${company.name} · ${cal.label} · ${clockLabel(state.hour)} · economy: ${economy.label}`,
    }),
  );

  // The single most important thing to do right now. It is read from the
  // company in order of urgency — survive, then trade, then grow — so it is
  // never a generic prompt and the bar moves while the player works.
  const step = nextStep(state);
  const level = levelOf(state);
  const ahead = nextLevel(state);
  el.appendChild(
    h(
      'section',
      { class: 'panel next-step' },
      h('div', { class: 'next-step-label', text: 'YOUR NEXT STEP' }),
      h('h2', { class: 'next-step-title', text: step.title }),
      h('p', { class: 'next-step-why', text: step.why }),
      bar(step.progress, step.progress > 0.66 ? 'good' : ''),
      h(
        'div',
        { class: 'next-step-foot' },
        h('span', {
          class: 'next-step-reward',
          text: ahead
            ? `Reward: ${step.reward} · Level ${level.n} ${level.name}, ${Math.round(levelProgress(state) * 100)}% towards ${ahead.name}`
            : `Reward: ${step.reward} · Level ${level.n} ${level.name}`,
        }),
        button('Take me there', () => ctx.go(step.view), 'btn primary'),
        button('The ladder', () => ctx.go('progress')),
      ),
    ),
  );

  if (state.stats.bankrupt) {
    el.appendChild(
      h(
        'section',
        { class: 'panel', style: 'border-color:var(--bad)' },
        h('h3', { class: 'panel-title bad', text: 'Bankrupt' }),
        h('p', {
          text: 'Your debts are larger than everything the company owns. Sell property and stock to raise cash, or start again from Settings.',
        }),
      ),
    );
  }

  // ---------------------------------------------------------- decisions
  for (const decision of state.decisions) {
    el.appendChild(
      h(
        'section',
        { class: 'panel decision-panel' },
        h(
          'div',
          { class: 'decision-card' },
          h(
            'div',
            { style: 'flex:1;min-width:0' },
            h('div', { class: 'panel-title accent-text', text: 'Decision needed' }),
            h('div', { class: 'card-title', text: decision.title }),
            h('div', { class: 'card-sub', text: decision.body }),
          ),
          button('Decide', () => showDecision(ctx, decision), 'btn primary'),
        ),
      ),
    );
  }

  // --------------------------------------------------- what needs you today
  // The same advisor as before, split in two: what is wrong goes to the top of
  // the screen where it cannot be missed, and what is merely worth doing goes
  // down the side. A dashboard that gives both the same weight is telling the
  // player nothing about which to read first.
  const problems = topProblems(state, 3);
  const chances = topOpportunities(state, 4);

  const adviceRow = (item: Advice, star: boolean): HTMLElement =>
    h(
      'button',
      {
        class: `advice-row ${item.severity} clickable-row`,
        on: { click: () => ctx.go(item.route, item.params) },
      },
      star
        ? h('span', { class: 'advice-star', text: '\u2605' })
        : severityTile(item.severity),
      h(
        'div',
        { style: 'flex:1;min-width:0;text-align:left' },
        h('div', { class: 'advice-headline', text: item.headline }),
        h('div', { class: 'advice-detail', text: item.detail }),
        h('div', { class: 'advice-action', text: `\u2192 ${item.action}` }),
      ),
      h('span', { class: 'row-chevron', text: '\u203a' }),
    );

  if (problems.length > 0) {
    const panel = section('Needs you today');
    panel.classList.add('urgent');
    for (const item of problems) panel.appendChild(adviceRow(item, false));
    el.appendChild(panel);
  }

  // ------------------------------------------------- the four things at once
  // Four blocks rather than twelve equal tiles: the money, the shops, the
  // people and the market, each answering the question a manager asks about it.
  const staff = state.employees.filter((e) => e.companyId === state.playerCompanyId);
  const cash = forecast(state, 14);
  const shortage = sum(open, (b) => staffingSummary(state, b).shortage);
  const lastWeek = sum(state.dayHistory.slice(-7), (d) => d.revenue);
  const weekBefore = sum(state.dayHistory.slice(-14, -7), (d) => d.revenue);
  const growth = weekBefore > 0 ? (lastWeek - weekBefore) / weekBefore : 0;
  const rivals = state.businesses.filter((b) => b.companyId !== state.playerCompanyId && b.status === 'open').length;
  const attention = ownerAttention(state);
  const reputation = open.length > 0 ? sum(open, (b) => b.reputation) / open.length : 0;
  const morale = staff.length > 0 ? sum(staff, (e) => e.morale) / staff.length : 0;
  const workload = staff.length > 0 ? sum(staff, (e) => e.workload) / staff.length : 0;
  const performance = staff.length > 0 ? sum(staff, (e) => performanceOf(e)) / staff.length : 0;

  el.appendChild(
    h(
      'div',
      { class: 'grid cols-4' },
      block('Financial', [
        ['Cash', money(company.cash), company.cash < 0 ? 'bad' : undefined],
        ['Today', moneySigned(todayRevenue - todayCosts), todayRevenue - todayCosts >= 0 ? 'good' : 'bad'],
        ['Profit, 30 days', moneySigned(monthProfit), monthProfit >= 0 ? 'good' : 'bad'],
        [
          'Cashflow, 14 days',
          moneySigned(cash.balances[cash.balances.length - 1] - company.cash),
          cash.emptyOnDay !== null ? 'bad' : undefined,
        ],
      ]),
      block('Business', [
        ['Locations trading', String(open.length), undefined],
        ['Revenue, 30 days', moneyShort(monthRevenue), undefined],
        ['Week on week', state.dayHistory.length >= 14 ? pct(growth * 100, 1) : '\u2014', growth >= 0 ? 'good' : 'bad'],
        ['Your attention', attention.toFixed(2), attention < 0.8 ? 'bad' : attention < 1 ? 'warn' : undefined],
      ]),
      block('People', [
        ['On the payroll', String(staff.length), undefined],
        [
          'Average performance',
          staff.length ? `${Math.round(performance)}/100` : '\u2014',
          performance < 45 && staff.length > 0 ? 'bad' : undefined,
        ],
        [
          'Morale \u00b7 workload',
          staff.length ? `${Math.round(morale)} \u00b7 ${Math.round(workload)}` : '\u2014',
          staff.length > 0 && (morale < 45 || workload > 80) ? 'bad' : undefined,
        ],
        [
          'Short of the plan',
          shortage > 0 ? `${shortage} ${shortage === 1 ? 'person' : 'people'}` : 'nobody',
          shortage > 0 ? 'bad' : 'good',
        ],
      ]),
      block('Market', [
        ['Share of your markets', open.length ? pct(groupShare(state) * 100, 1) : '\u2014', undefined],
        [
          'Reputation',
          open.length ? `${Math.round(reputation)}/100` : '\u2014',
          reputation < 40 && open.length > 0 ? 'bad' : undefined,
        ],
        ['Rival outlets', String(rivals), undefined],
        [
          'Consumer confidence',
          String(Math.round(state.economy.confidence)),
          state.economy.confidence < 92 ? 'bad' : state.economy.confidence > 108 ? 'good' : undefined,
        ],
      ]),
    ),
  );

  // ---------------------------------------------------------- main grid
  // What the company is known for, and what each part of it is buying. Placed
  // where the player will see it next to the trading figures, because the point
  // of splitting reputation into five was that they are not the same thing.
  const standingPanel = section('What you are known for');
  standingPanel.appendChild(
    h('p', {
      class: 'sub',
      style: 'margin:-4px 0 10px',
      text: 'Each of these is earned separately and each buys you something different. They move slowly, which is why a bad month still costs you two months later.',
    }),
  );
  for (const row of standingRows(state)) {
    standingPanel.appendChild(
      h(
        'div',
        { class: 'meter' },
        h('span', { class: `meter-dot ${row.tone}` }),
        h('span', { class: 'meter-name', text: row.name }),
        h('div', { class: 'meter-bar' }, bar(row.value / 100, row.tone)),
        h('span', { class: 'meter-value', text: String(Math.round(row.value)) }),
      ),
    );
    standingPanel.appendChild(h('div', { class: 'tiny muted', style: 'margin:-4px 0 6px 20px', text: row.drives }));
  }

  // The argument down the left, the asides down the right — not two equal
  // columns, because the chart and the locations table need the room and the
  // alerts beside them do not.
  const left = h('div', { class: 'list' });
  const right = h('div', { class: 'list' });

  // Revenue, costs and profit on one pair of axes, because the gap between the
  // first two is the third and seeing all three at once is the whole point.
  const window = state.dayHistory.slice(-45);
  const trading = [
    { label: 'Revenue', values: window.map((d) => d.revenue), color: SERIES_COLORS.info, fill: true },
    { label: 'Costs', values: window.map((d) => d.costs), color: SERIES_COLORS.bad },
    { label: 'Profit', values: window.map((d) => d.profit), color: SERIES_COLORS.good },
  ];
  const chartPanel = section('Revenue and profit');
  chartPanel.appendChild(chartLegend(trading));
  chartPanel.appendChild(multiChart(trading, { height: 190 }));
  chartPanel.appendChild(
    h('p', {
      class: 'tiny muted',
      text:
        state.dayHistory.length === 0
          ? 'Nothing has been settled yet. Press play and let a day run.'
          : `Last ${Math.min(45, state.dayHistory.length)} days. Best day ${money(Math.max(...state.dayHistory.map((d) => d.profit)))}, worst ${money(Math.min(...state.dayHistory.map((d) => d.profit)))}.`,
    }),
  );
  left.appendChild(chartPanel);

  if (open.length > 0) {
    // Grouped the way the company is actually run, because by the time there
    // are seven locations a flat list has stopped being how anybody thinks
    // about them. With no divisions this is one heading and the same table.
    const panel = section('Your locations');
    const groups = groupStructure(state).filter((row) => row.businesses.some((b) => b.status === 'open'));
    for (const group of groups) {
      const inGroup = group.businesses.filter((b) => b.status === 'open');
      if (groups.length > 1 || group.division) {
        panel.appendChild(
          h('div', {
            class: 'group-heading',
            text: group.division
              ? `${group.division.name.toUpperCase()} \u2014 ${inGroup.length} location${inGroup.length === 1 ? '' : 's'} \u00b7 ${
                  group.head ? `${group.head.name} runs it` : 'nobody running it'
                }`
              : `REPORTS TO YOU \u2014 ${inGroup.length} location${inGroup.length === 1 ? '' : 's'}`,
          }),
        );
      }
      panel.appendChild(
        table(
          ['Business', 'District', 'Customers', 'Revenue', 'Profit', 'Share'],
          inGroup.map((business) => {
            const type = businessType(business.typeId);
            const building = state.buildings.find((b) => b.id === business.buildingId);
            const profit = business.yesterday.revenue
              ? business.yesterday.revenue -
                (business.yesterday.cogs +
                  business.yesterday.wages +
                  business.yesterday.rent +
                  business.yesterday.marketing +
                  business.yesterday.otherCosts)
              : 0;
            return [
              h('button', {
                class: 'division-link',
                text: `${type?.icon ?? ''} ${business.name}`,
                on: { click: () => ctx.go('businesses', { business: business.id }) },
              }),
              building?.address ?? '\u2014',
              count(business.today.customers),
              money(business.today.revenue),
              h('span', {
                class: profit >= 0 ? 'good' : 'bad',
                text: state.dayHistory.length ? moneySigned(profit) : '\u2014',
              }),
              pct(marketShare(state, business.id) * 100),
            ];
          }),
        ),
      );
    }
    panel.appendChild(
      h('p', {
        class: 'tiny muted',
        text: 'Customers and revenue are today so far; profit is yesterday\u2019s settled figure.',
      }),
    );
    left.appendChild(panel);
  } else {
    left.appendChild(
      section(
        'Your businesses',
        empty('You are not trading yet. Open the map, find a unit you can afford, and create your first business.'),
        h(
          'div',
          { class: 'btn-row' },
          h('button', { class: 'btn primary', on: { click: () => ctx.go('map') } }, 'Open the map'),
        ),
      ),
    );
  }

  // ------------------------------------------------------------- sidebar
  if (chances.length > 0) {
    const panel = section('Worth doing');
    for (const item of chances) panel.appendChild(adviceRow(item, true));
    right.appendChild(panel);
  }

  const alerts = distinctAlerts(state).slice(0, 7);
  const alertPanel = section('Alerts');
  if (alerts.length === 0) alertPanel.appendChild(empty('Nothing needs your attention.'));
  for (const alert of alerts) {
    // Every alert is a shortcut to the screen where it can be acted on.
    const target = alert.businessId
      ? () => ctx.go('businesses', { business: alert.businessId as string })
      : () => ctx.go('reports');
    alertPanel.appendChild(
      h(
        'button',
        { class: 'alert-row clickable-row', on: { click: target } },
        h('span', { class: `alert-dot ${alert.priority}` }),
        h(
          'div',
          { style: 'flex:1;min-width:0;text-align:left' },
          h('div', { class: 'alert-title', text: alert.title }),
          h('div', { class: 'alert-detail', text: alert.detail }),
        ),
        h('span', { class: 'row-chevron', text: '›' }),
      ),
    );
  }
  right.appendChild(alertPanel);

  // ------------------------------------------------------------ headlines
  const feed = recentNews(state, 5);
  const newsPanel = section('Latest news');
  if (feed.length === 0) {
    newsPanel.appendChild(empty('The city has not reported anything yet.'));
  }
  for (const item of feed) {
    newsPanel.appendChild(
      h(
        'div',
        { class: 'news-mini' },
        h('span', { class: 'news-icon', text: NEWS_ICONS[item.category] }),
        h(
          'div',
          { style: 'flex:1;min-width:0' },
          h('div', { class: 'alert-title', text: item.headline }),
          h('div', { class: 'alert-detail', text: item.body }),
        ),
      ),
    );
  }
  newsPanel.appendChild(
    h('div', { class: 'btn-row', style: 'margin-top:8px' }, button('Open the newsroom', () => ctx.go('news'), 'btn small ghost')),
  );
  right.appendChild(newsPanel);

  right.appendChild(
    section(
      'Balance sheet',
      stat('Cash', money(company.cash), company.cash < 0 ? 'bad' : undefined),
      stat('Stock', money(inventoryValue(state))),
      stat('Property', money(propertyValue(state))),
      stat('Debt', money(-debtTotal(state)), debtTotal(state) > 0 ? 'bad' : 'muted'),
      stat('Net worth', money(worth), worth >= 0 ? 'good' : 'bad'),
      statWithHint(
        'Credit rating',
        `${Math.round(company.creditRating)}/100`,
        'What lenders think of you. Built from profitability, debt and whether you have missed payments. It decides which loans you are offered and at what rate.',
      ),
    ),
  );

  // -------------------------------------------------------------- goals
  const goalPanel = section('Goals');
  if (state.goals.length === 0) {
    goalPanel.appendChild(
      empty(
        playerBusinesses(state).some((b) => b.status === 'open')
          ? 'Nothing on the board right now. A new goal will come along within a few days.'
          : 'Open a business and the city will start setting you targets.',
      ),
    );
  }
  for (const goal of state.goals) {
    const progress = goalProgress(state, goal);
    const now = readMetric(state, goal.metric, goal.businessId);
    const daysLeft = goal.expiresOnDay - state.day;
    goalPanel.appendChild(
      h(
        'div',
        { class: 'goal-row' },
        h(
          'div',
          { class: 'goal-head' },
          h('span', { class: 'goal-title', text: goal.title }),
          h('span', {
            class: `tag ${daysLeft <= 3 ? 'bad' : daysLeft <= 7 ? 'warn' : ''}`,
            text: `${Math.max(0, daysLeft)}d left`,
          }),
        ),
        bar(progress, progress > 0.66 ? 'good' : progress < 0.2 ? 'bad' : 'warn'),
        h('div', {
          class: 'goal-meta',
          text: `${goalNumber(goal.metric, now)} of ${goalNumber(goal.metric, goal.target)} · ${goal.rewardText}`,
        }),
      ),
    );
  }
  right.appendChild(goalPanel);

  right.appendChild(
    section(
      'Progression',
      stat('Tier', tier.name),
      tier.next ? stat('Next', tier.next, 'muted') : stat('Next', 'Top tier reached', 'good'),
      bar(tier.progress, 'good'),
      h('p', { class: 'tiny muted', text: `${state.achievements.length} achievements unlocked · ${state.goalsCompleted} goal${state.goalsCompleted === 1 ? '' : 's'} met.` }),
    ),
  );

  const economyPanel = section(
    'City economy',
    statWithHint(
      'Consumer confidence',
      `${Math.round(state.economy.confidence)}`,
      'How freely the city is spending. 100 is normal. Below that people buy less and trade down to cheaper options.',
      economy.tone === 'good' ? 'good' : economy.tone === 'bad' ? 'bad' : undefined,
    ),
    statWithHint(
      'Interest rate',
      pct(state.economy.interestRate * 100, 2),
      'The base rate. Loan offers are priced off it, so borrowing gets dearer as it rises.',
    ),
    statWithHint(
      'Unemployment',
      pct(state.economy.unemployment * 100, 1),
      'When it is low, staff are scarce and wages rise. When it is high, applicants are cheaper but the city has less money to spend.',
    ),
    statWithHint(
      'Price level',
      `${((state.economy.inflation - 1) * 100).toFixed(1)}% above day 1`,
      'Cumulative inflation. Wages, rent and wholesale prices all follow it, so a price you set months ago is quietly getting cheaper.',
    ),
  );
  if (state.events.length > 0) {
    for (const active of state.events) {
      const def = cityEvent(active.defId);
      if (!def) continue;
      economyPanel.appendChild(
        h(
          'div',
          { style: 'margin-top:8px' },
          h('span', { class: `tag ${def.demand < 1 ? 'bad' : 'good'}`, text: def.name }),
          h('div', { class: 'tiny muted', text: `${def.description} ${active.daysLeft} days left.` }),
        ),
      );
    }
  }
  right.appendChild(economyPanel);

  right.appendChild(standingPanel);
  el.appendChild(h('div', { class: 'grid split' }, left, right));
  return { el };
}

/**
 * One of the four things a manager watches, with the four figures that answer
 * it. Grouping them is the point: cash next to cashflow says something that
 * cash alone does not, and a wall of equal tiles says nothing at all.
 */
type BlockRow = [label: string, value: string, tone: 'good' | 'bad' | 'warn' | undefined];

function block(name: string, rows: BlockRow[]): HTMLElement {
  const el = h('div', { class: 'kpi-block' }, h('div', { class: 'kpi-label', text: name }));
  for (const [label, value, tone] of rows) {
    el.appendChild(
      h(
        'div',
        { class: 'kpi-row' },
        h('span', { class: 'kpi-row-label', text: label }),
        h('span', { class: `kpi-row-value${tone ? ` ${tone}` : ''}`, text: value }),
      ),
    );
  }
  return el;
}

/** Goal figures read differently depending on what is being measured. */
function goalNumber(metric: string, value: number): string {
  if (metric === 'reviewScore') return `${value.toFixed(1)}★`;
  if (metric === 'marketShare') return `${value.toFixed(1)}%`;
  if (metric === 'cash' || metric === 'weeklyProfit' || metric === 'netWorth') return money(value);
  if (metric === 'staffMorale' || metric === 'awareness' || metric === 'reputation') return `${Math.round(value)}/100`;
  return count(value);
}
