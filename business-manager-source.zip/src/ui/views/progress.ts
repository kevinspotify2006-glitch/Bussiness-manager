import type { Ctx, View } from '../app';
import {
  LEVELS,
  bindingMeasure,
  levelOf,
  levelProgress,
  locationCap,
  measures,
  nextLevel,
  nextStep,
  unlockedLevel,
} from '../../sim/progress';
import { ACHIEVEMENTS } from '../../sim/achievements';
import { goalProgress } from '../../sim/goals';
import { money, moneySigned } from '../../sim/format';
import { bar, empty, h, keepingScroll, section, stat, table } from '../dom';
import { chronicleByMonth, recordRows, summary } from '../../sim/chronicle';

/**
 * The ladder.
 *
 * One screen that answers "how big am I, what is next, and what will it get
 * me" — the requirements the company is measured against, how far along each
 * one is, and what every level above opens up. Nothing on it is decorative:
 * every figure is read live from the company.
 */
export function progressView(ctx: Ctx): View {
  const el = h('div', { class: 'view' });

  const render = (): void => {
    el.replaceChildren();
    const state = ctx.state;
    const level = levelOf(state);
    const next = nextLevel(state);
    const step = nextStep(state);

    // ------------------------------------------------------ your next step
    const stepPanel = h(
      'section',
      { class: 'panel next-step' },
      h('div', { class: 'next-step-label', text: 'YOUR NEXT STEP' }),
      h('h2', { class: 'next-step-title', text: step.title }),
      h('p', { class: 'next-step-why', text: step.why }),
      bar(step.progress, step.progress > 0.66 ? 'good' : ''),
      h(
        'div',
        { class: 'next-step-foot' },
        h('span', { class: 'next-step-reward', text: `Reward: ${step.reward}` }),
        h(
          'button',
          { class: 'btn primary', on: { click: () => ctx.go(step.view) } },
          'Take me there',
        ),
      ),
    );
    el.appendChild(stepPanel);

    // ------------------------------------------------------------- level
    const cap = locationCap(state);
    const everReached = unlockedLevel(state);
    const levelPanel = section(
      `Level ${level.n} — ${level.name}`,
      h('p', { class: 'muted', text: level.blurb }),
      next
        ? h(
            'div',
            {},
            h('div', { class: 'sub', text: `Towards ${next.name}` }),
            bar(levelProgress(state)),
            h(
              'div',
              { class: 'grid cols-2' },
              ...measures(state, next).map((row) =>
                h(
                  'div',
                  { class: 'measure' },
                  stat(row.label, `${row.format(row.now)} of ${row.format(row.need)}`, row.now >= row.need ? 'good' : undefined),
                  bar(row.progress, row.now >= row.need ? 'good' : ''),
                ),
              ),
            ),
          )
        : h('p', { class: 'good', text: 'Top of the ladder. There is nothing above this.' }),
      h('div', { class: 'sub', text: 'What this level lets you do' }),
      h('ul', { class: 'unlock-list' }, ...level.unlocks.map((text) => h('li', { text }))),
      stat('Locations you may run', cap === Infinity ? 'No limit' : String(cap)),
      everReached > level.n
        ? h('p', {
            class: 'sub',
            text: `You have been a ${LEVELS[everReached - 1].name.toLowerCase()}, and nothing you unlocked has been taken away — but on today's figures the company is back at ${level.name.toLowerCase()}.`,
          })
        : null,
    );
    el.appendChild(levelPanel);

    const binding = bindingMeasure(state);
    if (binding && next) {
      el.appendChild(
        section(
          'What is holding you back',
          h('p', {
            text: `${binding.label}: ${binding.format(binding.now)}. A ${next.name.toLowerCase()} needs ${binding.format(binding.need)}.`,
          }),
          bar(binding.progress),
        ),
      );
    }

    // ------------------------------------------------------------ the ladder
    const ladder = h('div', { class: 'ladder' });
    for (const def of LEVELS) {
      const reached = def.n <= level.n;
      ladder.appendChild(
        h(
          'div',
          { class: `ladder-row${reached ? ' reached' : ''}${def.n === level.n ? ' current' : ''}` },
          h('div', { class: 'ladder-n', text: String(def.n) }),
          h(
            'div',
            {},
            h('div', { class: 'ladder-name', text: def.name }),
            h('div', { class: 'sub', text: def.unlocks.join(' · ') }),
            def.n > level.n
              ? h('div', {
                  class: 'sub muted',
                  text: `Needs ${money(def.requires.netWorth)}, ${def.requires.locations} locations, ${def.requires.headcount} staff, ${money(def.requires.monthlyProfit)} a month`,
                })
              : null,
          ),
        ),
      );
    }
    el.appendChild(section('The ladder', ladder));

    // ------------------------------------------------------------- goals
    const goals = state.goals;
    el.appendChild(
      section(
        'Current objectives',
        goals.length === 0
          ? empty('Nothing on the board. New objectives appear as the company changes.')
          : h(
              'div',
              {},
              ...goals.map((goal) =>
                h(
                  'div',
                  { class: 'measure' },
                  stat(goal.title, goal.rewardText),
                  h('div', { class: 'sub', text: goal.detail }),
                  bar(goalProgress(state, goal)),
                ),
              ),
            ),
      ),
    );

    // -------------------------------------------------------- achievements
    const earned = new Set(state.achievements.map((a) => a.id));
    el.appendChild(
      section(
        `Achievements — ${earned.size} of ${ACHIEVEMENTS.length}`,
        h(
          'div',
          { class: 'grid cols-2' },
          ...ACHIEVEMENTS.map((achievement) =>
            h(
              'div',
              { class: `award${earned.has(achievement.id) ? ' earned' : ''}` },
              h('div', { class: 'award-name', text: achievement.name }),
              h('div', { class: 'sub', text: achievement.description }),
            ),
          ),
        ),
      ),
    );
    // ------------------------------------------------------------- the past
    // Not a feed and not a ledger: the decisions the player made, in order,
    // and the highest the company ever reached. Every line was written at the
    // moment the thing happened, by the system that did it.
    const records = section('The record books');
    records.appendChild(h('p', { class: 'sub', style: 'margin:-4px 0 12px', text: summary(state) }));
    records.appendChild(
      table(
        ['What', 'How much', 'When'],
        recordRows(state).map((row) => [row.label, row.value, h('span', { class: 'tiny muted', text: row.when })]),
      ),
    );
    el.appendChild(records);

    const months = chronicleByMonth(state);
    const log = section('What you did');
    if (months.length === 0) {
      log.appendChild(
        empty('Nothing worth writing down yet. Open a location, hire somebody or borrow money and it will start filling in.'),
      );
    } else {
      for (const month of months.slice(0, 8)) {
        log.appendChild(h('div', { class: 'group-heading', text: month.label }));
        for (const entry of month.entries) {
          log.appendChild(
            h(
              'div',
              { class: 'staff-row' },
              h('span', { class: 'tiny muted', style: 'width:58px;flex:0 0 auto', text: `day ${entry.day}` }),
              h('span', { style: 'flex:1;min-width:0', text: entry.text }),
              entry.amount !== null
                ? h('span', {
                    class: `stat-value ${entry.amount >= 0 ? 'good' : 'bad'}`,
                    text: moneySigned(entry.amount),
                  })
                : null,
            ),
          );
        }
      }
    }
    el.appendChild(log);

  };

  /** What this screen is showing, so it only repaints when that changes. */
  function signature(): string {
    const state = ctx.state;
    return `${state.day}|${state.levelReached}|${state.goals.length}|${state.goalsCompleted}|${state.achievements.length}`;
  }

  render();
  // Repainting three times a second would throw the reader back to the top of
  // the page three times a second. It only repaints when what it shows has
  // actually changed, and then without moving them.
  let shown = signature();
  return {
    el,
    update: () => {
      const now = signature();
      if (now === shown) return;
      shown = now;
      keepingScroll(render);
    },
  };
}
