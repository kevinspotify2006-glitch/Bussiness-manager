import type { Ctx, View } from '../app';
import type { Employee } from '../../sim/types';
import { businessById, employeesOf, playerBusinesses } from '../../sim/state';
import { businessTypeOrThrow } from '../../data/businessTypes';
import { ROLES, role, trait } from '../../data/roles';
import {
  BONUS_MONTHS,
  RECRUITMENT_FEE,
  applicantsFor,
  dailyWage,
  fire,
  hire,
  marketRate,
  payBonus,
  promote,
  quotePromotion,
  roleTitle,
  setSalary,
  sickDaysLeft,
  staffCapacityOf,
  startTraining,
  trainingCost,
  transfer,
} from '../../sim/employees';
import { money } from '../../sim/format';
import { GRADES, ROLE_SKILLS, SKILLS, fitLabel, gradeBlocker, gradeOf, performanceLabel, performanceOf, roleFit, titleOf } from '../../sim/skills';
import { department, departmentOf, tradeFitOf } from '../../sim/staffing';
import { COURSES, COURSE_BY_ID, suggestedCourse } from '../../sim/skills';
import { sum } from '../../sim/util';
import { relationshipsOf, describeBond } from '../../sim/relationships';
import { avatar, bar, button, confirmDialog, empty, h, kpi, modal, numberInput, section, select, stat, table, tag, toast } from '../dom';

export function employeesView(ctx: Ctx): View {
  const el = h('div', { class: 'view' });
  const state = ctx.state;
  const businesses = playerBusinesses(state);

  el.appendChild(
    h(
      'div',
      { class: 'view-head' },
      h('h1', { text: 'Employees' }),
      h('p', {
        text: `${state.employees.length} on the payroll · ${money(sum(state.employees, (e) => e.salary))}/month`,
      }),
    ),
  );

  if (businesses.length === 0) {
    el.appendChild(section('No businesses', empty('Create a business before hiring anyone.')));
    return { el };
  }

  const selectedId = ctx.params.business ?? businesses[0].id;
  const business = businessById(state, selectedId) ?? businesses[0];
  const staff = employeesOf(state, business.id);
  const capacity = staffCapacityOf(business);

  el.appendChild(
    section(
      'Location',
      select(
        businesses.map((b) => ({ value: b.id, label: b.name })),
        business.id,
        (value) => ctx.go('employees', { business: value }),
      ),
    ),
  );

  // The three figures that decide everything else on this screen: how many
  // people, what they cost, and whether they want to be here.
  const morale = staff.length ? sum(staff, (e) => e.morale) / staff.length : 0;
  el.appendChild(
    h(
      'div',
      { class: 'grid cols-3' },
      kpi({
        label: 'Team size', value: `${staff.length} / ${capacity}`, icon: 'people', tone: 'accent',
        sub: staff.length >= capacity ? 'fully staffed for this size' : `${capacity - staff.length} short of comfortable`,
        subTone: staff.length >= capacity ? 'good' : 'warn',
      }),
      kpi({
        label: 'Wage bill', value: `${money(sum(staff, (e) => e.salary))}/mo`, icon: 'cash', tone: 'warn',
        sub: `${money(sum(staff, (e) => dailyWage(e)))} a trading day`,
      }),
      kpi({
        label: 'Average morale', value: staff.length ? `${Math.round(morale)}/100` : '—', icon: 'good',
        tone: morale < 45 ? 'bad' : morale > 70 ? 'good' : 'info',
        valueTone: staff.length === 0 ? undefined : morale < 45 ? 'bad' : morale > 70 ? 'good' : undefined,
        sub: staff.length === 0 ? 'nobody on the payroll' : morale < 38 ? 'people start looking elsewhere below 38' : 'nobody is looking elsewhere',
        subTone: staff.length === 0 ? undefined : morale < 45 ? 'bad' : 'good',
      }),
    ),
  );

  // ------------------------------------------------------------ the team
  const teamPanel = section('Your team');
  if (staff.length === 0) {
    teamPanel.appendChild(
      empty('Nobody works here. Without staff you can serve about four customers an hour yourself, which is not a business.'),
    );
  } else {
    teamPanel.appendChild(
      table(
        ['Name', 'Role', 'Skill', 'Morale', 'Stress', 'Salary', ''],
        staff.map((employee) => [
          // A face, a name and what they are like — the three things you use to
          // tell one row of a staff list from another.
          h(
            'div',
            { class: 'cell-person' },
            avatar(employee.name, employee.morale < 40 ? 'warn' : employee.morale > 70 ? 'good' : undefined),
            h(
              'div',
              { style: 'min-width:0' },
              h('div', { class: 'cell-person-name', text: employee.name }),
              h('div', {
                class: 'tiny muted',
                text: employee.traits.map((t) => trait(t).name).join(', ') || 'No notable traits',
              }),
            ),
          ),
          h(
            'div',
            {},
            h('div', { text: roleTitle(employee) }),
            sickDaysLeft(state, employee) > 0
              ? h('span', { class: 'tag warn', text: `Off sick · ${sickDaysLeft(state, employee)}d` })
              : employee.trainingEndsOnDay !== null
                ? h('span', { class: 'tag', text: 'On a course' })
                : quotePromotion(state, employee).blocked === null
                  ? h('span', { class: 'tag accent', text: 'Ready to step up' })
                  : null,
          ),
          // Skill, morale and stress as badges rather than bare numbers: the
          // colour is the reading, and the figure is there for whoever wants it.
          tag(
            `${Math.round(employee.skill)}`,
            employee.skill >= 70 ? 'good' : employee.skill < 40 ? 'bad' : 'muted',
          ),
          tag(
            `${Math.round(employee.morale)}`,
            employee.morale < 40 ? 'bad' : employee.morale > 70 ? 'good' : 'warn',
          ),
          tag(
            `${Math.round(employee.stress)}`,
            employee.stress > 65 ? 'bad' : employee.stress > 40 ? 'warn' : 'muted',
          ),
          h(
            'div',
            {},
            h('div', { text: money(employee.salary) }),
            h('div', { class: 'tiny muted', text: `${money(dailyWage(employee))}/day` }),
          ),
          button('Manage', () => openEmployeeDialog(ctx, employee), 'btn small'),
        ]),
      ),
    );
    teamPanel.appendChild(
      h('p', {
        class: 'tiny muted',
        text: 'Morale falls when pay is below the market rate or the team is stretched. Below 38 people start looking elsewhere.',
      }),
    );
  }
  el.appendChild(teamPanel);

  // ---------------------------------------------------------- applicants
  const applicants = applicantsFor(state, business);
  const applicantPanel = section('Applicants');
  applicantPanel.appendChild(
    h('p', {
      class: 'tiny muted',
      text: `${businessTypeOrThrow(business.typeId).name} uses these roles: ${businessTypeOrThrow(business.typeId)
        .roles.map((r) => role(r).name)
        .join(', ')}. It lives on ${businessTypeOrThrow(business.typeId)
        .keySkills.map((id) => SKILLS.find((s) => s.id === id)?.name.toLowerCase() ?? id)
        .join(' and ')}, so that is what the ranking below is sorted on. Recruitment costs ${money(RECRUITMENT_FEE)} plus a week of wages up front.`,
    }),
  );

  if (applicants.length === 0) {
    applicantPanel.appendChild(empty('Nobody suitable applied today. The pool refreshes each day.'));
  } else {
    // Sorted by how well they would suit this particular trade, because that
    // is the question being asked — not who has the biggest headline number.
    const type = businessTypeOrThrow(business.typeId);
    const ranked = [...applicants].sort((a, b) => tradeFitOf(b, type) - tradeFitOf(a, type));
    applicantPanel.appendChild(
      table(
        ['Name', 'Role', 'Suits this trade', 'Skill', 'Traits', 'Asking salary', ''],
        ranked.map((applicant) => [
          h(
            'div',
            {},
            h('div', { text: applicant.name }),
            h('div', { class: 'tiny muted', text: `${applicant.age}, ${titleOf(applicant).toLowerCase()}` }),
          ),
          role(applicant.role).name,
          h(
            'div',
            { style: 'min-width:120px' },
            h('div', {
              class: 'tiny',
              text: `${Math.round(tradeFitOf(applicant, type))} · ${type.keySkills
                .map((id) => SKILLS.find((s) => s.id === id)?.name.toLowerCase() ?? id)
                .join(', ')}`,
            }),
            bar(tradeFitOf(applicant, type) / 100, tradeFitOf(applicant, type) > 62 ? 'good' : tradeFitOf(applicant, type) < 38 ? 'bad' : ''),
          ),
          skillCell(applicant.skill),
          h('div', { class: 'tiny muted', text: applicant.traits.map((t) => trait(t).name).join(', ') }),
          money(applicant.salary),
          button(
            'Hire',
            () => {
              const result = hire(state, applicant.id, business.id);
              toast(result.message, result.ok ? 'good' : 'bad');
              if (result.ok) ctx.refresh();
            },
            'btn small primary',
          ),
        ]),
      ),
    );
  }
  el.appendChild(applicantPanel);

  // -------------------------------------------------------- whole company
  if (state.employees.length > 0) {
    const byRole = ROLES.map((roleDef) => ({
      label: roleDef.name,
      value: state.employees.filter((e) => e.role === roleDef.id).length,
    })).filter((row) => row.value > 0);

    el.appendChild(
      section(
        'Across the company',
        table(
          ['Role', 'People', 'Average skill', 'Average morale', 'Monthly cost'],
          byRole.map((row) => {
            const people = state.employees.filter((e) => role(e.role).name === row.label);
            return [
              row.label,
              String(people.length),
              `${Math.round(sum(people, (e) => e.skill) / people.length)}`,
              `${Math.round(sum(people, (e) => e.morale) / people.length)}`,
              money(sum(people, (e) => e.salary)),
            ];
          }),
        ),
      ),
    );
  }

  return { el };
}

function skillCell(value: number): HTMLElement {
  return h(
    'div',
    { style: 'min-width:70px' },
    h('div', { class: 'tiny', text: String(Math.round(value)) }),
    bar(value / 100, value > 70 ? 'good' : value < 40 ? 'bad' : ''),
  );
}

/** A big number with its own bar — the three that say how somebody is doing. */
function figure(label: string, value: number, caption: string, inverted = false): HTMLElement {
  const good = inverted ? value < 62 : value > 66;
  const bad = inverted ? value > 82 : value < 38;
  return h(
    'div',
    { class: 'profile-figure' },
    h('span', { class: 'profile-figure-label', text: label }),
    h('span', { class: `profile-figure-value${good ? ' good' : bad ? ' bad' : ''}`, text: `${Math.round(value)}%` }),
    bar(value / 100, good ? 'good' : bad ? 'bad' : ''),
    h('span', { class: 'sub', text: caption }),
  );
}

function openEmployeeDialog(ctx: Ctx, employee: Employee): void {
  const state = ctx.state;
  const { body, footer, close } = modal({ title: employee.name, width: 520 });
  const businesses = playerBusinesses(state);

  // ------------------------------------------------------- who they are
  const performance = performanceOf(employee);
  const fit = roleFit(employee.skills, employee.role);
  const site = employee.businessId
    ? state.businesses.find((b) => b.id === employee.businessId)?.name ??
      (state.headOffice?.id === employee.businessId ? state.headOffice.name : null) ??
      state.warehouses.find((w) => w.id === employee.businessId)?.name ??
      null
    : null;

  body.appendChild(
    h(
      'div',
      { class: 'panel profile-head' },
      h(
        'div',
        {},
        h('div', { class: 'profile-role', text: roleTitle(employee) }),
        h('div', { class: 'sub', text: `${department(departmentOf(employee.role)).name}${site ? ` · ${site}` : ' · not posted anywhere'}` }),
      ),
      h(
        'div',
        { class: 'profile-figures' },
        figure('Performance', performance, performanceLabel(performance)),
        figure('Morale', employee.morale, employee.morale < 40 ? 'At risk' : employee.morale > 72 ? 'Happy' : 'Settled'),
        figure('Workload', employee.workload, employee.workload > 82 ? 'Flat out' : employee.workload > 62 ? 'Busy' : 'Comfortable', true),
      ),
    ),
  );

  // ------------------------------------------------ working relationships
  // Who this person actually works with. Not a team average: named colleagues,
  // and what each of those relationships is doing to the place.
  const bonds = relationshipsOf(state, employee);
  if (bonds.length > 0) {
    const people = h('div', { class: 'panel' }, h('h3', { class: 'panel-title', text: 'Who they work with' }));
    for (const { other, bond } of bonds) {
      const described = describeBond(bond, other);
      people.appendChild(
        h(
          'div',
          { class: 'staff-row' },
          avatar(other.name, described.tone === 'bad' ? 'warn' : undefined, true),
          h(
            'div',
            { style: 'flex:1;min-width:0' },
            h('div', { class: 'staff-name', text: described.text }),
            h('div', { class: 'tiny muted', text: `${titleOf(other)} · ${roleTitle(other)}` }),
          ),
          tag(
            bond.kind === 'mentor' ? 'mentoring' : bond.strength < 0 ? 'friction' : 'works well',
            described.tone === 'bad' ? 'bad' : 'good',
          ),
        ),
      );
    }
    people.appendChild(
      h('p', {
        class: 'tiny muted',
        text: bonds.some((row) => row.bond.strength < 0)
          ? 'Friction costs morale on both sides and the customers notice it. Somebody senior enough to sort it out is the usual answer.'
          : 'People who work well together are happier, stay longer, and serve customers better.',
      }),
    );
    body.appendChild(people);
  }

  // ------------------------------------------------------------- skills
  const skillPanel = h(
    'div',
    { class: 'panel' },
    h('h3', { class: 'panel-title', text: 'Skills' }),
    h('p', {
      class: 'tiny muted',
      style: 'margin:-4px 0 10px',
      text: `${fitLabel(fit)} — they fit ${role(employee.role).name.toLowerCase()} ${Math.round(fit)}/100. What the job leans on is marked.`,
    }),
  );
  const weights = ROLE_SKILLS[employee.role];
  for (const def of SKILLS) {
    const weight = weights[def.id] ?? 0;
    const value = employee.skills[def.id] ?? 0;
    skillPanel.appendChild(
      h(
        'div',
        { class: `skill-row${weight > 0.2 ? ' wanted' : ''}` },
        h(
          'div',
          { class: 'skill-head' },
          h('span', { class: 'skill-name', text: def.name }),
          weight > 0.2 ? h('span', { class: 'skill-tag', text: 'this job' }) : null,
          h('span', { class: 'skill-value', text: String(Math.round(value)) }),
        ),
        bar(value / 100, value > 70 ? 'good' : value < 35 ? 'bad' : ''),
      ),
    );
  }
  body.appendChild(skillPanel);

  body.appendChild(
    h(
      'div',
      { class: 'panel' },
      h('h3', { class: 'panel-title', text: 'The rest of the file' }),
      stat('Age', String(employee.age)),
      stat('Overall level', `${Math.round(employee.skill)}/100`),
      stat('Years in the trade', employee.experience.toFixed(1)),
      stat('Productivity', `${Math.round(employee.productivity)}/100`),
      stat('Reliability', `${Math.round(employee.reliability)}/100`),
      stat('Stress', `${Math.round(employee.stress)}/100`, employee.stress > 65 ? 'bad' : undefined),
      stat('Loyalty', `${Math.round(employee.loyalty)}/100`),
      stat('Courses completed', String(employee.trainingDays)),
      stat('Grade', `${gradeOf(employee).n} of 6 — ${gradeOf(employee).name}`),
      stat('Promotions', String(employee.promotions)),
      stat('Salary', `${money(employee.salary)}/mo`),
      sickDaysLeft(state, employee) > 0
        ? stat('Off sick', `back on day ${employee.sickUntilDay}`, 'bad')
        : stat('At work', 'yes', 'muted'),
    ),
  );

  if (employee.traits.length > 0) {
    const traits = h('div', { class: 'panel' }, h('h3', { class: 'panel-title', text: 'Traits' }));
    for (const id of employee.traits) {
      const def = trait(id);
      traits.appendChild(
        h('div', { class: 'stat' }, h('span', { class: 'stat-label', text: def.name }), h('span', { class: 'stat-value muted', text: def.effect })),
      );
    }
    body.appendChild(traits);
  }

  // ------------------------------------------------------------ career
  const quote = quotePromotion(state, employee);
  const bonus = Math.round((employee.salary * BONUS_MONTHS) / 10) * 10;
  const here = gradeOf(employee);
  const career = h('div', { class: 'panel' }, h('h3', { class: 'panel-title', text: 'Where they can get to' }));

  // The whole ladder, not just the next rung — because the interesting part is
  // usually where somebody stops, and why.
  for (const step of GRADES) {
    const isHere = step.n === here.n;
    const done = step.n < here.n;
    const wall = step.n > here.n ? gradeBlocker(employee, step) : null;
    career.appendChild(
      h(
        'div',
        { class: `ladder-row${isHere ? ' here' : ''}${done ? ' done' : ''}` },
        h('span', {
          class: 'ladder-name',
          text: isHere ? titleOf(employee) : step.n === 0 ? 'Junior' : step.name,
        }),
        h('span', {
          class: `ladder-state${wall && step.n === here.n + 1 ? ' bad' : ''}`,
          text: done
            ? 'done'
            : isHere
              ? 'here'
              : step.leadership > 0
                ? `needs leadership ${step.leadership}${step.n === here.n + 1 ? ` — they are on ${Math.round(employee.skills.leadership)}` : ''}`
                : `needs an overall level of ${step.skill}`,
        }),
      ),
    );
  }

  career.appendChild(
    h('p', {
      class: 'tiny muted',
      style: 'margin:8px 0',
      text:
        quote.blocked ??
        `Promoting them to ${quote.title} costs ${money(quote.extra)} more a month and buys real loyalty.`,
    }),
  );
  if (!quote.blocked && quote.role !== employee.role) {
    career.appendChild(
      h('p', {
        class: 'tiny warn',
        style: 'margin:0 0 8px',
        text: `That is a different job, not a bigger version of this one — ${employee.name} would stop doing what they are currently the best in the building at.`,
      }),
    );
  }
  const careerRow = h('div', { class: 'btn-row' });
  const promoteBtn = button(
    quote.blocked ? 'Promote' : `Promote to ${quote.title}`,
    () => {
      const result = promote(state, employee.id);
      toast(result.message, result.ok ? 'good' : 'bad');
      close();
      ctx.refresh();
    },
    'btn primary',
  );
  if (quote.blocked) (promoteBtn as HTMLButtonElement).disabled = true;
  careerRow.appendChild(promoteBtn);
  careerRow.appendChild(
    button(`Pay a ${money(bonus)} bonus`, () => {
      const result = payBonus(state, employee.id);
      toast(result.message, result.ok ? 'good' : 'bad');
      close();
      ctx.refresh();
    }),
  );
  career.appendChild(careerRow);
  body.appendChild(career);

  const rate = marketRate(state, employee);
  body.appendChild(
    h(
      'label',
      { class: 'field' },
      h('span', { text: `Monthly salary (market rate for a ${titleOf(employee).toLowerCase()}: ${money(rate)})` }),
      numberInput(
        employee.salary,
        (value) => {
          const result = setSalary(state, employee.id, value);
          toast(result.message, result.ok ? 'good' : 'bad');
          ctx.refresh();
        },
        { step: '50', min: '0' },
      ),
    ),
  );

  if (businesses.length > 1) {
    body.appendChild(
      h(
        'label',
        { class: 'field' },
        h('span', { text: 'Assigned to' }),
        select(
          businesses.map((b) => ({ value: b.id, label: b.name })),
          employee.businessId ?? businesses[0].id,
          (value) => {
            const result = transfer(state, employee.id, value);
            toast(result.message, result.ok ? 'good' : 'bad');
            close();
            ctx.refresh();
          },
        ),
      ),
    );
  }

  // --------------------------------------------------------- training
  const training = h('div', { class: 'panel' }, h('h3', { class: 'panel-title', text: 'Training' }));
  if (employee.trainingEndsOnDay !== null) {
    const onCourse = employee.trainingCourseId ? COURSE_BY_ID.get(employee.trainingCourseId) : null;
    training.appendChild(
      h('p', {
        class: 'tiny muted',
        style: 'margin:0',
        text: onCourse
          ? `On ${onCourse.name.toLowerCase()} until day ${employee.trainingEndsOnDay}. ${onCourse.detail}`
          : `In training until day ${employee.trainingEndsOnDay}.`,
      }),
    );
  } else {
    const suggested = suggestedCourse(employee);
    training.appendChild(
      h('p', {
        class: 'tiny muted',
        style: 'margin:0 0 8px',
        text: `A course puts them on one skill and takes them off the floor while it runs. Each one after the first does a little less. ${suggested.name} would do them the most good where they are.`,
      }),
    );
    for (const course of COURSES) {
      const weight = ROLE_SKILLS[employee.role][course.skill] ?? 0;
      training.appendChild(
        h(
          'div',
          { class: `course-row${course.id === suggested.id ? ' suggested' : ''}` },
          h(
            'div',
            { style: 'flex:1;min-width:0' },
            h('div', { class: 'course-name', text: course.name }),
            h('div', {
              class: 'sub',
              text: `${course.days} days · ${money(trainingCost(course))} · ${
                weight > 0.2 ? 'this job leans on it' : 'not what this job needs'
              }`,
            }),
          ),
          button(
            'Send',
            () => {
              const result = startTraining(state, employee.id, course.id);
              toast(result.message, result.ok ? 'good' : 'bad');
              close();
              ctx.refresh();
            },
            course.id === suggested.id ? 'btn small primary' : 'btn small',
          ),
        ),
      );
    }
  }
  body.appendChild(training);

  footer.appendChild(
    button(
      'Dismiss',
      async () => {
        const ok = await confirmDialog(
          `Dismiss ${employee.name}?`,
          'Severance is based on length of service, and the rest of the team will notice.',
          'Dismiss',
        );
        if (!ok) return;
        const result = fire(state, employee.id);
        toast(result.message, result.ok ? 'good' : 'bad');
        close();
        ctx.refresh();
      },
      'btn danger',
    ),
  );
}
