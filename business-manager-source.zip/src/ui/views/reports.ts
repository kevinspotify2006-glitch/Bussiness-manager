import type { Ctx, View } from '../app';
import type { LedgerCategory } from '../../sim/types';
import { playerBusinesses } from '../../sim/state';
import { LEDGER_LABELS, isRevenue } from '../../sim/finance';
import { attractiveness, rivalsOf } from '../../sim/demand';
import { businessTypeOrThrow } from '../../data/businessTypes';
import { product } from '../../data/products';
import { ACHIEVEMENTS, currentTier } from '../../sim/achievements';
import { basketOf, grossMarginOf, movements } from '../../sim/accounts';
import { calendar, count, money, moneySigned, pct } from '../../sim/format';
import { sum } from '../../sim/util';
import { bar, clear, empty, h, kpi, section, select, stat, table } from '../dom';
import { lineChart } from '../chart';

/**
 * Reports answer three questions in order: what happened, why it happened, and
 * what the player could do about it. Nothing here decides anything for them.
 */
export function reportsView(ctx: Ctx): View {
  const el = h('div', { class: 'view' });
  const state = ctx.state;
  const businesses = playerBusinesses(state);

  el.appendChild(
    h('div', { class: 'view-head' }, h('h1', { text: 'Reports' }), h('p', { text: 'What happened, and why' })),
  );

  if (state.dayHistory.length === 0) {
    el.appendChild(section('Nothing to report', empty('No day has been settled yet. Let the clock run.')));
    return { el };
  }

  const yesterday = state.dayHistory[state.dayHistory.length - 1];
  const previous = state.dayHistory[state.dayHistory.length - 2];
  const cal = calendar(yesterday.day);

  // ------------------------------------------------------ headline change
  const headline = section(`Day ${yesterday.day} — ${cal.label}`);
  headline.appendChild(
    h(
      'div',
      { class: 'grid cols-4' },
      metric('Revenue', money(yesterday.revenue), previous ? delta(yesterday.revenue, previous.revenue) : '', undefined, 'revenue', 'info'),
      metric('Costs', money(yesterday.costs), previous ? delta(yesterday.costs, previous.costs, true) : '', undefined, 'cash', 'warn'),
      metric('Profit', moneySigned(yesterday.profit), previous ? delta(yesterday.profit, previous.profit) : '', yesterday.profit >= 0 ? 'good' : 'bad', 'profit', yesterday.profit >= 0 ? 'tech' : 'bad'),
      metric('Customers', count(yesterday.customers), previous ? delta(yesterday.customers, previous.customers) : '', undefined, 'people', 'accent'),
    ),
  );

  if (previous) {
    headline.appendChild(explainChange(ctx, yesterday.day, previous.day));
  }
  el.appendChild(headline);

  // -------------------------------------------------- management accounts
  el.appendChild(accountsPanel(ctx));

  // ------------------------------------------------------------- trends
  el.appendChild(
    h(
      'div',
      { class: 'grid cols-2' },
      section('Profit trend', lineChart(state.dayHistory.slice(-45).map((d) => d.profit))),
      section('Net worth', lineChart(state.dayHistory.slice(-45).map((d) => d.netWorth), { showZero: false })),
    ),
  );

  // -------------------------------------------------- per-business review
  for (const business of businesses) {
    const type = businessTypeOrThrow(business.typeId);
    const stats = business.yesterday;
    const profit =
      stats.revenue - (stats.cogs + stats.wages + stats.rent + stats.marketing + stats.otherCosts);
    const lostShare = stats.customers + stats.lostCustomers > 0
      ? stats.lostCustomers / (stats.customers + stats.lostCustomers)
      : 0;
    const own = attractiveness(state, business);
    const rivals = rivalsOf(state, business);
    const weakest = [...own.factors].sort((a, b) => a.value - b.value)[0];
    const outOfStock = type.productIds.filter((id) => (business.stock[id] ?? 0) <= 0);

    const advice: string[] = [];
    if (stats.revenue === 0 && business.status !== 'open') {
      advice.push('The business is not open. Nothing will happen until it is.');
    }
    if (lostShare > 0.15) {
      advice.push(
        `${pct(lostShare * 100)} of customers were turned away. More staff on shift, or longer hours, converts them.`,
      );
    }
    if (outOfStock.length > 0) {
      advice.push(
        `Out of stock: ${outOfStock.map((id) => product(id)?.name ?? id).join(', ')}. Raise the reorder point or switch to a faster supplier.`,
      );
    }
    if (weakest && weakest.value < 0.85) {
      advice.push(`Your weakest point against rivals is ${weakest.label.toLowerCase()} (${weakest.hint}).`);
    }
    if (profit < 0 && stats.rent > stats.revenue * 0.3) {
      advice.push('Rent is eating more than 30% of revenue. This location may simply be too expensive for what it takes.');
    }
    if (profit > 0 && lostShare < 0.05 && business.awareness < 40) {
      advice.push('You have spare capacity and low awareness — marketing would fill it.');
    }
    if (advice.length === 0) advice.push('Nothing is obviously wrong. Consider raising prices slightly to test the ceiling.');

    el.appendChild(
      section(
        `${type.icon} ${business.name}`,
        h(
          'div',
          { class: 'grid cols-4' },
          metric('Revenue', money(stats.revenue), '', undefined, 'revenue', 'info'),
          metric('Profit', moneySigned(profit), '', profit >= 0 ? 'good' : 'bad', 'profit', profit >= 0 ? 'tech' : 'bad'),
          metric('Customers', count(stats.customers), '', undefined, 'people', 'accent'),
          metric('Turned away', count(stats.lostCustomers), '', lostShare > 0.15 ? 'bad' : undefined, 'warning', lostShare > 0.15 ? 'bad' : 'warn'),
        ),
        h(
          'div',
          { class: 'grid cols-2', style: 'margin-top:12px' },
          h(
            'div',
            {},
            h('h4', { class: 'panel-title', text: 'Cost structure' }),
            costRow('Cost of goods', stats.cogs, stats.revenue),
            costRow('Wages', stats.wages, stats.revenue),
            costRow('Rent & utilities', stats.rent + stats.otherCosts, stats.revenue),
            costRow('Marketing', stats.marketing, stats.revenue),
          ),
          h(
            'div',
            {},
            h('h4', { class: 'panel-title', text: 'What you could do' }),
            ...advice.map((line) => h('p', { class: 'tiny muted', text: `• ${line}` })),
            h('p', {
              class: 'tiny muted',
              text: `${rivals.length} direct rival${rivals.length === 1 ? '' : 's'} in this district.`,
            }),
          ),
        ),
      ),
    );
  }

  // ------------------------------------------------------- achievements
  const tier = currentTier(state);
  const achievementPanel = section('Progression');
  achievementPanel.appendChild(stat('Tier', tier.name));
  achievementPanel.appendChild(bar(tier.progress, 'good'));
  achievementPanel.appendChild(
    table(
      ['Achievement', 'Progress', 'Status'],
      ACHIEVEMENTS.map((def) => {
        const unlocked = state.achievements.find((a) => a.id === def.id);
        const progress = def.progress(state);
        return [
          h('div', {}, h('div', { text: def.name }), h('div', { class: 'tiny muted', text: def.description })),
          bar(progress, unlocked ? 'good' : ''),
          unlocked
            ? h('span', { class: 'tag good', text: `Day ${unlocked.unlockedOnDay}` })
            : h('span', { class: 'tag', text: pct(progress * 100) }),
        ];
      }),
    ),
  );
  el.appendChild(achievementPanel);

  return { el };
}

/**
 * One figure from the accounts.
 *
 * A thin wrapper over the shared KPI card rather than a second one: this used
 * to build the markup by hand, and the day the card grew an icon tile every
 * number on this screen was squeezed into an ellipsis.
 */
function metric(
  label: string,
  value: string,
  change: string,
  tone?: 'good' | 'bad',
  glyph?: string,
  category?: 'accent' | 'good' | 'bad' | 'warn' | 'tech' | 'info',
): HTMLElement {
  return kpi({
    label,
    value,
    sub: change || undefined,
    icon: glyph ?? 'reports',
    tone: category ?? 'accent',
    valueTone: tone,
    subTone: change.startsWith('▲') ? 'good' : change.startsWith('▼') ? 'bad' : undefined,
  });
}

function delta(current: number, previous: number, invert = false): string {
  if (previous === 0) return '';
  const change = ((current - previous) / Math.abs(previous)) * 100;
  const arrow = change >= 0 ? '▲' : '▼';
  const good = invert ? change < 0 : change >= 0;
  return `${arrow} ${Math.abs(change).toFixed(0)}% ${good ? 'vs yesterday' : 'vs yesterday'}`;
}

function costRow(label: string, amount: number, revenue: number): HTMLElement {
  const share = revenue > 0 ? amount / revenue : 0;
  return h(
    'div',
    { style: 'margin:6px 0' },
    h(
      'div',
      { style: 'display:flex;justify-content:space-between;font-size:12px' },
      h('span', { class: 'muted', text: label }),
      h('span', { text: `${money(amount)} (${pct(share * 100)})` }),
    ),
    bar(share, share > 0.45 ? 'bad' : share > 0.3 ? 'warn' : ''),
  );
}

/** Compares two days category by category and reports the biggest movers. */
function explainChange(ctx: Ctx, day: number, previousDay: number): HTMLElement {
  const state = ctx.state;
  const totals = new Map<LedgerCategory, { now: number; before: number }>();
  for (const entry of state.ledger) {
    if (entry.day !== day && entry.day !== previousDay) continue;
    const bucket = totals.get(entry.category) ?? { now: 0, before: 0 };
    if (entry.day === day) bucket.now += entry.amount;
    else bucket.before += entry.amount;
    totals.set(entry.category, bucket);
  }

  const movers = [...totals.entries()]
    .map(([category, bucket]) => ({ category, change: bucket.now - bucket.before }))
    .filter((row) => Math.abs(row.change) > 1)
    .sort((a, b) => Math.abs(b.change) - Math.abs(a.change))
    .slice(0, 6);

  if (movers.length === 0) {
    return h('p', { class: 'tiny muted', text: 'Nothing changed materially compared with the day before.' });
  }

  return h(
    'div',
    { style: 'margin-top:12px' },
    h('h4', { class: 'panel-title', text: 'Why the result moved' }),
    table(
      ['Category', 'Change vs previous day'],
      movers.map((row) => [
        LEDGER_LABELS[row.category],
        h('span', {
          class: (isRevenue(row.category) ? row.change > 0 : row.change > 0) ? 'good' : 'bad',
          text: moneySigned(row.change),
        }),
      ]),
    ),
    h('p', {
      class: 'tiny muted',
      text: `Total swing: ${moneySigned(sum(movers, (m) => m.change))}.`,
    }),
  );
}

/**
 * The month's management accounts: profit and loss, where it went, what the
 * company is worth at the close, and which sites carried it.
 */
function accountsPanel(ctx: Ctx): HTMLElement {
  const state = ctx.state;
  const panel = section('Management accounts');

  if (state.accounts.length === 0) {
    panel.appendChild(
      empty(
        `The books are closed at the end of each month. The first set is due on day ${Math.ceil(state.day / 30) * 30}.`,
      ),
    );
    return panel;
  }

  let index = state.accounts.length - 1;
  const body = h('div', {});

  const render = (): void => {
    const account = state.accounts[index];
    const before = state.accounts[index - 1];
    clear(body);

    body.appendChild(
      h('p', {
        class: 'tiny muted',
        text: `Days ${account.fromDay}–${account.toDay} · ${account.locations} location${account.locations === 1 ? '' : 's'} · ${account.headcount} on the payroll`,
      }),
    );

    // Profit and loss, in the order an accountant would read it.
    const pl = h('div', {});
    const line = (label: string, value: number, tone?: 'good' | 'bad' | 'muted'): HTMLElement =>
      stat(label, money(value), tone);
    pl.appendChild(line('Turnover', account.revenue));
    pl.appendChild(line('Cost of sales', -account.costOfSales));
    pl.appendChild(
      stat(
        `Gross profit (${Math.round(grossMarginOf(account) * 100)}%)`,
        money(account.grossProfit),
        account.grossProfit >= 0 ? 'good' : 'bad',
      ),
    );
    pl.appendChild(line('Wages', -account.wages));
    pl.appendChild(line('Rent', -account.rent));
    pl.appendChild(line('Utilities', -account.utilities));
    pl.appendChild(line('Marketing', -account.marketing));
    pl.appendChild(line('Logistics', -account.logistics));
    if (account.training > 0) pl.appendChild(line('Training and severance', -account.training));
    if (account.recruitment > 0) pl.appendChild(line('Recruitment', -account.recruitment));
    if (account.management > 0) pl.appendChild(line('Management and coordination', -account.management));
    if (account.outsourcing > 0) pl.appendChild(line('Outsourced services', -account.outsourcing));
    if (account.interest > 0) pl.appendChild(line('Interest', -account.interest));
    if (account.tax > 0) pl.appendChild(line('Corporation tax', -account.tax));
    pl.appendChild(
      stat('Net profit', moneySigned(account.netProfit), account.netProfit >= 0 ? 'good' : 'bad'),
    );

    const balance = h('div', {});
    balance.appendChild(stat('Cash', money(account.cash), account.cash < 0 ? 'bad' : undefined));
    balance.appendChild(stat('Stock', money(account.stock)));
    balance.appendChild(stat('Property', money(account.property)));
    balance.appendChild(stat('Goodwill', money(account.goodwill)));
    balance.appendChild(stat('Debt', money(-account.debt), account.debt > 0 ? 'bad' : 'muted'));
    balance.appendChild(stat('Net worth', money(account.netWorth), 'good'));
    balance.appendChild(stat('Customers served', count(account.customers)));
    balance.appendChild(stat('Average basket', money(basketOf(account))));
    balance.appendChild(
      stat(
        'Revenue per head',
        account.headcount > 0 ? money(account.revenue / account.headcount) : '—',
      ),
    );

    body.appendChild(
      h(
        'div',
        { class: 'grid cols-2', style: 'margin-top:10px' },
        h('div', {}, h('h4', { class: 'panel-title', text: 'Profit and loss' }), pl),
        h('div', {}, h('h4', { class: 'panel-title', text: 'At the close' }), balance),
      ),
    );

    if (before) {
      body.appendChild(h('h4', { class: 'panel-title', style: 'margin-top:14px', text: 'Against last month' }));
      body.appendChild(
        table(
          ['', 'This month', 'Last month', 'Change'],
          movements(account, before)
            .slice(0, 6)
            .map((row) => [
              row.label,
              money(row.now),
              money(row.before),
              h('span', {
                class:
                  row.change === 0
                    ? 'muted'
                    : (row.change > 0) === row.higherIsBetter
                      ? 'good'
                      : 'bad',
                text: moneySigned(row.change),
              }),
            ]),
        ),
      );
    }

    if (account.byBusiness.length > 0) {
      body.appendChild(h('h4', { class: 'panel-title', style: 'margin-top:14px', text: 'By location' }));
      body.appendChild(
        table(
          ['Business', 'Turnover', 'Costs', 'Contribution'],
          account.byBusiness
            .slice()
            .sort((a, b) => b.profit - a.profit)
            .map((row) => [
              row.name,
              money(row.revenue),
              money(row.costs),
              h('span', { class: row.profit >= 0 ? 'good' : 'bad', text: moneySigned(row.profit) }),
            ]),
        ),
      );
      body.appendChild(
        h('p', {
          class: 'tiny muted',
          text: 'Contribution is what each site earned after everything charged to it. Company-wide costs — an empty lease, a distribution centre, interest, tax — sit outside this table and are in the profit and loss above.',
        }),
      );
    }
  };

  if (state.accounts.length > 1) {
    panel.appendChild(
      h(
        'label',
        { class: 'field' },
        h('span', { text: 'Month' }),
        select(
          state.accounts.map((account, i) => ({
            value: String(i),
            label: `Days ${account.fromDay}–${account.toDay}`,
          })),
          String(index),
          (value) => {
            index = Number(value);
            render();
          },
        ),
      ),
    );
  }
  panel.appendChild(body);
  render();
  return panel;
}
