import type { Ctx, View } from '../app';
import type { Warehouse } from '../../sim/types';
import { buildingById, businessById, employeesOf, playerBusinesses, playerCompany } from '../../sim/state';
import { district } from '../../data/districts';
import { product } from '../../data/products';
import { role } from '../../data/roles';
import { SUPPLIERS } from '../../data/suppliers';
import {
  BASE_TRIPS,
  FIT_OUT_COST,
  TRIPS_PER_DRIVER,
  TRIP_COST,
  canConvert,
  capacityOf,
  closeWarehouse,
  freeSpace,
  hireToWarehouse,
  openWarehouse,
  placeBulkOrder,
  planDispatch,
  quoteBulk,
  stockValue,
  stockableProducts,
  tripsPerDay,
  usedSpace,
  warehousesOf,
} from '../../sim/warehouse';
import { count, money, pct } from '../../sim/format';
import { sum } from '../../sim/util';
import { bar, button, clear, confirmDialog, empty, h, numberInput, section, select, stat, table, toast } from '../dom';

/**
 * Distribution.
 *
 * The screen only earns its place once the player runs more than one shop, so
 * until then it explains the trade-off rather than pretending to be useful.
 */
export function logisticsView(ctx: Ctx): View {
  const el = h('div', { class: 'view' });
  const state = ctx.state;
  const warehouses = warehousesOf(state);
  const shops = playerBusinesses(state).filter((b) => b.status !== 'closed');

  el.appendChild(
    h(
      'div',
      { class: 'view-head' },
      h('h1', { text: 'Distribution' }),
      h('p', {
        text:
          warehouses.length > 0
            ? `${warehouses.length} distribution centre${warehouses.length === 1 ? '' : 's'} supplying ${shops.length} location${shops.length === 1 ? '' : 's'}`
            : 'Buy in bulk once, deliver to your own shops overnight',
      }),
    ),
  );

  if (warehouses.length === 0) el.appendChild(pitchPanel(ctx));
  for (const warehouse of warehouses) el.appendChild(warehousePanel(ctx, warehouse));
  el.appendChild(convertPanel(ctx));

  return { el };
}

/** What a warehouse is for, in numbers drawn from the player's own company. */
function pitchPanel(ctx: Ctx): HTMLElement {
  const state = ctx.state;
  const shops = playerBusinesses(state).filter((b) => b.status === 'open');
  const spent = sum(
    state.ledger.filter((entry) => entry.category === 'logistics' && entry.day > state.day - 30),
    (entry) => -entry.amount,
  );

  return section(
    'Why a distribution centre',
    h('p', {
      class: 'tiny muted',
      text: 'Every supplier delivery carries a call-out charge and its own lead time, and each shop ordering separately misses the volume discount. A warehouse buys once, in bulk, and your own van restocks the shelves overnight.',
    }),
    h(
      'div',
      { class: 'grid cols-3', style: 'margin:12px 0' },
      stat('Your locations', String(shops.length), shops.length >= 3 ? 'good' : undefined),
      stat('Delivery charges, last 30 days', money(spent)),
      stat('Fit-out cost', money(FIT_OUT_COST)),
    ),
    h('p', {
      class: 'tiny muted',
      text:
        shops.length >= 3
          ? 'At your size this usually pays for itself: bulk pricing, no minimum order per shop, and a supplier letting you down stops being a crisis.'
          : 'With one or two shops this is normally a waste of money — the rent and the wages cost more than the deliveries you would save. It becomes worth it at about three locations.',
    }),
  );
}

function warehousePanel(ctx: Ctx, warehouse: Warehouse): HTMLElement {
  const state = ctx.state;
  const building = buildingById(state, warehouse.buildingId);
  const capacity = capacityOf(state, warehouse);
  const used = usedSpace(warehouse);
  const staff = employeesOf(state, warehouse.id);
  const drivers = staff.filter((e) => e.role === 'driver').length;
  const trips = tripsPerDay(state, warehouse);
  const plan = planDispatch(state, warehouse);

  const panel = section(warehouse.name);
  panel.appendChild(
    h('p', {
      class: 'tiny muted',
      text: building
        ? `${building.address}, ${district(building.district).name} · ${money(building.rent)}/mo`
        : 'Premises unknown',
    }),
  );

  panel.appendChild(
    h(
      'div',
      { class: 'grid cols-4', style: 'margin:12px 0' },
      stat('Space used', `${count(used)} / ${count(capacity)}`, used > capacity * 0.92 ? 'bad' : undefined),
      stat('Stock at cost', money(stockValue(warehouse))),
      stat('Runs a day', `${trips}`, drivers === 0 ? 'bad' : 'good'),
      stat('Staff', `${staff.length}`),
    ),
  );
  panel.appendChild(bar(capacity > 0 ? used / capacity : 0, used > capacity * 0.92 ? 'bad' : 'good'));

  // ------------------------------------------------------------- tonight
  panel.appendChild(h('h4', { class: 'panel-title', style: 'margin-top:14px', text: "Tonight's run" }));
  if (!warehouse.autoDispatch) {
    panel.appendChild(empty('Automatic dispatch is off, so nothing leaves the racks tonight.'));
  } else if (plan.length === 0) {
    panel.appendChild(
      empty(
        stockValue(warehouse) <= 0
          ? 'The racks are empty. Order stock in below and your shops can draw on it.'
          : 'Every shop is above its reorder point, so the vans stay in.',
      ),
    );
  } else {
    const byBusiness = new Map<string, number>();
    for (const line of plan) byBusiness.set(line.businessId, (byBusiness.get(line.businessId) ?? 0) + line.units);
    panel.appendChild(
      table(
        ['Shop', 'Units going out', ''],
        [...byBusiness.entries()].map(([businessId, units]) => {
          const business = businessById(state, businessId);
          return [
            business?.name ?? 'Unknown',
            count(units),
            button('Open', () => ctx.go('businesses', { business: businessId }), 'btn small ghost'),
          ];
        }),
      ),
    );
    panel.appendChild(
      h('p', {
        class: 'tiny muted',
        text: `${byBusiness.size} run${byBusiness.size === 1 ? '' : 's'} at ${money(TRIP_COST)} each. ${
          drivers === 0
            ? `Without a driver you can only manage ${BASE_TRIPS} runs a day; each driver adds ${TRIPS_PER_DRIVER}.`
            : `${drivers} driver${drivers === 1 ? '' : 's'} on the payroll.`
        }`,
      }),
    );
  }

  // ------------------------------------------------------------ the racks
  const stockRows = Object.entries(warehouse.stock)
    .filter(([, units]) => units > 0.5)
    .sort((a, b) => b[1] - a[1])
    .map(([productId, units]) => {
      const def = product(productId);
      return [
        def?.name ?? productId,
        count(units),
        money((warehouse.costBasis[productId] ?? def?.wholesalePrice ?? 0) * units),
        def && def.shelfLife > 0 ? h('span', { class: 'tag warn', text: `${def.shelfLife}d shelf life` }) : '—',
      ];
    });
  panel.appendChild(h('h4', { class: 'panel-title', style: 'margin-top:14px', text: 'On the racks' }));
  panel.appendChild(
    stockRows.length > 0
      ? table(['Product', 'Units', 'At cost', ''], stockRows)
      : empty('Nothing on the racks yet.'),
  );

  // --------------------------------------------------------------- buying
  panel.appendChild(bulkOrder(ctx, warehouse));

  // ---------------------------------------------------------------- staff
  panel.appendChild(staffPanel(ctx, warehouse));

  // -------------------------------------------------------------- actions
  const actions = h('div', { class: 'btn-row', style: 'margin-top:14px' });
  actions.appendChild(
    h(
      'label',
      { class: 'switch' },
      h('input', { type: 'checkbox', checked: warehouse.autoDispatch, on: { change: () => {
        warehouse.autoDispatch = !warehouse.autoDispatch;
        ctx.refresh();
      } } }),
      h('span', { text: 'Send the vans out automatically' }),
    ),
  );
  actions.appendChild(
    button(
      'Close this centre',
      async () => {
        const ok = await confirmDialog(
          `Close ${warehouse.name}?`,
          'Staff are paid off and everything on the racks is cleared at half what it cost. The premises stay yours.',
          'Close it',
        );
        if (!ok) return;
        const result = closeWarehouse(state, warehouse.id);
        toast(result.message, result.ok ? 'good' : 'bad');
        ctx.refresh();
      },
      'btn danger',
    ),
  );
  panel.appendChild(actions);

  return panel;
}

/** Bulk purchasing, with the saving against shop-by-shop ordering spelled out. */
function bulkOrder(ctx: Ctx, warehouse: Warehouse): HTMLElement {
  const state = ctx.state;
  const products = stockableProducts(state);
  const host = h('div', { style: 'margin-top:14px' }, h('h4', { class: 'panel-title', text: 'Order in bulk' }));

  if (products.length === 0) {
    host.appendChild(empty('None of your businesses sell stock, so there is nothing to hold here.'));
    return host;
  }

  let supplierId = SUPPLIERS[0].id;
  const quantities: Record<string, number> = {};
  const figures = h('div', { style: 'margin-top:10px' });
  const problemsHost = h('div', {});

  const currentLines = (): { productId: string; quantity: number }[] =>
    Object.entries(quantities)
      .filter(([, quantity]) => quantity > 0)
      .map(([productId, quantity]) => ({ productId, quantity }));

  // The button is built once and only ever enabled or disabled: rebuilding it
  // on every keystroke replaces the element under the player's cursor.
  const place = button(
    'Place bulk order',
    () => {
      const result = placeBulkOrder(state, supplierId, warehouse.id, currentLines());
      toast(result.message, result.ok ? 'good' : 'bad');
      if (result.ok) ctx.refresh();
    },
    'btn primary',
  );

  const refresh = (): void => {
    const quote = quoteBulk(state, supplierId, warehouse.id, currentLines());
    clear(figures);
    figures.appendChild(
      h(
        'div',
        {},
        stat('Units', count(quote.units)),
        stat('Goods', money(quote.goodsCost)),
        stat('Delivery', money(quote.deliveryCost)),
        stat('Total', money(quote.total)),
        stat(
          'Against shop-by-shop',
          quote.units > 0 ? `saves ${money(Math.max(0, quote.retailEquivalent - quote.total))}` : '—',
          quote.retailEquivalent > quote.total ? 'good' : 'muted',
        ),
        stat('Space after delivery', `${count(Math.max(0, freeSpace(state, warehouse) - quote.volume))} free`),
      ),
    );
    clear(problemsHost);
    for (const problem of quote.problems) {
      problemsHost.appendChild(h('p', { class: 'tiny bad', text: problem }));
    }
    place.disabled = quote.problems.length > 0;
  };

  host.appendChild(
    h(
      'label',
      { class: 'field' },
      h('span', { text: 'Supplier' }),
      select(
        SUPPLIERS.map((def) => ({
          value: def.id,
          label: `${def.name} — ${pct(def.priceMultiplier * 100)} of list, ${def.leadTimeHours}h, min €${def.minimumOrderValue}`,
        })),
        supplierId,
        (value) => {
          supplierId = value;
          refresh();
        },
      ),
    ),
  );

  const rows = products.map((productId) => {
    const def = product(productId);
    quantities[productId] = quantities[productId] ?? 0;
    return [
      def?.name ?? productId,
      money(def?.wholesalePrice ?? 0),
      count(warehouse.stock[productId] ?? 0),
      numberInput(0, (value) => {
        quantities[productId] = Math.max(0, Math.round(value));
        refresh();
      }, { step: '50', min: '0' }),
    ];
  });
  host.appendChild(table(['Product', 'List price', 'On the racks', 'Order'], rows));
  host.appendChild(figures);
  host.appendChild(problemsHost);
  host.appendChild(h('div', { class: 'btn-row', style: 'margin-top:10px' }, place));
  refresh();
  return host;
}

function staffPanel(ctx: Ctx, warehouse: Warehouse): HTMLElement {
  const state = ctx.state;
  const staff = employeesOf(state, warehouse.id);
  const host = h('div', { style: 'margin-top:14px' }, h('h4', { class: 'panel-title', text: 'People' }));

  host.appendChild(
    staff.length > 0
      ? table(
          ['Name', 'Role', 'Skill', 'Salary'],
          staff.map((employee) => [
            employee.name,
            role(employee.role).name,
            `${Math.round(employee.skill)}`,
            `${money(employee.salary)}/mo`,
          ]),
        )
      : empty('Nobody works here. Without a driver the centre manages only a couple of runs a day.'),
  );

  const applicants = state.applicants.filter(
    (a) => a.role === 'warehouse' || a.role === 'driver' || a.role === 'manager',
  );
  host.appendChild(
    applicants.length > 0
      ? table(
          ['Applicant', 'Role', 'Skill', 'Asking', ''],
          applicants.slice(0, 5).map((applicant) => [
            applicant.name,
            role(applicant.role).name,
            `${Math.round(applicant.skill)}`,
            `${money(applicant.salary)}/mo`,
            button(
              'Hire',
              () => {
                const result = hireToWarehouse(state, applicant.id, warehouse.id);
                toast(result.message, result.ok ? 'good' : 'bad');
                ctx.refresh();
              },
              'btn small primary',
            ),
          ]),
        )
      : empty('No warehouse staff or drivers are looking for work today.'),
  );
  return host;
}

/** Turning a unit the company already holds into a distribution centre. */
function convertPanel(ctx: Ctx): HTMLElement {
  const state = ctx.state;
  const company = playerCompany(state);
  const candidates = state.buildings.filter(
    (b) => b.occupantCompanyId === company.id && !b.businessId && !state.warehouses.some((w) => w.buildingId === b.id),
  );

  const panel = section('Premises you could rack out');
  if (candidates.length === 0) {
    panel.appendChild(
      empty('You hold no empty units. Take a lease on something with plenty of storage — the industrial and warehouse districts are cheapest per unit of space.'),
    );
    panel.appendChild(
      h('div', { class: 'btn-row' }, button('Find premises', () => ctx.go('property'), 'btn primary')),
    );
    return panel;
  }

  panel.appendChild(
    table(
      ['Address', 'District', 'Storage', 'Rent', ''],
      candidates.map((building) => {
        const check = canConvert(state, building.id);
        return [
          building.address,
          district(building.district).name,
          count(building.storageCapacity),
          `${money(building.rent)}/mo`,
          check.ok
            ? button(
                `Rack it out — ${money(FIT_OUT_COST)}`,
                () => {
                  const result = openWarehouse(state, building.id, `${company.name} Distribution`);
                  toast(result.message, result.ok ? 'good' : 'bad');
                  ctx.refresh();
                },
                'btn small primary',
              )
            : h('span', { class: 'tiny muted', text: check.message }),
        ];
      }),
    ),
  );
  return panel;
}
