import type { Ctx, View } from '../app';
import type { NewsCategory } from '../../sim/types';
import { NEWS_ICONS, NEWS_LABELS, recentNews } from '../../sim/news';
import { showDecision } from '../decisionModal';
import { clockLabel, calendar } from '../../sim/format';
import { button, clear, empty, h, section } from '../dom';

const FILTERS: { id: NewsCategory | 'all'; label: string }[] = [
  { id: 'all', label: 'Everything' },
  { id: 'company', label: 'Your company' },
  { id: 'competitor', label: 'Competition' },
  { id: 'economy', label: 'Economy' },
  { id: 'staff', label: 'Staff' },
  { id: 'supplier', label: 'Suppliers' },
  { id: 'market', label: 'Market' },
  { id: 'property', label: 'Property' },
];

export function newsView(ctx: Ctx): View {
  const el = h('div', { class: 'view' });
  const state = ctx.state;
  let filter: NewsCategory | 'all' = 'all';

  el.appendChild(
    h(
      'div',
      { class: 'view-head' },
      h('h1', { text: 'Newsroom' }),
      h('p', { text: 'Everything the simulation has done that you would want to know about' }),
    ),
  );

  // ---------------------------------------------------------- decisions
  if (state.decisions.length > 0) {
    const panel = section('Waiting on you');
    for (const decision of state.decisions) {
      panel.appendChild(
        h(
          'div',
          { class: 'decision-card' },
          h(
            'div',
            { style: 'flex:1;min-width:0' },
            h('div', { class: 'card-title', text: decision.title }),
            h('div', { class: 'card-sub', text: decision.body }),
            h('div', { class: 'tiny muted', text: `Expires on day ${decision.expiresOnDay}.` }),
          ),
          button('Decide', () => showDecision(ctx, decision), 'btn primary'),
        ),
      );
    }
    el.appendChild(panel);
  }

  // --------------------------------------------------------------- feed
  const feedHost = h('div', {});
  const filterRow = h('div', { class: 'filter-row' });

  const renderFeed = (): void => {
    clear(feedHost);
    const items = recentNews(state, 40, filter === 'all' ? undefined : filter);
    if (items.length === 0) {
      feedHost.appendChild(
        empty(
          state.day <= 1
            ? 'Nothing has happened yet. Let the clock run and the city will start reporting.'
            : 'Nothing in this category yet.',
        ),
      );
      return;
    }
    for (const item of items) {
      const cal = calendar(item.day);
      feedHost.appendChild(
        h(
          'article',
          { class: `news-item${item.importance === 'high' ? ' hot' : ''}` },
          h('span', { class: 'news-icon', text: NEWS_ICONS[item.category] }),
          h(
            'div',
            { style: 'flex:1;min-width:0' },
            h(
              'div',
              { class: 'news-meta' },
              h('span', { class: 'news-category', text: NEWS_LABELS[item.category] }),
              h('span', { text: `Day ${item.day} · ${cal.weekday} ${clockLabel(item.hour)}` }),
            ),
            h('div', { class: 'news-headline', text: item.headline }),
            h('div', { class: 'news-body', text: item.body }),
            item.businessId
              ? h(
                  'button',
                  {
                    class: 'btn small ghost',
                    style: 'margin-top:6px',
                    on: { click: () => ctx.go('businesses', { business: item.businessId as string }) },
                  },
                  'Open that business',
                )
              : null,
          ),
        ),
      );
    }
  };

  for (const option of FILTERS) {
    filterRow.appendChild(
      h(
        'button',
        {
          class: `map-mode${option.id === filter ? ' active' : ''}`,
          data: { filter: option.id },
          on: {
            click: () => {
              filter = option.id;
              for (const child of Array.from(filterRow.children)) {
                const el2 = child as HTMLElement;
                el2.className = `map-mode${el2.dataset.filter === filter ? ' active' : ''}`;
              }
              renderFeed();
            },
          },
        },
        option.label,
      ),
    );
  }

  const feed = section('The feed');
  feed.appendChild(filterRow);
  feed.appendChild(feedHost);
  el.appendChild(feed);
  renderFeed();

  return { el };
}
