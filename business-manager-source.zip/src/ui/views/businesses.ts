import type { Ctx, View } from '../app';
import type { Business } from '../../sim/types';
import { businessById, employeesOf, playerBusinesses } from '../../sim/state';
import { businessTypeOrThrow } from '../../data/businessTypes';
import { product } from '../../data/products';
import { district } from '../../data/districts';
import { role } from '../../data/roles';
import {
  closeBusiness,
  grossMargin,
  hourlyCapacity,
  openBusiness,
  setHours,
  setMarketingBudget,
  setPrice,
  shutDownBusiness,
  storageUsed,
} from '../../sim/business';
import { attractiveness, estimateDailyCustomers, priceIndex, rivalsOf } from '../../sim/demand';
import { staffPower } from '../../sim/employees';
import { marketShare } from '../../sim/demand';
import { count, money, moneyCents, moneySigned, pct } from '../../sim/format';
import { clamp, sum } from '../../sim/util';
import { bar, button, confirmDialog, empty, h, hint, numberInput, section, severityTile, stat, statWithHint, table, toast } from '../dom';
import { DRIVER_LABELS, reviewsFor, topComplaint } from '../../sim/reviews';
import { adviceFor } from '../../sim/advice';
import { SEGMENTS, basketFactor, districtMix, leadingSegment, normaliseMix } from '../../sim/segments';
import type { OrgNode } from '../../sim/staffing';
import {
  SIZES,
  departmentsOf,
  findings,
  managementFactor,
  nextSize,
  opportunities,
  orgChart,
  sizeOf,
  staffingSummary,
  supervisionCapacity,
  supervisionLoad,
} from '../../sim/staffing';
import { fitLabel, gradeOf, titleOf } from '../../sim/skills';

export function businessesView(ctx: Ctx): View {
  const el = h('div', { class: 'view' });
  const state = ctx.state;
  const businesses = playerBusinesses(state);

  el.appendChild(
    h(
      'div',
      { class: 'view-head' },
      h('h1', { text: 'Businesses' }),
      h('p', { text: `${businesses.length} location${businesses.length === 1 ? '' : 's'}` }),
    ),
  );

  if (businesses.length === 0) {
    el.appendChild(
      section(
        'No businesses yet',
        empty('Find premises on the map first, then create a business in the unit you have taken on.'),
        h('div', { class: 'btn-row' }, button('Open the map', () => ctx.go('map'), 'btn primary')),
      ),
    );
    return { el };
  }

  const selectedId = ctx.params.business ?? businesses[0].id;
  const selected = businessById(state, selectedId) ?? businesses[0];

  const list = h('div', { class: 'list', style: 'margin-bottom:14px' });
  for (const business of businesses) {
    const type = businessTypeOrThrow(business.typeId);
    const building = state.buildings.find((b) => b.id === business.buildingId);
    const yesterday = business.yesterday;
    const profit =
      yesterday.revenue -
      (yesterday.cogs + yesterday.wages + yesterday.rent + yesterday.marketing + yesterday.otherCosts);
    list.appendChild(
      h(
        'div',
        {
          class: `card clickable${business.id === selected.id ? '' : ''}`,
          style: business.id === selected.id ? 'border-color:var(--accent-2)' : '',
          on: { click: () => ctx.go('businesses', { business: business.id }) },
        },
        h(
          'div',
          { class: 'card-head' },
          h(
            'div',
            {},
            h('div', { class: 'card-title', text: `${type.icon} ${business.name}` }),
            h('div', {
              class: 'card-sub',
              text: `${building?.address ?? ''} · ${building ? district(building.district).name : ''}`,
            }),
          ),
          h('span', {
            class: `tag ${business.status === 'open' ? 'good' : business.status === 'setup' ? 'warn' : ''}`,
            text: business.status === 'setup' ? 'Not open' : business.status,
          }),
        ),
        h(
          'div',
          { style: 'display:flex;gap:16px;flex-wrap:wrap;font-size:12px' },
          h('span', { class: 'muted', text: `Today: ${money(business.today.revenue)}` }),
          h('span', { class: 'muted', text: `Customers: ${count(business.today.customers)}` }),
          h('span', {
            class: profit >= 0 ? 'good' : 'bad',
            text: `Yesterday: ${moneySigned(profit)}`,
          }),
        ),
      ),
    );
  }
  el.appendChild(list);
  el.appendChild(detailPanel(ctx, selected));

  return { el };
}

function detailPanel(ctx: Ctx, business: Business): HTMLElement {
  const state = ctx.state;
  const type = businessTypeOrThrow(business.typeId);
  const building = state.buildings.find((b) => b.id === business.buildingId);
  const staff = employeesOf(state, business.id);
  const power = staffPower(state, business);
  const host = h('div', {});

  // ------------------------------------------------------------ header
  const actions = h('div', { class: 'btn-row' });
  if (business.status === 'open') {
    actions.appendChild(
      button('Close temporarily', () => {
        const result = closeBusiness(state, business.id);
        toast(result.message, 'info');
        ctx.refresh();
      }),
    );
  } else {
    actions.appendChild(
      button(
        'Open for business',
        () => {
          const result = openBusiness(state, business.id);
          toast(result.message, result.ok ? 'good' : 'bad');
          if (result.ok) {
            if (state.speed === 0) ctx.engine.setSpeed(2);
            ctx.refresh();
          }
        },
        'btn primary',
      ),
    );
  }
  actions.appendChild(button('Order stock', () => ctx.go('inventory', { business: business.id })));
  actions.appendChild(button('Hire staff', () => ctx.go('employees', { business: business.id })));
  if (building) actions.appendChild(button('Show on map', () => ctx.go('map', { building: building.id })));
  actions.appendChild(
    button(
      'Shut down',
      async () => {
        const ok = await confirmDialog(
          'Shut this business down?',
          `Staff are paid off, remaining stock is cleared at half its cost, and ${business.name} is gone for good. The premises stay yours.`,
          'Shut it down',
        );
        if (!ok) return;
        const result = shutDownBusiness(state, business.id);
        toast(result.message, 'info');
        ctx.go('businesses');
      },
      'btn danger',
    ),
  );

  host.appendChild(
    section(
      'Overview',
      h(
        'div',
        { class: 'grid cols-3' },
        h(
          'div',
          {},
          stat('Type', type.name),
          stat('Location', building?.address ?? '—'),
          stat('District', building ? district(building.district).name : '—'),
          stat('Opened', business.openedOnDay > 0 ? `Day ${business.openedOnDay}` : 'Not yet'),
        ),
        h(
          'div',
          {},
          statWithHint(
            'Reputation',
            `${Math.round(business.reputation)}/100`,
            'How well regarded the business is. It follows your review scores over time and feeds straight back into how many people walk in.',
          ),
          stat('Reviews', `${business.reviewScore.toFixed(1)}★ (${count(business.reviewCount)})`),
          statWithHint(
            'Service quality',
            `${Math.round(business.serviceQuality)}/100`,
            'How well the place is being run right now: the skill, morale and number of people on the floor today. It moves reviews within days.',
            business.serviceQuality < 45 ? 'bad' : undefined,
          ),
          statWithHint(
            'Awareness',
            pct(business.awareness),
            'The share of the district that knows this business exists. It grows slowly from customers who have been in, and quickly from marketing.',
          ),
        ),
        h(
          'div',
          {},
          stat('Staff', `${staff.length}`),
          stat('Can serve', `${Math.round(hourlyCapacity(state, business))}/hour`),
          stat('Market share', pct(marketShare(state, business.id) * 100, 1)),
          stat('Gross margin', pct(grossMargin(business) * 100)),
        ),
      ),
      actions,
    ),
  );

  // ------------------------------------------------------------ the team
  // Everything a manager needs to see about the people here, in one place:
  // how many the trade needs, how many there are, who is doing what, and what
  // is wrong with it.
  host.appendChild(managementPanel(ctx, business));

  // ----------------------------------------------------------- diagnosis
  const notes = adviceFor(state, business);
  if (notes.length > 0) {
    const panel = section('What is holding this back');
    for (const item of notes.slice(0, 4)) {
      panel.appendChild(
        h(
          'button',
          {
            class: `advice-row ${item.severity} clickable-row`,
            on: { click: () => ctx.go(item.route, item.params) },
          },
          severityTile(item.severity),
          h(
            'div',
            { style: 'flex:1;min-width:0;text-align:left' },
            h('div', { class: 'advice-headline', text: item.headline }),
            h('div', { class: 'advice-detail', text: item.detail }),
            h('div', { class: 'advice-action', text: `\u2192 ${item.action}` }),
          ),
          h('span', { class: 'row-chevron', text: '\u203a' }),
        ),
      );
    }
    host.appendChild(panel);
  } else if (business.status === 'open') {
    host.appendChild(
      section(
        'What is holding this back',
        h('p', { class: 'tiny muted', text: 'Nothing. Stock, staffing, pricing and reputation all look healthy here.' }),
      ),
    );
  }

  // ------------------------------------------------------- today / yesterday
  const today = business.today;
  const yesterday = business.yesterday;
  const yesterdayProfit =
    yesterday.revenue - (yesterday.cogs + yesterday.wages + yesterday.rent + yesterday.marketing + yesterday.otherCosts);

  host.appendChild(
    h(
      'div',
      { class: 'grid cols-2' },
      section(
        'Today so far',
        stat('Customers served', count(today.customers)),
        stat('Turned away', count(today.lostCustomers), today.lostCustomers > today.customers * 0.15 ? 'bad' : 'muted'),
        stat('Revenue', money(today.revenue)),
        stat('Units sold', count(today.units)),
      ),
      section(
        'Yesterday',
        stat('Revenue', money(yesterday.revenue)),
        stat('Cost of goods', money(-yesterday.cogs)),
        stat('Wages', money(-yesterday.wages)),
        stat('Rent & utilities', money(-(yesterday.rent + yesterday.otherCosts))),
        stat('Marketing', money(-yesterday.marketing)),
        stat('Profit', moneySigned(yesterdayProfit), yesterdayProfit >= 0 ? 'good' : 'bad'),
      ),
    ),
  );

  // -------------------------------------------------------------- pricing
  if (type.productIds.length > 0) {
    const rows = type.productIds.map((productId) => {
      const def = product(productId);
      if (!def) return [];
      const price = business.prices[productId] ?? def.marketPrice;
      const cost = business.costBasis[productId] ?? def.wholesalePrice;
      const margin = price > 0 ? (price - cost) / price : 0;
      const input = numberInput(
        Number(price.toFixed(2)),
        (value) => {
          setPrice(state, business.id, productId, value);
          ctx.refresh();
        },
        { step: '0.05', min: '0.05' },
      );
      return [
        def.name,
        moneyCents(cost),
        input,
        h('span', { class: margin < 0.1 ? 'bad' : margin > 0.4 ? 'good' : '', text: pct(margin * 100) }),
        count(business.stock[productId] ?? 0),
        count(business.incoming[productId] ?? 0),
      ];
    });

    host.appendChild(
      section(
        'Products and pricing',
        table(['Product', 'Cost', 'Your price', 'Margin', 'In stock', 'On order'], rows),
        priceAnalysis(ctx, business),
      ),
    );
  } else {
    const fee = business.prices.service ?? type.serviceFee;
    host.appendChild(
      section(
        'Service pricing',
        h(
          'label',
          { class: 'field' },
          h('span', { text: 'Fee per job' }),
          numberInput(Number(fee.toFixed(2)), (value) => {
            setPrice(state, business.id, 'service', value);
            ctx.refresh();
          }, { step: '1', min: '1' }),
        ),
        priceAnalysis(ctx, business),
      ),
    );
  }

  // ---------------------------------------------------------- the crowd
  host.appendChild(crowdPanel(ctx, business));

  // ------------------------------------------------------------- reviews
  host.appendChild(reviewPanel(ctx, business));

  // ------------------------------------------------- competitive position
  host.appendChild(competitivePanel(ctx, business));

  // ----------------------------------------------------- staff & settings
  const staffRows = staff.map((employee) => [
    employee.name,
    role(employee.role).name,
    `${Math.round(employee.skill)}`,
    `${Math.round(employee.morale)}`,
    money(employee.salary),
  ]);

  host.appendChild(
    h(
      'div',
      { class: 'grid cols-2' },
      section(
        'Team',
        staff.length === 0
          ? empty('Nobody works here yet. Without staff you can serve about four customers an hour yourself.')
          : table(['Name', 'Role', 'Skill', 'Morale', 'Salary'], staffRows),
        h('p', {
          class: 'tiny muted',
          text: `Present today: ${power.present} of ${power.headcount}. Capacity ${Math.round(hourlyCapacity(state, business))} customers/hour.`,
        }),
        h('div', { class: 'btn-row' }, button('Manage staff', () => ctx.go('employees', { business: business.id }))),
      ),
      section(
        'Operations',
        h(
          'label',
          { class: 'field' },
          h('span', { text: 'Opening hour' }),
          numberInput(business.openFrom, (value) => {
            setHours(state, business.id, value, business.openTo);
            ctx.refresh();
          }, { min: '0', max: '23', step: '1' }),
        ),
        h(
          'label',
          { class: 'field' },
          h('span', { text: 'Closing hour' }),
          numberInput(business.openTo, (value) => {
            setHours(state, business.id, business.openFrom, value);
            ctx.refresh();
          }, { min: '1', max: '24', step: '1' }),
        ),
        h(
          'label',
          { class: 'field' },
          h('span', { text: 'Marketing budget per day' }),
          numberInput(business.marketingBudget, (value) => {
            setMarketingBudget(state, business.id, value);
            ctx.refresh();
          }, { min: '0', step: '10' }),
        ),
        building
          ? stat(
              'Storage used',
              `${Math.round(storageUsed(business))} / ${count(building.storageCapacity)}`,
              storageUsed(business) > building.storageCapacity * 0.9 ? 'bad' : undefined,
            )
          : null,
        h('p', {
          class: 'tiny muted',
          text: 'Longer hours reach more customers but cost more in wages. Marketing raises awareness, which fades if you stop.',
        }),
      ),
    ),
  );

  return host;
}

/** What customers are actually saying, and what they complain about most. */
function reviewPanel(ctx: Ctx, business: Business): HTMLElement {
  const reviews = reviewsFor(ctx.state, business.id, 6);
  const complaint = topComplaint(ctx.state, business.id);
  const panel = section('Customer reviews');

  panel.appendChild(
    h(
      'div',
      { class: 'review-summary' },
      h('div', { class: 'review-score', text: business.reviewScore.toFixed(1) }),
      h(
        'div',
        {},
        h('div', { class: 'review-stars', text: stars(business.reviewScore) }),
        h('div', { class: 'tiny muted', text: `${business.reviewCount.toLocaleString('en-GB')} reviews` }),
        complaint
          ? h('div', {
              class: 'tiny bad',
              text: `Most common complaint: ${DRIVER_LABELS[complaint.driver]} (${complaint.count} of the last few).`,
            })
          : null,
      ),
    ),
  );

  if (reviews.length === 0) {
    panel.appendChild(empty('Nobody has left a review yet. Serve a few more customers.'));
    return panel;
  }
  for (const review of reviews) {
    panel.appendChild(
      h(
        'div',
        { class: 'review-row' },
        h('span', { class: `review-row-stars${review.stars >= 4 ? ' good' : review.stars <= 2 ? ' bad' : ''}`, text: stars(review.stars) }),
        h(
          'div',
          { style: 'flex:1;min-width:0' },
          h('div', { class: 'review-text', text: `“${review.text}”` }),
          h('div', { class: 'tiny muted', text: `Day ${review.day} · on ${DRIVER_LABELS[review.driver]}` }),
        ),
      ),
    );
  }
  return panel;
}

function stars(score: number): string {
  const filled = Math.max(0, Math.min(5, Math.round(score)));
  return '★'.repeat(filled) + '☆'.repeat(5 - filled);
}

/** Estimated demand at different price points — the pricing analytics from §32. */
/**
 * The management overview.
 *
 * Staffing against what the trade actually needs, the departments the place has
 * grown, and a plain list of what is wrong and what would help — all read from
 * the same figures the simulation runs on, so the panel cannot disagree with
 * the shop it is describing.
 */
function managementPanel(ctx: Ctx, business: Business): HTMLElement {
  const state = ctx.state;
  const plan = staffingSummary(state, business);
  const panel = section(`The team — ${plan.size.name.toLowerCase()} business`);

  panel.appendChild(
    h(
      'div',
      { class: 'grid cols-4' },
      statWithHint(
        'People',
        `${plan.current}`,
        'Everybody on the payroll at this location.',
      ),
      statWithHint(
        'The trade needs',
        `${plan.required}`,
        'How many it takes to serve the customers this shop is actually getting, at the pace one person works and the hours the doors are open.',
        plan.shortage > 0 ? 'bad' : undefined,
      ),
      statWithHint(
        'Comfortable at',
        `${plan.recommended}`,
        'Enough to cover peaks, holidays and somebody being off sick without turning customers away.',
      ),
      statWithHint(
        'Workload',
        `${Math.round(plan.workload)}%`,
        'How hard the team was worked yesterday. Above eighty they start making mistakes, getting ill, and leaving.',
        plan.workload > 82 ? 'bad' : plan.workload < 45 ? 'muted' : undefined,
      ),
    ),
  );

  const rows = h('div', { style: 'margin-top:10px' });
  for (const row of plan.rows) {
    const short = row.current < row.required;
    const spare = row.current > row.recommended;
    rows.appendChild(
      h(
        'div',
        { class: 'staff-row' },
        severityTile(short ? 'bad' : spare ? 'warn' : 'good', 'finding-dot'),
        h(
          'div',
          { style: 'flex:1;min-width:0' },
          h('div', { class: 'staff-name', text: row.name }),
          h('div', {
            class: 'sub',
            text: row.fit === null ? 'nobody in the seat' : `${fitLabel(row.fit)} — fit ${Math.round(row.fit)}/100`,
          }),
        ),
        h('span', { class: 'staff-count', text: `${row.current} of ${row.required} · ${row.recommended} ideal` }),
        h('span', {
          class: `staff-gap ${short ? 'bad' : spare ? 'warn' : 'good'}`,
          text: short ? `${row.required - row.current} short` : spare ? `${row.current - row.recommended} spare` : 'covered',
        }),
      ),
    );
  }
  panel.appendChild(rows);

  // ------------------------------------------------------- where it has got to
  // Scale is not "the same shop, bigger": each step is a different job, and the
  // strip says which one this is and what the next one asks for.
  const size = sizeOf(state, business);
  const bigger = nextSize(size);
  const scale = h('div', { class: 'scale-strip' });
  for (const step of SIZES) {
    scale.appendChild(
      h(
        'div',
        { class: `scale-step${step.id === size.id ? ' here' : ''}${step.from <= size.from ? ' reached' : ''}` },
        h('span', { class: 'scale-name', text: step.name }),
        h('span', { class: 'scale-from', text: step.from === 0 ? 'from 1' : `from ${step.from}` }),
        h('span', { class: 'scale-bar' }),
      ),
    );
  }
  panel.appendChild(h('div', { class: 'sub', style: 'margin-top:14px', text: 'Where this business has got to' }));
  panel.appendChild(scale);
  panel.appendChild(
    h('p', {
      class: 'tiny muted',
      style: 'margin:6px 0 0',
      text: bigger
        ? `${size.detail} ${Math.max(1, bigger.from - plan.current)} more ${bigger.from - plan.current === 1 ? 'person' : 'people'} and this is a ${bigger.name.toLowerCase()} business — which is not this one several times over. ${bigger.detail}`
        : `${size.detail} There is nothing bigger than this.`,
    }),
  );

  // ------------------------------------------- management, by span of control
  const load = supervisionLoad(state, business);
  const capacity = supervisionCapacity(state, business);
  const cover = plan.managementCover;
  panel.appendChild(h('div', { class: 'sub', style: 'margin-top:14px', text: 'Management cover' }));
  panel.appendChild(bar(Math.min(1, cover), cover >= 1 ? 'good' : cover > 0.6 ? 'warn' : 'bad'));
  panel.appendChild(
    h('p', {
      class: 'tiny muted',
      style: 'margin:6px 0 0',
      text:
        load <= 0
          ? 'Nobody here needs managing yet — you are the management, which is exactly what a small business is.'
          : `${Math.round(load)} ${Math.round(load) === 1 ? 'person needs' : 'people need'} managing, weighted by who they are, and the grades on this payroll cover about ${Math.round(capacity)}. A Team Lead covers 5, a Manager 11, an Executive 34.${
              cover < 1 ? ` Everything still happens, about ${Math.round((1 - managementFactor(state, business)) * 100)}% slower.` : ''
            }`,
    }),
  );

  // --------------------------------------------------------- who answers to whom
  const chart = orgChart(state, business);
  if (chart.length > 0 && plan.current > 1) {
    panel.appendChild(h('div', { class: 'sub', style: 'margin-top:14px', text: 'Who answers to whom' }));
    const tree = h('div', { class: 'org-tree' });
    const draw = (node: OrgNode, depth: number): void => {
      const grade = gradeOf(node.person);
      tree.appendChild(
        h(
          'div',
          { class: `org-node depth-${Math.min(depth, 3)}${depth === 0 ? ' top' : ''}` },
          h('span', { class: 'org-name', text: node.person.name }),
          h('span', {
            class: 'org-role',
            text: grade.span > 0 ? `${titleOf(node.person)} · covers ${grade.span}` : titleOf(node.person),
          }),
        ),
      );
      for (const child of node.reports) draw(child, depth + 1);
    };
    for (const root of chart) draw(root, 0);
    panel.appendChild(tree);
    panel.appendChild(
      h('p', {
        class: 'tiny muted',
        style: 'margin:6px 0 0',
        text: 'Read from grade and department rather than stored, so the chart can never disagree with the payroll. Promote somebody and it changes — there is nothing here to drag about.',
      }),
    );
  }

  const departments = departmentsOf(state, business);
  if (departments.length > 0) {
    panel.appendChild(h('div', { class: 'sub', style: 'margin-top:12px', text: 'Departments' }));
    for (const row of departments) {
      panel.appendChild(
        h(
          'div',
          { class: 'staff-row' },
          h('div', { style: 'flex:1;min-width:0' },
            h('div', { class: 'staff-name', text: row.name }),
            h('div', { class: 'sub', text: row.detail })),
          h('span', { class: 'staff-count', text: `${row.people.length} · ${money(row.payroll)}/mo` }),
          h('span', {
            class: `staff-gap ${row.performance > 66 ? 'good' : row.performance < 42 ? 'bad' : ''}`,
            text: `${Math.round(row.performance)}%`,
          }),
        ),
      );
    }
  }

  const problems = findings(state, business);
  const chances = opportunities(state, business);
  if (problems.length > 0 || chances.length > 0) {
    panel.appendChild(h('div', { class: 'sub', style: 'margin-top:12px', text: 'What to do about it' }));
    for (const item of [...problems, ...chances]) {
      panel.appendChild(
        h(
          'div',
          { class: 'finding' },
          severityTile(item.level, 'finding-dot'),
          h('div', { style: 'flex:1;min-width:0' },
            h('div', { class: 'finding-title', text: item.title }),
            h('div', { class: 'sub', text: item.detail })),
        ),
      );
    }
  }

  panel.appendChild(
    h('div', { class: 'row', style: 'margin-top:10px' },
      button('Manage the people here', () => ctx.go('employees', { business: business.id }), 'btn primary')),
  );
  return panel;
}

function priceAnalysis(ctx: Ctx, business: Business): HTMLElement {
  const state = ctx.state;
  const type = businessTypeOrThrow(business.typeId);
  const steps = [0.8, 0.9, 1, 1.1, 1.25, 1.5];
  const current = priceIndex(business);

  const rows = steps.map((factor) => {
    const overrides: Record<string, number> = {};
    for (const productId of type.productIds) {
      const def = product(productId);
      if (!def) continue;
      overrides[productId] = (business.prices[productId] ?? def.marketPrice) * factor;
    }
    if (type.serviceFee > 0) {
      overrides.service = (business.prices.service ?? type.serviceFee) * factor;
    }
    const customers = estimateDailyCustomers(state, business, overrides);
    // Revenue per customer moves with the price change.
    const perCustomer = revenuePerCustomer(business, factor);
    const cogs = costPerCustomer(business);
    const gross = customers * (perCustomer - cogs);
    return {
      factor,
      customers,
      revenue: customers * perCustomer,
      gross,
    };
  });

  const best = rows.reduce((a, b) => (b.gross > a.gross ? b : a), rows[0]);

  return h(
    'div',
    {},
    h('h4', { class: 'panel-title', style: 'margin-top:14px', text: 'What happens if you change price' }),
    table(
      ['Price', 'Est. customers/day', 'Est. revenue/day', 'Est. gross profit/day'],
      rows.map((row) => [
        h('span', {
          class: row.factor === 1 ? 'tag accent' : '',
          text: row.factor === 1 ? 'Current' : `${row.factor > 1 ? '+' : ''}${Math.round((row.factor - 1) * 100)}%`,
        }),
        count(row.customers),
        money(row.revenue),
        h('span', { class: row === best ? 'good' : '', text: money(row.gross) }),
      ]),
    ),
    h('p', {
      class: 'tiny muted',
      text: `You are currently charging ${Math.round(current * 100)}% of the market price. These are estimates at today's demand; competitors will react to a big move.`,
    }),
  );
}

function revenuePerCustomer(business: Business, factor: number): number {
  const type = businessTypeOrThrow(business.typeId);
  let total = type.serviceFee > 0 ? (business.prices.service ?? type.serviceFee) * factor : 0;
  const defs = type.productIds.map((id) => product(id)).filter((d): d is NonNullable<typeof d> => Boolean(d));
  const appeal = sum(defs, (d) => d.appeal);
  if (appeal <= 0) return total;
  for (const def of defs) {
    const price = (business.prices[def.id] ?? def.marketPrice) * factor;
    total += (def.appeal / appeal) * def.unitsPerBasket * price;
  }
  return total;
}

function costPerCustomer(business: Business): number {
  const type = businessTypeOrThrow(business.typeId);
  const defs = type.productIds.map((id) => product(id)).filter((d): d is NonNullable<typeof d> => Boolean(d));
  const appeal = sum(defs, (d) => d.appeal);
  if (appeal <= 0) return 0;
  let total = 0;
  for (const def of defs) {
    const cost = business.costBasis[def.id] ?? def.wholesalePrice;
    total += (def.appeal / appeal) * def.unitsPerBasket * cost;
  }
  return total;
}

/** Why this business is winning or losing against the businesses next door. */
function competitivePanel(ctx: Ctx, business: Business): HTMLElement {
  const state = ctx.state;
  const own = attractiveness(state, business);
  const rivals = rivalsOf(state, business);
  const panel = section('Competitive position');

  panel.appendChild(
    h('p', {
      class: 'tiny muted',
      text:
        rivals.length === 0
          ? 'Nobody else in this district sells what you sell. Enjoy it while it lasts.'
          : `${rivals.length} rival${rivals.length === 1 ? '' : 's'} compete for the same customers here.`,
    }),
  );

  for (const factor of own.factors) {
    const relative = clamp(factor.value / 2, 0, 1);
    panel.appendChild(
      h(
        'div',
        { style: 'margin:8px 0' },
        h(
          'div',
          { style: 'display:flex;justify-content:space-between;font-size:12px;margin-bottom:3px' },
          h('span', { text: factor.label }),
          h('span', { class: 'muted', text: factor.hint }),
        ),
        bar(relative, factor.value >= 1.05 ? 'good' : factor.value < 0.85 ? 'bad' : ''),
      ),
    );
  }

  if (rivals.length > 0) {
    panel.appendChild(
      table(
        ['Competitor', 'Owner', 'Price level', 'Reviews', 'Pull'],
        rivals.map((rival) => {
          const owner = state.companies.find((c) => c.id === rival.companyId);
          const score = attractiveness(state, rival).score;
          const total = own.score + sum(rivals, (r) => attractiveness(state, r).score);
          return [
            rival.name,
            owner?.name ?? '—',
            pct(priceIndex(rival) * 100),
            `${rival.reviewScore.toFixed(1)}★`,
            pct((score / Math.max(0.0001, total)) * 100),
          ];
        }),
      ),
    );
  }

  return panel;
}

/**
 * Who actually comes through the door, and what each group wants. The mix is
 * measured from the customers the demand model handed this business yesterday,
 * so it changes when the shop, its prices or its hours change.
 */
function crowdPanel(ctx: Ctx, business: Business): HTMLElement {
  const state = ctx.state;
  const building = state.buildings.find((b) => b.id === business.buildingId);
  const type = businessTypeOrThrow(business.typeId);
  const panel = section('Who comes in');

  const served = normaliseMix(business.yesterdayMix);
  const total = SEGMENTS.reduce((acc, s) => acc + served[s.id], 0);
  const catchment = building ? districtMix(district(building.district), type.category) : null;

  if (total <= 0) {
    panel.appendChild(
      empty(
        catchment
          ? `Nobody yesterday. The district around you is mostly ${leadingSegment(catchment).name.toLowerCase()}.`
          : 'Nobody yesterday.',
      ),
    );
  }

  for (const seg of SEGMENTS) {
    const share = served[seg.id] ?? 0;
    const local = catchment ? catchment[seg.id] : 0;
    if (share < 0.01 && local < 0.04) continue;
    panel.appendChild(
      h(
        'div',
        { style: 'margin:9px 0' },
        h(
          'div',
          { style: 'display:flex;justify-content:space-between;font-size:12px;margin-bottom:3px;gap:10px' },
          h('span', {}, seg.name, hint(seg.description)),
          h('span', {
            class: share > local * 1.15 ? 'good' : share < local * 0.85 ? 'bad' : 'muted',
            text: `${pct(share * 100)} of your customers · ${pct(local * 100)} of the district`,
          }),
        ),
        bar(share, share > local * 1.15 ? 'good' : share < local * 0.85 ? 'bad' : ''),
      ),
    );
  }

  if (total > 0) {
    const lead = leadingSegment(served);
    const spend = basketFactor(served);
    panel.appendChild(
      h('p', {
        class: 'tiny muted',
        style: 'margin-top:10px',
        text: `Mostly ${lead.name.toLowerCase()}. ${lead.description} This crowd spends about ${pct(spend * 100)} of what an average Northgate customer does, which is already in your takings.`,
      }),
    );
  }
  if (catchment) {
    const missing = SEGMENTS.filter((seg) => catchment[seg.id] > 0.12 && (served[seg.id] ?? 0) < catchment[seg.id] * 0.6);
    if (missing.length > 0 && total > 0) {
      panel.appendChild(
        h('p', {
          class: 'tiny bad',
          text: `You are under-trading with ${missing.map((m) => m.name.toLowerCase()).join(' and ')} compared with who lives here. Opening hours, price and the state of the place are what decide that.`,
        }),
      );
    }
  }
  return panel;
}
