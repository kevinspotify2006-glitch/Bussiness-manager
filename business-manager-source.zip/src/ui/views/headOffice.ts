import type { Ctx, View } from '../app';
import type { Employee } from '../../sim/types';
import {
  AUTOMATION_TIERS,
  FUNCTIONS,
  HQ_LEVELS,
  STANCES,
  canAutomate,
  canOpenHeadOffice,
  centralStaff,
  closeHeadOffice,
  coverNeeded,
  functionStates,
  hireToHeadOffice,
  openHeadOffice,
  outsourceCost,
  outsourcingBill,
  setOutsourced,
  hqLevel,
  investInAutomation,
  nextHqLevel,
  overheadBill,
  setStance,
  stanceOf,
  upgradeHeadOffice,
  hqArea,
  relocateHeadOffice,
  relocationCost,
  relocationOptions,
  HQ_FIT_OUT,
} from '../../sim/headOffice';
import { buildingById, playerBusinesses, playerCompany } from '../../sim/state';
import { performanceOf, roleFit } from '../../sim/skills';
import { money } from '../../sim/format';
import { bar, button, confirmDialog, empty, h, keepingScroll, kpi, meter, section, select, stat, table, tag, toast } from '../dom';
import { appoint, officerRows, officerPremiums, vacate } from '../../sim/executives';
import { policyRows, setPolicy } from '../../sim/policies';
import {
  MAX_OUTSIDE_STAKE,
  buyBack,
  buybackCost,
  canRaise,
  confidenceRows,
  outsideStake,
  ownersStake,
  priceForShare,
  raiseEquity,
  register,
} from '../../sim/board';
import { attentionOf, ownerAttention } from '../../sim/holding';
import {
  activeProject,
  cancelProject,
  desksLeft,
  desksTotal,
  desksUsed,
  facilitiesBill,
  facilityOrThrow,
  facilityRows,
  hasBoard,
  startProject,
  utilisation,
  utilisationPenalty,
} from '../../sim/facilities';

/**
 * The head office.
 *
 * One screen that answers the only question it exists to answer: which central
 * functions does this company have, how well are they covered, what is that
 * costing, and what is it worth. Every function says what it does in the same
 * words the effect works in, so the player can tell whether it is paying.
 */
export function headOfficeView(ctx: Ctx): View {
  const el = h('div', { class: 'view' });

  const render = (): void => {
    el.replaceChildren();
    const state = ctx.state;
    const hq = state.headOffice;

    el.appendChild(
      h(
        'div',
        { class: 'view-head' },
        h('h1', { text: hq ? hq.name : 'Head office' }),
        h('p', {
          text: hq
            ? 'Personnel, the books, the brand and the systems, run once for the whole company.'
            : 'Three shops do not need three personnel departments. This is where you stop paying for that.',
        }),
      ),
    );

    if (!hq) {
      renderOpening(ctx, el);
      return;
    }

    const building = buildingById(state, hq.buildingId);
    const staff = centralStaff(state);
    const states = functionStates(state);
    const locations = playerBusinesses(state).filter((b) => b.status === 'open').length;

    const floor = hqLevel(state);
    const next = nextHqLevel(state);

    el.appendChild(
      section(
        'Overview',
        h(
          'div',
          { class: 'grid cols-4' },
          stat('Address', building?.address ?? '—'),
          stat('Desks', `${staff.length} of ${floor.desks} taken`, staff.length >= floor.desks ? 'bad' : undefined),
          stat('Supporting', `${locations} location${locations === 1 ? '' : 's'}`),
          // Management capacity said as a figure rather than left implicit in
          // how badly things are going. It is the same number the simulation
          // charges against, not a second one computed for the screen.
          stat(
            'Management capacity',
            `${locations} of ${attentionOf(state).toFixed(1)}`,
            ownerAttention(state) < 0.999 ? 'bad' : 'good',
          ),
          stat('Standing cost', `${money(overheadBill(state) + outsourcingBill(state) + officerPremiums(state))}/mo`),
        ),
      ),
    );

    // -------------------------------------------- how much head office there is
    const floors = section('How much head office there is');
    const strip = h('div', { class: 'scale-strip' });
    for (const step of HQ_LEVELS) {
      strip.appendChild(
        h(
          'div',
          { class: `scale-step${step.n === floor.n ? ' here' : ''}${step.n <= floor.n ? ' reached' : ''}` },
          h('span', { class: 'scale-name', text: step.name }),
          h('span', { class: 'scale-from', text: `${step.desks} desks` }),
          h('span', { class: 'scale-bar' }),
        ),
      );
    }
    floors.appendChild(strip);
    floors.appendChild(
      h('p', {
        class: 'tiny muted',
        style: 'margin:8px 0 0',
        text: next
          ? `${floor.detail} A ${next.name.toLowerCase()} costs ${money(next.upgrade)} to fit out and ${money(next.running)} a month to run — for ${next.desks} desks, ${Math.round((next.reach - 1) * 100)}% more out of the same people, and systems up to tier ${next.automationCap}. It needs about ${next.needsArea} m², and this building has ${hqArea(state)}.`
          : `${floor.detail} There is nothing above this.`,
      }),
    );
    if (next) {
      floors.appendChild(
        h(
          'div',
          { class: 'btn-row' },
          button(
            `Fit out a ${next.name.toLowerCase()} — ${money(next.upgrade)}`,
            () => {
              const result = upgradeHeadOffice(state);
              toast(result.message, result.ok ? 'good' : 'bad');
              keepingScroll(render);
            },
            // Offered as the obvious next thing only when it would actually
            // happen. A primary button that refuses is worse than a plain one.
            playerCompany(state).cash >= next.upgrade && hqArea(state) >= next.needsArea ? 'btn primary' : 'btn',
          ),
        ),
      );
    }

    // Somewhere to move to, when the floor the company wants does not fit in
    // the address it has. Everything comes with it; only the rent changes.
    const cramped = next !== null && hqArea(state) < next.needsArea;
    const options = relocationOptions(state);
    if (cramped || options.some((option) => option.ok)) {
      const move = h('div', { class: 'division-card', style: 'margin-top:12px' });
      move.appendChild(
        h(
          'div',
          { class: 'division-head' },
          h('span', { class: 'division-name', text: 'Move the head office' }),
          h('span', { class: 'division-lead', text: `${money(relocationCost(state))} to fit out` }),
        ),
      );
      move.appendChild(
        h('div', {
          class: cramped ? 'tiny warn' : 'sub',
          text: cramped
            ? `This building cannot hold a ${next.name.toLowerCase()}. Everybody and everything moves with you; the old premises stay yours until you end the lease or sell them.`
            : 'Everybody and everything moves with you. The old premises stay yours until you end the lease or sell them.',
        }),
      );
      if (options.length === 0) {
        move.appendChild(
          h('div', {
            class: 'tiny muted',
            text: 'You do not hold another empty unit. Rent or buy a larger one and it will appear here.',
          }),
        );
      } else {
        for (const option of options.slice(0, 6)) {
          move.appendChild(
            h(
              'div',
              { class: 'plan-row' },
              h(
                'div',
                { class: 'plan-main' },
                h('div', { class: 'plan-head' }, h('strong', { text: option.address })),
                h('div', { class: 'tiny muted', text: option.ok ? `${option.area} m²` : option.reason }),
              ),
              h(
                'div',
                { class: 'plan-when' },
                button(
                  'Move here',
                  async () => {
                    const ok = await confirmDialog(
                      'Move the head office?',
                      `${money(relocationCost(state))} to fit out ${option.address}. Everybody, every department and every room you have built comes with it.`,
                      'Move',
                    );
                    if (!ok) return;
                    const result = relocateHeadOffice(state, option.id);
                    toast(result.message, result.ok ? 'good' : 'bad');
                    keepingScroll(render);
                  },
                  option.ok ? 'btn small primary' : 'btn small',
                ),
              ),
            ),
          );
        }
      }
      floors.appendChild(move);
    }
    el.appendChild(floors);

    // ------------------------------------------------------------- the rooms
    // Departments are the jobs people do; these are the places. A room takes
    // months to build, takes desks for ever, costs a running bill whether or
    // not anybody uses it, and then permanently changes what the company can do.
    const rooms = section('What is in the building');
    const used = desksUsed(state);
    const total = desksTotal(state);
    const fit = utilisationPenalty(state);
    rooms.appendChild(
      h(
        'div',
        { class: 'grid cols-3' },
        kpi({
          label: 'Desks', value: `${used} of ${total}`, icon: 'hq',
          tone: 'accent',
          sub: `${Math.round(utilisation(state) * 100)}% of the building in use`,
        }),
        kpi({
          label: 'Room to build', value: String(desksLeft(state)), icon: 'plus',
          tone: desksLeft(state) > 0 ? 'good' : 'warn',
          sub: desksLeft(state) > 0 ? 'desks spare' : 'upgrade the building to make room',
          subTone: desksLeft(state) > 0 ? 'good' : 'warn',
        }),
        kpi({
          label: 'Rooms cost', value: `${money(facilitiesBill(state))}/mo`, icon: 'cash',
          tone: 'warn',
          sub: fit > 1 ? `and the building is ${Math.round((fit - 1) * 100)}% less efficient than it should be` : 'the building fits what is in it',
          subTone: fit > 1 ? 'warn' : 'good',
        }),
      ),
    );
    if (fit > 1) {
      rooms.appendChild(
        h('p', {
          class: 'warn',
          text:
            utilisation(state) < 0.5
              ? 'Most of this building is empty, and empty floors are rent for nothing. Either put something in it or move back down a size.'
              : 'People are working on top of each other. The next size up would pay for itself.',
        }),
      );
    }

    const project = activeProject(state);
    if (project) {
      const def = facilityOrThrow(project.facilityId);
      const card = h('div', { class: 'division-card' });
      card.appendChild(
        h(
          'div',
          { class: 'division-head' },
          h('span', { class: 'division-name', text: `Building the ${def.name.toLowerCase()}` }),
          h('span', { class: 'division-lead', text: `${project.days - project.daysDone} days left` }),
        ),
      );
      card.appendChild(bar(project.daysDone / project.days, 'good'));
      card.appendChild(
        h('div', {
          class: 'sub',
          style: 'margin-top:8px',
          text: `${money(project.spent)} of ${money(project.total)} paid, about ${money(Math.round(project.total / project.days))} a day. ${def.gives}`,
        }),
      );
      card.appendChild(
        h(
          'div',
          { class: 'btn-row' },
          button('Stop the work', () => {
            const result = cancelProject(state, project.id);
            toast(result.message, result.ok ? 'info' : 'bad');
            keepingScroll(render);
          }, 'btn small'),
        ),
      );
      rooms.appendChild(card);
    }

    for (const row of facilityRows(state)) {
      if (row.building) continue;
      const card = h('div', { class: 'division-card' });
      card.appendChild(
        h(
          'div',
          { class: 'division-head' },
          h('span', { class: 'division-name', text: row.def.name }),
          row.built
            ? tag('built', 'good')
            : h('span', { class: 'division-lead muted', text: `${money(row.def.cost)} · ${row.def.days} days · ${row.def.desks} desks` }),
        ),
      );
      card.appendChild(h('div', { class: 'sub', text: row.def.detail }));
      card.appendChild(h('div', { class: 'function-says', text: row.def.gives }));
      if (row.built) {
        card.appendChild(h('div', { class: 'tiny muted', text: `${money(row.def.running)} a month to run.` }));
      } else {
        card.appendChild(
          h(
            'div',
            { class: 'btn-row' },
            button(
              `Build it — ${money(row.def.cost)}`,
              () => {
                const result = startProject(state, row.def.id);
                toast(result.message, result.ok ? 'good' : 'bad');
                keepingScroll(render);
              },
              row.check.ok ? 'btn small primary' : 'btn small',
            ),
          ),
        );
        if (!row.check.ok && row.check.reason) {
          card.appendChild(h('div', { class: 'tiny warn', text: row.check.reason }));
        }
      }
      rooms.appendChild(card);
    }
    el.appendChild(rooms);

    // ------------------------------------------------------- who runs what
    // Departments are capacity; these are the people over them. A post only
    // exists once there is an executive floor to sit them on, and it is worth
    // what the person in it is worth.
    const suite = section('Who runs what');
    const rows = officerRows(state);
    suite.appendChild(
      h('p', {
        class: 'tiny muted',
        style: 'margin:0 0 10px',
        text: rows[0]?.available
          ? `Officers lead the departments you already have. They get more out of the same people — never more than a fifth more — and nothing at all out of a department with nobody in it.${officerPremiums(state) > 0 ? ` The posts you have filled cost ${money(officerPremiums(state))} a month on top of their salaries.` : ''}`
          : 'An executive floor is what a board of officers sits on. Build one and these posts open.',
      }),
    );
    for (const row of rows) {
      const card = h('div', { class: 'division-card' });
      card.appendChild(
        h(
          'div',
          { class: 'division-head' },
          h('span', { class: 'division-name', text: row.def.title }),
          row.person
            ? tag(row.person.name, 'good')
            : h('span', { class: 'division-lead muted', text: `${money(row.def.premium)}/mo` }),
        ),
      );
      card.appendChild(h('div', { class: 'sub', text: row.def.brief }));
      if (row.person) {
        card.appendChild(meter('How well they hold it', row.strength, `${Math.round(row.strength * 100)}%`, row.strength > 0.6 ? 'good' : row.strength > 0.35 ? 'warn' : 'bad'));
        card.appendChild(h('div', { class: 'function-says', text: row.effect }));
        card.appendChild(
          h(
            'div',
            { class: 'btn-row' },
            button('Take them out of the post', () => {
              const result = vacate(state, row.def.id);
              toast(result.message, result.ok ? 'info' : 'bad');
              keepingScroll(render);
            }, 'btn small'),
          ),
        );
      } else if (!row.available) {
        card.appendChild(h('div', { class: 'tiny warn', text: 'Needs an executive floor.' }));
      } else if (row.candidates.length === 0) {
        // Two different problems that look the same from here, and the player
        // can only act on the right one: nobody is senior enough yet, or
        // everybody who is has already been given a post.
        const taken = officerRows(state).some((other) => other.person !== null);
        card.appendChild(
          h('div', {
            class: 'tiny warn',
            text: taken
              ? 'Everybody in the head office senior enough for a post already holds one. You need another person at that level.'
              : 'Nobody in the head office is senior enough for this yet. Promote somebody, or hire in at a higher grade.',
          }),
        );
      } else {
        const picker = select(
          row.candidates.map((person) => ({
            value: person.id,
            label: `${person.name} — ${person.role} · ${Math.round(person.skills[row.def.skill] ?? 0)} ${row.def.skill}`,
          })),
          row.candidates[0].id,
          () => undefined,
        );
        card.appendChild(picker);
        card.appendChild(
          h(
            'div',
            { class: 'btn-row' },
            button(`Appoint — ${money(row.def.premium)}/mo more`, () => {
              const result = appoint(state, row.def.id, picker.value);
              toast(result.message, result.ok ? 'good' : 'bad');
              keepingScroll(render);
            }, 'btn small primary'),
          ),
        );
      }
      suite.appendChild(card);
    }
    el.appendChild(suite);

    // ---------------------------------------------------------- the rules
    // Set once, applied to every location. None of them costs money to change
    // and none of them is simply better than the others — what they cost is the
    // other side of the trade, and that lands in systems that already existed.
    const rules = section('How this company does things');
    rules.appendChild(
      h('p', {
        class: 'tiny muted',
        style: 'margin:0 0 10px',
        text: 'Four rules that apply everywhere at once. Changing one is free; living with it is not.',
      }),
    );
    for (const row of policyRows(state)) {
      const card = h('div', { class: 'division-card' });
      card.appendChild(
        h(
          'div',
          { class: 'division-head' },
          h('span', { class: 'division-name', text: row.def.name }),
          tag(row.chosen.name, 'accent'),
        ),
      );
      card.appendChild(h('div', { class: 'sub', text: row.def.question }));
      const choices = h('div', { class: 'stance-row' });
      for (const option of row.def.options) {
        const picked = option.id === row.chosen.id;
        choices.appendChild(
          h(
            'button',
            {
              class: `stance-card${picked ? ' chosen' : ''}`,
              on: {
                click: () => {
                  const result = setPolicy(state, row.def.id, option.id);
                  if (result.ok) toast(result.message, 'good');
                  keepingScroll(render);
                },
              },
            },
            h('div', { class: 'stance-head' }, h('span', { class: 'stance-name', text: option.name })),
            h('div', { class: 'tiny muted', text: option.detail }),
          ),
        );
      }
      card.appendChild(choices);
      rules.appendChild(card);
    }
    el.appendChild(rules);

    // ----------------------------------------------------------- the board
    const reg = register(state);
    const boardPanel = section('The board and who owns this');
    boardPanel.appendChild(
      h(
        'div',
        { class: 'grid cols-4' },
        kpi({
          label: 'You own', value: `${(reg.owner * 100).toFixed(1)}%`, icon: 'worth',
          tone: reg.owner > 0.8 ? 'good' : 'warn',
          sub: reg.outside > 0 ? `investors hold ${(reg.outside * 100).toFixed(1)}%` : 'all of it',
        }),
        kpi({
          label: 'Valued at', value: money(reg.valuation), icon: 'finance', tone: 'accent',
          sub: 'what a buyer would pay for the whole company',
        }),
        kpi({
          label: 'The board is', value: reg.label, icon: 'people',
          tone: reg.confidence >= 60 ? 'good' : reg.confidence >= 42 ? 'warn' : 'bad',
          sub: `${Math.round(reg.confidence)} out of a hundred`,
        }),
        kpi({
          label: 'Paid out', value: `${money(reg.paidOut)}`, icon: 'cash',
          tone: reg.paidOut > 0 ? 'warn' : 'muted',
          sub: 'to investors, last thirty days',
        }),
      ),
    );

    // A bar for how each part of the board's view stands, and the reason on a
    // line of its own — the reason is a sentence, and a sentence does not fit in
    // the figure column a meter keeps for a number.
    for (const row of confidenceRows(state)) {
      boardPanel.appendChild(
        h(
          'div',
          { class: 'board-view' },
          meter(
            row.label,
            (50 + row.value * 1.25) / 100,
            `${row.value > 0 ? '+' : ''}${Math.round(row.value)}`,
            row.value > 4 ? 'good' : row.value < -4 ? 'bad' : undefined,
          ),
          h('div', { class: 'tiny muted', text: row.detail }),
        ),
      );
    }

    if (!hasBoard(state)) {
      boardPanel.appendChild(
        h('p', {
          class: 'tiny muted',
          text: 'Without a board room this is only an opinion. Build one and the company can sell part of itself: money with no interest and nothing to call in, in exchange for a permanent share of everything it makes afterwards.',
        }),
      );
    } else {
      boardPanel.appendChild(
        h('p', {
          class: 'tiny muted',
          text: 'Selling part of the company raises money you never repay. What it costs instead is a share of every profitable day from here on, and it is priced on what the company is worth today — so a good quarter is a cheap time to raise and a bad one is a dear one.',
        }),
      );
      const offers = h('div', { class: 'btn-row' });
      for (const share of [0.05, 0.1, 0.2]) {
        const price = priceForShare(state, share);
        const check = canRaise(state, price);
        offers.appendChild(
          button(
            `Sell ${Math.round(share * 100)}% — ${money(price)}`,
            async () => {
              if (!check.ok) { toast(check.message, 'bad'); return; }
              const ok = await confirmDialog(
                `Sell ${Math.round(share * 100)}% of the company?`,
                `${money(price)} arrives now and is never repaid. In exchange, investors take a share of every profitable day from here on, and you would be left owning ${((ownersStake(state) - share) * 100).toFixed(1)}%. Buying it back later costs whatever the company is worth then.`,
                'Take the money',
              );
              if (!ok) return;
              const result = raiseEquity(state, price);
              toast(result.message, result.ok ? 'good' : 'bad');
              keepingScroll(render);
            },
            check.ok ? 'btn small primary' : 'btn small',
          ),
        );
      }
      boardPanel.appendChild(offers);
      const why = canRaise(state, priceForShare(state, 0.05));
      if (!why.ok) boardPanel.appendChild(h('p', { class: 'tiny warn', text: why.message }));

      if (outsideStake(state) > 0) {
        const cost = buybackCost(state, outsideStake(state));
        boardPanel.appendChild(
          h(
            'div',
            { class: 'btn-row' },
            button(`Buy the investors out — ${money(cost)}`, async () => {
              const ok = await confirmDialog(
                'Buy back the whole outside stake?',
                `${money(cost)} in cash, priced on what the company is worth today. You would own all of it again and keep every future profit.`,
                'Buy it back',
              );
              if (!ok) return;
              const result = buyBack(state, outsideStake(state));
              toast(result.message, result.ok ? 'good' : 'bad');
              keepingScroll(render);
            }, playerCompany(state).cash >= cost ? 'btn small' : 'btn small'),
          ),
        );
        boardPanel.appendChild(
          h('p', {
            class: 'tiny muted',
            text: `Investors will not go above ${Math.round(MAX_OUTSIDE_STAKE * 100)}% of the company — past that you would not be running it.`,
          }),
        );
      }
    }
    el.appendChild(boardPanel);

    // ----------------------------------------------------------- who decides
    const stance = stanceOf(state);
    const decides = section('Who decides');
    decides.appendChild(
      h('p', {
        class: 'sub',
        style: 'margin:-4px 0 10px',
        text: 'There is no right answer to this and the game will not suggest one. The centre is cheaper and more consistent; the shops read their own street better. You cannot have both.',
      }),
    );
    for (const option of STANCES) {
      const chosen = option.id === stance.id;
      decides.appendChild(
        h(
          'button',
          {
            class: `stance-card${chosen ? ' chosen' : ''}`,
            on: {
              click: () => {
                if (chosen) return;
                const result = setStance(state, option.id);
                toast(result.message, result.ok ? 'good' : 'bad');
                keepingScroll(render);
              },
            },
          },
          h(
            'div',
            { class: 'stance-head' },
            h('span', { class: 'stance-name', text: option.name }),
            h('span', { class: 'stance-tag', text: chosen ? 'current' : 'switch to this' }),
          ),
          h('div', { class: 'sub', text: option.detail }),
          h('div', {
            class: 'tiny muted',
            text: `Central functions worth ${Math.round(option.central * 100)}% · coordination bill ${Math.round(option.coordination * 100)}% · every shop reads its own street at ${Math.round(option.local * 100)}%`,
          }),
        ),
      );
    }
    el.appendChild(decides);

    // ------------------------------------------------------- the functions
    const panel = section('Central functions');
    for (const row of states) {
      const { def } = row;
      const inHouse = row.people.length;
      panel.appendChild(
        h(
          'div',
          { class: 'function-row' },
          h(
            'div',
            { class: 'function-main' },
            h(
              'div',
              { class: 'function-head' },
              h('span', { class: 'function-name', text: def.name }),
              h('span', {
                class: 'tag',
                text: `systems: ${AUTOMATION_TIERS[row.automation].name.toLowerCase()}`,
              }),
              h('span', {
                class: `function-cover ${row.cover >= 0.99 ? 'good' : row.cover <= 0 ? 'bad' : ''}`,
                text: row.cover <= 0 ? 'not covered' : `${Math.round(row.cover * 100)}% covered`,
              }),
            ),
            h('div', { class: 'sub', text: def.detail }),
            bar(row.cover, row.cover >= 0.99 ? 'good' : row.cover <= 0 ? 'bad' : ''),
            h('div', {
              class: row.cover > 0 ? 'function-says' : 'sub muted',
              text: row.cover > 0 ? `${def.says} — at ${Math.round(row.cover * 100)}% of that.` : def.says,
            }),
            h('div', {
              class: 'sub',
              text: row.outsourced
                ? `Bought in for ${money(row.cost)} a month. A supplier is never as good as somebody who works here.`
                : `${inHouse} of ${coverNeeded(state, def)} ${def.role === 'accountant' ? 'accountants' : `${def.name.toLowerCase()} people`} needed at this size · ${money(row.cost)}/mo in wages`,
            }),
          ),
          h(
            'div',
            { class: 'function-actions' },
            button(
              row.outsourced ? 'Bring back in house' : `Buy it in — ${money(outsourceCost(state, def))}/mo`,
              () => {
                const result = setOutsourced(state, def.id, !row.outsourced);
                toast(result.message, result.ok ? 'good' : 'bad');
                keepingScroll(render);
              },
              'btn small',
            ),
            // Systems are the third way to cover a function: they never notice
            // anything, and they never hand in their notice either.
            AUTOMATION_TIERS[row.automation + 1]
              ? button(
                  `${AUTOMATION_TIERS[row.automation + 1].name} systems — ${money(AUTOMATION_TIERS[row.automation + 1].cost)}`,
                  () => {
                    const result = investInAutomation(state, def.id);
                    toast(result.message, result.ok ? 'good' : 'bad');
                    keepingScroll(render);
                  },
                  canAutomate(state, def.id).ok ? 'btn small primary' : 'btn small',
                )
              : h('span', { class: 'tiny muted', text: 'fully automated' }),
          ),
        ),
      );
    }
    el.appendChild(panel);

    // ---------------------------------------------------------- the people
    el.appendChild(
      section(
        'Who works here',
        staff.length === 0
          ? empty('Nobody yet. Take somebody on below, or buy a function in and pay a supplier instead.')
          : table(
              ['Name', 'Function', 'Fit', 'Performance', 'Salary'],
              staff.map((person) => [
                person.name,
                FUNCTIONS.find((f) => f.role === person.role)?.name ?? person.role,
                `${Math.round(roleFit(person.skills, person.role))}/100`,
                `${Math.round(performanceOf(person))}%`,
                `${money(person.salary)}/mo`,
              ]),
            ),
      ),
    );

    // ------------------------------------------------------------- hiring
    const central = new Set(FUNCTIONS.map((f) => f.role));
    const applicants = state.applicants.filter((a) => central.has(a.role));
    el.appendChild(
      section(
        'Available centrally',
        applicants.length === 0
          ? empty('Nobody suitable is looking this week. The pool turns over daily.')
          : table(
              ['Name', 'Function', 'Fit', 'Salary', ''],
              applicants.map((person: Employee) => [
                person.name,
                FUNCTIONS.find((f) => f.role === person.role)?.name ?? person.role,
                `${Math.round(roleFit(person.skills, person.role))}/100`,
                `${money(person.salary)}/mo`,
                button(
                  'Take on',
                  () => {
                    const result = hireToHeadOffice(state, person.id);
                    toast(result.message, result.ok ? 'good' : 'bad');
                    ctx.refresh();
                  },
                  'btn small primary',
                ),
              ]),
            ),
      ),
    );

    el.appendChild(
      section(
        'Close the head office',
        h('p', {
          class: 'sub',
          text: 'Everything it does centrally goes back to being done in the shops, or not at all. Move or let go of the people here first.',
        }),
        button(
          'Close it',
          () => {
            const result = closeHeadOffice(state);
            toast(result.message, result.ok ? 'good' : 'bad');
            ctx.refresh();
          },
          'btn danger',
        ),
      ),
    );
  };

  /** What this screen is showing, so it only repaints when that changes. */
  const signature = (): string => {
    const state = ctx.state;
    const hq = state.headOffice;
    return [
      state.day,
      hq?.id ?? '',
      hq?.level ?? 0,
      hq?.stance ?? '',
      hq ? FUNCTIONS.map((f) => hq.automation[f.id] ?? 0).join('') : '',
      centralStaff(state).length,
      outsourcingBill(state),
      state.applicants.length,
    ].join('|');
  };

  render();
  let shown = signature();
  return {
    el,
    update: () => {
      const now = signature();
      if (now === shown) return;
      shown = now;
      keepingScroll(render);
    },
  };
}

/** What the player sees before there is a head office: how to get one. */
function renderOpening(ctx: Ctx, el: HTMLElement): void {
  const state = ctx.state;
  const held = state.buildings.filter(
    (building) =>
      building.occupantCompanyId === state.playerCompanyId &&
      !building.businessId &&
      !state.warehouses.some((w) => w.buildingId === building.id),
  );

  el.appendChild(
    section(
      'What a head office is for',
      h(
        'div',
        {},
        ...FUNCTIONS.map((def) =>
          h(
            'div',
            { class: 'finding' },
            h('span', { class: 'finding-dot good' }),
            h('div', { style: 'flex:1;min-width:0' },
              h('div', { class: 'finding-title', text: def.name }),
              h('div', { class: 'sub', text: `${def.detail} ${def.says}.` })),
          ),
        ),
      ),
      h('p', {
        class: 'sub',
        text: `Cover is measured against how many shops you run, and not in proportion — six shops need three HR people, not six. Fitting out a head office costs ${money(HQ_FIT_OUT)} on top of the lease.`,
      }),
    ),
  );

  if (held.length === 0) {
    el.appendChild(
      section(
        'You need a unit for it',
        h('p', { text: 'Take a lease on somewhere with nothing trading in it, then come back here.' }),
        button('Find a unit', () => ctx.go('property'), 'btn primary'),
      ),
    );
    return;
  }

  let chosen = held[0].id;
  const picker = select(
    held.map((building) => ({ value: building.id, label: `${building.address} — ${money(building.rent)}/mo` })),
    chosen,
    (value) => {
      chosen = value;
    },
  );
  const company = playerCompany(state);
  const affordable = company.cash >= HQ_FIT_OUT;

  el.appendChild(
    section(
      'Open one',
      h('label', { class: 'field' }, h('span', { text: 'In which unit' }), picker),
      h('p', {
        class: affordable ? 'sub' : 'bad',
        text: affordable
          ? `Fit-out costs ${money(HQ_FIT_OUT)}. You have ${money(company.cash)}.`
          : `Fit-out costs ${money(HQ_FIT_OUT)} and you have ${money(company.cash)}.`,
      }),
      button(
        'Open the head office',
        () => {
          const check = canOpenHeadOffice(state, chosen);
          if (!check.ok) {
            toast(check.message, 'bad');
            return;
          }
          const result = openHeadOffice(state, chosen, `${company.name} Head Office`);
          toast(result.message, result.ok ? 'good' : 'bad');
          ctx.refresh();
        },
        affordable ? 'btn primary' : 'btn',
      ),
    ),
  );
}
