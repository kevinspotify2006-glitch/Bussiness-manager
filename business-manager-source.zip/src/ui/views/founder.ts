import type { Ctx, View } from '../app';
import { playerBusinesses, playerCompany } from '../../sim/state';
import { FOUNDER_SKILLS, founderTrait } from '../../data/founders';
import { scenario } from '../../data/scenarios';
import {
  attentionSpan,
  lendingFactor,
  marketingSkillFactor,
  moraleFromOwner,
  negotiationFactor,
  operationsFactor,
  rateDiscount,
  researchSpeed,
  skillOf,
} from '../../sim/founder';
import { ownerAttention } from '../../sim/holding';
import { levelOf } from '../../sim/progress';
import { money, pct } from '../../sim/format';
import { sum } from '../../sim/util';
import { bar, empty, h, keepingScroll, section, stat } from '../dom';

/**
 * You.
 *
 * The player was a pair of hands that cost nothing and knew nothing. This is
 * the other half of the company: what the person running it is good at, what
 * each of those is worth in figures the rest of the game uses, and — the part
 * that makes it a system rather than a badge — what you have to keep doing to
 * get better at it.
 */
export function founderView(ctx: Ctx): View {
  const el = h('div', { class: 'view' });

  const render = (): void => {
    el.replaceChildren();
    const state = ctx.state;
    const founder = state.founder;
    const company = playerCompany(state);

    if (!founder) {
      el.appendChild(
        h('div', { class: 'view-head' }, h('h1', { text: 'You' })),
      );
      el.appendChild(section('Nothing on file', empty('This company was started before the game kept a record of who runs it.')));
      return;
    }

    const trait = founderTrait(founder.traitId);
    const started = scenario(founder.scenarioId);
    const open = playerBusinesses(state).filter((b) => b.status === 'open');

    el.appendChild(
      h(
        'div',
        { class: 'view-head' },
        h('h1', { text: founder.name }),
        h('p', {
          text: `${trait.name} · started as ${started.name.toLowerCase()} · ${company.name} · day ${state.day}`,
        }),
      ),
    );

    // ------------------------------------------------------- what it adds up to
    el.appendChild(
      section(
        'Where the company has got to under you',
        h(
          'div',
          { class: 'grid cols-4' },
          stat('Level', `${levelOf(state).n} · ${levelOf(state).name}`),
          stat('Locations', String(open.length)),
          stat('People', String(state.employees.length)),
          stat('Payroll', `${money(sum(state.employees, (e) => e.salary))}/mo`),
        ),
      ),
    );

    // ------------------------------------------------------------ the skills
    const panel = section('What you are good at');
    panel.appendChild(
      h('p', {
        class: 'sub',
        style: 'margin:-4px 0 10px',
        text: 'Nothing here is spent or allocated. You get better at the things you actually do, and the first twenty points come far faster than the last twenty.',
      }),
    );

    // What each skill is doing right now, in the units the effect works in.
    const worth: Record<string, string> = {
      management: `you can hold about ${attentionSpan(state).toFixed(1)} locations before anything drifts`,
      finance: `${
        rateDiscount(state) >= 0 ? `${pct(rateDiscount(state) * 100, 2)} off every rate quoted` : `${pct(-rateDiscount(state) * 100, 2)} added to every rate quoted`
      }, and ${pct((lendingFactor(state) - 1) * 100)} on what the bank will lend`,
      sales: `${pct((marketingSkillFactor(state) - 1) * 100)} on what marketing buys`,
      operations: `${pct((1 - operationsFactor(state)) * 100)} off the coordination bill`,
      strategy: `research finishes ${pct((researchSpeed(state) - 1) * 100)} sooner`,
      leadership: `${moraleFromOwner(state) >= 0 ? '+' : ''}${Math.round(moraleFromOwner(state))} morale for everybody on the payroll`,
      negotiation: `${pct((1 - negotiationFactor(state)) * 100)} off supplier prices and sellers' reserves`,
    };

    for (const def of FOUNDER_SKILLS) {
      const value = skillOf(state, def.id);
      const toNext = founder.progress[def.id] ?? 0;
      panel.appendChild(
        h(
          'div',
          { class: 'founder-skill' },
          h(
            'div',
            { class: 'founder-skill-head' },
            h('span', { class: 'founder-skill-name', text: def.name }),
            h('span', { class: 'founder-skill-value', text: `${Math.round(value)}/100` }),
          ),
          bar(value / 100, value >= 70 ? 'good' : value <= 25 ? 'bad' : ''),
          h('div', { class: 'sub', text: def.detail }),
          h('div', { class: 'founder-skill-worth', text: `Right now: ${worth[def.id] ?? def.says}.` }),
          value < 100
            ? h('div', { class: 'tiny muted', text: `${Math.round(toNext * 100)}% of the way to the next point.` })
            : h('div', { class: 'tiny good', text: 'As far as this one goes.' }),
        ),
      );
    }
    el.appendChild(panel);

    // ---------------------------------------------------- what is stretching you
    const attention = ownerAttention(state);
    el.appendChild(
      section(
        'What you can actually keep an eye on',
        bar(attention, attention >= 1 ? 'good' : attention > 0.75 ? 'warn' : 'bad'),
        h('p', {
          class: attention >= 1 ? 'sub' : 'warn',
          style: 'margin:8px 0 0',
          text:
            attention >= 1
              ? `Comfortable. At management ${Math.round(skillOf(state, 'management'))} you can hold about ${attentionSpan(
                  state,
                ).toFixed(1)} locations, and you are inside that.`
              : `Stretched. At management ${Math.round(skillOf(state, 'management'))} you can hold about ${attentionSpan(
                  state,
                ).toFixed(1)} locations, and you are past it. Getting better at managing raises that ceiling; putting somebody senior over a division moves the work off it entirely.`,
        }),
      ),
    );

    el.appendChild(
      section(
        'Where you came from',
        h('p', { class: 'sub', text: trait.detail }),
        h('p', { text: trait.plays }),
        h('p', {
          class: 'tiny muted',
          text: `${started.name}: ${started.focus}`,
        }),
      ),
    );
  };

  /** Repaint when a skill moves or a day passes, and not otherwise. */
  const signature = (): string => {
    const founder = ctx.state.founder;
    if (!founder) return 'none';
    return `${ctx.state.day}|${FOUNDER_SKILLS.map((s) => Math.round(founder.skills[s.id])).join(',')}`;
  };

  render();
  let shown = signature();
  return {
    el,
    update: () => {
      const now = signature();
      if (now === shown) return;
      shown = now;
      keepingScroll(render);
    },
  };
}
