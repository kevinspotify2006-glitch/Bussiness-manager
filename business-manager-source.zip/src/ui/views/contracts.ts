import type { Ctx, View } from '../app';
import {
  STRIKES,
  accept,
  available,
  contractsOf,
  decline,
  eligibility,
  weeklyContractValue,
} from '../../sim/contracts';
import { contractsUnlocked, levelOf } from '../../sim/progress';
import { product } from '../../data/products';
import { money } from '../../sim/format';
import { bar, button, empty, h, keepingScroll, section, stat, table, toast } from '../dom';

/**
 * Contracts.
 *
 * A shop waits for people to come in. A contract is somebody else's business
 * depending on you every week whether or not you feel like it — a known price
 * for a known quantity, against a penalty if the pallet is not there. The
 * screen has to make both halves of that obvious before the player signs.
 */
export function contractsView(ctx: Ctx): View {
  const el = h('div', { class: 'view' });

  const render = (): void => {
    el.replaceChildren();
    const state = ctx.state;

    el.appendChild(
      h(
        'div',
        { class: 'view-head' },
        h('h1', { text: 'Contracts' }),
        h('p', { text: 'Supply somebody else, every week, for a price agreed in advance.' }),
      ),
    );

    if (!contractsUnlocked(state)) {
      el.appendChild(
        h(
          'section',
          { class: 'panel panel-danger' },
          h('h3', { class: 'panel-title', text: 'Nobody is offering you one yet' }),
          h('p', {
            text: `Clients put work out to companies that can be relied on. You are a ${levelOf(
              state,
            ).name.toLowerCase()}; offers start arriving at growing company.`,
          }),
          button('What would it take?', () => ctx.go('progress'), 'btn primary'),
        ),
      );
    }

    // ------------------------------------------------------------- running
    const running = contractsOf(state);
    el.appendChild(
      section(
        `Running — ${money(weeklyContractValue(state))} a week`,
        running.length === 0
          ? empty('Nothing signed. Offers appear below as clients look for suppliers.')
          : table(
              ['Client', 'Supplying', 'A week', 'Weeks', 'Stock to hand', 'Strikes'],
              running.map((contract) => {
                const def = product(contract.productId);
                const have = available(state, contract.productId);
                const short = have < contract.unitsPerWeek;
                return [
                  contract.client,
                  `${contract.unitsPerWeek} × ${def?.name ?? contract.productId}`,
                  money(contract.unitsPerWeek * contract.unitPrice),
                  h(
                    'div',
                    {},
                    h('span', { text: `${contract.weeksDone} of ${contract.weeksTotal}` }),
                    bar(contract.weeksDone / Math.max(1, contract.weeksTotal)),
                  ),
                  h('span', { class: short ? 'bad' : 'good', text: `${have}` }),
                  h('span', {
                    class: contract.missed > 0 ? 'bad' : 'muted',
                    text: `${contract.missed} of ${STRIKES}`,
                  }),
                ];
              }),
            ),
      ),
    );

    // -------------------------------------------------------------- offers
    const offers = state.contractOffers;
    const cards = h('div', { class: 'grid cols-2' });
    for (const offer of offers) {
      const def = product(offer.productId);
      const check = eligibility(state, offer);
      const have = available(state, offer.productId);
      cards.appendChild(
        h(
          'div',
          { class: 'panel' },
          h('h4', { text: offer.client }),
          stat('Supplying', `${offer.unitsPerWeek} × ${def?.name ?? offer.productId} a week`),
          stat('Price a unit', money(offer.unitPrice)),
          stat('Worth a week', money(offer.unitsPerWeek * offer.unitPrice)),
          stat('Term', `${offer.weeks} weeks`),
          stat('Penalty if short', money(offer.penalty), 'bad'),
          stat('Needs', `${offer.requiresHeadcount} staff${offer.requiresWarehouse ? ', a distribution centre' : ''}`),
          stat(
            'You hold now',
            `${have} units`,
            have >= offer.unitsPerWeek ? 'good' : 'bad',
          ),
          check.ok
            ? h('p', { class: 'sub', text: 'You can service this today.' })
            : h('p', { class: 'bad', text: `You would need ${check.reasons.join(' and ')}.` }),
          h(
            'div',
            { class: 'row' },
            button(
              'Accept',
              () => {
                const result = accept(state, offer.id);
                toast(result.message);
                if (result.ok) ctx.refresh();
                render();
              },
              check.ok ? 'btn primary' : 'btn',
            ),
            button('Decline', () => {
              decline(state, offer.id);
              render();
            }),
          ),
        ),
      );
    }
    el.appendChild(
      section(
        'On the table',
        offers.length === 0 ? empty('No offers this week. Clients come looking as the company grows.') : cards,
      ),
    );

    el.appendChild(
      section(
        'How they work',
        h('ul', { class: 'unlock-list' },
          h('li', { text: 'Every week the units come off the warehouse racks first, then off the shelves — but never more than half a shop’s stock, so a contract cannot empty a shop.' }),
          h('li', { text: 'A full delivery is paid in full and lifts reputation. A short one is paid for what went out, charges the penalty, and costs reputation.' }),
          h('li', { text: `Three short weeks and the client leaves. Finish the term and there is a completion bonus.` }),
        ),
      ),
    );
  };

  /** What this screen is showing, so it only repaints when that changes. */
  function signature(): string {
    const state = ctx.state;
    return `${state.day}|${state.contracts.length}|${state.contractOffers.length}|${state.contracts.map((c) => c.weeksDone + ':' + c.missed).join()}`;
  }

  render();
  // Repainting three times a second would throw the reader back to the top of
  // the page three times a second. It only repaints when what it shows has
  // actually changed, and then without moving them.
  let shown = signature();
  return {
    el,
    update: () => {
      const now = signature();
      if (now === shown) return;
      shown = now;
      keepingScroll(render);
    },
  };
}
