import type { Ctx, View } from '../app';
import type { Business, Company } from '../../sim/types';
import { buildingById, competitorBusinesses, playerBusinesses, playerCompany } from '../../sim/state';
import { businessTypeOrThrow } from '../../data/businessTypes';
import { DISTRICTS, district } from '../../data/districts';
import { PERSONALITY_LABELS } from '../../sim/competitors';
import { districtPool, marketRows, marketShare, priceIndex, typeShare } from '../../sim/demand';
import { count, money, pct } from '../../sim/format';
import { sum } from '../../sim/util';
import { bar, button, empty, h, hint, modal, numberInput, section, stat, table, toast } from '../dom';
import { APPROACH_COOLDOWN, acquisitionTargets, approachStatus, makeOffer } from '../../sim/acquisitions';
import { SEGMENTS, basketFactor, districtMix, leadingSegment } from '../../sim/segments';

/**
 * The market screen answers one question: who is taking the customers you are
 * not getting? Every number here is the same one the demand model uses, so the
 * share shown is the share the player actually receives.
 */
export function marketView(ctx: Ctx): View {
  const el = h('div', { class: 'view' });
  const state = ctx.state;
  const mine = playerBusinesses(state).filter((b) => b.status === 'open');

  el.appendChild(
    h(
      'div',
      { class: 'view-head' },
      h('h1', { text: 'Market' }),
      h('p', { text: 'Where you stand, and who is standing in your way' }),
    ),
  );

  // ------------------------------------------------------- your markets
  const markets = section('Your markets');
  if (mine.length === 0) {
    markets.appendChild(
      empty('You are not trading yet, so you have no share of anything. Open a business and this fills in.'),
    );
  } else {
    for (const business of mine) {
      const building = buildingById(state, business.buildingId);
      if (!building) continue;
      const type = businessTypeOrThrow(business.typeId);
      const share = typeShare(business.typeId);

      // One definition of a market, and it lives in the demand model: the same
      // trade, in the same district, share by attractiveness against everybody
      // else plus the outlets the simulation does not model one by one. This
      // screen reads it rather than working it out again, so the share here can
      // never disagree with the share the dashboard shows.
      const shares = marketRows(state, business.id);
      const peers = state.businesses.filter((other) => {
        if (other.status !== 'open' || other.typeId !== business.typeId) return false;
        const otherBuilding = buildingById(state, other.buildingId);
        return otherBuilding?.district === building.district;
      });

      // Daily size of this specific market.
      let dailyPool = 0;
      const savedHour = state.hour;
      for (let hour = 0; hour < 24; hour += 1) {
        (state as { hour: number }).hour = hour;
        dailyPool += districtPool(state, building.district, type.category) * share;
      }
      (state as { hour: number }).hour = savedHour;

      const ownShare = marketShare(state, business.id);
      const leader = shares.find((row) => row.businessId !== business.id) ?? null;
      const background = shares.find((row) => row.businessId === null)?.share ?? 0;

      markets.appendChild(
        h(
          'div',
          { class: 'card', style: 'margin-bottom:10px' },
          h(
            'div',
            { class: 'card-head' },
            h(
              'div',
              {},
              h('div', { class: 'card-title', text: `${type.icon} ${business.name}` }),
              h('div', {
                class: 'card-sub',
                text: `${type.name} in ${district(building.district).name} · market of about ${count(dailyPool)} customers a day`,
              }),
            ),
            h('span', {
              class: `tag ${ownShare > 0.2 ? 'good' : ownShare < 0.06 ? 'bad' : ''}`,
              text: `${pct(ownShare * 100, 1)} share`,
            }),
          ),
          bar(ownShare, ownShare > 0.2 ? 'good' : ownShare < 0.06 ? 'bad' : ''),
          h(
            'p',
            { class: 'tiny muted', style: 'margin-top:8px' },
            leader && leader.share > ownShare
              ? `${leader.name} leads here. `
              : peers.length > 1
                ? 'You have the largest share of the named businesses here. '
                : 'No named rival trades here. ',
            `${pct(background * 100, 1)} of this market goes to outlets the game does not name individually.`,
          ),
          // Everybody in this market, you included, on one list — which is
          // the only way a share figure means anything.
          table(
            ['Business', 'Owner', 'Price level', 'Reviews', 'Share'],
            shares.map((row) => {
              const peer = row.businessId ? state.businesses.find((entry) => entry.id === row.businessId) : null;
              const owner = peer ? state.companies.find((c) => c.id === peer.companyId) : null;
              return [
                h('span', { class: row.isPlayer ? 'good' : peer ? '' : 'muted', text: row.name }),
                owner?.name ?? (peer ? '—' : 'unnamed operators'),
                peer ? pct(priceIndex(peer) * 100) : '—',
                peer ? `${peer.reviewScore.toFixed(1)}★` : '—',
                h('span', { class: row.isPlayer ? 'good' : '', text: pct(row.share * 100, 1) }),
              ];
            }),
          ),
        ),
      );
    }
  }
  el.appendChild(markets);

  // ---------------------------------------------------------- companies
  const rivals = competitorBusinesses(state);
  const byCompany = new Map<string, Business[]>();
  for (const business of rivals) {
    const list = byCompany.get(business.companyId) ?? [];
    list.push(business);
    byCompany.set(business.companyId, list);
  }

  const rows = [...byCompany.entries()]
    .map(([companyId, businesses]) => {
      const company = state.companies.find((c) => c.id === companyId) as Company | undefined;
      const districts = new Set(
        businesses.map((b) => buildingById(state, b.buildingId)?.district).filter(Boolean),
      );
      const avgPrice = sum(businesses, (b) => priceIndex(b)) / businesses.length;
      const avgReview = sum(businesses, (b) => b.reviewScore) / businesses.length;
      const meetsYou = businesses.some((rival) => {
        const rivalBuilding = buildingById(state, rival.buildingId);
        return mine.some((own) => {
          const ownBuilding = buildingById(state, own.buildingId);
          return ownBuilding?.district === rivalBuilding?.district && own.typeId === rival.typeId;
        });
      });
      return { company, businesses, districts: districts.size, avgPrice, avgReview, meetsYou };
    })
    .sort((a, b) => b.businesses.length - a.businesses.length);

  const playerOpen = mine.length;
  const biggest = rows[0]?.businesses.length ?? 0;

  el.appendChild(
    section(
      'Competitors',
      h(
        'div',
        { class: 'grid cols-3', style: 'margin-bottom:12px' },
        stat('Your open locations', String(playerOpen), playerOpen > biggest ? 'good' : undefined),
        stat('Largest competitor', `${biggest} locations`),
        stat('Companies trading', String(rows.length + 1)),
      ),
      rows.length === 0
        ? empty('No competitors are trading right now.')
        : table(
            ['Company', 'Strategy', 'Locations', 'Districts', 'Price level', 'Reviews', ''],
            rows.map((row) => [
              h(
                'div',
                {},
                h('div', { text: row.company?.name ?? 'Unknown' }),
                h('div', { class: 'tiny muted', text: `${money(row.company?.cash ?? 0)} cash` }),
              ),
              row.company?.personality ? PERSONALITY_LABELS[row.company.personality] : '—',
              String(row.businesses.length),
              String(row.districts),
              pct(row.avgPrice * 100),
              `${row.avgReview.toFixed(1)}★`,
              row.meetsYou
                ? h('span', { class: 'tag bad', text: 'Competes with you' })
                : h('span', { class: 'tag', text: 'Elsewhere' }),
            ]),
          ),
      h('p', {
        class: 'tiny muted',
        text: 'Competitors set their own prices, marketing and expansion from what they can observe. A low price level means they are undercutting the market, not that they are cheap to beat.',
      }),
    ),
  );

  // ------------------------------------------------------- who is out there
  const catchments = section('Who lives in each district');
  catchments.appendChild(
    h('p', {
      class: 'tiny muted',
      text: 'Every district produces the same number of customers whoever they are — but not the same customers. Students fill a shop and barely fill a till; professionals do the opposite. This is the catchment, before your own shop is taken into account.',
    }),
  );
  catchments.appendChild(
    table(
      ['District', 'Mostly', ...SEGMENTS.map((seg) => seg.name), 'Spend'],
      DISTRICTS.map((def) => {
        const mix = districtMix(def, 'retail');
        return [
          def.name,
          h('span', {}, leadingSegment(mix).name, hint(leadingSegment(mix).description)),
          ...SEGMENTS.map((seg) =>
            h('span', {
              class: mix[seg.id] > 0.34 ? 'good' : mix[seg.id] < 0.06 ? 'muted' : '',
              text: pct(mix[seg.id] * 100),
            }),
          ),
          h('span', {
            class: basketFactor(mix) > 1.04 ? 'good' : basketFactor(mix) < 0.96 ? 'bad' : '',
            text: pct(basketFactor(mix) * 100),
          }),
        ];
      }),
    ),
  );
  catchments.appendChild(
    h('p', {
      class: 'tiny muted',
      text: 'Spend is what an average basket here is worth against the city average. It is already in every revenue figure the game shows you.',
    }),
  );
  el.appendChild(catchments);

  // ------------------------------------------------------- acquisitions
  const targets = acquisitionTargets(state, 10);
  const buyPanel = section('Businesses you could buy');
  buyPanel.appendChild(
    h('p', {
      class: 'tiny muted',
      text: 'Buying a rival gets you a trading shop, its lease, its fittings and its team on the same day — at a price that reflects all four. Owners who are losing money are easier to persuade; one who is doing well will hold out.',
    }),
  );
  if (targets.length === 0) {
    buyPanel.appendChild(empty('Nobody else is trading in the city right now.'));
  } else {
    buyPanel.appendChild(
      table(
        ['Business', 'Owner', 'District', 'Trading', 'Rough value', ''],
        targets.map(({ business, valuation }) => {
          const building = buildingById(state, business.buildingId);
          const owner = state.companies.find((c) => c.id === business.companyId);
          const type = businessTypeOrThrow(business.typeId);
          const daily = business.profitHistory.slice(-14);
          const avg = daily.length > 0 ? sum(daily, (p) => p) / daily.length : 0;
          const status = approachStatus(state, business.id);
          return [
            h(
              'div',
              {},
              h('div', { text: `${type.icon} ${business.name}` }),
              h('div', { class: 'tiny muted', text: `${business.reviewScore.toFixed(1)}★ · ${Math.round(business.reputation)}/100 reputation` }),
            ),
            owner?.name ?? '—',
            building ? district(building.district).name : '—',
            h('span', { class: avg >= 0 ? 'good' : 'bad', text: `${money(avg)}/day` }),
            money(valuation.fair),
            status?.blocked
              ? h('span', { class: 'tag warn', text: 'Not talking' })
              : button('Make an offer', () => showOffer(ctx, business.id), 'btn small'),
          ];
        }),
      ),
    );
  }
  el.appendChild(buyPanel);

  return { el };
}

/** The negotiation. Everything the seller is weighing is on the table. */
function showOffer(ctx: Ctx, businessId: string): void {
  const state = ctx.state;
  const business = state.businesses.find((b) => b.id === businessId);
  const status = approachStatus(state, businessId);
  if (!business || !status) return;
  const owner = state.companies.find((c) => c.id === business.companyId);
  const { valuation } = status;

  const { body, footer, close } = modal({ title: `Offer for ${business.name}`, width: 560 });

  body.appendChild(
    h('p', {
      class: 'decision-body',
      text: `${owner?.name ?? 'The owner'} has not put it up for sale. What you pay has to be worth more to them than keeping it.`,
    }),
  );

  body.appendChild(
    h(
      'div',
      { class: 'panel' },
      h('h3', { class: 'panel-title', text: 'What you would be buying' }),
      stat('Trade (goodwill)', money(valuation.goodwill)),
      stat('Fittings and equipment', money(valuation.fixtures)),
      stat('Stock on the shelves', money(valuation.stock)),
      stat('Lease or freehold', money(valuation.premises)),
      stat('Rough value', money(valuation.fair), 'good'),
      h('p', {
        class: 'tiny muted',
        style: 'margin-top:8px',
        text:
          valuation.history >= 21
            ? `Valued on ${valuation.history} days of trading — about ${money(valuation.annualProfit)} of profit a year.`
            : `Only ${valuation.history} days of trading to go on, so the price leans on the assets rather than the profit.`,
      }),
    ),
  );

  let amount = Math.round((valuation.fair * 1.15) / 100) * 100;
  body.appendChild(
    h(
      'label',
      { class: 'field' },
      h('span', { text: 'Your offer' }),
      numberInput(amount, (value) => {
        amount = value;
      }, { step: '500', min: '0' }),
    ),
  );
  body.appendChild(
    h('p', {
      class: 'tiny muted',
      text: `You are holding ${money(playerCompany(state).cash)}. A refusal closes the conversation for ${APPROACH_COOLDOWN} days, so lowballing has a real cost.`,
    }),
  );

  footer.appendChild(button('Walk away', () => close(), 'btn ghost'));
  footer.appendChild(
    button(
      'Make the offer',
      () => {
        const result = makeOffer(state, businessId, amount);
        toast(result.message, result.accepted ? 'good' : 'bad');
        close();
        if (result.accepted) ctx.go('businesses', { business: businessId });
        else ctx.refresh();
      },
      'btn primary',
    ),
  );
}
