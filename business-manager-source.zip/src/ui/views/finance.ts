import type { Ctx, View } from '../app';
import type { LedgerCategory } from '../../sim/types';
import { playerBusinesses, playerCompany } from '../../sim/state';
import {
  LEDGER_LABELS,
  TAX_RATE,
  borrowingHeadroom,
  debtTotal,
  goodwillValue,
  inventoryValue,
  interestRemaining,
  isRevenue,
  loanOffers,
  loanType,
  monthlyPayment,
  monthsRemaining,
  netWorth,
  propertyValue,
  quoteRepayment,
  repayLoan,
  takeLoan,
} from '../../sim/finance';
import type { Loan } from '../../sim/types';
import { clockLabel, money, moneySigned, pct } from '../../sim/format';
import { clamp, sum } from '../../sim/util';
import { bar, button, confirmDialog, empty, h, kpi, numberInput, section, stat, statWithHint, table, tag, toast } from '../dom';
import {
  FACTORING_FEE,
  ageing,
  duesoon,
  factorInvoices,
  workingCapital,
} from '../../sim/workingCapital';
import { creditFactors } from '../../sim/finance';
import { lineChart } from '../chart';
import { HORIZON, WARNING_DAYS, forecast } from '../../sim/cashflow';

export function financeView(ctx: Ctx): View {
  const el = h('div', { class: 'view' });
  const state = ctx.state;
  const company = playerCompany(state);

  el.appendChild(
    h('div', { class: 'view-head' }, h('h1', { text: 'Finance' }), h('p', { text: 'Profit and loss, balance sheet, borrowing' })),
  );

  // ------------------------------------------------------- working capital
  // The gap between what the company has earned and what it actually holds.
  // This is the panel that explains how a profitable month can still end with
  // an empty account, and it is deliberately the first thing on the screen.
  const wc = workingCapital(state);
  const owed = wc.receivables + wc.overdue;
  const owing = wc.payables + wc.arrears;
  el.appendChild(
    h(
      'div',
      { class: 'grid cols-4' },
      kpi({
        label: 'In the bank', value: money(company.cash), icon: 'cash',
        tone: company.cash < 0 ? 'bad' : 'accent',
        valueTone: company.cash < 0 ? 'bad' : undefined,
        sub: wc.runwayDays === Infinity ? 'nothing going out yet' : `${Math.round(wc.runwayDays)} days of outgoings`,
        subTone: wc.runwayDays < 14 ? 'bad' : wc.runwayDays < 30 ? 'warn' : 'good',
      }),
      kpi({
        label: 'Owed to you', value: money(owed), icon: 'revenue', tone: 'info',
        sub: wc.overdue > 0 ? `${money(wc.overdue)} of it is late` : 'all of it within terms',
        subTone: wc.overdue > 0 ? 'warn' : 'good',
      }),
      kpi({
        label: 'You owe', value: money(owing + wc.taxDue), icon: 'warning',
        tone: wc.arrears > 0 ? 'bad' : 'warn',
        sub: wc.arrears > 0 ? `${money(wc.arrears)} already late` : `${money(wc.taxDue)} of it is tax set aside`,
        subTone: wc.arrears > 0 ? 'bad' : undefined,
      }),
      kpi({
        label: 'Working capital', value: money(wc.net), icon: 'profit',
        tone: wc.net < 0 ? 'bad' : 'tech',
        valueTone: wc.net < 0 ? 'bad' : 'good',
        sub: 'cash plus what is owed to you, less what you owe',
      }),
    ),
  );

  if (owed > 0 || owing > 0) {
    const ledger = section('The sales and purchase ledgers');
    ledger.appendChild(
      h('p', {
        class: 'sub',
        style: 'margin:-4px 0 12px',
        text:
          owed > company.cash
            ? `More is owed to you than you are holding. The money exists — it is sitting with your customers. You can chase it, sell the ledger to a lender at a discount, or borrow against it.`
            : 'What has been earned but not yet collected, and what has been bought but not yet paid for.',
      }),
    );

    const rows = ageing(state).slice(0, 8);
    if (rows.length > 0) {
      ledger.appendChild(h('div', { class: 'group-heading', text: 'Owed to you, worst first' }));
      ledger.appendChild(
        table(
          ['Customer', 'Amount', 'Raised', 'Due', 'Status'],
          rows.map((row) => [
            row.invoice.from,
            money(row.invoice.amount),
            `day ${row.invoice.raisedOnDay}`,
            `day ${row.invoice.dueOnDay}`,
            row.daysLate > 0
              ? tag(`${row.daysLate}d late`, row.daysLate > 14 ? 'bad' : 'warn')
              : tag(`due in ${-row.daysLate}d`, 'good'),
          ]),
        ),
      );
      ledger.appendChild(
        h(
          'div',
          { class: 'btn-row', style: 'margin-top:12px' },
          button(
            `Sell the ledger — about ${money(Math.round(owed * (1 - FACTORING_FEE)))} today`,
            () => openFactoring(ctx),
            'btn small',
          ),
        ),
      );
    }

    const bills = duesoon(state).slice(0, 6);
    if (bills.length > 0) {
      ledger.appendChild(h('div', { class: 'group-heading', text: 'You owe, soonest first' }));
      ledger.appendChild(
        table(
          ['Supplier', 'Amount', 'Due', 'Status'],
          bills.map((bill) => [
            bill.to,
            money(bill.amount),
            `day ${bill.dueOnDay}`,
            bill.lateDays > 0
              ? tag(`${bill.lateDays}d late`, 'bad')
              : tag(`in ${bill.dueOnDay - state.day}d`, 'muted'),
          ]),
        ),
      );
    }
    el.appendChild(ledger);
  }

  // ------------------------------------------------------- the credit rating
  const rating = section('What a lender thinks of you');
  rating.appendChild(
    h(
      'div',
      { class: 'grid cols-2' },
      h(
        'div',
        {},
        h('div', { class: 'kpi-label', text: 'Credit rating' }),
        h('div', {
          class: `kpi-value ${company.creditRating >= 70 ? 'good' : company.creditRating < 40 ? 'bad' : ''}`,
          text: `${Math.round(company.creditRating)}/100`,
        }),
        h('p', {
          class: 'tiny muted',
          text: 'Sets what you pay to borrow, how much a bank will lend, and how long your suppliers let you take to pay.',
        }),
      ),
      h('div', {}, ...creditFactors(state).map((factor) =>
        h(
          'div',
          { class: 'meter' },
          h('span', { class: `meter-dot ${factor.score / factor.of > 0.7 ? 'good' : factor.score / factor.of < 0.35 ? 'bad' : 'warn'}` }),
          h('span', { class: 'meter-name', text: factor.label }),
          h('div', { class: 'meter-bar' }, bar(factor.score / factor.of, factor.score / factor.of > 0.7 ? 'good' : factor.score / factor.of < 0.35 ? 'bad' : 'warn')),
          h('span', { class: 'meter-value', text: `${Math.round(factor.score)}/${factor.of}` }),
        ),
      )),
    ),
  );
  for (const factor of creditFactors(state)) {
    rating.appendChild(h('div', { class: 'tiny muted', text: `${factor.label}: ${factor.detail}` }));
  }
  el.appendChild(rating);

  // Cash is not profit: the accounts say whether the month made money, this
  // says whether the company can still pay for things in three weeks.
  const view = forecast(state);
  const dangerous = view.emptyOnDay !== null && view.emptyOnDay - state.day <= WARNING_DAYS;
  el.appendChild(
    h(
      'section',
      { class: `panel${dangerous ? ' panel-danger' : ''}` },
      h('h3', { class: 'panel-title', text: 'Cash forecast — the next 30 days' }),
      dangerous
        ? h('p', {
            class: 'bad',
            text: `⚠️ CASHFLOW WARNING: your company may run out of cash in ${(view.emptyOnDay ?? state.day) - state.day} days.`,
          })
        : h('p', {
            class: 'sub',
            text:
              view.emptyOnDay === null
                ? `Nothing in the next ${HORIZON} days empties the account at the current rate.`
                : `The account runs dry on day ${view.emptyOnDay}.`,
          }),
      lineChart(view.balances, { height: 110 }),
      h(
        'div',
        { class: 'grid cols-3' },
        stat('Cash now', money(company.cash)),
        stat('Trading, a day', moneySigned(view.dailyNet), view.dailyNet >= 0 ? 'good' : 'bad'),
        stat('Days of cover', view.emptyOnDay === null ? `${HORIZON}+` : String(view.runway), dangerous ? 'bad' : undefined),
      ),
      view.commitments.length > 0
        ? table(
            ['Day', 'Already committed', 'Amount'],
            view.commitments.map((item) => [String(item.day), item.label, moneySigned(item.amount)]),
          )
        : h('p', { class: 'sub muted', text: 'Nothing lands in a lump: rent, wages, utilities and stock are all in the daily rate.' }),
    ),
  );

  // ----------------------------------------------- where the money went
  // Every operating cost the company has, grouped the way an accountant would
  // group it, over the same thirty days the profit figure covers. People are
  // the group that is easiest to under-count — wages are the obvious part and
  // never the whole of it — so the group is broken out line by line.
  const COST_GROUPS: { name: string; lines: { label: LedgerCategory; text: string }[] }[] = [
    {
      name: 'Cost of sales',
      lines: [{ label: 'cogs', text: 'Goods sold' }],
    },
    {
      name: 'People',
      lines: [
        { label: 'wages', text: 'Payroll' },
        { label: 'recruitment', text: 'Recruitment' },
        { label: 'training', text: 'Training' },
        { label: 'severance', text: 'Severance' },
        { label: 'management', text: 'Management and coordination' },
        { label: 'outsourcing', text: 'Outsourced central services' },
      ],
    },
    {
      name: 'Premises and equipment',
      lines: [
        { label: 'rent', text: 'Rent' },
        { label: 'utilities', text: 'Energy and standing charges' },
        { label: 'equipment', text: 'Equipment and servicing' },
      ],
    },
    {
      name: 'Getting it sold and shifted',
      lines: [
        { label: 'marketing', text: 'Marketing' },
        { label: 'logistics', text: 'Distribution' },
      ],
    },
    {
      name: 'Finance and tax',
      lines: [
        { label: 'interest', text: 'Interest' },
        { label: 'tax', text: 'Tax' },
      ],
    },
  ];

  const costDays = 30;
  const since = state.day - costDays;
  const spend = new Map<LedgerCategory, number>();
  for (const entry of state.ledger) {
    if (entry.day < since) continue;
    if (entry.amount >= 0) continue;
    spend.set(entry.category, (spend.get(entry.category) ?? 0) + -entry.amount);
  }
  const revenue30 = sum(state.dayHistory.slice(-costDays), (day) => day.revenue);
  const outgoings = sum(
    COST_GROUPS.flatMap((group) => group.lines),
    (line) => spend.get(line.label) ?? 0,
  );
  const share = (value: number): string => (revenue30 > 0 ? pct((value / revenue30) * 100, 1) : '\u2014');

  const costRows: (string | HTMLElement)[][] = [];
  for (const group of COST_GROUPS) {
    const used = group.lines.filter((line) => (spend.get(line.label) ?? 0) > 0);
    if (used.length === 0) continue;
    const groupTotal = sum(used, (line) => spend.get(line.label) ?? 0);
    costRows.push([
      h('strong', { text: group.name }),
      h('strong', { text: money(groupTotal) }),
      h('strong', { text: share(groupTotal) }),
    ]);
    // A group of one adds nothing by repeating itself.
    if (used.length > 1) {
      for (const line of used) {
        const value = spend.get(line.label) ?? 0;
        costRows.push([h('span', { class: 'muted', text: `\u2003${line.text}` }), money(value), share(value)]);
      }
    }
  }
  costRows.push([
    h('strong', { text: 'Everything it costs to trade' }),
    h('strong', { text: money(outgoings) }),
    h('strong', { text: share(outgoings) }),
  ]);

  el.appendChild(
    section(
      'Where the money went \u2014 last 30 days',
      outgoings <= 0
        ? empty('Nothing has been spent yet. Costs appear here as soon as the company is trading.')
        : table(['', 'Amount', 'Of turnover'], costRows),
      outgoings > 0
        ? h('p', {
            class: 'tiny muted',
            text: 'Operating costs only. Buying a building, fitting out a shop and drawing or repaying a loan all move cash without being costs of trading \u2014 counting those here would make every expansion look like a disaster.',
          })
        : null,
    ),
  );

  const periods: { label: string; days: number }[] = [
    { label: 'Yesterday', days: 1 },
    { label: 'Last 7 days', days: 7 },
    { label: 'Last 30 days', days: 30 },
  ];

  el.appendChild(
    section(
      'Profit and loss',
      table(
        ['Period', 'Revenue', 'Costs', 'Profit', 'Margin'],
        periods.map((period) => {
          const slice = state.dayHistory.slice(-period.days);
          const revenue = sum(slice, (d) => d.revenue);
          const costs = sum(slice, (d) => d.costs);
          const profit = revenue - costs;
          return [
            period.label,
            money(revenue),
            money(costs),
            h('span', { class: profit >= 0 ? 'good' : 'bad', text: moneySigned(profit) }),
            revenue > 0 ? pct((profit / revenue) * 100, 1) : '—',
          ];
        }),
      ),
      state.dayHistory.length === 0 ? empty('No days have been settled yet.') : null,
    ),
  );

  el.appendChild(
    section(
      'Cash balance, day by day',
      lineChart(state.dayHistory.slice(-60).map((d) => d.cash), { showZero: true }),
      h('p', { class: 'tiny muted', text: 'Closing cash balance per day.' }),
    ),
  );

  // ------------------------------------------------------ cost breakdown
  const breakdown = new Map<LedgerCategory, number>();
  const recentDay = state.day - 7;
  for (const entry of state.ledger) {
    if (entry.day < recentDay) continue;
    breakdown.set(entry.category, (breakdown.get(entry.category) ?? 0) + entry.amount);
  }
  const rows = [...breakdown.entries()].sort((a, b) => Math.abs(b[1]) - Math.abs(a[1]));

  el.appendChild(
    h(
      'div',
      { class: 'grid cols-2' },
      section(
        'Where the money went (last 7 days)',
        rows.length === 0
          ? empty('Nothing has moved yet.')
          : table(
              ['Category', 'Amount'],
              rows.map(([category, amount]) => [
                LEDGER_LABELS[category],
                h('span', { class: isRevenue(category) ? 'good' : 'bad', text: moneySigned(amount) }),
              ]),
            ),
      ),
      section(
        'Balance sheet',
        stat('Cash', money(company.cash), company.cash < 0 ? 'bad' : undefined),
        stat('Stock at cost', money(inventoryValue(state))),
        stat('Property', money(propertyValue(state))),
        stat('Business goodwill', money(goodwillValue(state)), 'muted'),
        stat('Debt', money(-debtTotal(state)), debtTotal(state) > 0 ? 'bad' : 'muted'),
        stat('Net worth', money(netWorth(state)), netWorth(state) >= 0 ? 'good' : 'bad'),
        stat('Credit rating', `${Math.round(company.creditRating)}/100`),
        h('p', {
          class: 'tiny muted',
          text: `Corporation tax is ${Math.round(TAX_RATE * 100)}% of monthly profit, charged on the first of the month. Losses are not refunded.`,
        }),
      ),
    ),
  );

  // -------------------------------------------------------------- loans
  const loanPanel = section('Borrowing');
  loanPanel.appendChild(
    h('p', {
      class: 'tiny muted',
      text: `The bank will lend up to about ${money(borrowingHeadroom(state))} more against what you own. Missing a payment damages your credit rating badly.`,
    }),
  );

  if (state.loans.length > 0) {
    for (const loan of state.loans) {
      loanPanel.appendChild(loanCard(ctx, loan));
    }
  } else {
    loanPanel.appendChild(empty('No borrowing. Every euro in the business is yours.'));
  }

  loanPanel.appendChild(h('div', { class: 'sub', style: 'margin-top:14px', text: 'What you could borrow' }));
  for (const offer of loanOffers(state)) {
    const amountInput = numberInput(
      Math.max(1000, Math.min(offer.maxPrincipal, Math.round(offer.maxPrincipal / 2 / 1000) * 1000)),
      () => {},
      { min: '1000', max: String(Math.max(1000, offer.maxPrincipal)), step: '1000' },
    );
    const schedule = offer.maxPrincipal > 0
      ? monthlyPayment(Number(amountInput.value), offer.annualRate, offer.termMonths)
      : 0;
    loanPanel.appendChild(
      h(
        'div',
        { class: `card${offer.blocked ? ' muted-card' : ''}`, style: 'margin-top:8px' },
        h(
          'div',
          { class: 'card-head' },
          h(
            'div',
            {},
            h('div', { class: 'card-title', text: offer.type.name }),
            h('div', { class: 'card-sub', text: offer.type.detail }),
          ),
          h('span', {
            class: `tag ${offer.blocked ? 'bad' : 'good'}`,
            text: offer.blocked ? 'not available' : 'available',
          }),
        ),
        h('div', {
          class: 'sub',
          text: `${offer.lender} · up to ${money(offer.maxPrincipal)} · ${pct(offer.annualRate * 100, 2)} over ${
            offer.termMonths
          } months · about ${money(schedule)} a month`,
        }),
        offer.blocked
          ? h('div', { class: 'tiny warn', text: offer.blocked })
          : h(
              'div',
              { style: 'display:flex;gap:8px;align-items:flex-end;flex-wrap:wrap;margin-top:8px' },
              h(
                'label',
                { class: 'field', style: 'flex:1;min-width:150px;margin:0' },
                h('span', { text: 'How much' }),
                amountInput,
              ),
              button(
                'Borrow',
                () => {
                  const result = takeLoan(state, offer.id, Number(amountInput.value));
                  toast(result.message, result.ok ? 'good' : 'bad');
                  if (result.ok) ctx.refresh();
                },
                'btn primary',
              ),
            ),
      ),
    );
  }

  el.appendChild(loanPanel);

  // ------------------------------------------------------------- ledger
  const ledger = [...state.ledger].reverse().slice(0, 60);
  el.appendChild(
    section(
      'Recent transactions',
      ledger.length === 0
        ? empty('The ledger is empty.')
        : table(
            ['Day', 'Time', 'Category', 'Detail', 'Amount'],
            ledger.map((entry) => [
              String(entry.day),
              clockLabel(entry.hour),
              LEDGER_LABELS[entry.category],
              entry.label,
              h('span', { class: entry.amount >= 0 ? 'good' : 'bad', text: moneySigned(entry.amount) }),
            ]),
          ),
      h('p', {
        class: 'tiny muted',
        text: `Every euro the company moves is recorded here. ${playerBusinesses(state).length} businesses contribute to these figures.`,
      }),
    ),
  );

  return { el };
}

/**
 * One loan, with everything a person needs to decide whether to pay it down.
 *
 * The four buttons are the whole point of the panel. A quarter, a half, the
 * lot, or a figure you type — and every one of them says, before you press it,
 * how many months it takes off the term and how much interest you will now
 * never pay. That last number is the reason to do it at all, and it was the one
 * thing this screen never showed.
 */
function loanCard(ctx: Ctx, loan: Loan): HTMLElement {
  const state = ctx.state;
  const type = loanType(loan.typeId);
  const months = monthsRemaining(loan.outstanding, loan.annualRate, loan.monthlyPayment);
  const owed = interestRemaining(loan.outstanding, loan.annualRate, loan.monthlyPayment);
  const paidOff = loan.principal > 0 ? 1 - loan.outstanding / loan.principal : 0;

  const card = h('div', { class: 'card loan-card' });
  card.appendChild(
    h(
      'div',
      { class: 'card-head' },
      h(
        'div',
        {},
        h('div', { class: 'card-title', text: loan.lender }),
        h('div', { class: 'card-sub', text: `${type.name} · taken on day ${loan.takenOnDay}` }),
      ),
      loan.missedPayments > 0
        ? h('span', { class: 'tag bad', text: `${loan.missedPayments} missed` })
        : h('span', { class: 'tag good', text: 'up to date' }),
    ),
  );

  card.appendChild(bar(clamp(paidOff, 0, 1), paidOff > 0.66 ? 'good' : ''));
  card.appendChild(
    h('div', {
      class: 'tiny muted',
      style: 'margin-top:4px',
      text: `${money(loan.principal - loan.outstanding)} of ${money(loan.principal)} repaid${
        loan.earlyRepaid > 0 ? `, ${money(loan.earlyRepaid)} of it ahead of schedule` : ''
      }.`,
    }),
  );

  card.appendChild(
    h(
      'div',
      { class: 'grid cols-4', style: 'margin-top:10px' },
      stat('Still owed', money(loan.outstanding)),
      stat('Rate', pct(loan.annualRate * 100, 2)),
      stat('Every month', money(loan.monthlyPayment)),
      stat('Months left', Number.isFinite(months) ? String(months) : 'never at this rate'),
    ),
  );
  card.appendChild(
    h(
      'div',
      { class: 'grid cols-2', style: 'margin-top:2px' },
      statWithHint(
        'Interest still to pay',
        Number.isFinite(owed) ? money(owed) : '—',
        'What this loan costs from here if you simply let it run: every remaining monthly payment added up, less the principal still owed. Paying early is how you make this number smaller.',
      ),
      statWithHint(
        'Interest paid so far',
        money(loan.interestPaid),
        'What this loan has already cost you, on top of the money you borrowed.',
      ),
    ),
  );

  // ------------------------------------------------------ paying it down
  const custom = numberInput(Math.round(loan.outstanding / 4), () => updateQuote(), {
    min: '0',
    max: String(Math.ceil(loan.outstanding)),
    step: '100',
  });
  const verdict = h('div', { class: 'tiny muted', style: 'margin-top:6px' });

  const describe = (amount: number): string => {
    const quote = quoteRepayment(state, loan.id, amount);
    if (!quote) return '';
    if (quote.blocked) return quote.blocked;
    const saved = Math.max(0, Math.round(quote.monthsBefore - quote.monthsAfter));
    if (quote.outstandingAfter <= 0) {
      return `${money(quote.amount)} clears it outright, ${saved} month${saved === 1 ? '' : 's'} early, and saves ${money(
        quote.interestSaved,
      )} of interest you would otherwise have paid.`;
    }
    return `${money(quote.amount)} leaves ${money(quote.outstandingAfter)} owing, takes ${saved} month${
      saved === 1 ? '' : 's'
    } off the term, and saves ${money(quote.interestSaved)} of interest. The monthly payment does not change — that is what shortens it.`;
  };
  const updateQuote = (): void => {
    verdict.textContent = describe(Number(custom.value));
  };

  const pay = (amount: number): void => {
    const result = repayLoan(state, loan.id, amount);
    toast(result.message, result.ok ? 'good' : 'bad');
    if (result.ok) ctx.refresh();
  };

  const row = h('div', { class: 'btn-row', style: 'margin-top:10px' });
  for (const share of [0.25, 0.5, 1]) {
    const amount = Math.round(loan.outstanding * share);
    const affordable = playerCompany(state).cash >= amount;
    row.appendChild(
      button(
        `${Math.round(share * 100)}% — ${money(amount)}`,
        () => pay(amount),
        affordable ? (share === 1 ? 'btn small primary' : 'btn small') : 'btn small',
      ),
    );
  }
  card.appendChild(row);
  card.appendChild(
    h(
      'div',
      { style: 'display:flex;gap:8px;align-items:flex-end;flex-wrap:wrap;margin-top:8px' },
      h(
        'label',
        { class: 'field', style: 'flex:1;min-width:150px;margin:0' },
        h('span', { text: 'Or an amount of your own' }),
        custom,
      ),
      button('Pay that off', () => pay(Number(custom.value)), 'btn'),
    ),
  );
  updateQuote();
  card.appendChild(verdict);
  return card;
}

/**
 * Selling the sales ledger.
 *
 * The player is told exactly what it costs before they agree, because the whole
 * point of this door is that it is expensive and they should know it — it is
 * for a company with real customers and no cash, not a way of funding growth.
 */
function openFactoring(ctx: Ctx): void {
  const state = ctx.state;
  const wc = workingCapital(state);
  const face = wc.receivables + wc.overdue;
  const fee = Math.round(face * FACTORING_FEE);
  void confirmDialog(
    'Sell the sales ledger',
    `A lender will advance ${money(face - fee)} against ${money(face)} of invoices, today. The ${money(fee)} difference is theirs, and lenders notice a company that does this — your rating takes a small knock.\n\nThe money is already yours; this is only about having it sooner.`,
    `Take ${money(face - fee)} now`,
  ).then((yes) => {
    if (!yes) return;
    const result = factorInvoices(state, face);
    toast(result.message, result.ok ? 'good' : 'bad');
    ctx.refresh();
  });
}
