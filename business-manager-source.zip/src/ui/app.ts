import type { GameState } from '../sim/state';
import { SPEEDS, SPEED_LABELS, playerBusinesses, playerCompany } from '../sim/state';
import { Engine } from '../sim/engine';
import { on } from '../sim/bus';
import { netWorth } from '../sim/finance';
import { currentTier } from '../sim/achievements';
import { economyLabel } from '../sim/economy';
import { PRIORITY_LABELS, distinctAlerts, markAlertsRead, unreadAlerts } from '../sim/alerts';
import type { Alert, AlertPriority } from '../sim/types';
import { AUTOSAVE_ID, saveGame } from '../sim/save';
import { calendar, clockLabel, money, moneyShort, moneySigned } from '../sim/format';
import { levelOf, levelProgress, nextLevel, nextStep } from '../sim/progress';
import { sum } from '../sim/util';
import { clear, h, modal, toast } from './dom';
import { icon } from './icons';
import { renderTutorial } from './tutorial';
import { showDecision } from './decisionModal';

export interface View {
  el: HTMLElement;
  /** Called a few times a second while the view is on screen. */
  update?: () => void;
  destroy?: () => void;
}

export interface Ctx {
  engine: Engine;
  state: GameState;
  /** Switch to another view. */
  go: (route: string, params?: Record<string, string>) => void;
  /** Rebuild the current view from scratch. */
  refresh: () => void;
  /** Route parameters, e.g. the selected business id. */
  params: Record<string, string>;
}

export type ViewFactory = (ctx: Ctx) => View;

interface NavEntry {
  route: string;
  label: string;
  /** A name from the icon set in ./icons — never an emoji. */
  icon: string;
  factory: ViewFactory;
  /** Which part of the job this screen belongs to. */
  group?: string;
  /** One line in the header saying what this screen is for. */
  blurb?: string;
  badge?: (state: GameState) => number;
}

export class App {
  private engine: Engine;
  private root: HTMLElement;
  private entries: NavEntry[] = [];
  private current: View | null = null;
  private route = 'dashboard';
  private params: Record<string, string> = {};
  private main!: HTMLElement;
  private navHost!: HTMLElement;
  private mobileNavHost!: HTMLElement;
  private topbar!: HTMLElement;
  private lastAutosaveDay = 0;
  private updateTimer: number | null = null;
  private tutorialHost: HTMLElement | null = null;
  /**
   * A rebuild that has been held back because the player is in the middle of
   * something — typing in a field, or reading a dialog. It runs the moment they
   * are finished, which is the only reason it is safe to rebuild a whole view
   * on a clock tick at all.
   */
  private pendingRebuild = false;
  /** Decisions already put in front of the player, so they open only once. */
  private shownDecisions = new Set<string>();

  constructor(root: HTMLElement, engine: Engine) {
    this.root = root;
    this.engine = engine;
    this.lastAutosaveDay = engine.state.day;
  }

  register(entry: NavEntry): void {
    this.entries.push(entry);
  }

  start(): void {
    this.build();
    this.go(this.route);
    this.engine.start();

    on('tick', () => this.updateChrome());
    on('day', () => {
      this.maybeAutosave();
      this.refresh();
      this.maybeShowDecision();
    });
    on('alert', (alert) => {
      if (alert.priority === 'critical') toast(alert.title, 'bad');
      this.updateChrome();
    });

    // Views repaint a few times a second, which is plenty for numbers that
    // change hourly and keeps typing in forms from being interrupted.
    this.updateTimer = window.setInterval(() => {
      // A rebuild that was held back while the player was busy runs as soon as
      // they are not.
      if (this.pendingRebuild && !this.busy()) this.refresh();
      else if (!this.busy()) this.current?.update?.();
      this.updateChrome();
    }, 320);

    document.addEventListener('keydown', (event) => {
      if (event.target instanceof HTMLInputElement || event.target instanceof HTMLTextAreaElement) return;
      if (event.code === 'Space') {
        event.preventDefault();
        this.engine.togglePause();
        this.updateChrome();
      }
      const index = ['Digit1', 'Digit2', 'Digit3', 'Digit4'].indexOf(event.code);
      if (index >= 0) {
        this.engine.setSpeed(index + 1);
        this.updateChrome();
      }
    });
  }

  stop(): void {
    this.engine.stop();
    if (this.updateTimer !== null) window.clearInterval(this.updateTimer);
  }

  private get state(): GameState {
    return this.engine.state;
  }

  private ctx(): Ctx {
    return {
      engine: this.engine,
      state: this.state,
      go: (route, params) => this.go(route, params),
      refresh: () => this.refresh(),
      params: this.params,
    };
  }

  /**
   * Goes somewhere.
   *
   * The line between navigation and selection is drawn here, and it is drawn at
   * the screen: asking for a *different screen* is navigation, and a new screen
   * rightly starts at the top. Picking a different thing on the screen you are
   * already on is selection — choosing another location from the dropdown,
   * clicking another shop in the list — and selection must never move the
   * reader, because they are still reading the same page.
   *
   * That distinction used to be drawn at the parameters as well, which meant
   * choosing a different shop from halfway down the employee screen threw the
   * player back to the top of it. It was the last of the scroll jumps and it
   * was the least obvious, because from the code's point of view something had
   * genuinely changed.
   */
  go(route: string, params: Record<string, string> = {}): void {
    const entry = this.entries.find((item) => item.route === route) ?? this.entries[0];
    if (!entry) return;
    const movedScreen = entry.route !== this.route;
    this.route = entry.route;
    this.params = params;
    this.mount(entry, movedScreen);
  }

  /**
   * Rebuilds the screen the player is already on.
   *
   * The view is thrown away and built again, which is how this game has always
   * shown new numbers, and it is fast enough. What it must not do is move the
   * player: their scroll position is theirs, and a day passing is not a reason
   * to take it away. So the position is put back, and a rebuild is held off
   * entirely while they are typing or reading a dialog.
   */
  refresh(): void {
    const entry = this.entries.find((item) => item.route === this.route) ?? this.entries[0];
    if (!entry) return;
    if (this.busy()) {
      this.pendingRebuild = true;
      return;
    }
    this.pendingRebuild = false;
    this.mount(entry, false);
  }

  /**
   * True while the player is doing something a rebuild would interrupt: a
   * dialog is open, or the caret is in a field they are filling in.
   */
  private busy(): boolean {
    if (document.querySelector('.modal-overlay')) return true;
    const active = document.activeElement;
    if (!active || !this.main.contains(active)) return false;
    return (
      active instanceof HTMLInputElement ||
      active instanceof HTMLTextAreaElement ||
      active instanceof HTMLSelectElement
    );
  }

  private mount(entry: NavEntry, toTop: boolean): void {
    const scroll = this.main.scrollTop;
    this.current?.destroy?.();
    clear(this.main);
    this.current = entry.factory(this.ctx());
    this.main.appendChild(this.current.el);
    // Restoring before the browser has laid the new content out would clamp to
    // a height that does not exist yet, so it is set now and again on the next
    // frame, once the page is as tall as it is going to be.
    this.main.scrollTop = toTop ? 0 : scroll;
    if (!toTop && scroll > 0) {
      requestAnimationFrame(() => {
        if (this.main.scrollTop !== scroll) this.main.scrollTop = scroll;
      });
    }
    this.renderNav();
    this.renderPageHead(entry);
    this.updateChrome();
  }

  private build(): void {
    clear(this.root);
    this.topbar = h('header', { class: 'topbar' });
    this.navHost = h('nav', { class: 'nav' });
    this.mobileNavHost = h('nav', { class: 'mobile-nav' });
    this.main = h('main', { class: 'main' });

    const mark = h('div', { class: 'brand-mark' });
    mark.appendChild(icon('brand', 17));
    const brand = h(
      'div',
      { class: 'brand' },
      mark,
      h(
        'div',
        { style: 'min-width:0' },
        h('div', { class: 'brand-name', text: 'Business Manager' }),
        h('div', { class: 'brand-sub', id: 'brand-company', text: 'Northgate' }),
      ),
    );

    this.root.appendChild(
      h('div', { class: 'shell' }, brand, this.topbar, this.navHost, this.main, this.mobileNavHost),
    );
    this.renderNav();
    this.renderTopbar();
  }

  private renderNav(): void {
    for (const host of [this.navHost, this.mobileNavHost]) {
      clear(host);
      // The sidebar is grouped by what each screen is for; the phone bar is a
      // single scrolling row, where headings would only take up space.
      const grouped = host === this.navHost;
      let lastGroup = '';
      for (const entry of this.entries) {
        if (grouped && entry.group && entry.group !== lastGroup) {
          lastGroup = entry.group;
          host.appendChild(h('div', { class: 'nav-group', text: entry.group }));
        }
        const count = entry.badge?.(this.state) ?? 0;
        const glyph = h('span', { class: 'nav-icon' });
        glyph.appendChild(icon(entry.icon, 16));
        host.appendChild(
          h(
            'button',
            {
              class: `nav-item${entry.route === this.route ? ' active' : ''}`,
              data: { route: entry.route },
              title: entry.label,
              aria: { label: entry.label, current: entry.route === this.route ? 'page' : 'false' },
              on: { click: () => this.go(entry.route) },
            },
            glyph,
            h('span', { class: 'nav-label', text: entry.label }),
            count > 0 ? h('span', { class: 'nav-badge', text: String(count) }) : null,
          ),
        );
      }
    }
  }

  /**
   * The header.
   *
   * Left to right it answers: where am I, what is this screen for, what is the
   * company doing right now, what time is it, and who is playing. The live
   * figures sit in their own scroller so a narrow window shortens the strip
   * rather than widening the page.
   */
  private renderTopbar(): void {
    clear(this.topbar);

    this.topbar.appendChild(
      h(
        'div',
        { class: 'page-title' },
        h('h1', { id: 'page-title', text: 'Dashboard' }),
        h('p', { id: 'page-blurb', text: '' }),
      ),
    );

    this.topbar.appendChild(h('div', { class: 'topbar-spacer' }));

    const hud = h('div', { class: 'hud' });
    const metric = (label: string, id: string): HTMLElement =>
      h(
        'div',
        { class: 'metric' },
        h('span', { class: 'metric-label', text: label }),
        h('span', { class: 'metric-value', id }),
        h('span', { class: 'metric-sub', id: `${id}-sub` }),
      );
    // Three figures, not six. Company value, today's profit and the level are
    // all on the dashboard and the progress screen in more detail; repeating
    // them here only crowded out the name of the screen you are looking at.
    hud.appendChild(metric('Cash', 'hud-cash'));
    hud.appendChild(metric('Profit, 30 days', 'hud-month'));
    hud.appendChild(metric('Date', 'hud-date'));
    this.topbar.appendChild(hud);

    const speeds = h('div', { class: 'speed-group', id: 'hud-speeds' });
    SPEEDS.forEach((_, index) => {
      speeds.appendChild(
        h(
          'button',
          {
            class: 'speed-btn',
            data: { speed: String(index) },
            title: index === 0 ? 'Pause (space)' : `Speed ${SPEED_LABELS[index]}`,
            on: {
              click: () => {
                this.engine.setSpeed(index);
                this.updateChrome();
              },
            },
          },
          SPEED_LABELS[index],
        ),
      );
    });
    this.topbar.appendChild(speeds);

    const bellBtn = h('button', { class: 'icon-btn', title: 'Alerts', aria: { label: 'Alerts' }, on: { click: () => this.openAlerts() } });
    bellBtn.appendChild(icon('bell', 16));
    this.topbar.appendChild(
      h('div', { class: 'bell' }, bellBtn, h('span', { class: 'bell-count', id: 'hud-alerts', text: '0' })),
    );

    this.topbar.appendChild(
      h(
        'div',
        { class: 'whoami' },
        h('span', { class: 'avatar', id: 'hud-initials', text: '—' }),
        h(
          'div',
          { class: 'whoami-text' },
          h('span', { class: 'whoami-name', id: 'hud-founder', text: 'You' }),
          h('span', { class: 'whoami-sub', id: 'hud-company', text: '' }),
        ),
      ),
    );

    this.updateChrome();
  }

  /** Puts the name of the screen, and what it is for, into the header. */
  private renderPageHead(entry: NavEntry): void {
    const title = document.getElementById('page-title');
    const blurb = document.getElementById('page-blurb');
    if (title) title.textContent = entry.label;
    if (blurb) blurb.textContent = entry.blurb ?? '';
  }

  private updateChrome(): void {
    const state = this.state;
    const company = playerCompany(state);
    const set = (id: string, value: string, tone?: string): void => {
      const el = document.getElementById(id);
      if (!el) return;
      el.textContent = value;
      el.className = `metric-value${tone ? ` ${tone}` : ''}`;
    };
    const setSub = (id: string, value: string): void => {
      const el = document.getElementById(`${id}-sub`);
      if (el) el.textContent = value;
    };

    set('hud-cash', money(company.cash), company.cash < 0 ? 'bad' : undefined);
    const businesses = playerBusinesses(state).filter((b) => b.status === 'open').length;
    setSub('hud-cash', `${businesses} open · ${state.employees.length} staff`);

    const worth = netWorth(state);
    set('hud-worth', moneyShort(worth));
    setSub('hud-worth', currentTier(state).name);

    // Accrual profit over the last thirty days, which is the figure the levels
    // and the accounts are both measured on.
    const month = sum(state.dayHistory.slice(-30), (day) => day.profit);
    set('hud-month', moneySigned(month), month >= 0 ? 'good' : 'bad');
    const reputation = playerBusinesses(state).filter((b) => b.status === 'open');
    setSub(
      'hud-month',
      reputation.length > 0
        ? `reputation ${Math.round(sum(reputation, (b) => b.reputation) / reputation.length)}`
        : 'nothing trading',
    );

    const level = levelOf(state);
    const ahead = nextLevel(state);
    set('hud-level', `${level.n} · ${level.name}`);
    setSub('hud-level', ahead ? `${Math.round(levelProgress(state) * 100)}% to ${ahead.name}` : nextStep(state).title);

    let revenue = 0;
    let costs = 0;
    for (const business of playerBusinesses(state)) {
      revenue += business.today.revenue;
      costs +=
        business.today.cogs + business.today.wages + business.today.rent + business.today.marketing + business.today.otherCosts;
    }
    const profit = revenue - costs;
    set('hud-today', moneySigned(profit), profit >= 0 ? 'good' : 'bad');
    setSub('hud-today', `${money(revenue)} in`);

    const cal = calendar(state.day);
    set('hud-date', `${clockLabel(state.hour)}`);
    setSub('hud-date', `${cal.weekday.slice(0, 3)} ${cal.dayOfMonth} ${cal.monthName.slice(0, 3)} · ${economyLabel(state).label}`);

    const speeds = document.getElementById('hud-speeds');
    if (speeds) {
      for (const child of Array.from(speeds.children)) {
        const index = Number((child as HTMLElement).dataset.speed);
        child.className = `speed-btn${index === state.speed ? ' active' : ''}`;
      }
    }

    const founder = state.founder;
    const initials = document.getElementById('hud-initials');
    if (initials) {
      initials.textContent = (founder?.name ?? 'You')
        .split(/\s+/)
        .filter(Boolean)
        .slice(0, 2)
        .map((part) => part[0]?.toUpperCase() ?? '')
        .join('') || 'Y';
    }
    const who = document.getElementById('hud-founder');
    if (who) who.textContent = founder?.name ?? 'You';
    const firm = document.getElementById('hud-company');
    if (firm) firm.textContent = company.name;
    const brandCompany = document.getElementById('brand-company');
    if (brandCompany) brandCompany.textContent = company.name;

    const count = unreadAlerts(state).length;
    const badge = document.getElementById('hud-alerts');
    if (badge) {
      badge.textContent = String(count);
      badge.style.display = count > 0 ? '' : 'none';
    }

    this.renderNavBadges();
    this.renderTutorial();
  }

  private renderNavBadges(): void {
    for (const host of [this.navHost, this.mobileNavHost]) {
      // By route, not by position: the sidebar has group headings between the
      // buttons, so counting children puts every badge on the wrong screen.
      this.entries.forEach((entry) => {
        const item = host.querySelector(`.nav-item[data-route="${entry.route}"]`);
        if (!item) return;
        const count = entry.badge?.(this.state) ?? 0;
        const existing = item.querySelector('.nav-badge');
        if (count > 0) {
          if (existing) existing.textContent = String(count);
          else item.appendChild(h('span', { class: 'nav-badge', text: String(count) }));
        } else if (existing) {
          existing.remove();
        }
      });
    }
  }

  private renderTutorial(): void {
    this.tutorialHost?.remove();
    this.tutorialHost = renderTutorial(this.ctx());
    if (this.tutorialHost) document.body.appendChild(this.tutorialHost);
  }

  /**
   * The notification centre.
   *
   * Everything the simulation wanted to tell the player, in one place, worst
   * first — and every row goes somewhere. An alert you cannot act on is just
   * noise, so clicking one closes the centre and opens the screen the problem
   * lives on: the shop it is about, or the system that raised it.
   */
  private openAlerts(): void {
    const { body, close } = modal({ title: 'Notifications', width: 640 });
    const alerts = distinctAlerts(this.state);
    if (alerts.length === 0) {
      body.appendChild(h('p', { class: 'empty', text: 'Nothing needs your attention right now.' }));
    }

    const order: AlertPriority[] = ['critical', 'warning', 'info', 'success'];
    for (const priority of order) {
      const group = alerts.filter((alert) => alert.priority === priority);
      if (group.length === 0) continue;
      body.appendChild(
        h('div', { class: `alert-heading ${priority}` }, `${PRIORITY_LABELS[priority]} — ${group.length}`),
      );
      for (const alert of group) {
        const where = this.destinationOf(alert);
        const row = h(
          'div',
          { class: 'alert-row clickable-row' },
          h('span', { class: `alert-dot ${alert.priority}` }),
          h(
            'div',
            { style: 'flex:1' },
            h('div', { class: 'alert-title', text: alert.title }),
            h('div', { class: 'alert-detail', text: alert.detail }),
            h('div', { class: 'alert-go', text: `→ ${this.labelOf(where.route)}` }),
          ),
          h('span', { class: 'alert-time', text: `Day ${alert.day} ${clockLabel(alert.hour)}` }),
        );
        row.addEventListener('click', () => {
          close();
          this.go(where.route, where.params);
        });
        body.appendChild(row);
      }
    }

    markAlertsRead(this.state);
    this.updateChrome();
  }

  /** Where an alert takes the player when they click it. */
  private destinationOf(alert: Alert): { route: string; params?: Record<string, string> } {
    if (alert.businessId) return { route: 'businesses', params: { business: alert.businessId } };
    if (alert.view) return { route: alert.view };
    return { route: 'dashboard' };
  }

  private labelOf(route: string): string {
    return this.entries.find((entry) => entry.route === route)?.label ?? 'Dashboard';
  }

  /**
   * A new decision interrupts once, pausing the clock. Closing it without
   * choosing leaves it open in the newsroom until it expires.
   */
  private maybeShowDecision(): void {
    // Never stack dialogs on top of each other. If the player is already busy
    // with something, the decision waits in the newsroom and tries again
    // tomorrow — it is never lost, and it is never a pile of overlays.
    if (document.querySelector('.modal-overlay')) return;
    const decision = this.state.decisions.find((d) => !this.shownDecisions.has(d.id));
    if (!decision) return;
    this.shownDecisions.add(decision.id);
    showDecision(this.ctx(), decision);
  }

  private maybeAutosave(): void {
    const state = this.state;
    if (!state.settings.autosave) return;
    if (state.day === this.lastAutosaveDay) return;
    this.lastAutosaveDay = state.day;
    saveGame(state, AUTOSAVE_ID, 'Autosave', true);
  }
}
