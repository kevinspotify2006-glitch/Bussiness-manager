/**
 * The icon set.
 *
 * One family, drawn on the same 24-unit grid at the same 1.75 stroke, inheriting
 * `currentColor` so an icon is tinted by whatever it sits in rather than by a
 * copy of the palette. That is the whole reason these replaced the emoji the
 * interface used to navigate by: an emoji is a different picture on every
 * platform, it cannot take a colour, and a row of them never lines up.
 *
 * Every path here is drawn for this game. Adding one is cheap; reaching for a
 * second icon family is not, so don't.
 */

const P: Record<string, string> = {
  // ---- navigation
  dashboard: 'M3 3h7v8H3zM14 3h7v5h-7zM14 12h7v9h-7zM3 15h7v6H3z',
  you: 'M12 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8zM4 21a8 8 0 0 1 16 0',
  news: 'M4 5h13v14H4zM17 9h3v8a2 2 0 0 1-3 1.7M7 9h7M7 12h7M7 15h4',
  shop: 'M4 9h16l-1 11H5zM4 9l1.5-5h13L20 9M9 13v4M15 13v4',
  people: 'M9 12a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7zM2 20a7 7 0 0 1 14 0M17 6.5a3 3 0 0 1 0 6M18 20a6.5 6.5 0 0 0-2-4.7',
  inventory: 'M3 8l9-4 9 4-9 4zM3 8v8l9 4 9-4V8M12 12v8',
  truck: 'M3 6h11v10H3zM14 9h4l3 3v4h-7zM7.5 19a1.75 1.75 0 1 0 0-3.5 1.75 1.75 0 0 0 0 3.5zM17.5 19a1.75 1.75 0 1 0 0-3.5 1.75 1.75 0 0 0 0 3.5z',
  hq: 'M3 21h18M5 21V7l7-4 7 4v14M9 11h2M13 11h2M9 15h2M13 15h2',
  holding: 'M12 3v4M6 21v-6M18 21v-6M6 15h12v-2a2 2 0 0 0-2-2H8a2 2 0 0 0-2 2zM4 21h4M16 21h4',
  finance: 'M12 2v20M17 6.5C17 4.6 14.8 3.5 12 3.5S7 4.6 7 6.5s2.2 2.8 5 3.4 5 1.5 5 3.6-2.2 3-5 3-5-1.1-5-3',
  reports: 'M4 20V9M10 20V4M16 20v-7M22 20H2',
  marketing: 'M4 10v4h3l6 4V6L7 10zM17 9a4 4 0 0 1 0 6M20 6.5a8 8 0 0 1 0 11',
  property: 'M3 21h18M4 21V8l8-5 8 5v13M9 21v-6h6v6M8 11h2M14 11h2',
  progress: 'M7 21h10M12 17v4M6 4h12v5a6 6 0 0 1-12 0zM6 6H3v2a3 3 0 0 0 3 3M18 6h3v2a3 3 0 0 1-3 3',
  contracts: 'M7 3h7l5 5v13H7zM14 3v5h5M10 13h7M10 17h5',
  research: 'M9 3h6M10 3v6L5 19a2 2 0 0 0 1.8 3h10.4A2 2 0 0 0 19 19l-5-10V3M7.5 15h9',
  map: 'M9 4L3 6.5v14L9 18l6 2.5 6-2.5v-14L15 6.5zM9 4v14M15 6.5v14',
  competition: 'M6.5 3l5 11M17.5 3l-5 11M4 14h6l-1.5 7h-3zM14 14h6l-1.5 7h-3z',
  settings: 'M12 15.5a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7z M19.4 14.5a1.7 1.7 0 0 0 .3 1.9l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-2.9 1.2v.2a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-2.9-1.2l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0-1.2-2.9H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.2-2.9l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 2.9-1.2V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 2.9 1.2l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0 1.2 2.9H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z',

  // ---- figures and status
  cash: 'M2 7h20v10H2zM12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6zM5.5 7v10M18.5 7v10',
  revenue: 'M3 17l6-6 4 4 8-8M15 7h6v6',
  profit: 'M4 19h16M7 19v-6M12 19V7M17 19v-9',
  worth: 'M12 3l8 4.5v9L12 21l-8-4.5v-9zM12 12l8-4.5M12 12v9M12 12L4 7.5',
  level: 'M12 3l2.6 5.6 6 .8-4.4 4.3 1.1 6.2L12 17l-5.3 2.9 1.1-6.2L3.4 9.4l6-.8z',
  clock: 'M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18zM12 7v5l3.5 2',
  alert: 'M12 3l9 16H3zM12 9v5M12 17.5v.01',
  warning: 'M12 3l9 16H3zM12 9v5M12 17.5v.01',
  critical: 'M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18zM12 7.5v5.5M12 16.5v.01',
  info: 'M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18zM12 11v5M12 8v.01',
  good: 'M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18zM8.5 12.2l2.4 2.4 4.6-4.8',
  opportunity: 'M12 2.5a6 6 0 0 0-3.5 10.9V16h7v-2.6A6 6 0 0 0 12 2.5zM9.5 19h5M10.5 21.5h3',

  // ---- actions and chrome
  search: 'M11 18a7 7 0 1 0 0-14 7 7 0 0 0 0 14zM20 20l-4-4',
  bell: 'M18 9a6 6 0 1 0-12 0c0 5-2 6-2 6h16s-2-1-2-6M10.5 20a1.8 1.8 0 0 0 3 0',
  plus: 'M12 5v14M5 12h14',
  chevron: 'M9 5l7 7-7 7',
  close: 'M6 6l12 12M18 6L6 18',
  filter: 'M3 5h18l-7 8v6l-4 2v-8z',
  download: 'M12 3v12M7.5 10.5L12 15l4.5-4.5M4 19h16',
  brand: 'M4 20V9M10 20V4M16 20v-8M22 20H2',
};

/** An icon, sized by the box it sits in and coloured by what it sits in. */
export function icon(name: string, size = 16): SVGSVGElement {
  const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
  svg.setAttribute('viewBox', '0 0 24 24');
  svg.setAttribute('width', String(size));
  svg.setAttribute('height', String(size));
  svg.setAttribute('fill', 'none');
  svg.setAttribute('stroke', 'currentColor');
  svg.setAttribute('stroke-width', '1.75');
  svg.setAttribute('stroke-linecap', 'round');
  svg.setAttribute('stroke-linejoin', 'round');
  svg.setAttribute('aria-hidden', 'true');
  const path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
  path.setAttribute('d', P[name] ?? P.info);
  svg.appendChild(path);
  return svg;
}
