import type { GameState } from '../sim/state';
import { businessById } from '../sim/state';
import type { Building, DistrictDef } from '../sim/types';
import { DISTRICTS } from '../data/districts';
import { businessType } from '../data/businessTypes';
import type { Amenity, Filler, FillerKind, Road } from '../sim/cityLayout';
import { cityLayout } from '../sim/cityLayout';
import { asset } from '../data/atlas';
import { paintAsset, paintFurniture, paintTree, paintVehicle } from './sprites';
import type { Traffic } from '../sim/traffic';
import { advanceTraffic, createTraffic, vehiclePosition } from '../sim/traffic';
import type { MapReport } from '../sim/validateMap';
import { validateMap } from '../sim/validateMap';
import { clamp } from '../sim/util';

/**
 * The city map.
 *
 * Everything is drawn in code at the device's real pixel density, so it stays
 * sharp at any zoom level on any screen. The layout never changes; the overlays
 * are what turn it into an analysis tool.
 */

export type MapMode = 'standard' | 'commercial' | 'demand' | 'income' | 'competition' | 'property' | 'traffic';

export const MAP_MODES: { id: MapMode; label: string; legend: string }[] = [
  { id: 'standard', label: 'Standard', legend: 'Districts and available units' },
  { id: 'commercial', label: 'Commercial', legend: 'Units suitable for business' },
  { id: 'demand', label: 'Demand', legend: 'Customer demand per district' },
  { id: 'income', label: 'Income', legend: 'Average household income' },
  { id: 'competition', label: 'Competition', legend: 'Competitor density' },
  { id: 'property', label: 'Property', legend: 'Price per square metre' },
  { id: 'traffic', label: 'Traffic', legend: 'Foot traffic at each address' },
];

const CITY_W = 1;
const CITY_H = 0.92;
const MIN_ZOOM = 0.85;
// Past about 9x a single shopfront fills the screen and the city stops
// reading as a city, so that is where zooming stops.
const MAX_ZOOM = 9;

export interface Camera {
  x: number;
  y: number;
  zoom: number;
}

interface Pointer {
  id: number;
  x: number;
  y: number;
}

/** Blue → amber → red ramp used by every data overlay. */
function heat(value: number): string {
  const t = clamp(value, 0, 1);
  if (t < 0.5) {
    const k = t / 0.5;
    return `rgb(${Math.round(58 + k * 92)}, ${Math.round(110 + k * 60)}, ${Math.round(180 - k * 40)})`;
  }
  const k = (t - 0.5) / 0.5;
  return `rgb(${Math.round(150 + k * 90)}, ${Math.round(170 - k * 90)}, ${Math.round(140 - k * 90)})`;
}


/** How much of each layer is worth drawing at the current zoom. */
interface Detail {
  /** Pixels per world unit. */
  s: number;
  /** Houses, blocks, side streets — the fabric of the city. */
  fabric: boolean;
  /** Pavements and drop shadows. */
  kerbs: boolean;
  /** Lane markings, roofs, shopfronts. */
  markings: boolean;
  /** Trees, fountains, park names, street names. */
  scenery: boolean;
  /** Bus stops, signals, addresses, roof plant. */
  fine: boolean;
  /** District names rather than abbreviations. */
  labels: boolean;
}

/** The city's palette. Muted, so the data overlays and the player's own units carry the colour. */
const C = {
  ground: '#0a1119',
  land: '#141c26',
  water: '#0e2536',
  waterEdge: 'rgba(120,170,200,0.22)',
  road: '#333e4d',
  roadMain: '#3d4a5b',
  runway: '#39424e',
  taxiway: '#333b46',
  path: '#44505f',
  pavement: '#4c5a6b',
  kerb: 'rgba(10,16,23,0.55)',
  outskirts: '#101a17',
  marking: 'rgba(226,214,160,0.5)',
  ballast: '#2b3037',
  rail: '#6b7784',
  park: '#1c3324',
  pitch: '#22412c',
  plaza: '#2a3340',
  parking: '#262f3a',
  quay: '#28323d',
  shadow: 'rgba(0,0,0,0.34)',
  roadLabel: 'rgba(190,205,222,0.55)',
};

/** Uses that are ground, not buildings: they go under the roads. */
const GROUND_KINDS = new Set<FillerKind>([
  'park', 'plaza', 'parking', 'pitch', 'quay',
  'field', 'orchard', 'pasture', 'solar',
]);

/** Everything outside the ring road, drawn muted so the city still leads. */
const COUNTRY_KINDS = new Set<FillerKind>(['field', 'orchard', 'pasture', 'solar', 'turbine', 'glasshouse', 'farmstead']);

export class CityMap {
  /**
   * The map currently on screen. The map is a canvas, so it has no DOM for a
   * test to drive; this is how the browser tests point the camera somewhere and
   * check what got drawn.
   */
  static current: CityMap | null = null;

  readonly canvas: HTMLCanvasElement;
  /**
   * The city is painted into an off-screen canvas and blitted; only the traffic
   * is redrawn every frame. Northgate is several thousand shapes, and repainting
   * all of them sixty times a second to move ninety vehicles would be absurd.
   */
  private base: HTMLCanvasElement;
  private ctx: CanvasRenderingContext2D;
  private screen: CanvasRenderingContext2D;
  private baseDirty = true;
  private traffic: Traffic | null = null;
  private raf: number | null = null;
  private lastFrame = 0;
  private debug = false;
  private report: MapReport | null = null;
  private state: GameState;
  private camera: Camera;
  private mode: MapMode = 'standard';
  private pointers: Pointer[] = [];
  private dragged = false;
  private pinchStart = 0;
  private pinchZoom = 1;
  private hoverId: string | null = null;
  private selectedId: string | null = null;
  private dpr = 1;
  private cssW = 0;
  private cssH = 0;
  private frame: number | null = null;
  private resizeObserver: ResizeObserver | null = null;

  onSelect: (building: Building | null) => void = () => {};

  constructor(state: GameState, camera: Camera) {
    this.state = state;
    this.camera = camera;
    this.canvas = document.createElement('canvas');
    this.canvas.className = 'map-canvas';
    const context = this.canvas.getContext('2d');
    if (!context) throw new Error('Canvas 2D is not available in this browser.');
    this.screen = context;
    this.base = document.createElement('canvas');
    const baseContext = this.base.getContext('2d');
    if (!baseContext) throw new Error('Canvas 2D is not available in this browser.');
    this.ctx = baseContext;
    CityMap.current = this;
    this.attach();
    this.run();
  }

  /** Points the camera at a place, for tests and for the "show me" buttons. */
  setCamera(x: number, y: number, zoom: number): void {
    this.camera.x = x;
    this.camera.y = y;
    this.camera.zoom = clamp(zoom, MIN_ZOOM, MAX_ZOOM);
    this.draw();
  }

  /**
   * The check-your-work view: footprints, the road graph the traffic runs on,
   * district boundaries, the route every vehicle is driving, and a marker on
   * anything `validateMap()` found wrong with the city.
   */
  setDebug(on: boolean): void {
    this.debug = on;
    if (on && !this.report) this.report = validateMap();
    this.draw();
  }

  getDebug(): boolean {
    return this.debug;
  }

  /** What the last check found. Runs the check if it has not run yet. */
  checkMap(): MapReport {
    if (!this.report) this.report = validateMap();
    return this.report;
  }

  setMode(mode: MapMode): void {
    this.mode = mode;
    this.draw();
  }

  getMode(): MapMode {
    return this.mode;
  }

  setState(state: GameState): void {
    this.state = state;
    this.draw();
  }

  select(id: string | null): void {
    this.selectedId = id;
    this.draw();
  }

  /** Centres the view on a building without changing zoom. */
  focus(building: Building, zoom = 4): void {
    this.camera.x = building.x + building.w / 2;
    this.camera.y = building.y + building.h / 2;
    this.camera.zoom = clamp(zoom, MIN_ZOOM, MAX_ZOOM);
    this.draw();
  }

  zoomBy(factor: number): void {
    this.camera.zoom = clamp(this.camera.zoom * factor, MIN_ZOOM, MAX_ZOOM);
    this.clampCamera();
    this.draw();
  }

  resize(): void {
    const rect = this.canvas.getBoundingClientRect();
    // The canvas keeps a 16:10 shape so the city is never squashed.
    const width = Math.max(240, rect.width);
    const height = clamp(width * 0.72, 280, 780);
    this.cssW = width;
    this.cssH = height;
    this.dpr = Math.min(window.devicePixelRatio || 1, 3);
    this.canvas.style.height = `${height}px`;
    this.canvas.width = Math.round(width * this.dpr);
    this.canvas.height = Math.round(height * this.dpr);
    this.base.width = this.canvas.width;
    this.base.height = this.canvas.height;
    this.draw();
  }

  destroy(): void {
    this.resizeObserver?.disconnect();
    if (this.frame !== null) cancelAnimationFrame(this.frame);
    if (this.raf !== null) cancelAnimationFrame(this.raf);
    this.raf = null;
    if (CityMap.current === this) CityMap.current = null;
  }

  /**
   * The traffic loop. It runs only while the map is on screen and the clock is
   * running: a paused game is a still city, and a map nobody is looking at
   * costs nothing.
   */
  private run(): void {
    const step = (now: number): void => {
      this.raf = requestAnimationFrame(step);
      if (!this.canvas.isConnected || document.hidden) {
        this.lastFrame = now;
        return;
      }
      const dt = Math.min(0.06, (now - this.lastFrame) / 1000);
      this.lastFrame = now;
      const speed = this.state.speed ?? 1;
      let moved = false;
      if (!this.traffic) {
        this.traffic = createTraffic();
        moved = true;
      }
      if (speed > 0 && dt > 0) {
        advanceTraffic(this.traffic, dt * Math.min(speed, 3));
        moved = true;
      }
      if (moved || this.baseDirty) this.render();
    };
    this.raf = requestAnimationFrame(step);
  }

  // ---------------------------------------------------------- projection

  private scale(): number {
    return Math.min(this.cssW / CITY_W, this.cssH / CITY_H) * this.camera.zoom;
  }

  private toScreen(x: number, y: number): { x: number; y: number } {
    const s = this.scale();
    return {
      x: (x - this.camera.x) * s + this.cssW / 2,
      y: (y - this.camera.y) * s + this.cssH / 2,
    };
  }

  private toWorld(px: number, py: number): { x: number; y: number } {
    const s = this.scale();
    return {
      x: (px - this.cssW / 2) / s + this.camera.x,
      y: (py - this.cssH / 2) / s + this.camera.y,
    };
  }

  private clampCamera(): void {
    // Allow a small margin so edge districts can be centred.
    const s = this.scale();
    const halfW = this.cssW / 2 / s;
    const halfH = this.cssH / 2 / s;
    const margin = 0.06;
    const minX = Math.min(halfW - margin, CITY_W / 2);
    const maxX = Math.max(CITY_W - halfW + margin, CITY_W / 2);
    const minY = Math.min(halfH - margin, CITY_H / 2);
    const maxY = Math.max(CITY_H - halfH + margin, CITY_H / 2);
    this.camera.x = clamp(this.camera.x, minX, maxX);
    this.camera.y = clamp(this.camera.y, minY, maxY);
  }

  // ------------------------------------------------------------- input

  private attach(): void {
    const canvas = this.canvas;
    canvas.addEventListener('pointerdown', (event) => {
      canvas.setPointerCapture(event.pointerId);
      this.pointers.push({ id: event.pointerId, x: event.clientX, y: event.clientY });
      this.dragged = false;
      if (this.pointers.length === 2) {
        this.pinchStart = this.pointerDistance();
        this.pinchZoom = this.camera.zoom;
      }
      canvas.classList.add('dragging');
    });

    canvas.addEventListener('pointermove', (event) => {
      const index = this.pointers.findIndex((p) => p.id === event.pointerId);
      if (index === -1) {
        this.updateHover(event);
        return;
      }
      const previous = this.pointers[index];
      const dx = event.clientX - previous.x;
      const dy = event.clientY - previous.y;
      this.pointers[index] = { id: event.pointerId, x: event.clientX, y: event.clientY };

      if (this.pointers.length === 2 && this.pinchStart > 0) {
        const distance = this.pointerDistance();
        this.camera.zoom = clamp((distance / this.pinchStart) * this.pinchZoom, MIN_ZOOM, MAX_ZOOM);
        this.dragged = true;
        this.clampCamera();
        this.draw();
        return;
      }

      if (Math.abs(dx) > 2 || Math.abs(dy) > 2) this.dragged = true;
      const s = this.scale();
      this.camera.x -= dx / s;
      this.camera.y -= dy / s;
      this.clampCamera();
      this.draw();
    });

    const release = (event: PointerEvent): void => {
      const wasSingle = this.pointers.length === 1;
      this.pointers = this.pointers.filter((p) => p.id !== event.pointerId);
      if (this.pointers.length < 2) this.pinchStart = 0;
      if (this.pointers.length === 0) canvas.classList.remove('dragging');
      if (wasSingle && !this.dragged) this.handleTap(event);
    };
    canvas.addEventListener('pointerup', release);
    canvas.addEventListener('pointercancel', release);

    canvas.addEventListener(
      'wheel',
      (event) => {
        event.preventDefault();
        const rect = canvas.getBoundingClientRect();
        const before = this.toWorld(event.clientX - rect.left, event.clientY - rect.top);
        this.camera.zoom = clamp(this.camera.zoom * (event.deltaY < 0 ? 1.16 : 1 / 1.16), MIN_ZOOM, MAX_ZOOM);
        const after = this.toWorld(event.clientX - rect.left, event.clientY - rect.top);
        // Keep the point under the cursor fixed while zooming.
        this.camera.x += before.x - after.x;
        this.camera.y += before.y - after.y;
        this.clampCamera();
        this.draw();
      },
      { passive: false },
    );

    canvas.addEventListener('pointerleave', () => {
      this.hoverId = null;
      this.draw();
    });

    if ('ResizeObserver' in window) {
      this.resizeObserver = new ResizeObserver(() => this.resize());
      this.resizeObserver.observe(canvas);
    } else {
      globalThis.addEventListener('resize', () => this.resize());
    }
  }

  private pointerDistance(): number {
    if (this.pointers.length < 2) return 0;
    return Math.hypot(this.pointers[0].x - this.pointers[1].x, this.pointers[0].y - this.pointers[1].y);
  }

  private updateHover(event: PointerEvent): void {
    const rect = this.canvas.getBoundingClientRect();
    const found = this.pick(event.clientX - rect.left, event.clientY - rect.top);
    const id = found?.id ?? null;
    if (id !== this.hoverId) {
      this.hoverId = id;
      this.draw();
    }
  }

  private handleTap(event: PointerEvent): void {
    const rect = this.canvas.getBoundingClientRect();
    const found = this.pick(event.clientX - rect.left, event.clientY - rect.top);
    this.selectedId = found?.id ?? null;
    this.onSelect(found);
    this.draw();
  }

  /** Finds the building under a screen point, with a touch-friendly margin. */
  private pick(px: number, py: number): Building | null {
    const world = this.toWorld(px, py);
    const s = this.scale();
    // At least a 22px target, so small units stay tappable on a phone.
    const pad = Math.max(0, (11 - 0) / s);
    let best: Building | null = null;
    let bestDistance = Infinity;
    for (const building of this.state.buildings) {
      const inside =
        world.x >= building.x - pad &&
        world.x <= building.x + building.w + pad &&
        world.y >= building.y - pad &&
        world.y <= building.y + building.h + pad;
      if (!inside) continue;
      const cx = building.x + building.w / 2;
      const cy = building.y + building.h / 2;
      const distance = (world.x - cx) ** 2 + (world.y - cy) ** 2;
      if (distance < bestDistance) {
        bestDistance = distance;
        best = building;
      }
    }
    return best;
  }

  // ------------------------------------------------------------ drawing

  draw(): void {
    this.baseDirty = true;
    if (this.frame !== null) return;
    this.frame = requestAnimationFrame(() => {
      this.frame = null;
      this.render();
    });
  }

  /** Blits the city, then draws the traffic on top of it. */
  private render(): void {
    if (this.cssW === 0) this.resize();
    if (this.baseDirty) {
      this.paint();
      this.baseDirty = false;
    }
    this.screen.setTransform(1, 0, 0, 1, 0, 0);
    this.screen.clearRect(0, 0, this.canvas.width, this.canvas.height);
    this.screen.drawImage(this.base, 0, 0);
    this.paintTraffic();
    if (this.debug) this.paintDebug();
  }

  private paintDebug(): void {
    const ctx = this.screen;
    const s = this.scale();
    const layout = cityLayout();
    ctx.setTransform(this.dpr, 0, 0, this.dpr, 0, 0);

    // District boundaries.
    ctx.strokeStyle = 'rgba(120,190,255,0.5)';
    ctx.lineWidth = 1;
    for (const def of DISTRICTS) {
      const p = this.toScreen(def.x, def.y);
      ctx.strokeRect(p.x, p.y, def.w * s, def.h * s);
    }

    // Footprints, so overlapping buildings are obvious.
    ctx.strokeStyle = 'rgba(255,255,255,0.22)';
    for (const filler of layout.fillers) {
      if (!this.visible(filler)) continue;
      const p = this.toScreen(filler.x, filler.y);
      ctx.strokeRect(p.x, p.y, filler.w * s, filler.h * s);
    }

    // The road graph the traffic actually drives on.
    if (this.traffic) {
      const graph = this.traffic.graph;
      ctx.strokeStyle = 'rgba(255,200,90,0.35)';
      ctx.beginPath();
      for (const edge of graph.edges) {
        if (edge.from > edge.to) continue;
        const a = this.toScreen(graph.nodes[edge.from].x, graph.nodes[edge.from].y);
        const b = this.toScreen(graph.nodes[edge.to].x, graph.nodes[edge.to].y);
        ctx.moveTo(a.x, a.y);
        ctx.lineTo(b.x, b.y);
      }
      ctx.stroke();
      ctx.fillStyle = 'rgba(255,220,140,0.8)';
      for (const node of graph.nodes) {
        const p = this.toScreen(node.x, node.y);
        if (p.x < 0 || p.x > this.cssW || p.y < 0 || p.y > this.cssH) continue;
        ctx.fillRect(p.x - 1.5, p.y - 1.5, 3, 3);
      }
      // Where each vehicle is going.
      ctx.strokeStyle = 'rgba(120,255,190,0.5)';
      ctx.beginPath();
      for (const vehicle of this.traffic.vehicles) {
        for (let i = vehicle.leg; i + 1 < vehicle.path.length; i += 1) {
          const a = this.toScreen(graph.nodes[vehicle.path[i]].x, graph.nodes[vehicle.path[i]].y);
          const b = this.toScreen(graph.nodes[vehicle.path[i + 1]].x, graph.nodes[vehicle.path[i + 1]].y);
          ctx.moveTo(a.x, a.y);
          ctx.lineTo(b.x, b.y);
        }
      }
      ctx.stroke();
    }

    // Anything the checker found.
    const report = this.checkMap();
    ctx.strokeStyle = '#ff5a5a';
    ctx.lineWidth = 2;
    for (const problem of report.problems) {
      const p = this.toScreen(problem.at.x, problem.at.y);
      ctx.beginPath();
      ctx.arc(p.x, p.y, 7, 0, Math.PI * 2);
      ctx.stroke();
    }

    // The tally, top left.
    const c = report.counts;
    ctx.fillStyle = 'rgba(8,14,22,0.82)';
    ctx.fillRect(8, 8, 232, 74);
    ctx.fillStyle = '#dbe6f2';
    ctx.font = '11px system-ui, sans-serif';
    ctx.textAlign = 'left';
    ctx.fillText(`${c.roads} roads · ${c.nodes} junctions · ${c.edges} links`, 16, 26);
    ctx.fillText(`${c.structures} buildings · ${c.plots} units · ${c.amenities} details`, 16, 42);
    ctx.fillText(`${c.parking} car parks · ${this.traffic?.vehicles.length ?? 0} vehicles`, 16, 58);
    ctx.fillStyle = report.problems.length === 0 ? '#7fd6a2' : '#ff7b7b';
    ctx.fillText(
      report.problems.length === 0 ? 'no problems found' : `${report.problems.length} problems`,
      16,
      74,
    );
  }

  /**
   * The moving city. Every vehicle is somewhere on an edge of the road graph,
   * so none of them can be anywhere but on a road.
   */
  private paintTraffic(): void {
    if (!this.traffic) return;
    const s = this.scale();
    // Below this a vehicle is smaller than a pixel and the road is a line.
    if (s < 1400) return;
    const ctx = this.screen;
    const detail = { markings: s > 1900, fine: s > 4200 };
    ctx.setTransform(this.dpr, 0, 0, this.dpr, 0, 0);
    for (const vehicle of this.traffic.vehicles) {
      const at = vehiclePosition(vehicle);
      const p = this.toScreen(at.x, at.y);
      if (p.x < -20 || p.x > this.cssW + 20 || p.y < -20 || p.y > this.cssH + 20) continue;
      paintVehicle(
        ctx,
        asset(vehicle.asset),
        p.x, p.y, at.heading,
        Math.max(2.5, vehicle.length * s),
        Math.max(1.2, vehicle.width * s),
        detail,
      );
    }
  }

  /**
   * One frame of Northgate.
   *
   * Drawn the way a city is built up: ground, water, parks, then the roads,
   * then everything standing on the blocks, then the details you only notice
   * when you are close — trees, crossings, street names. Each layer has a zoom
   * at which it starts being worth drawing, which is what keeps the whole city
   * on screen at once from costing anything.
   */
  private paint(): void {
    const ctx = this.ctx;
    const layout = cityLayout();
    ctx.setTransform(this.dpr, 0, 0, this.dpr, 0, 0);
    ctx.clearRect(0, 0, this.cssW, this.cssH);

    const s = this.scale();
    const detail: Detail = {
      s,
      fabric: s > 560,
      kerbs: s > 1500,
      markings: s > 1900,
      scenery: s > 2400,
      fine: s > 4200,
      labels: s > 520,
    };

    // Ground, the country beyond the city, then water.
    ctx.fillStyle = C.ground;
    ctx.fillRect(0, 0, this.cssW, this.cssH);
    this.paintOutskirts();
    for (const body of layout.water) this.paintWater(body);

    // District ground tint: the land each district sits on.
    for (const def of DISTRICTS) this.paintDistrictGround(def);

    // Ground-level uses, under the roads: parks, plazas, yards, water frontage.
    if (detail.fabric) {
      for (const filler of layout.fillers) {
        if (!GROUND_KINDS.has(filler.kind)) continue;
        if (!this.visible(filler)) continue;
        this.paintGroundFiller(filler, detail);
      }
    }

    // The road network.
    this.paintRoads(layout.roads, detail);

    // Everything standing on the blocks.
    if (detail.fabric) {
      for (const filler of layout.fillers) {
        if (GROUND_KINDS.has(filler.kind)) continue;
        if (!this.visible(filler)) continue;
        this.paintStructure(filler, detail);
      }
    }

    // The data overlays sit above the fabric and below the units, so a heat map
    // still reads as a heat map without hiding what the player owns.
    if (this.mode !== 'standard') {
      for (const def of DISTRICTS) this.paintOverlay(def);
    }

    // Street furniture.
    if (detail.scenery) this.paintAmenities(layout.amenities, detail);

    // The units the game actually trades in, on top of everything.
    for (const building of this.state.buildings) {
      if (!this.visible(building)) continue;
      this.paintBuilding(building, detail);
    }

    // Names.
    if (detail.scenery) this.paintRoadNames(layout.roads, detail);
    if (detail.labels) {
      for (const park of layout.parks) this.paintParkName(park, detail);
      for (const def of DISTRICTS) this.paintDistrictLabel(def, detail);
    } else {
      for (const def of DISTRICTS) this.paintDistrictShort(def);
    }
  }

  /**
   * The country the city sits in. Northgate does not stop at a hard edge: the
   * land runs on, and the main roads run out into it.
   */
  private paintOutskirts(): void {
    const ctx = this.ctx;
    const s = this.scale();
    const p = this.toScreen(-0.2, -0.2);
    ctx.fillStyle = C.outskirts;
    ctx.fillRect(p.x, p.y, 1.4 * s, 1.34 * s);
  }

  /** Is any part of this rectangle on screen? */
  private visible(rect: { x: number; y: number; w: number; h: number }): boolean {
    const p = this.toScreen(rect.x, rect.y);
    const s = this.scale();
    return !(p.x + rect.w * s < -8 || p.x > this.cssW + 8 || p.y + rect.h * s < -8 || p.y > this.cssH + 8);
  }

  private paintWater(body: { x: number; y: number; w: number; h: number }): void {
    const ctx = this.ctx;
    const p = this.toScreen(body.x, body.y);
    const s = this.scale();
    ctx.fillStyle = C.water;
    ctx.fillRect(p.x, p.y, body.w * s, body.h * s);
    // A lighter band at the edge reads as a shoreline rather than a hole.
    ctx.strokeStyle = C.waterEdge;
    ctx.lineWidth = Math.max(1, s * 0.0016);
    ctx.strokeRect(p.x, p.y, body.w * s, body.h * s);
  }

  private paintDistrictGround(def: DistrictDef): void {
    const ctx = this.ctx;
    const p = this.toScreen(def.x, def.y);
    const s = this.scale();
    const w = def.w * s;
    const h = def.h * s;
    if (p.x + w < -40 || p.x > this.cssW + 40 || p.y + h < -40 || p.y > this.cssH + 40) return;
    ctx.fillStyle = C.land;
    ctx.fillRect(p.x, p.y, w, h);
    // A breath of the district's own colour, so neighbourhoods differ.
    ctx.globalAlpha = 0.1;
    ctx.fillStyle = def.colour;
    ctx.fillRect(p.x, p.y, w, h);
    ctx.globalAlpha = 1;
  }

  private paintOverlay(def: DistrictDef): void {
    const ctx = this.ctx;
    const value = this.districtValue(def);
    if (value < 0) return;
    const p = this.toScreen(def.x, def.y);
    const s = this.scale();
    ctx.globalAlpha = 0.42;
    ctx.fillStyle = heat(value);
    ctx.fillRect(p.x, p.y, def.w * s, def.h * s);
    ctx.globalAlpha = 1;
    ctx.strokeStyle = 'rgba(255,255,255,0.16)';
    ctx.lineWidth = 1;
    ctx.strokeRect(p.x + 0.5, p.y + 0.5, def.w * s - 1, def.h * s - 1);
  }

  // ------------------------------------------------------------- roads

  private paintRoads(roads: Road[], detail: Detail): void {
    const ctx = this.ctx;
    const s = detail.s;
    ctx.lineJoin = 'round';
    ctx.lineCap = 'butt';

    const trace = (road: Road): void => {
      ctx.beginPath();
      road.pts.forEach((pt, index) => {
        const p = this.toScreen(pt.x, pt.y);
        if (index === 0) ctx.moveTo(p.x, p.y);
        else ctx.lineTo(p.x, p.y);
      });
    };

    const carriageways = roads.filter((road) => road.cls !== 'rail');
    const minor = (road: Road): boolean => road.cls === 'lane' || road.cls === 'street';

    // Pavements first, as a wider band under the asphalt.
    if (detail.kerbs) {
      ctx.strokeStyle = C.pavement;
      for (const road of carriageways) {
        if (road.cls === 'runway' || road.cls === 'taxiway') continue;
        if (minor(road) && !detail.fabric) continue;
        ctx.lineWidth = road.width * s + Math.min(Math.max(2, s * 0.0022), 9);
        trace(road);
        ctx.stroke();
      }
    }

    // The carriageway.
    for (const road of carriageways) {
      if (minor(road) && !detail.fabric) continue;
      ctx.strokeStyle =
        road.cls === 'arterial' ? C.roadMain
        : road.cls === 'runway' ? C.runway
        : road.cls === 'taxiway' ? C.taxiway
        : road.cls === 'pedestrian' || road.cls === 'path' ? C.path
        : C.road;
      ctx.lineWidth = Math.max(road.cls === 'arterial' ? 1.6 : 0.8, road.width * s);
      trace(road);
      ctx.stroke();
    }

    // Lane markings, which are what make a road read as a road.
    if (detail.markings) {
      ctx.strokeStyle = C.marking;
      ctx.lineWidth = Math.max(1, s * 0.0006);
      ctx.setLineDash([s * 0.006, s * 0.005]);
      for (const road of carriageways) {
        if (road.cls !== 'arterial' && road.cls !== 'runway') continue;
        trace(road);
        ctx.stroke();
      }
      ctx.setLineDash([]);

      // Ordinary streets get a kerb line rather than markings: it is what
      // separates the carriageway from the pavement when you are close in.
      if (detail.fine) {
        ctx.strokeStyle = C.kerb;
        ctx.lineWidth = 1;
        for (const road of carriageways) {
          if (road.cls === 'runway' || road.cls === 'taxiway') continue;
          for (const side of [-0.5, 0.5]) {
            const vertical = Math.abs(road.pts[road.pts.length - 1].x - road.pts[0].x) < 0.0001;
            ctx.beginPath();
            road.pts.forEach((pt, index) => {
              const offset = road.width * side;
              const q = this.toScreen(pt.x + (vertical ? offset : 0), pt.y + (vertical ? 0 : offset));
              if (index === 0) ctx.moveTo(q.x, q.y);
              else ctx.lineTo(q.x, q.y);
            });
            ctx.stroke();
          }
        }
      }
    }

    // The railway: ballast, then the rails themselves.
    for (const road of roads) {
      if (road.cls !== 'rail') continue;
      ctx.strokeStyle = C.ballast;
      ctx.lineWidth = Math.max(1.4, road.width * s);
      trace(road);
      ctx.stroke();
      if (detail.markings) {
        ctx.strokeStyle = C.rail;
        ctx.lineWidth = Math.max(0.6, road.width * s * 0.16);
        for (const offset of [-road.width * 0.3, road.width * 0.3]) {
          ctx.beginPath();
          road.pts.forEach((pt, index) => {
            const vertical = road.pts.length > 1 && Math.abs(road.pts[1].x - road.pts[0].x) < 0.0001;
            const p = this.toScreen(pt.x + (vertical ? offset : 0), pt.y + (vertical ? 0 : offset));
            if (index === 0) ctx.moveTo(p.x, p.y);
            else ctx.lineTo(p.x, p.y);
          });
          ctx.stroke();
        }
      }
    }
  }

  private paintRoadNames(roads: Road[], detail: Detail): void {
    const ctx = this.ctx;
    ctx.font = '600 9px system-ui, sans-serif';
    ctx.textAlign = 'center';
    ctx.fillStyle = C.roadLabel;
    for (const road of roads) {
      if (!road.name || road.pts.length < 2) continue;
      if (!road.major && !detail.fine) continue;
      const a = road.pts[0];
      const b = road.pts[road.pts.length - 1];
      const vertical = Math.abs(b.x - a.x) < Math.abs(b.y - a.y);
      // Put the label where the road is actually on screen.
      const mid = vertical
        ? { x: a.x, y: clamp(this.camera.y, Math.min(a.y, b.y) + 0.02, Math.max(a.y, b.y) - 0.02) }
        : { x: clamp(this.camera.x, Math.min(a.x, b.x) + 0.02, Math.max(a.x, b.x) - 0.02), y: a.y };
      const p = this.toScreen(mid.x, mid.y);
      if (p.x < -60 || p.x > this.cssW + 60 || p.y < -20 || p.y > this.cssH + 20) continue;
      ctx.save();
      ctx.translate(p.x, p.y);
      if (vertical) ctx.rotate(-Math.PI / 2);
      ctx.fillText(road.name, 0, -Math.max(3, road.width * detail.s * 0.5 + 3));
      ctx.restore();
    }
  }

  // -------------------------------------------------------- the fabric

  private paintGroundFiller(filler: Filler, detail: Detail): void {
    const ctx = this.ctx;
    const p = this.toScreen(filler.x, filler.y);
    const s = detail.s;
    const w = filler.w * s;
    const h = filler.h * s;

    // The country beyond the ring road is the pack's farmland, muted so the
    // city keeps the eye.
    if (COUNTRY_KINDS.has(filler.kind)) {
      ctx.globalAlpha = 0.38;
      paintAsset(ctx, asset(filler.asset), { x: p.x, y: p.y, w, h }, filler.tone, detail);
      ctx.globalAlpha = 1;
      return;
    }

    switch (filler.kind) {
      case 'park':
        ctx.fillStyle = C.park;
        ctx.fillRect(p.x, p.y, w, h);
        // Paths, stalls, graves, swings — whatever this green actually is.
        paintAsset(ctx, asset(filler.asset), { x: p.x, y: p.y, w, h }, filler.tone, { ...detail, base: false });
        break;
      case 'pitch':
        ctx.fillStyle = C.pitch;
        ctx.fillRect(p.x, p.y, w, h);
        if (detail.markings) {
          ctx.strokeStyle = 'rgba(255,255,255,0.22)';
          ctx.lineWidth = 1;
          ctx.strokeRect(p.x + 1, p.y + 1, w - 2, h - 2);
          ctx.beginPath();
          ctx.moveTo(p.x + w / 2, p.y + 1);
          ctx.lineTo(p.x + w / 2, p.y + h - 1);
          ctx.stroke();
        }
        break;
      case 'plaza':
        ctx.fillStyle = C.plaza;
        ctx.fillRect(p.x, p.y, w, h);
        paintAsset(ctx, asset(filler.asset), { x: p.x, y: p.y, w, h }, filler.tone, { ...detail, base: false });
        break;
      case 'quay':
        ctx.fillStyle = C.quay;
        ctx.fillRect(p.x, p.y, w, h);
        break;
      case 'parking':
      default:
        ctx.fillStyle = C.parking;
        ctx.fillRect(p.x, p.y, w, h);
        if (detail.markings && w > 14 && h > 10) {
          // Parking bays, which is the cheapest way to say "this is a car park".
          ctx.strokeStyle = 'rgba(255,255,255,0.14)';
          ctx.lineWidth = 1;
          const step = Math.max(5, s * 0.0026);
          ctx.beginPath();
          for (let x = p.x + step; x < p.x + w - 1; x += step) {
            ctx.moveTo(x, p.y + 1);
            ctx.lineTo(x, p.y + h - 1);
          }
          ctx.stroke();
        }
        break;
    }
  }

  /**
   * A building, drawn as whichever asset from the pack it was built as. The
   * choice was made once when the city was generated, so this is a lookup and a
   * few dozen rectangles — cheap enough to do for every structure on screen.
   */
  private paintStructure(filler: Filler, detail: Detail): void {
    const ctx = this.ctx;
    const p = this.toScreen(filler.x, filler.y);
    const s = detail.s;
    const w = Math.max(1, filler.w * s);
    const h = Math.max(1, filler.h * s);

    // Height as a drop shadow: taller buildings throw a longer one.
    if (detail.kerbs && filler.floors > 0) {
      const drop = Math.min(10, filler.floors * (detail.fine ? 0.9 : 0.5));
      ctx.fillStyle = C.shadow;
      ctx.fillRect(p.x + drop, p.y + drop, w, h);
    }

    if (COUNTRY_KINDS.has(filler.kind)) {
      ctx.globalAlpha = 0.45;
      paintAsset(ctx, asset(filler.asset), { x: p.x, y: p.y, w, h }, filler.tone, detail);
      ctx.globalAlpha = 1;
      return;
    }

    paintAsset(ctx, asset(filler.asset), { x: p.x, y: p.y, w, h }, filler.tone, detail);

    if (detail.markings && w > 5 && h > 5) {
      ctx.strokeStyle = C.kerb;
      ctx.lineWidth = 1;
      ctx.strokeRect(p.x + 0.5, p.y + 0.5, w - 1, h - 1);
    }
  }

  private paintAmenities(amenities: Amenity[], detail: Detail): void {
    const ctx = this.ctx;
    const s = detail.s;
    for (const item of amenities) {
      const p = this.toScreen(item.x, item.y);
      if (p.x < -20 || p.x > this.cssW + 20 || p.y < -20 || p.y > this.cssH + 20) continue;
      const a = asset(item.asset);
      // Capped in screen pixels: a tree is a tree, not a hill.
      const r = clamp(item.r * s, 1.1, item.kind === 'fountain' ? 26 : item.kind === 'tree' ? 4.6 : 6);
      if (item.kind === 'tree') {
        paintTree(ctx, a, p.x, p.y, r, detail);
        continue;
      }
      if (item.kind === 'crossing') {
        // Zebra stripes across the carriageway.
        if (!detail.markings) continue;
        const half = item.r * s;
        ctx.fillStyle = 'rgba(230,236,244,0.42)';
        const bars = 4;
        for (let i = 0; i < bars; i += 1) {
          const t = -half + ((i + 0.25) * 2 * half) / bars;
          if (item.vertical) ctx.fillRect(p.x - 2, p.y + t, 4, Math.max(1, (2 * half) / bars / 2.2));
          else ctx.fillRect(p.x + t, p.y - 2, Math.max(1, (2 * half) / bars / 2.2), 4);
        }
        continue;
      }
      // Everything else is street furniture, and only worth drawing up close.
      if (!detail.fine && item.kind !== 'fountain') continue;
      paintFurniture(ctx, a, p.x, p.y, r, item.vertical ?? false);
    }
  }

  // ------------------------------------------------------------- labels

  private districtValue(def: DistrictDef): number {
    const districtState = this.state.districts[def.id];
    switch (this.mode) {
      case 'demand': {
        const index = districtState?.demandIndex ?? 1;
        return clamp((def.footTraffic / 42000) * 0.5 + (def.population / 130000) * 0.5 * index, 0, 1);
      }
      case 'income':
        return clamp((def.averageIncome - 20000) / 125000, 0, 1);
      case 'property':
        return clamp((def.pricePerSqm * (districtState?.propertyIndex ?? 1)) / 6500, 0, 1);
      case 'traffic':
        return clamp(def.footTraffic / 42000, 0, 1);
      case 'competition': {
        const buildings = this.state.buildings.filter((b) => b.district === def.id);
        const rivals = buildings.filter((b) => b.status === 'competitor').length;
        return clamp(rivals / Math.max(1, buildings.length * 0.55), 0, 1);
      }
      case 'commercial':
        return clamp(def.commercialActivity / 1.9, 0, 1);
      default:
        return -1;
    }
  }

  private paintDistrictShort(def: DistrictDef): void {
    const ctx = this.ctx;
    const p = this.toScreen(def.x, def.y);
    const s = this.scale();
    const w = def.w * s;
    if (p.x + w < 0 || p.x > this.cssW || w < 46) return;
    ctx.fillStyle = 'rgba(230,237,245,0.62)';
    ctx.font = '600 10px system-ui, sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText(def.short, p.x + w / 2, p.y + (def.h * s) / 2 + 3);
  }

  private paintDistrictLabel(def: DistrictDef, detail: Detail): void {
    const ctx = this.ctx;
    const p = this.toScreen(def.x, def.y);
    const s = detail.s;
    const w = def.w * s;
    if (p.x + w < 0 || p.x > this.cssW) return;
    // Never let one district's name run across its neighbour: shrink first,
    // and only fall back to the short form when even that will not fit.
    const label = def.name.toUpperCase();
    let size = 10;
    ctx.font = `700 ${size}px system-ui, sans-serif`;
    while (ctx.measureText(label).width + 18 > w && size > 7) {
      size -= 1;
      ctx.font = `700 ${size}px system-ui, sans-serif`;
    }
    ctx.textAlign = 'left';
    const width = ctx.measureText(label).width;
    if (width + 18 > w) return;
    ctx.fillStyle = 'rgba(11,16,23,0.72)';
    ctx.fillRect(p.x + 4, p.y + 3, width + 10, 15);
    ctx.fillStyle = 'rgba(230,237,245,0.9)';
    ctx.fillText(label, p.x + 9, p.y + 14);
  }

  private paintParkName(park: { x: number; y: number; w: number; h: number; name: string }, detail: Detail): void {
    if (!detail.scenery) return;
    const ctx = this.ctx;
    const p = this.toScreen(park.x, park.y);
    const s = detail.s;
    if (park.w * s < 60) return;
    ctx.fillStyle = 'rgba(190,218,196,0.75)';
    ctx.font = 'italic 600 10px system-ui, sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText(park.name, p.x + (park.w * s) / 2, p.y + (park.h * s) / 2 + 3);
  }

  private buildingColour(building: Building): string {
    const player = this.state.playerCompanyId;
    if (building.occupantCompanyId === player) return '#4bbf87';
    if (building.status === 'competitor') return '#e2686d';

    switch (this.mode) {
      case 'traffic':
        return heat(clamp(building.footTraffic / 42000, 0, 1));
      case 'property':
        return heat(clamp(building.value / 900000, 0, 1));
      case 'commercial':
        return building.status === 'available' ? '#6f9bd0' : '#4a5567';
      default:
        return building.status === 'available' ? '#5d708a' : '#4a5567';
    }
  }

  private paintBuilding(building: Building, detail: Detail): void {
    const ctx = this.ctx;
    const p = this.toScreen(building.x, building.y);
    const s = detail.s;
    const w = Math.max(2, building.w * s);
    const h = Math.max(2, building.h * s);
    const colour = this.buildingColour(building);

    if (detail.kerbs) {
      const drop = Math.min(9, building.floors * (detail.fine ? 1.4 : 0.8));
      ctx.fillStyle = C.shadow;
      ctx.fillRect(p.x + drop, p.y + drop, w, h);
    }

    ctx.fillStyle = colour;
    ctx.fillRect(p.x, p.y, w, h);

    // Shopfront: a lighter band along the side that faces the street.
    if (detail.markings && h > 6) {
      ctx.fillStyle = 'rgba(255,255,255,0.13)';
      ctx.fillRect(p.x, p.y + h - Math.max(1.5, h * 0.2), w, Math.max(1.5, h * 0.2));
    }

    const selected = building.id === this.selectedId;
    const hovered = building.id === this.hoverId;
    if (selected || hovered) {
      ctx.strokeStyle = selected ? '#ffffff' : 'rgba(255,255,255,0.65)';
      ctx.lineWidth = selected ? 2 : 1.5;
      ctx.strokeRect(p.x - 1.5, p.y - 1.5, w + 3, h + 3);
    }

    if (!detail.markings || w < 22 || h < 9) return;

    // Close in, show what is actually in the unit.
    const business = building.businessId ? businessById(this.state, building.businessId) : undefined;
    if (business) {
      const type = businessType(business.typeId);
      ctx.fillStyle = 'rgba(0,0,0,0.32)';
      ctx.fillRect(p.x, p.y, w, h);
      ctx.fillStyle = '#e6edf5';
      ctx.font = `${Math.min(13, Math.max(7, h * 0.55))}px system-ui, sans-serif`;
      ctx.textAlign = 'center';
      ctx.fillText(type?.icon ?? '•', p.x + w / 2, p.y + h / 2 + 4);
      if (detail.fine && h > 22 && w > 54) {
        ctx.fillStyle = 'rgba(230,237,245,0.9)';
        ctx.font = '600 9px system-ui, sans-serif';
        ctx.fillText(this.truncate(business.name, w), p.x + w / 2, p.y + h - 4);
      }
    } else if (detail.fine && h > 14 && w > 46) {
      ctx.fillStyle = 'rgba(15,22,31,0.75)';
      ctx.font = '9px system-ui, sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText(this.truncate(building.address, w), p.x + w / 2, p.y + h / 2 + 3);
    }
  }

  private truncate(text: string, width: number): string {
    const max = Math.max(3, Math.floor(width / 5.6));
    return text.length > max ? `${text.slice(0, max - 1)}…` : text;
  }
}
