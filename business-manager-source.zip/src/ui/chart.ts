/**
 * Inline SVG charts.
 *
 * No dependency, sharp at any DPI, and drawn in the same palette as everything
 * else — the colours below are the tokens from design/tokens.json, because a
 * chart that invents its own green is a chart that disagrees with the figure
 * printed next to it.
 *
 * Deliberately quiet: a thin grid, one or two bright lines, and no chartjunk.
 * The data is the only loud thing on the panel.
 */

const NS = 'http://www.w3.org/2000/svg';

/* Tokens, mirrored. A line here that drifts from styles.css is a bug. */
const C = {
  good: '#2fbf7e',
  bad: '#ef4657',
  accent: '#2f7bff',
  info: '#38bdf8',
  tech: '#8b5cf6',
  grid: '#172134',
  zero: '#2b3958',
  muted: '#64748f',
};

function svg(width: number, height: number): SVGSVGElement {
  const el = document.createElementNS(NS, 'svg');
  el.setAttribute('viewBox', `0 0 ${width} ${height}`);
  el.setAttribute('preserveAspectRatio', 'none');
  el.setAttribute('class', 'chart');
  return el;
}

function node(tag: string, attrs: Record<string, string>): SVGElement {
  const el = document.createElementNS(NS, tag);
  for (const [key, value] of Object.entries(attrs)) el.setAttribute(key, value);
  return el;
}

/** Four horizontal rules. Enough to read a height against, quiet enough to ignore. */
function grid(el: SVGSVGElement, width: number, height: number, pad: number): void {
  for (let i = 0; i <= 4; i += 1) {
    const y = pad + ((height - pad * 2) / 4) * i;
    el.appendChild(
      node('line', {
        x1: '0', x2: String(width), y1: y.toFixed(1), y2: y.toFixed(1),
        stroke: C.grid, 'stroke-width': '1', 'vector-effect': 'non-scaling-stroke',
      }),
    );
  }
}

export interface Series {
  label: string;
  values: number[];
  color: string;
  /** Fill the area under the line. One series per chart should, at most. */
  fill?: boolean;
}

/** The palette a caller should pick series colours from. */
export const SERIES_COLORS = C;

/**
 * A line chart with a zero baseline.
 *
 * Values above zero are drawn green and below red, because in this game the
 * sign is the whole story and the reader should not have to find the axis to
 * learn it.
 */
export function lineChart(values: number[], options: { height?: number; showZero?: boolean } = {}): SVGSVGElement {
  const width = 600;
  const height = options.height ?? 150;
  const el = svg(width, height);
  if (values.length === 0) {
    const label = node('text', {
      x: String(width / 2), y: String(height / 2),
      fill: C.muted, 'font-size': '13', 'text-anchor': 'middle',
    });
    label.textContent = 'No data yet';
    el.appendChild(label);
    return el;
  }

  const max = Math.max(...values, 0);
  const min = Math.min(...values, 0);
  const span = max - min || 1;
  const pad = 8;
  const usable = height - pad * 2;
  const stepX = values.length > 1 ? width / (values.length - 1) : width;
  const toY = (value: number): number => pad + (1 - (value - min) / span) * usable;

  grid(el, width, height, pad);

  if (options.showZero !== false && min < 0 && max > 0) {
    el.appendChild(
      node('line', {
        x1: '0', x2: String(width),
        y1: String(toY(0)), y2: String(toY(0)),
        stroke: C.zero, 'stroke-width': '1', 'stroke-dasharray': '4 4',
        'vector-effect': 'non-scaling-stroke',
      }),
    );
  }

  const points = values.map((value, index) => `${(index * stepX).toFixed(1)},${toY(value).toFixed(1)}`);
  const last = values[values.length - 1];
  const stroke = last >= 0 ? C.good : C.bad;
  const id = `g${Math.random().toString(36).slice(2, 8)}`;

  const defs = document.createElementNS(NS, 'defs');
  const gradient = node('linearGradient', { id, x1: '0', y1: '0', x2: '0', y2: '1' });
  gradient.appendChild(node('stop', { offset: '0%', 'stop-color': stroke, 'stop-opacity': '0.28' }));
  gradient.appendChild(node('stop', { offset: '100%', 'stop-color': stroke, 'stop-opacity': '0' }));
  defs.appendChild(gradient);
  el.appendChild(defs);

  el.appendChild(
    node('polyline', {
      points: `0,${toY(min)} ${points.join(' ')} ${width},${toY(min)}`,
      fill: `url(#${id})`,
      stroke: 'none',
    }),
  );
  el.appendChild(
    node('polyline', {
      points: points.join(' '),
      fill: 'none',
      stroke,
      'stroke-width': '2',
      'stroke-linejoin': 'round',
      'stroke-linecap': 'round',
      'vector-effect': 'non-scaling-stroke',
    }),
  );
  return el;
}

/**
 * Several series on one pair of axes, sharing a scale.
 *
 * Used where the comparison is the point — revenue against costs says something
 * neither says alone — and never for series whose units differ, which would be
 * two charts pretending to be one.
 */
export function multiChart(series: Series[], options: { height?: number } = {}): SVGSVGElement {
  const width = 600;
  const height = options.height ?? 180;
  const el = svg(width, height);
  const all = series.flatMap((s) => s.values);
  if (all.length === 0) {
    const label = node('text', {
      x: String(width / 2), y: String(height / 2),
      fill: C.muted, 'font-size': '13', 'text-anchor': 'middle',
    });
    label.textContent = 'No data yet';
    el.appendChild(label);
    return el;
  }

  const max = Math.max(...all, 0);
  const min = Math.min(...all, 0);
  const span = max - min || 1;
  const pad = 8;
  const usable = height - pad * 2;
  const toY = (value: number): number => pad + (1 - (value - min) / span) * usable;

  grid(el, width, height, pad);
  if (min < 0 && max > 0) {
    el.appendChild(
      node('line', {
        x1: '0', x2: String(width), y1: String(toY(0)), y2: String(toY(0)),
        stroke: C.zero, 'stroke-width': '1', 'stroke-dasharray': '4 4',
        'vector-effect': 'non-scaling-stroke',
      }),
    );
  }

  for (const line of series) {
    if (line.values.length === 0) continue;
    const stepX = line.values.length > 1 ? width / (line.values.length - 1) : width;
    const points = line.values.map((value, index) => `${(index * stepX).toFixed(1)},${toY(value).toFixed(1)}`);
    if (line.fill) {
      const id = `f${Math.random().toString(36).slice(2, 8)}`;
      const defs = document.createElementNS(NS, 'defs');
      const gradient = node('linearGradient', { id, x1: '0', y1: '0', x2: '0', y2: '1' });
      gradient.appendChild(node('stop', { offset: '0%', 'stop-color': line.color, 'stop-opacity': '0.24' }));
      gradient.appendChild(node('stop', { offset: '100%', 'stop-color': line.color, 'stop-opacity': '0' }));
      defs.appendChild(gradient);
      el.appendChild(defs);
      el.appendChild(
        node('polyline', {
          points: `0,${toY(min)} ${points.join(' ')} ${width},${toY(min)}`,
          fill: `url(#${id})`, stroke: 'none',
        }),
      );
    }
    el.appendChild(
      node('polyline', {
        points: points.join(' '),
        fill: 'none',
        stroke: line.color,
        'stroke-width': '2',
        'stroke-linejoin': 'round',
        'stroke-linecap': 'round',
        'vector-effect': 'non-scaling-stroke',
      }),
    );
  }
  return el;
}

/** The key for a multi-series chart, in the same colours as the lines. */
export function chartLegend(series: Series[]): HTMLElement {
  const row = document.createElement('div');
  row.className = 'chart-legend';
  for (const line of series) {
    const item = document.createElement('span');
    item.className = 'chart-legend-item';
    const swatch = document.createElement('span');
    swatch.className = 'chart-legend-swatch';
    swatch.style.background = line.color;
    item.appendChild(swatch);
    item.appendChild(document.createTextNode(line.label));
    row.appendChild(item);
  }
  return row;
}
