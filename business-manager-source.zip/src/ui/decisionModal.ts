import type { Ctx } from './app';
import type { PendingDecision } from '../sim/types';
import { resolveDecision } from '../sim/decisions';
import { h, modal, toast } from './dom';

/**
 * Decisions are the one thing the game interrupts the player for, so the dialog
 * states the situation, spells out what each option actually costs, and pauses
 * the clock while they think.
 */
export function showDecision(ctx: Ctx, decision: PendingDecision): void {
  const speedBefore = ctx.state.speed;
  ctx.engine.setSpeed(0);

  const { body, footer, close } = modal({
    title: decision.title,
    width: 620,
    onClose: () => {
      // Closing without choosing leaves the decision open until it expires.
      ctx.engine.setSpeed(speedBefore);
    },
  });

  body.appendChild(h('p', { class: 'decision-body', text: decision.body }));
  body.appendChild(
    h('p', {
      class: 'tiny muted',
      text: `You have until day ${decision.expiresOnDay}. If you do not decide, the situation resolves itself — usually not in your favour.`,
    }),
  );

  const list = h('div', { class: 'list', style: 'margin-top:12px' });
  for (const option of decision.options) {
    const disabled = Boolean(option.blocked);
    list.appendChild(
      h(
        'button',
        {
          class: `decision-option${disabled ? ' disabled' : ''}`,
          disabled,
          title: option.blocked ?? '',
          on: {
            click: () => {
              if (disabled) return;
              const result = resolveDecision(ctx.state, decision.id, option.id);
              toast(result.message, result.ok ? 'good' : 'bad');
              close();
              ctx.engine.setSpeed(speedBefore);
              ctx.refresh();
            },
          },
        },
        h('span', { class: 'decision-option-label', text: option.label }),
        h('span', { class: 'decision-option-detail', text: option.blocked ?? option.detail }),
      ),
    );
  }
  body.appendChild(list);

  footer.appendChild(
    h(
      'button',
      {
        class: 'btn ghost',
        on: {
          click: () => {
            close();
            ctx.engine.setSpeed(speedBefore);
          },
        },
      },
      'Decide later',
    ),
  );
}
