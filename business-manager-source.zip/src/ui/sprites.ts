import type { AtlasAsset } from '../data/atlas';

/**
 * The asset pack, drawn.
 *
 * `src/data/atlas.ts` says what every asset in the pack is made of. This says
 * what it looks like from above, which is the only view Northgate has. A filling
 * station is a small block under a wide canopy; a distribution centre is a long
 * ribbed roof with loading doors down one side; a terrace is a ridge line with
 * two slopes and a chimney. None of it is a texture: it is a few dozen
 * rectangles per building, so a thousand of them still draw in a frame.
 *
 * Everything here takes a screen rectangle and the level of detail the camera is
 * at, and draws nothing it cannot be seen at that distance.
 */

export interface SpriteDetail {
  /** Roofs, ridges, shopfronts. */
  markings: boolean;
  /** Roof plant, loading doors, chimneys, panel rows. */
  fine: boolean;
  /**
   * False when the ground underneath has already been painted in the map's own
   * palette and only the things standing on it are wanted.
   */
  base?: boolean;
}

// ------------------------------------------------------------------ colour

/** Lightens (positive) or darkens (negative) a hex colour by a fraction. */
export function shade(hex: string, amount: number): string {
  const value = parseInt(hex.slice(1), 16);
  const r = (value >> 16) & 255;
  const g = (value >> 8) & 255;
  const b = value & 255;
  const mix = (channel: number): number =>
    Math.max(0, Math.min(255, Math.round(amount >= 0 ? channel + (255 - channel) * amount : channel * (1 + amount))));
  return `rgb(${mix(r)}, ${mix(g)}, ${mix(b)})`;
}

/** The same colour at a given opacity. */
export function alpha(hex: string, a: number): string {
  const value = parseInt(hex.slice(1), 16);
  return `rgba(${(value >> 16) & 255}, ${(value >> 8) & 255}, ${value & 255}, ${a})`;
}

/**
 * The pack was lit for a showroom; Northgate is a working map at dusk. Facades
 * are pulled towards the map's own slate so a street reads as a street rather
 * than a colour chart — the accent each asset is recognised by is left alone,
 * which is why a filling station is still red and a bank still blue.
 */
const SLATE = [58, 68, 84];
/** Planting is pulled towards the map's own park green, not towards slate. */
const LEAF = [44, 74, 52];

function towards(hex: string, target: number[], amount: number): string {
  const value = parseInt(hex.slice(1), 16);
  const rgb = [(value >> 16) & 255, (value >> 8) & 255, value & 255];
  const out = rgb.map((v, i) => Math.round(v + (target[i] - v) * amount));
  return `#${out.map((v) => Math.max(0, Math.min(255, v)).toString(16).padStart(2, '0')).join('')}`;
}

/**
 * The pack photographs every building on a lawn, so some facades came back
 * green. A green office is a measurement error, not a design choice, so
 * greenish facades are pulled much harder towards the slate.
 */
function green(hex: string): boolean {
  const value = parseInt(hex.slice(1), 16);
  const r = (value >> 16) & 255;
  const g = (value >> 8) & 255;
  const b = value & 255;
  if (g > r + 6 && g > b + 14) return true;
  // Olive, which is what a lawn averages to once it is mixed with render.
  return Math.abs(r - g) < 26 && b < Math.min(r, g) - 22;
}

function mute(hex: string, amount: number): string {
  return towards(hex, SLATE, green(hex) ? Math.min(0.85, amount + 0.32) : amount);
}

const BUILT = new Set<string>(['office', 'retail', 'industry', 'logistics', 'civic', 'leisure', 'housing', 'landmark']);
const faces = new Map<string, AtlasAsset>();

/** The asset as the map draws it. Computed once per asset, then cached. */
function face(a: AtlasAsset): AtlasAsset {
  const found = faces.get(a.id);
  if (found) return found;
  let made = a;
  if (BUILT.has(a.kind)) {
    made = {
      ...a,
      roof: mute(a.roof, 0.5),
      roofAlt: mute(a.roofAlt, 0.46),
      wall: mute(a.wall, 0.54),
      wallAlt: mute(a.wallAlt, 0.52),
      accent: green(a.accent) ? mute(a.accent, 0.7) : a.accent,
    };
  } else if (a.kind === 'vehicle') {
    // The pack photographs cars in daylight. A black saloon on a dark road at
    // this size is a hole, so the darkest ones are lifted until they read.
    const value = parseInt(a.roof.slice(1), 16);
    const lum = (((value >> 16) & 255) + ((value >> 8) & 255) + (value & 255)) / 3;
    made = lum < 95
      ? { ...a, roof: towards(a.roof, [214, 219, 226], 0.42), wall: towards(a.wall, [214, 219, 226], 0.3) }
      : a;
  } else if (a.kind === 'nature' || a.kind === 'park' || a.kind === 'farm') {
    // Planting is darkened towards the map's park green: at dusk a canopy is a
    // dark shape, and a hundred bright ones would read as confetti.
    made = {
      ...a,
      roof: towards(a.roof, LEAF, 0.55),
      roofAlt: towards(a.roofAlt, LEAF, 0.5),
      wall: towards(a.wall, LEAF, 0.45),
      wallAlt: towards(a.wallAlt, LEAF, 0.45),
    };
  }
  faces.set(a.id, made);
  return made;
}

// ------------------------------------------------------- choosing an asset

/**
 * A stable pick from a list. The city is generated from a fixed seed and never
 * regenerated, so the same building must come back with the same face every
 * time the map is painted — no randomness at draw time.
 */
function hash(key: string): number {
  let h = 2166136261;
  for (let i = 0; i < key.length; i += 1) {
    h ^= key.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return (h >>> 0) / 4294967296;
}

// ------------------------------------------------------------- the drawing

interface Box {
  x: number;
  y: number;
  w: number;
  h: number;
}

/** The base every building starts from: walls showing at the edges, roof on top. */
function shell(ctx: CanvasRenderingContext2D, a: AtlasAsset, b: Box, tone: number, detail: SpriteDetail): Box {
  ctx.fillStyle = shade(a.wall, (tone - 0.5) * 0.16);
  ctx.fillRect(b.x, b.y, b.w, b.h);
  if (!detail.markings || b.w < 5 || b.h < 5) return b;
  const inset = Math.max(0.6, Math.min(b.w, b.h) * 0.13);
  const roof = { x: b.x + inset, y: b.y + inset, w: b.w - inset * 2, h: b.h - inset * 2 };
  ctx.fillStyle = shade(a.roof, (tone - 0.5) * 0.12);
  ctx.fillRect(roof.x, roof.y, roof.w, roof.h);
  return roof;
}

/** A row of things across a roof: plant, panels, lights, bays. */
function row(
  ctx: CanvasRenderingContext2D,
  b: Box,
  count: number,
  frac: number,
  colour: string,
  vertical = false,
): void {
  if (count < 1) return;
  ctx.fillStyle = colour;
  if (vertical) {
    const step = b.h / count;
    const size = Math.max(0.8, step * frac);
    for (let i = 0; i < count; i += 1) {
      ctx.fillRect(b.x, b.y + i * step + (step - size) / 2, b.w, size);
    }
  } else {
    const step = b.w / count;
    const size = Math.max(0.8, step * frac);
    for (let i = 0; i < count; i += 1) {
      ctx.fillRect(b.x + i * step + (step - size) / 2, b.y, size, b.h);
    }
  }
}

function dot(ctx: CanvasRenderingContext2D, x: number, y: number, r: number, colour: string): void {
  ctx.fillStyle = colour;
  ctx.beginPath();
  ctx.arc(x, y, Math.max(0.5, r), 0, Math.PI * 2);
  ctx.fill();
}

/**
 * A pitched roof seen from above: a ridge along the longer side with a lit
 * slope and a shaded one. This is what makes housing read as housing.
 */
function pitched(ctx: CanvasRenderingContext2D, a: AtlasAsset, b: Box, tone: number): void {
  const alongX = b.w >= b.h;
  const light = shade(a.roof, 0.12 + (tone - 0.5) * 0.1);
  const dark = shade(a.roof, -0.18 + (tone - 0.5) * 0.08);
  if (alongX) {
    ctx.fillStyle = light;
    ctx.fillRect(b.x, b.y, b.w, b.h / 2);
    ctx.fillStyle = dark;
    ctx.fillRect(b.x, b.y + b.h / 2, b.w, b.h / 2);
  } else {
    ctx.fillStyle = light;
    ctx.fillRect(b.x, b.y, b.w / 2, b.h);
    ctx.fillStyle = dark;
    ctx.fillRect(b.x + b.w / 2, b.y, b.w / 2, b.h);
  }
  if (Math.min(b.w, b.h) > 6) {
    ctx.strokeStyle = shade(a.roof, 0.3);
    ctx.lineWidth = 1;
    ctx.beginPath();
    if (alongX) {
      ctx.moveTo(b.x + 1, b.y + b.h / 2);
      ctx.lineTo(b.x + b.w - 1, b.y + b.h / 2);
    } else {
      ctx.moveTo(b.x + b.w / 2, b.y + 1);
      ctx.lineTo(b.x + b.w / 2, b.y + b.h - 1);
    }
    ctx.stroke();
  }
}

/**
 * Draws one asset into a screen rectangle.
 *
 * `tone` is the building's own 0..1 variation, so a street of the same asset is
 * not one flat colour.
 */
export function paintAsset(
  ctx: CanvasRenderingContext2D,
  raw: AtlasAsset,
  b: Box,
  tone: number,
  detail: SpriteDetail,
): void {
  const a = face(raw);
  switch (a.kind) {
    case 'housing':
      return paintHousing(ctx, a, b, tone, detail);
    case 'office':
      return paintOffice(ctx, a, b, tone, detail);
    case 'retail':
      return paintRetail(ctx, a, b, tone, detail);
    case 'industry':
      return paintIndustry(ctx, a, b, tone, detail);
    case 'logistics':
      return paintLogistics(ctx, a, b, tone, detail);
    case 'civic':
      return paintCivic(ctx, a, b, tone, detail);
    case 'leisure':
      return paintLeisure(ctx, a, b, tone, detail);
    case 'energy':
      return paintEnergy(ctx, a, b, tone, detail);
    case 'farm':
      return paintFarm(ctx, a, b, tone, detail);
    case 'landmark':
      return paintLandmark(ctx, a, b, tone, detail);
    case 'park':
      return paintPark(ctx, a, b, tone, detail);
    default:
      shell(ctx, a, b, tone, detail);
  }
}

// -------------------------------------------------------------- housing

function paintHousing(ctx: CanvasRenderingContext2D, a: AtlasAsset, b: Box, tone: number, d: SpriteDetail): void {
  ctx.fillStyle = shade(a.wall, (tone - 0.5) * 0.18);
  ctx.fillRect(b.x, b.y, b.w, b.h);
  if (!d.markings || b.w < 4 || b.h < 4) return;
  const flat = a.id === 'apartment-block' || a.id === 'social-housing' || a.id === 'student-house';
  const inset = Math.max(0.5, Math.min(b.w, b.h) * 0.1);
  const roof = { x: b.x + inset, y: b.y + inset, w: b.w - inset * 2, h: b.h - inset * 2 };
  if (flat) {
    ctx.fillStyle = shade(a.roof, (tone - 0.5) * 0.1);
    ctx.fillRect(roof.x, roof.y, roof.w, roof.h);
    if (d.fine && roof.w > 10 && roof.h > 8) {
      ctx.fillStyle = alpha('#000000', 0.28);
      ctx.fillRect(roof.x + roof.w * 0.3, roof.y + roof.h * 0.35, roof.w * 0.25, roof.h * 0.3);
    }
  } else {
    pitched(ctx, a, roof, tone);
    // A chimney, which at this size is one dark pixel in the right place.
    if (d.fine && Math.min(roof.w, roof.h) > 5) {
      dot(ctx, roof.x + roof.w * 0.72, roof.y + roof.h * 0.5, Math.min(roof.w, roof.h) * 0.09, alpha('#000000', 0.45));
    }
  }
}

// --------------------------------------------------------------- offices

function paintOffice(ctx: CanvasRenderingContext2D, a: AtlasAsset, b: Box, tone: number, d: SpriteDetail): void {
  const roof = shell(ctx, a, b, tone, d);
  if (!d.fine || roof.w < 9 || roof.h < 7) return;
  // Plant room, lift overrun, and the glazed strip that reads as an atrium.
  ctx.fillStyle = alpha('#000000', 0.26);
  ctx.fillRect(roof.x + roof.w * 0.12, roof.y + roof.h * 0.22, roof.w * 0.3, roof.h * 0.3);
  ctx.fillStyle = shade(a.roofAlt, 0.08);
  ctx.fillRect(roof.x + roof.w * 0.55, roof.y + roof.h * 0.18, roof.w * 0.3, roof.h * 0.22);
  ctx.fillStyle = alpha(a.accent, 0.5);
  ctx.fillRect(roof.x + roof.w * 0.2, roof.y + roof.h * 0.72, roof.w * 0.6, Math.max(1, roof.h * 0.1));
}

// ----------------------------------------------------------------- shops

function paintRetail(ctx: CanvasRenderingContext2D, a: AtlasAsset, b: Box, tone: number, d: SpriteDetail): void {
  if (a.id === 'filling-station') return paintFillingStation(ctx, a, b, tone, d);
  const roof = shell(ctx, a, b, tone, d);
  if (!d.markings) return;
  // The shopfront: a band of the asset's own sign colour along the long side.
  const alongX = b.w >= b.h;
  ctx.fillStyle = alpha(a.accent, 0.75);
  const band = Math.max(1, Math.min(b.w, b.h) * 0.13);
  if (alongX) ctx.fillRect(b.x, b.y + b.h - band, b.w, band);
  else ctx.fillRect(b.x + b.w - band, b.y, band, b.h);
  if (d.fine && roof.w > 12 && roof.h > 9) {
    // Rooftop plant in rows, which is what a supermarket roof actually is.
    row(ctx, { x: roof.x + roof.w * 0.15, y: roof.y + roof.h * 0.25, w: roof.w * 0.7, h: roof.h * 0.3 },
      3, 0.55, alpha('#000000', 0.22), false);
  }
}

function paintFillingStation(ctx: CanvasRenderingContext2D, a: AtlasAsset, b: Box, tone: number, d: SpriteDetail): void {
  // Forecourt first, then the canopy, then the little shop in the corner.
  ctx.fillStyle = shade('#2b3440', (tone - 0.5) * 0.1);
  ctx.fillRect(b.x, b.y, b.w, b.h);
  if (!d.markings) return;
  const cw = b.w * 0.62;
  const ch = b.h * 0.5;
  ctx.fillStyle = alpha(a.accent, 0.85);
  ctx.fillRect(b.x + b.w - cw, b.y + b.h * 0.25, cw, Math.max(1.5, ch));
  ctx.fillStyle = shade(a.wall, 0.05);
  ctx.fillRect(b.x, b.y, b.w * 0.34, b.h * 0.45);
  if (d.fine && cw > 10) {
    ctx.fillStyle = alpha('#000000', 0.35);
    for (let i = 0; i < 2; i += 1) {
      ctx.fillRect(b.x + b.w - cw + cw * (0.25 + i * 0.42), b.y + b.h * 0.25 + ch * 0.35, cw * 0.1, ch * 0.3);
    }
  }
}

// -------------------------------------------------------------- industry

function paintIndustry(ctx: CanvasRenderingContext2D, a: AtlasAsset, b: Box, tone: number, d: SpriteDetail): void {
  ctx.fillStyle = shade(a.wall, (tone - 0.5) * 0.14);
  ctx.fillRect(b.x, b.y, b.w, b.h);
  if (!d.markings || b.w < 6 || b.h < 5) return;
  const inset = Math.max(0.6, Math.min(b.w, b.h) * 0.1);
  const roof = { x: b.x + inset, y: b.y + inset, w: b.w - inset * 2, h: b.h - inset * 2 };
  ctx.fillStyle = shade(a.roof, (tone - 0.5) * 0.1);
  ctx.fillRect(roof.x, roof.y, roof.w, roof.h);
  if (!d.fine) return;
  // Sawtooth glazing: the north-light roof every works in the pack has.
  const bays = Math.max(2, Math.round(roof.w / 7));
  row(ctx, roof, bays, 0.35, alpha('#9fb6c4', 0.22), false);
  // Stacks, in the asset's own colour, which is why the brick works reads red.
  const r = Math.min(roof.w, roof.h) * 0.12;
  dot(ctx, b.x + b.w * 0.12, b.y + b.h * 0.16, r, a.accent);
  if (b.w > 26) dot(ctx, b.x + b.w * 0.24, b.y + b.h * 0.14, r * 0.8, shade(a.accent, -0.15));
}

// ------------------------------------------------------------- logistics

function paintLogistics(ctx: CanvasRenderingContext2D, a: AtlasAsset, b: Box, tone: number, d: SpriteDetail): void {
  const roof = shell(ctx, a, b, tone, d);
  if (!d.markings) return;
  const alongX = b.w >= b.h;
  // Loading doors down the yard side: dark notches, evenly spaced.
  if (d.fine && Math.min(b.w, b.h) > 8) {
    const doors = Math.max(3, Math.round((alongX ? b.w : b.h) / 6));
    const band = Math.max(1, Math.min(b.w, b.h) * 0.12);
    if (alongX) {
      row(ctx, { x: b.x + b.w * 0.06, y: b.y + b.h - band, w: b.w * 0.88, h: band }, doors, 0.5, alpha('#000000', 0.5));
    } else {
      row(ctx, { x: b.x + b.w - band, y: b.y + b.h * 0.06, w: band, h: b.h * 0.88 }, doors, 0.5, alpha('#000000', 0.5), true);
    }
  }
  // Ribbed roof, and the solar array half the pack's warehouses carry.
  if (d.fine && roof.w > 12 && roof.h > 9) {
    const ribs = Math.max(3, Math.round((alongX ? roof.w : roof.h) / 5));
    row(ctx, roof, ribs, 0.14, alpha('#ffffff', 0.06), !alongX);
    if (a.id === 'warehouse' || a.id === 'distribution-centre' || a.id === 'large-warehouse') {
      ctx.fillStyle = alpha('#3f5f96', 0.6);
      ctx.fillRect(roof.x + roof.w * 0.12, roof.y + roof.h * 0.16, roof.w * 0.5, roof.h * 0.34);
    }
  }
}

// ----------------------------------------------------------------- civic

function paintCivic(ctx: CanvasRenderingContext2D, a: AtlasAsset, b: Box, tone: number, d: SpriteDetail): void {
  const roof = shell(ctx, a, b, tone, d);
  if (!d.markings) return;
  // Civic buildings are symmetrical: a centre block with two wings.
  ctx.fillStyle = shade(a.roofAlt, 0.06);
  const alongX = b.w >= b.h;
  if (alongX) ctx.fillRect(b.x + b.w * 0.38, b.y, b.w * 0.24, b.h);
  else ctx.fillRect(b.x, b.y + b.h * 0.38, b.w, b.h * 0.24);
  if (d.fine && Math.min(roof.w, roof.h) > 7) {
    dot(ctx, b.x + b.w / 2, b.y + b.h / 2, Math.min(b.w, b.h) * 0.1, alpha(a.accent, 0.8));
  }
}

// --------------------------------------------------------------- leisure

function paintLeisure(ctx: CanvasRenderingContext2D, a: AtlasAsset, b: Box, tone: number, d: SpriteDetail): void {
  if (a.id === 'swimming-pool') {
    ctx.fillStyle = shade(a.wall, (tone - 0.5) * 0.12);
    ctx.fillRect(b.x, b.y, b.w, b.h);
    if (d.markings) {
      ctx.fillStyle = '#2f7f9e';
      ctx.fillRect(b.x + b.w * 0.2, b.y + b.h * 0.25, b.w * 0.6, b.h * 0.5);
    }
    return;
  }
  const roof = shell(ctx, a, b, tone, d);
  if (!d.markings) return;
  ctx.fillStyle = alpha(a.accent, 0.6);
  ctx.fillRect(b.x + b.w * 0.1, b.y + b.h * 0.82, b.w * 0.8, Math.max(1, b.h * 0.1));
  if (d.fine && roof.w > 10 && roof.h > 8) {
    // Café tables and parasols outside the door.
    for (let i = 0; i < 3; i += 1) {
      dot(ctx, b.x + b.w * (0.22 + i * 0.28), b.y + b.h * 0.94, Math.max(0.6, b.w * 0.035), alpha('#d9c7a8', 0.5));
    }
  }
}

// ---------------------------------------------------------------- energy

function paintEnergy(ctx: CanvasRenderingContext2D, a: AtlasAsset, b: Box, tone: number, d: SpriteDetail): void {
  if (a.id === 'solar-farm') {
    ctx.fillStyle = shade('#28351f', (tone - 0.5) * 0.1);
    ctx.fillRect(b.x, b.y, b.w, b.h);
    if (!d.markings) return;
    const rows = Math.max(3, Math.round(b.h / 6));
    row(ctx, { x: b.x + b.w * 0.06, y: b.y + b.h * 0.08, w: b.w * 0.88, h: b.h * 0.84 }, rows, 0.55, a.roof, true);
    return;
  }
  if (a.id === 'wind-turbine') {
    if (!d.markings) return;
    const cx = b.x + b.w / 2;
    const cy = b.y + b.h / 2;
    const r = Math.min(b.w, b.h) * 0.5;
    ctx.strokeStyle = alpha('#e8e6e2', 0.75);
    ctx.lineWidth = Math.max(0.8, r * 0.1);
    ctx.beginPath();
    for (let i = 0; i < 3; i += 1) {
      const angle = (i * Math.PI * 2) / 3 + hash(a.id + b.x.toFixed(1)) * 2;
      ctx.moveTo(cx, cy);
      ctx.lineTo(cx + Math.cos(angle) * r, cy + Math.sin(angle) * r);
    }
    ctx.stroke();
    dot(ctx, cx, cy, Math.max(0.8, r * 0.16), '#cfcdc9');
    return;
  }
  const roof = shell(ctx, a, b, tone, d);
  if (!d.markings) return;
  if (a.id === 'nuclear-plant' || a.id === 'gas-plant' || a.id === 'biogas-plant') {
    // Cooling towers and digesters: circles, because that is what they are.
    const r = Math.min(b.w, b.h) * 0.2;
    dot(ctx, b.x + b.w * 0.3, b.y + b.h * 0.35, r, shade(a.wall, 0.16));
    dot(ctx, b.x + b.w * 0.68, b.y + b.h * 0.42, r * 0.9, shade(a.wall, 0.08));
  } else if (d.fine && roof.w > 8) {
    row(ctx, roof, 4, 0.4, alpha(a.accent, 0.5), false);
  }
}

// ------------------------------------------------------------------ farm

function paintFarm(ctx: CanvasRenderingContext2D, a: AtlasAsset, b: Box, tone: number, d: SpriteDetail): void {
  switch (a.id) {
    case 'arable-field': {
      ctx.fillStyle = shade(a.wall, (tone - 0.5) * 0.16);
      ctx.fillRect(b.x, b.y, b.w, b.h);
      if (d.markings) {
        const furrows = Math.max(3, Math.round(b.w / 5));
        row(ctx, b, furrows, 0.35, alpha(a.accent, 0.35), false);
      }
      return;
    }
    case 'pasture': {
      ctx.fillStyle = shade(a.roof, (tone - 0.5) * 0.14);
      ctx.fillRect(b.x, b.y, b.w, b.h);
      if (d.fine) {
        for (let i = 0; i < 4; i += 1) {
          dot(ctx, b.x + b.w * (0.2 + 0.2 * i), b.y + b.h * (0.3 + 0.4 * hash(a.id + i)), Math.max(0.5, b.w * 0.02), '#e6e1d6');
        }
      }
      return;
    }
    case 'orchard':
    case 'fruit-plantation': {
      ctx.fillStyle = shade(a.wall, (tone - 0.5) * 0.12);
      ctx.fillRect(b.x, b.y, b.w, b.h);
      if (!d.markings) return;
      const cols = Math.max(2, Math.round(b.w / 7));
      const rows = Math.max(2, Math.round(b.h / 7));
      for (let i = 0; i < cols; i += 1) {
        for (let j = 0; j < rows; j += 1) {
          dot(ctx, b.x + ((i + 0.5) * b.w) / cols, b.y + ((j + 0.5) * b.h) / rows, Math.max(0.6, b.w / cols / 3.4), a.roof);
        }
      }
      return;
    }
    case 'glasshouse': {
      ctx.fillStyle = alpha('#9fc7cf', 0.5);
      ctx.fillRect(b.x, b.y, b.w, b.h);
      if (d.markings) {
        const bays = Math.max(2, Math.round(b.w / 6));
        row(ctx, b, bays, 0.12, alpha('#ffffff', 0.35), false);
      }
      return;
    }
    default: {
      const roof = shell(ctx, a, b, tone, d);
      if (d.markings) pitched(ctx, a, roof, tone);
      return;
    }
  }
}

// -------------------------------------------------------------- landmarks

function paintLandmark(ctx: CanvasRenderingContext2D, a: AtlasAsset, b: Box, tone: number, d: SpriteDetail): void {
  if (a.id === 'stadium') {
    ctx.fillStyle = shade(a.wall, (tone - 0.5) * 0.1);
    ctx.beginPath();
    ctx.ellipse(b.x + b.w / 2, b.y + b.h / 2, b.w / 2, b.h / 2, 0, 0, Math.PI * 2);
    ctx.fill();
    if (d.markings) {
      ctx.fillStyle = '#2f5c37';
      ctx.beginPath();
      ctx.ellipse(b.x + b.w / 2, b.y + b.h / 2, b.w * 0.3, b.h * 0.3, 0, 0, Math.PI * 2);
      ctx.fill();
    }
    return;
  }
  if (a.id === 'telecom-mast') {
    if (!d.markings) return;
    const cx = b.x + b.w / 2;
    const cy = b.y + b.h / 2;
    ctx.strokeStyle = alpha('#b9c3cc', 0.7);
    ctx.lineWidth = 1;
    ctx.strokeRect(cx - b.w * 0.18, cy - b.h * 0.18, b.w * 0.36, b.h * 0.36);
    dot(ctx, cx, cy, Math.max(0.7, b.w * 0.08), '#d4534b');
    return;
  }
  const roof = shell(ctx, a, b, tone, d);
  if (d.fine && roof.w > 12 && roof.h > 8) {
    row(ctx, { x: roof.x + roof.w * 0.1, y: roof.y + roof.h * 0.2, w: roof.w * 0.8, h: roof.h * 0.4 },
      4, 0.4, alpha('#000000', 0.2), false);
  }
}

// ------------------------------------------------------------------ parks

function paintPark(ctx: CanvasRenderingContext2D, a: AtlasAsset, b: Box, tone: number, d: SpriteDetail): void {
  if (d.base !== false) {
    ctx.fillStyle = shade(a.roof, (tone - 0.5) * 0.14);
    ctx.fillRect(b.x, b.y, b.w, b.h);
  }
  if (!d.markings) return;
  switch (a.id) {
    case 'market-square':
    case 'terrace-seating': {
      if (d.base !== false) {
        ctx.fillStyle = shade(a.wall, 0.04);
        ctx.fillRect(b.x, b.y, b.w, b.h);
      }
      if (!d.fine) return;
      // Market stalls: awnings in rows.
      const stalls = Math.max(2, Math.round(b.w / 8));
      row(ctx, { x: b.x + b.w * 0.1, y: b.y + b.h * 0.3, w: b.w * 0.8, h: b.h * 0.4 }, stalls, 0.5, alpha(a.accent, 0.55));
      return;
    }
    case 'cemetery': {
      if (!d.fine) return;
      const cols = Math.max(2, Math.round(b.w / 6));
      const rows = Math.max(2, Math.round(b.h / 6));
      ctx.fillStyle = alpha('#cfd6d9', 0.35);
      for (let i = 0; i < cols; i += 1) {
        for (let j = 0; j < rows; j += 1) {
          ctx.fillRect(b.x + ((i + 0.4) * b.w) / cols, b.y + ((j + 0.4) * b.h) / rows, 1, 1.6);
        }
      }
      return;
    }
    case 'playground': {
      if (!d.fine) return;
      for (let i = 0; i < 3; i += 1) {
        dot(ctx, b.x + b.w * (0.25 + i * 0.25), b.y + b.h * (0.35 + 0.25 * hash(a.id + i)), Math.max(0.7, b.w * 0.05), a.accent);
      }
      return;
    }
    default: {
      // A path curving through it, and trees along the path.
      ctx.strokeStyle = alpha('#b9ab8b', 0.28);
      ctx.lineWidth = Math.max(1, Math.min(b.w, b.h) * 0.05);
      ctx.beginPath();
      ctx.moveTo(b.x, b.y + b.h * 0.7);
      ctx.quadraticCurveTo(b.x + b.w * 0.5, b.y + b.h * 0.25, b.x + b.w, b.y + b.h * 0.55);
      ctx.stroke();
    }
  }
}

// ----------------------------------------------------- trees and furniture

/** A tree of a given species, seen from above: a canopy and its shadow. */
export function paintTree(
  ctx: CanvasRenderingContext2D,
  raw: AtlasAsset,
  x: number,
  y: number,
  r: number,
  detail: SpriteDetail,
): void {
  const a = face(raw);
  ctx.fillStyle = 'rgba(0,0,0,0.3)';
  ctx.beginPath();
  ctx.arc(x + r * 0.35, y + r * 0.35, r, 0, Math.PI * 2);
  ctx.fill();
  if (a.id === 'pine' && detail.markings) {
    // Conifers read as a tight dark star rather than a soft ball.
    ctx.fillStyle = a.roof;
    ctx.beginPath();
    ctx.moveTo(x, y - r);
    ctx.lineTo(x + r * 0.8, y + r * 0.7);
    ctx.lineTo(x - r * 0.8, y + r * 0.7);
    ctx.closePath();
    ctx.fill();
    return;
  }
  ctx.fillStyle = a.roof;
  ctx.beginPath();
  ctx.arc(x, y, r, 0, Math.PI * 2);
  ctx.fill();
  if (detail.fine && r > 2.6) {
    ctx.fillStyle = shade(a.roofAlt, 0.12);
    ctx.beginPath();
    ctx.arc(x - r * 0.22, y - r * 0.22, r * 0.45, 0, Math.PI * 2);
    ctx.fill();
  }
}

/** Street furniture: small, and only drawn when the camera is close. */
export function paintFurniture(
  ctx: CanvasRenderingContext2D,
  a: AtlasAsset,
  x: number,
  y: number,
  r: number,
  vertical: boolean,
): void {
  switch (a.id) {
    case 'street-light':
      ctx.strokeStyle = alpha(a.wall, 0.85);
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(x, y);
      ctx.lineTo(x + (vertical ? 0 : r * 1.6), y - (vertical ? r * 1.6 : 0));
      ctx.stroke();
      dot(ctx, x + (vertical ? 0 : r * 1.6), y - (vertical ? r * 1.6 : 0), Math.max(0.6, r * 0.4), alpha('#f0e2b4', 0.75));
      return;
    case 'traffic-light':
      dot(ctx, x, y, Math.max(0.8, r * 0.9), '#d8b24a');
      return;
    case 'bus-stop':
      ctx.fillStyle = shade(a.wall, 0.18);
      if (vertical) ctx.fillRect(x - r * 0.6, y - r, r * 1.2, r * 2);
      else ctx.fillRect(x - r, y - r * 0.6, r * 2, r * 1.2);
      return;
    case 'bench':
      ctx.fillStyle = a.roof;
      if (vertical) ctx.fillRect(x - r * 0.35, y - r, r * 0.7, r * 2);
      else ctx.fillRect(x - r, y - r * 0.35, r * 2, r * 0.7);
      return;
    case 'planter':
    case 'flowers':
      dot(ctx, x, y, Math.max(0.6, r * 0.8), a.accent);
      return;
    case 'hedge':
      ctx.fillStyle = a.roof;
      if (vertical) ctx.fillRect(x - r * 0.5, y - r * 2, r, r * 4);
      else ctx.fillRect(x - r * 2, y - r * 0.5, r * 4, r);
      return;
    case 'shrubs':
      dot(ctx, x, y, Math.max(0.7, r), a.roof);
      dot(ctx, x + r * 0.8, y + r * 0.4, Math.max(0.5, r * 0.7), shade(a.roofAlt, -0.05));
      return;
    case 'rocks':
      dot(ctx, x, y, Math.max(0.7, r), a.roof);
      return;
    case 'litter-bin':
      dot(ctx, x, y, Math.max(0.5, r * 0.5), shade(a.wall, -0.1));
      return;
    case 'railings':
      ctx.strokeStyle = alpha(a.wall, 0.5);
      ctx.lineWidth = 1;
      ctx.beginPath();
      if (vertical) {
        ctx.moveTo(x, y - r * 2);
        ctx.lineTo(x, y + r * 2);
      } else {
        ctx.moveTo(x - r * 2, y);
        ctx.lineTo(x + r * 2, y);
      }
      ctx.stroke();
      return;
    case 'fountain':
    default:
      dot(ctx, x, y, r, shade(a.wall, 0.1));
      dot(ctx, x, y, r * 0.55, '#2f6f8c');
  }
}

/** A vehicle, pointing along its heading. */
export function paintVehicle(
  ctx: CanvasRenderingContext2D,
  raw: AtlasAsset,
  x: number,
  y: number,
  heading: number,
  length: number,
  width: number,
  detail: SpriteDetail,
): void {
  const a = face(raw);
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate(heading);
  // A shadow under it, so it sits on the road rather than floating over it.
  ctx.fillStyle = 'rgba(0,0,0,0.35)';
  ctx.fillRect(-length / 2 + 1, -width / 2 + 1, length, width);
  ctx.fillStyle = a.roof;
  ctx.fillRect(-length / 2, -width / 2, length, width);
  if (detail.fine && length > 6) {
    // Cab and glass, so a lorry is not the same shape as a hatchback.
    ctx.fillStyle = shade(a.wall, -0.22);
    const cab = a.kind === 'vehicle' && (a.id === 'lorry' || a.id === 'articulated-lorry' || a.id === 'van')
      ? length * 0.28
      : length * 0.42;
    ctx.fillRect(-length / 2 + length * 0.06, -width / 2 + width * 0.16, cab, width * 0.68);
  }
  ctx.restore();
}
