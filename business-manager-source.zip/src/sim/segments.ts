import type { BusinessCategory, DistrictDef } from './types';
import { DISTRICTS } from '../data/districts';
import { clamp } from './util';

/**
 * Who walks in.
 *
 * A district's customers are not one undifferentiated crowd. A student and a
 * professional will not pay the same price for the same coffee, do not arrive
 * at the same hour, and do not judge a shop on the same things. Splitting the
 * demand pool by who the customers are is what makes "the University District
 * is huge but nobody will pay for quality" a real fact about the map rather
 * than a line of flavour text.
 *
 * The split never changes how many customers a district produces — only who
 * they are, which changes which businesses they choose and what they spend.
 */

export type SegmentId = 'students' | 'families' | 'professionals' | 'retirees' | 'visitors';

export interface SegmentDef {
  id: SegmentId;
  name: string;
  /** Multiplies the type's own price sensitivity. Above 1 means they shop on price. */
  priceSensitivity: number;
  /** Multiplies spend per visit. */
  basket: number;
  /** How much they weigh product quality when choosing. */
  quality: number;
  /** How much they weigh service and the state of the premises. */
  service: number;
  /** 24 hourly weights, centred on 1: when this group is out. */
  hours: number[];
  description: string;
}

const EVENING = [
  0.2, 0.1, 0.05, 0.05, 0.05, 0.1, 0.3, 0.5, 0.7, 0.8, 0.9, 1.0,
  1.1, 1.0, 1.0, 1.1, 1.3, 1.6, 1.9, 2.0, 1.8, 1.3, 0.8, 0.4,
];
const DAYTIME = [
  0.05, 0.02, 0.02, 0.02, 0.05, 0.2, 0.6, 1.1, 1.5, 1.7, 1.8, 1.7,
  1.5, 1.5, 1.5, 1.4, 1.2, 0.9, 0.6, 0.35, 0.2, 0.1, 0.05, 0.05,
];
const COMMUTER = [
  0.05, 0.02, 0.02, 0.02, 0.1, 0.4, 1.1, 1.8, 1.9, 1.1, 0.8, 0.9,
  1.4, 1.1, 0.8, 0.9, 1.4, 1.9, 1.8, 1.1, 0.6, 0.3, 0.1, 0.05,
];
const WEEKEND_ISH = [
  0.05, 0.02, 0.02, 0.02, 0.05, 0.15, 0.4, 0.8, 1.2, 1.5, 1.7, 1.7,
  1.6, 1.6, 1.6, 1.5, 1.3, 1.1, 0.9, 0.6, 0.35, 0.2, 0.1, 0.05,
];

/**
 * Segments redistribute demand; they must never inflate or deflate it.
 *
 * Every weight below is divided by the city-wide, population-weighted average
 * of that weight, so the average customer in Northgate is exactly the neutral
 * customer the economy was balanced against. What changes is that the average
 * is no longer evenly spread: a student district really is full of small,
 * price-driven baskets, and a financial district really is not.
 *
 * The divisors are measured from the district data itself, so they stay correct
 * if a district's population or income changes.
 */

export const SEGMENTS: SegmentDef[] = [
  {
    id: 'students',
    name: 'Students',
    priceSensitivity: 1.55,
    basket: 0.62,
    quality: 0.6,
    service: 0.8,
    hours: EVENING,
    description: 'Huge numbers, tiny budgets, out late. They will walk past a better shop to save twenty cents.',
  },
  {
    id: 'families',
    name: 'Families',
    priceSensitivity: 1.15,
    basket: 1.45,
    quality: 1.0,
    service: 1.15,
    hours: WEEKEND_ISH,
    description: 'The big baskets. They care about price, but they care more about not having to go somewhere else afterwards.',
  },
  {
    id: 'professionals',
    name: 'Professionals',
    priceSensitivity: 0.62,
    basket: 1.25,
    quality: 1.35,
    service: 1.3,
    hours: COMMUTER,
    description: 'Time-poor and price-blind. They buy on the way to work and on the way home, and they notice bad service.',
  },
  {
    id: 'retirees',
    name: 'Retirees',
    priceSensitivity: 1.05,
    basket: 0.95,
    quality: 1.2,
    service: 1.45,
    hours: DAYTIME,
    description: 'Daytime trade, loyal, and the first to stop coming when the service slips.',
  },
  {
    id: 'visitors',
    name: 'Visitors',
    priceSensitivity: 0.72,
    basket: 1.3,
    quality: 1.1,
    service: 1.05,
    hours: WEEKEND_ISH,
    description: 'Tourists and people passing through. They pay the asking price and never come back, so reputation matters less than being findable.',
  },
];

/** The city-wide average of each weight, used to keep the segments neutral. */
const NEUTRAL = (() => {
  const categories: BusinessCategory[] = ['retail', 'food', 'services', 'specialized'];
  let population = 0;
  const totals = { priceSensitivity: 0, quality: 0, service: 0, basket: 0 };
  for (const def of DISTRICTS) {
    for (const category of categories) {
      const mix = rawMix(def, category);
      for (const s of SEGMENTS) {
        totals.priceSensitivity += mix[s.id] * s.priceSensitivity * def.population;
        totals.quality += mix[s.id] * s.quality * def.population;
        totals.service += mix[s.id] * s.service * def.population;
        totals.basket += mix[s.id] * s.basket * def.population;
      }
      population += def.population;
    }
  }
  return {
    priceSensitivity: totals.priceSensitivity / population,
    quality: totals.quality / population,
    service: totals.service / population,
    basket: totals.basket / population,
  };
})();

/** A segment's weights, scaled so the average Northgate customer is neutral. */
export function weightsOf(seg: SegmentDef): {
  priceSensitivity: number;
  quality: number;
  service: number;
  basket: number;
} {
  return {
    priceSensitivity: seg.priceSensitivity / NEUTRAL.priceSensitivity,
    quality: seg.quality / NEUTRAL.quality,
    service: seg.service / NEUTRAL.service,
    basket: seg.basket / NEUTRAL.basket,
  };
}

export const SEGMENT_BY_ID = new Map(SEGMENTS.map((segment) => [segment.id, segment]));

export function segment(id: SegmentId): SegmentDef {
  const found = SEGMENT_BY_ID.get(id);
  if (!found) throw new Error(`Unknown segment: ${id}`);
  return found;
}

export type SegmentMix = Record<SegmentId, number>;

const mixCache = new Map<string, SegmentMix>();

/**
 * Who lives and shops in a district, derived from the district's own figures:
 * its age mix, its income, and how many visitors it draws. No new data — the
 * districts already describe their populations, this reads that description.
 */
export function districtMix(def: DistrictDef, category: BusinessCategory): SegmentMix {
  const key = `${def.id}|${category}`;
  const cached = mixCache.get(key);
  if (cached) return cached;
  const mix = rawMix(def, category);
  mixCache.set(key, mix);
  return mix;
}

/** The mix itself, before caching — also used to measure the city average. */
function rawMix(def: DistrictDef, category: BusinessCategory): SegmentMix {

  const income = clamp(def.averageIncome / 55000, 0.35, 2.4);
  // Young does not mean student: it takes a young population *and* low income.
  const students = def.ageMix.young * clamp(1.7 - income * 0.75, 0.15, 1.5);
  const retirees = def.ageMix.senior * 1.15;
  const adults = Math.max(0.05, def.ageMix.adult);
  const professionals = adults * clamp(income * 0.85, 0.25, 1.6);
  const families = adults * clamp(1.5 - income * 0.35, 0.4, 1.4) + def.ageMix.young * 0.35;
  // Visitors scale with tourism, and eat far more than they shop.
  const visitorPull = category === 'food' ? 1.5 : category === 'retail' ? 1.1 : 0.5;
  const visitors = def.tourism * 0.42 * visitorPull;

  const raw: SegmentMix = { students, families, professionals, retirees, visitors };
  const total = SEGMENTS.reduce((acc, s) => acc + raw[s.id], 0) || 1;
  const mix = {} as SegmentMix;
  for (const s of SEGMENTS) mix[s.id] = raw[s.id] / total;
  return mix;
}

/**
 * The same mix, weighted by which groups are actually out at this hour of the
 * day. This is why a coffee shop by the offices is empty at eight in the
 * evening and a bar by the university is not.
 */
export function mixAtHour(def: DistrictDef, category: BusinessCategory, hour: number): SegmentMix {
  const base = districtMix(def, category);
  const out = {} as SegmentMix;
  let total = 0;
  for (const s of SEGMENTS) {
    const weight = base[s.id] * (s.hours[hour] ?? 1);
    out[s.id] = weight;
    total += weight;
  }
  if (total <= 0) return base;
  for (const s of SEGMENTS) out[s.id] /= total;
  return out;
}

export function emptyMix(): SegmentMix {
  return { students: 0, families: 0, professionals: 0, retirees: 0, visitors: 0 };
}

/** The share of a served crowd made up by each segment, normalised. */
export function normaliseMix(mix: SegmentMix): SegmentMix {
  const total = SEGMENTS.reduce((acc, s) => acc + (mix[s.id] ?? 0), 0);
  if (total <= 0) return emptyMix();
  const out = emptyMix();
  for (const s of SEGMENTS) out[s.id] = (mix[s.id] ?? 0) / total;
  return out;
}

/** The average spend multiplier of a crowd with this composition. */
export function basketFactor(mix: SegmentMix): number {
  const normalised = normaliseMix(mix);
  const factor = SEGMENTS.reduce((acc, s) => acc + normalised[s.id] * weightsOf(s).basket, 0);
  return factor > 0 ? factor : 1;
}

/** The dominant group in a crowd, for the interface. */
export function leadingSegment(mix: SegmentMix): SegmentDef {
  let best = SEGMENTS[0];
  for (const s of SEGMENTS) if ((mix[s.id] ?? 0) > (mix[best.id] ?? 0)) best = s;
  return best;
}
