import type { GameState } from './state';
import { playerBusinesses, playerCompany } from './state';
import { HQ_LEVELS, centralStaff, hqLevel } from './headOffice';
import { post } from './finance';
import { pushNews } from './news';
import { pushAlert } from './alerts';
import { record } from './chronicle';
import { money } from './format';
import { officerStrength } from './executives';
import { clamp, makeId, sum } from './util';

/**
 * What the head office is actually made of.
 *
 * The head office already had departments — personnel, finance, marketing, IT,
 * legal — which are jobs people do. This is the other half: the rooms. A
 * training centre is not a department, it is a place, and the difference
 * matters because a room has to be built, takes months, occupies space the
 * company is paying for either way, and then permanently changes what the
 * company is capable of.
 *
 * Two rules keep this from becoming a second head office:
 *
 *   A facility never does a department's job. Personnel still recruits; the
 *   training centre makes the training that department runs go further.
 *
 *   Every facility has exactly one call site somewhere else in the simulation.
 *   A room that only appears on its own screen is scenery, and this game does
 *   not have scenery.
 */

export type FacilityId = 'training' | 'datacentre' | 'lab' | 'executive' | 'security' | 'board';

export interface FacilityDef {
  id: FacilityId;
  name: string;
  /** What it is, in the player's words. */
  detail: string;
  /** What it actually does, named precisely enough to be checkable. */
  gives: string;
  /** Build cost, paid across the life of the project. */
  cost: number;
  /** Working days to build. */
  days: number;
  /** Desks it occupies for ever after. */
  desks: number;
  /** What it costs to run, every month, whether or not it is used. */
  running: number;
  /** The head office has to be at least this big to hold it. */
  needsLevel: number;
  /** And this must already be built. */
  needs?: FacilityId;
}

export const FACILITIES: FacilityDef[] = [
  {
    id: 'training',
    name: 'Training centre',
    detail: 'Rooms, equipment and somebody whose job is to run the courses rather than book them.',
    gives: 'Training costs a third less and finishes a third sooner, everywhere in the company.',
    cost: 46_000, days: 60, desks: 3, running: 900, needsLevel: 2,
  },
  {
    id: 'lab',
    name: 'Research lab',
    detail: 'Somewhere to try things that are not yet how the company works.',
    gives: 'Research finishes 30% sooner.',
    cost: 120_000, days: 110, desks: 4, running: 2_600, needsLevel: 3,
  },
  {
    id: 'datacentre',
    name: 'Data centre',
    detail: 'The company stops running on spreadsheets somebody keeps on their own machine.',
    gives: 'Systems can be pushed one tier further than the building alone allows. Costs power, and gives somebody something worth attacking.',
    cost: 180_000, days: 90, desks: 2, running: 4_200, needsLevel: 3,
  },
  {
    id: 'security',
    name: 'Security operations',
    detail: 'People who look at the logs before somebody else does.',
    gives: 'Removes most of the risk the data centre introduced.',
    cost: 74_000, days: 45, desks: 3, running: 2_100, needsLevel: 3, needs: 'datacentre',
  },
  {
    id: 'executive',
    name: 'Executive floor',
    detail: 'Somewhere for the people who run parts of the company rather than parts of a shop.',
    gives: 'You can personally hold two more locations before anything starts drifting.',
    cost: 260_000, days: 120, desks: 6, running: 6_500, needsLevel: 4,
  },
  {
    id: 'board',
    name: 'Board room',
    detail: 'A table long enough for the people who now have an opinion about what you do.',
    gives: 'Unlocks decisions that need somebody other than you to agree to them.',
    cost: 150_000, days: 70, desks: 4, running: 3_000, needsLevel: 4, needs: 'executive',
  },
];

export function facility(id: FacilityId): FacilityDef | undefined {
  return FACILITIES.find((f) => f.id === id);
}

export function facilityOrThrow(id: FacilityId): FacilityDef {
  const def = facility(id);
  if (!def) throw new Error(`Unknown facility ${id}`);
  return def;
}

export function built(state: GameState, id: FacilityId): boolean {
  return (state.headOffice?.facilities ?? []).includes(id);
}

// ------------------------------------------------------------- the projects

/**
 * Building one.
 *
 * A facility is not a purchase, it is a project: the money goes out across the
 * build rather than on the day it is ordered, and the company carries the cost
 * for months before it gets anything for it. That is the decision — whether the
 * company can afford to be paying for something that is not helping yet.
 *
 * One at a time, because a company that can run two building projects at once
 * is a company with a facilities department, and it does not have one.
 */
export interface Project {
  id: string;
  facilityId: FacilityId;
  startedOnDay: number;
  days: number;
  daysDone: number;
  /** Paid so far, of the total. */
  spent: number;
  total: number;
}

export function activeProject(state: GameState): Project | null {
  return state.projects.find((p) => p.daysDone < p.days) ?? null;
}

export interface BuildCheck {
  ok: boolean;
  reason: string | null;
}

/** Whether this facility could be started right now, and why not. */
export function canBuild(state: GameState, id: FacilityId): BuildCheck {
  const def = facility(id);
  if (!def) return { ok: false, reason: 'Unknown facility.' };
  const office = state.headOffice;
  if (!office) return { ok: false, reason: 'There is no head office to put it in.' };
  if (built(state, id)) return { ok: false, reason: 'Already built.' };
  if (activeProject(state)) return { ok: false, reason: 'Something is already being built. One at a time.' };
  if (hqLevel(state).n < def.needsLevel) {
    return { ok: false, reason: `Needs a ${HQ_LEVELS[def.needsLevel - 1]?.name.toLowerCase() ?? 'larger office'} or bigger.` };
  }
  if (def.needs && !built(state, def.needs)) {
    return { ok: false, reason: `Needs the ${facilityOrThrow(def.needs).name.toLowerCase()} first.` };
  }
  if (desksLeft(state) < def.desks) {
    return { ok: false, reason: `No room. It needs ${def.desks} desks and there ${desksLeft(state) === 1 ? 'is 1' : `are ${desksLeft(state)}`} spare.` };
  }
  // Enough to cover the first month of building, not the whole thing — the
  // rest is a commitment the company has to keep trading to meet.
  const firstMonth = Math.round((def.cost / def.days) * 30);
  if (playerCompany(state).cash < firstMonth) {
    return { ok: false, reason: `It costs about ${money(firstMonth)} a month to build and you have ${money(playerCompany(state).cash)}.` };
  }
  return { ok: true, reason: null };
}

export function startProject(state: GameState, id: FacilityId): { ok: boolean; message: string } {
  const check = canBuild(state, id);
  if (!check.ok) return { ok: false, message: check.reason ?? 'Cannot build that.' };
  const def = facilityOrThrow(id);
  state.projects.push({
    id: makeId('proj'),
    facilityId: id,
    startedOnDay: state.day,
    days: def.days,
    daysDone: 0,
    spent: 0,
    total: def.cost,
  });
  record(state, 'research', `Started building the ${def.name.toLowerCase()}`, { amount: -def.cost });
  pushNews(
    state,
    'company',
    `Work has started on the ${def.name.toLowerCase()}`,
    `${def.days} working days and ${money(def.cost)}, paid as it goes. ${def.gives}`,
    { importance: 'normal' },
  );
  return { ok: true, message: `${def.name} started. ${def.days} days, ${money(Math.round(def.cost / def.days))} a day.` };
}

/** Stopping one. What has been spent is spent. */
export function cancelProject(state: GameState, projectId: string): { ok: boolean; message: string } {
  const project = state.projects.find((p) => p.id === projectId);
  if (!project || project.daysDone >= project.days) return { ok: false, message: 'Nothing to stop.' };
  const def = facilityOrThrow(project.facilityId);
  state.projects = state.projects.filter((p) => p.id !== projectId);
  pushNews(
    state,
    'company',
    `Work on the ${def.name.toLowerCase()} has stopped`,
    `${money(project.spent)} spent on a room that will not now exist.`,
    { importance: 'normal' },
  );
  return { ok: true, message: `Stopped. ${money(project.spent)} is gone.` };
}

/** A day on site: the money goes out, the work gets done, and eventually it opens. */
export function projectsDaily(state: GameState): void {
  const project = activeProject(state);
  if (!project) return;
  const company = playerCompany(state);
  const def = facilityOrThrow(project.facilityId);
  const perDay = Math.round(project.total / project.days);

  if (company.cash < perDay) {
    // Work stops rather than the company going further overdrawn for it. The
    // project keeps its place and picks up when there is money again.
    if (project.daysDone > 0 && state.day % 7 === 0) {
      pushAlert(
        state,
        'warning',
        `Work on the ${def.name.toLowerCase()} has stopped`,
        `It needs ${money(perDay)} a day and there is ${money(company.cash)} in the account. It will pick up when there is.`,
        null,
        'headoffice',
      );
    }
    return;
  }

  post(state, company.id, 'setup', `${def.name} — construction`, -perDay, null);
  project.spent += perDay;
  project.daysDone += 1;

  if (project.daysDone < project.days) return;

  const office = state.headOffice;
  if (office) {
    if (!office.facilities) office.facilities = [];
    office.facilities.push(def.id);
  }
  state.projects = state.projects.filter((p) => p.id !== project.id);
  record(state, 'research', `Opened the ${def.name.toLowerCase()}`);
  pushNews(state, 'company', `The ${def.name.toLowerCase()} is open`, def.gives, { importance: 'high' });
  pushAlert(state, 'info', `${def.name} is open`, def.gives, null, 'headoffice');
}

// ----------------------------------------------------------------- the room

/**
 * How much of the building is being used.
 *
 * Desks come from the level of the office; people and facilities take them up.
 * Both ends of this cost something: a company squeezed into a back office pays
 * for it in coordination, and a company rattling around a corporate centre it
 * does not need is paying rent on empty floors.
 */
export function desksTotal(state: GameState): number {
  return hqLevel(state).desks;
}

export function desksUsed(state: GameState): number {
  const people = centralStaff(state).length;
  const rooms = sum(state.headOffice?.facilities ?? [], (id) => facility(id as FacilityId)?.desks ?? 0);
  return people + rooms;
}

export function desksLeft(state: GameState): number {
  return Math.max(0, desksTotal(state) - desksUsed(state));
}

export function utilisation(state: GameState): number {
  const total = desksTotal(state);
  return total > 0 ? desksUsed(state) / total : 0;
}

/**
 * What the building is costing beyond what it is worth.
 *
 * An office running at a third full is mostly empty rent, and that shows up as
 * a penalty on the coordination the head office is supposed to be saving. Over
 * ninety per cent is the opposite problem: people working on top of each other.
 */
export function utilisationPenalty(state: GameState): number {
  if (!state.headOffice) return 1;
  const used = utilisation(state);
  if (used < 0.35) return 1.12;
  if (used < 0.5) return 1.05;
  if (used > 0.95) return 1.08;
  return 1;
}

/** What every room built costs to run, monthly. */
export function facilitiesBill(state: GameState): number {
  return sum(state.headOffice?.facilities ?? [], (id) => facility(id as FacilityId)?.running ?? 0);
}

// ------------------------------------------------------------- the effects

/** What a training centre does to a course: cheaper and quicker. */
export function trainingFactor(state: GameState): number {
  return built(state, 'training') ? 0.67 : 1;
}

/**
 * What a lab does to research — and what somebody running it does to the lab.
 *
 * The room takes nearly a third off the time. A chief technology officer takes
 * up to a fifth off what is left, which is worth having and is not worth having
 * instead of the lab.
 */
export function labFactor(state: GameState): number {
  const room = built(state, 'lab') ? 0.7 : 1;
  return room * (1 - officerStrength(state, 'cto') * 0.2);
}

/** How far systems can be pushed: the building, plus a data centre if there is one. */
export function automationCeiling(state: GameState): number {
  return hqLevel(state).automationCap + (built(state, 'datacentre') ? 1 : 0);
}

/** Locations the owner can hold, over and above their own management skill. */
export function executiveReach(state: GameState): number {
  return built(state, 'executive') ? 2 : 0;
}

/**
 * How exposed the company is, 0..100.
 *
 * A data centre is worth having and it is also the thing worth attacking; a
 * security team is what turns that back into an ordinary cost of business. The
 * exposure is not a die roll — it is a number the player moved by building one
 * room and can move back by building another.
 */
export function exposure(state: GameState): number {
  if (!built(state, 'datacentre')) return 0;
  const base = 55;
  const guarded = built(state, 'security') ? 38 : 0;
  const size = clamp(playerBusinesses(state).length * 1.5, 0, 15);
  return clamp(base + size - guarded, 0, 100);
}

/** Whether the company can take a decision that needs other people's consent. */
export function hasBoard(state: GameState): boolean {
  return built(state, 'board');
}

/** Every facility with its state, for the screen. */
export interface FacilityRow {
  def: FacilityDef;
  built: boolean;
  building: Project | null;
  check: BuildCheck;
}

export function facilityRows(state: GameState): FacilityRow[] {
  const project = activeProject(state);
  return FACILITIES.map((def) => ({
    def,
    built: built(state, def.id),
    building: project?.facilityId === def.id ? project : null,
    check: canBuild(state, def.id),
  }));
}
