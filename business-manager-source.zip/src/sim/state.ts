import type {
  ActiveEvent,
  Alert,
  Building,
  Business,
  Campaign,
  Company,
  DayRecord,
  DistrictId,
  Employee,
  LedgerEntry,
  Loan,
  NewsItem,
  PendingDecision,
  PurchaseOrder,
  Review,
  Goal,
  Warehouse,
  Contract,
  ContractOffer,
  Division,
  Founder,
  Merger,
  Invoice,
  Bill,
  HeadOffice,
  MonthlyAccount,
  PeriodTotals,
} from './types';

import type { ResearchState } from './research';
import type { Standing } from './standing';
import type { ChronicleEntry, Records } from './chronicle';
import type { Announcement } from './cityChange';
import type { OfficerId } from './executives';
import type { PolicyId } from './policies';
import type { Project } from './facilities';

/**
 * 1 → 2: eight skills instead of six, a seven-rung career ladder, head office
 * floors and systems, and divisions.
 *
 * 3 → 4: revenue and cash stopped being the same thing. A save made before
 * working capital existed has no sales ledger and no purchase ledger, which is
 * exactly right — everything it ever earned was settled on the day — so the
 * migration opens both empty and the company carries on from a clean position.
 *
 * 2 → 3: the ladder grew Specialist and Director, which moved every rung above
 * Senior up by one. A grade is a stored number, so a version 2 manager would
 * quietly become a team lead if it were read as-is — the migration remaps them
 * so nobody is demoted by an update. Version 3 also adds loan kinds and the
 * founder, both of which fill in from what the save already knew.
 */
export const SAVE_VERSION = 4;
export const SETTINGS_KEY = 'business-manager:settings';

/**
 * Starting capital. Tight enough that the first choice matters, but large
 * enough that more than one kind of business is actually reachable — a food
 * or specialist opening needs a fit-out a retail unit does not.
 */
export const START_CASH = 60000;
export const START_DAY = 1;
export const START_HOUR = 8;

export const LEDGER_LIMIT = 600;

/** A fresh set of running totals, starting on the given day. */
export function emptyPeriod(fromDay: number): PeriodTotals {
  return { fromDay, categories: {}, revenueByBusiness: {}, costsByBusiness: {} };
}
export const DAY_HISTORY_LIMIT = 365;
export const ALERT_LIMIT = 60;

/** In-game hours advanced per real second at each speed setting. */
export const SPEEDS = [0, 0.5, 1, 2, 4] as const;
export const SPEED_LABELS = ['❚❚', '1×', '2×', '4×', '8×'] as const;

export interface EconomyState {
  /** 0..200, 100 is neutral. Drives how freely people spend. */
  confidence: number;
  /** Cumulative price level, 1.0 at the start. */
  inflation: number;
  /** Yearly base interest rate, e.g. 0.045. */
  interestRate: number;
  /** 0..1 */
  unemployment: number;
  /** Yearly growth rate of the whole city economy. */
  growth: number;
  /** The last regime label reported, so a change is announced once. */
  lastLabel: string;
}

export interface DistrictState {
  /** Multiplier on customer demand in this district. */
  demandIndex: number;
  /** Multiplier on rent asked here. */
  rentIndex: number;
  /** Multiplier on property values here. */
  propertyIndex: number;
}

export interface Settings {
  autosave: boolean;
  showTutorial: boolean;
  compactNumbers: boolean;
  confirmLargeSpend: boolean;
}

export interface Achievement {
  id: string;
  unlockedOnDay: number;
}

export interface GameState {
  version: number;
  seed: number;
  /** Day 1 is the first day of business. */
  day: number;
  /** 0..23 */
  hour: number;
  /** Index into SPEEDS. */
  speed: number;
  playerCompanyId: string;

  companies: Company[];
  businesses: Business[];
  buildings: Building[];
  employees: Employee[];
  /** People available to hire right now. */
  applicants: Employee[];
  orders: PurchaseOrder[];
  campaigns: Campaign[];
  loans: Loan[];

  ledger: LedgerEntry[];
  dayHistory: DayRecord[];
  alerts: Alert[];
  events: ActiveEvent[];
  /** Rolling feed of things that actually happened in the simulation. */
  news: NewsItem[];
  /** Decisions waiting on the player. At most one is open at a time. */
  decisions: PendingDecision[];
  /** Day each kind of decision last appeared, so they do not repeat. */
  decisionHistory: Record<string, number>;
  /** Written customer reviews, newest first. */
  reviews: Review[];
  /** Distribution centres the company runs. */
  warehouses: Warehouse[];
  /** Finished and in-progress research. */
  research: ResearchState;
  /** The company's head office, if it has one. */
  headOffice: HeadOffice | null;
  /** Groups of locations, each of which can be handed to an executive. */
  divisions: Division[];
  /** Integrations in progress, and the record of the ones that finished. */
  mergers: Merger[];
  /** Work done and not yet paid for. An asset you cannot spend. */
  invoices: Invoice[];
  /** Stock taken on terms and not yet paid for. */
  bills: Bill[];
  /** Building work in progress at the head office. */
  projects: Project[];
  /** What the city has said it will do and has not yet done. */
  announcements: Announcement[];
  /** Who holds each executive post, by employee id. */
  officers: Record<OfficerId, string | null>;
  /** How much of the company outside investors own, 0..0.6. */
  outsideStake: number;
  /** How the company does things, everywhere at once. */
  policies: Record<PolicyId, string>;
  /** The decisions the player made, in order. */
  chronicle: ChronicleEntry[];
  /** The high-water marks the company ever reached. */
  records: Records;
  /** What the company is known for, in five parts. */
  standing: Standing;
  /** Money already spoken for by the tax bill that is coming. */
  taxReserve: number;
  /** Which liquidity warning is currently standing, so it is said once. */
  liquidityBand: 'clear' | 'warning' | 'critical';
  /** The person running the company, and what they are good at. */
  founder: Founder | null;
  /** Supply contracts the company is committed to. */
  contracts: Contract[];
  /** Contracts on the table, waiting on a yes or a no. */
  contractOffers: ContractOffer[];
  /** Management accounts, one per closed month, oldest first. */
  accounts: MonthlyAccount[];
  /** Running totals for the month in progress. */
  period: PeriodTotals;
  /** Business id -> day the owner last refused an offer for it. */
  approaches: Record<string, number>;
  /** Time-limited targets generated from the state of the company. */
  goals: Goal[];
  /** How many goals have been met, for the progression screen. */
  goalsCompleted: number;
  /**
   * The highest level the company has ever reached. The level itself is read
   * from the company, so this exists only so a promotion is announced once.
   */
  levelReached: number;

  economy: EconomyState;
  districts: Record<DistrictId, DistrictState>;

  /** Cumulative money spent per supplier, for volume discounts. */
  supplierSpend: Record<string, number>;

  achievements: Achievement[];
  tutorialStep: number;
  settings: Settings;

  stats: {
    revenueTotal: number;
    costsTotal: number;
    customersTotal: number;
    unitsTotal: number;
    peakNetWorth: number;
    bankrupt: boolean;
  };
}

export const DEFAULT_SETTINGS: Settings = {
  autosave: true,
  showTutorial: true,
  compactNumbers: true,
  confirmLargeSpend: true,
};

export const DEFAULT_ECONOMY: EconomyState = {
  confidence: 100,
  inflation: 1,
  interestRate: 0.045,
  unemployment: 0.062,
  growth: 0.024,
  lastLabel: 'Stable',
};

export function defaultDistrictState(): DistrictState {
  return { demandIndex: 1, rentIndex: 1, propertyIndex: 1 };
}

/** Absolute hour since day 0, used for order arrival times. */
export function absoluteHour(state: GameState): number {
  return state.day * 24 + state.hour;
}

// ---------------------------------------------------------------- lookups

export function playerCompany(state: GameState): Company {
  const company = state.companies.find((c) => c.id === state.playerCompanyId);
  if (!company) throw new Error('Player company missing from state');
  return company;
}

export function companyById(state: GameState, id: string): Company | undefined {
  return state.companies.find((c) => c.id === id);
}

export function businessById(state: GameState, id: string): Business | undefined {
  return state.businesses.find((b) => b.id === id);
}

export function buildingById(state: GameState, id: string): Building | undefined {
  return state.buildings.find((b) => b.id === id);
}

export function employeeById(state: GameState, id: string): Employee | undefined {
  return state.employees.find((e) => e.id === id);
}

/** Businesses the player owns, in the order they were opened. */
export function playerBusinesses(state: GameState): Business[] {
  return state.businesses.filter((b) => b.companyId === state.playerCompanyId);
}

export function competitorBusinesses(state: GameState): Business[] {
  return state.businesses.filter((b) => b.companyId !== state.playerCompanyId);
}

export function employeesOf(state: GameState, businessId: string): Employee[] {
  return state.employees.filter((e) => e.businessId === businessId);
}
