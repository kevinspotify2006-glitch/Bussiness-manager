import type { GameState } from './state';
import { playerBusinesses, playerCompany } from './state';
import { marketRate } from './employees';
import { managementCover, staffingSummary } from './staffing';
import { approach, clamp, sum } from './util';
import { pushNews } from './news';

/**
 * What the company is known for.
 *
 * A single `reputation: 72` said nothing useful, because the five things it was
 * standing in for are not the same thing and are not earned the same way. A
 * company can make a superb product and be a miserable place to work. It can
 * serve people beautifully and never pay a supplier on time. Collapsing that
 * into one number meant every one of those had the same consequence, which is
 * to say none.
 *
 * So there are five, each with its own drivers and — this is the part that
 * matters — its own consequence somewhere else in the simulation:
 *
 *   brand      how widely you are known  →  what marketing buys
 *   quality    whether the goods are good →  what customers write in reviews
 *   service    whether people are served  →  whether they come back
 *   employer   whether people want to work here → who applies, and for how much
 *   financial  whether you pay your bills →  what suppliers and lenders allow
 *
 * Each drifts toward a target computed from things the player actually did, so
 * standing is slow to earn and slow to lose, which is what makes it standing
 * rather than a readout.
 *
 * `business.reputation` is untouched and still means what it always meant: what
 * the people in that district think of that shop. This is the company.
 */

export interface Standing {
  brand: number;
  quality: number;
  service: number;
  employer: number;
  financial: number;
}

export const STANDING_FACETS: { id: keyof Standing; name: string; drives: string }[] = [
  { id: 'brand', name: 'Brand', drives: 'How far every euro of marketing reaches.' },
  { id: 'quality', name: 'Quality', drives: 'What customers say about you afterwards.' },
  { id: 'service', name: 'Service', drives: 'Whether they come back.' },
  { id: 'employer', name: 'Employer', drives: 'Who applies for your jobs, and what they cost.' },
  { id: 'financial', name: 'Financial', drives: 'What suppliers and lenders will allow you.' },
];

export function emptyStanding(): Standing {
  return { brand: 30, quality: 50, service: 50, employer: 50, financial: 50 };
}

export function standingOf(state: GameState): Standing {
  return state.standing ?? emptyStanding();
}

// -------------------------------------------------------------- the targets

/**
 * Where each facet is heading, read from what the company is actually doing.
 *
 * Nothing here is stored: every number is derived from the trading, the payroll
 * and the ledgers, so a facet cannot drift away from the thing it describes.
 */
export function standingTargets(state: GameState): Standing {
  const company = playerCompany(state);
  const open = playerBusinesses(state).filter((b) => b.status === 'open');
  const staff = state.employees.filter((e) => e.companyId === state.playerCompanyId);

  // ---- brand: being known, across everywhere you trade
  const awareness = open.length > 0 ? sum(open, (b) => b.awareness) / open.length : 0;
  const reach = clamp(open.length * 6, 0, 25);
  const brand = clamp(awareness * 0.75 + reach, 0, 100);

  // ---- quality: what people actually score you, and how well run the place is
  const reviewed = open.filter((b) => b.reviewCount > 0);
  const stars = reviewed.length > 0 ? sum(reviewed, (b) => b.reviewScore) / reviewed.length : 3;
  const run = open.length > 0 ? sum(open, (b) => b.serviceQuality) / open.length : 50;
  const quality = clamp(((stars - 1) / 4) * 70 + run * 0.3, 0, 100);

  // ---- service: enough people, not run off their feet, properly supervised
  const cover = open.length > 0
    ? sum(open, (b) => {
        const plan = staffingSummary(state, b);
        const staffed = plan.required > 0 ? clamp(plan.current / plan.required, 0, 1.2) : 1;
        return staffed * 0.6 + clamp(managementCover(state, b), 0, 1) * 0.4;
      }) / open.length
    : 0.5;
  const strain = staff.length > 0 ? sum(staff, (e) => e.workload) / staff.length : 40;
  const service = clamp(cover * 82 - Math.max(0, strain - 70) * 1.2, 0, 100);

  // ---- employer: pay, morale, and whether people stay
  const paid = staff.length > 0
    ? sum(staff, (e) => e.salary / Math.max(1, marketRate(state, e))) / staff.length
    : 1;
  const morale = staff.length > 0 ? sum(staff, (e) => e.morale) / staff.length : 50;
  const employer = staff.length === 0
    ? 50
    : clamp(42 + (paid - 1) * 90 + (morale - 55) * 0.55, 0, 100);

  // ---- financial: the rating, plus whatever is currently unpaid
  const arrears = state.bills.filter((b) => b.lateDays > 0).length;
  const missed = sum(state.loans, (loan) => loan.missedPayments);
  const financial = clamp(company.creditRating - arrears * 6 - missed * 8, 0, 100);

  return { brand, quality, service, employer, financial };
}

/**
 * A day of standing.
 *
 * Deliberately slow — a fifty-day half-life — because a reputation that moved
 * as fast as the thing it measures would just be the thing it measures with a
 * second name on it. The lag is the point: it is why a bad month still costs
 * you something two months later, and why fixing the cause does not instantly
 * fix the consequence.
 */
export function standingDaily(state: GameState): void {
  const now = standingOf(state);
  const target = standingTargets(state);
  const before = { ...now };
  for (const facet of STANDING_FACETS) {
    now[facet.id] = approach(now[facet.id], target[facet.id], 0.014);
  }
  state.standing = now;

  // Crossing a threshold is worth saying out loud once, because each of these
  // changes what the player can do rather than just how they look.
  announce(state, 'employer', before.employer, now.employer, 70, 'People are starting to apply to you unprompted', 'A good name as an employer means better applicants at a lower fee.');
  announce(state, 'employer', before.employer, now.employer, 35, 'Word has got round that this is a bad place to work', 'Worse applicants, and recruiters cost more.', true);
  announce(state, 'quality', before.quality, now.quality, 75, 'You have a name for doing good work', 'Reviews will run better than the day itself deserves.');
  announce(state, 'financial', before.financial, now.financial, 35, 'Your suppliers have started talking to each other', 'Terms shorten, and some will want cash up front.', true);
}

function announce(
  state: GameState,
  id: keyof Standing,
  before: number,
  after: number,
  line: number,
  title: string,
  body: string,
  falling = false,
): void {
  const crossed = falling ? before >= line && after < line : before < line && after >= line;
  if (!crossed) return;
  pushNews(state, 'company', title, body, { importance: falling ? 'high' : 'normal' });
  void id;
}

// ------------------------------------------------------------- the effects

/**
 * What a euro of marketing is worth to a company people have heard of.
 *
 * A known name converts; an unknown one is paying to introduce itself first.
 * Fifty changes nothing, as it does for every other facet — a company that has
 * earned no name either way should not be quietly rewarded for it.
 */
export function brandFactor(state: GameState): number {
  return 0.65 + (standingOf(state).brand / 100) * 0.7;
}

/** The nudge a reputation for good work gives a review before it is written. */
export function qualityBias(state: GameState): number {
  return ((standingOf(state).quality - 50) / 50) * 0.45;
}

/**
 * How much of yesterday's custom comes back today.
 *
 * Service is the facet nobody notices until it is missing: a shop that serves
 * people well keeps them, and one that does not has to find new ones every day
 * out of the same finite district.
 */
export function retentionFactorOf(state: GameState): number {
  return 0.88 + (standingOf(state).service / 100) * 0.24;
}

/**
 * What being a decent employer is worth.
 *
 * Two things at once: better people apply, and they cost less to find. A
 * company with a bad name pays a premium to recruiters and still gets a worse
 * field, which is exactly how it works.
 */
export function employerPull(state: GameState): { skill: number; fee: number } {
  const employer = standingOf(state).employer;
  return {
    skill: ((employer - 50) / 50) * 9,
    fee: clamp(1.3 - (employer / 100) * 0.6, 0.7, 1.3),
  };
}

/** What paying your bills is worth in days of credit from a supplier. */
export function financialStanding(state: GameState): number {
  return standingOf(state).financial;
}

/** The five facets with their current readings, for the screen. */
export function standingRows(state: GameState): { name: string; value: number; drives: string; tone: 'good' | 'bad' | 'warn' }[] {
  const standing = standingOf(state);
  return STANDING_FACETS.map((facet) => {
    const value = standing[facet.id];
    return {
      name: facet.name,
      value,
      drives: facet.drives,
      tone: value >= 65 ? 'good' : value < 40 ? 'bad' : 'warn',
    };
  });
}
