import type { GameState } from './state';
import type { Business, Review } from './types';
import { businessTypeOrThrow } from '../data/businessTypes';
import { buildingById } from './state';
import { priceIndex } from './demand';
import { makeId } from './util';
import { gameRng } from './rng';
import { qualityBias } from './standing';

/**
 * Customer reviews.
 *
 * The star rating already comes out of the simulation; this turns the strongest
 * driver behind it into something a person actually wrote, so a run of two-star
 * days reads as "the queue was out of the door" rather than as a number.
 */

export const REVIEW_LIMIT = 60;

type Driver = Review['driver'];

const POSITIVE: Record<Driver, string[]> = {
  price: [
    'Cheaper than anywhere else nearby and the quality is fine.',
    'Good value. I checked two other places first and came back here.',
    'Prices have not crept up like everywhere else. Appreciated.',
  ],
  service: [
    'Staff actually seemed pleased to see me.',
    'In and out in two minutes, and someone still said good morning.',
    'Whoever is running this place has trained the team properly.',
  ],
  availability: [
    'They had everything I came for, which is rarer than it should be.',
    'Shelves full, no queue. Simple things done well.',
    'Never had to settle for a substitute here.',
  ],
  quality: [
    'Noticeably better stock than the chain down the road.',
    'You can tell they buy decent products.',
    'Worth the extra few euro for what you get.',
  ],
  premises: [
    'Clean, bright and easy to find things.',
    'The place has clearly had money spent on it. Pleasant to walk around.',
    'Tidy and well kept, which puts you in the mood to buy.',
  ],
};

const NEGATIVE: Record<Driver, string[]> = {
  price: [
    'Fine, but I am not paying those prices twice.',
    'Everything is a euro or two more than it should be.',
    'Convenient, expensive, and they know it.',
  ],
  service: [
    'Stood at the counter while two staff talked to each other.',
    'Nobody could answer a straight question.',
    'The person serving looked like they would rather be anywhere else.',
  ],
  availability: [
    'Half of what I wanted was out of stock. Again.',
    'Queued for ten minutes and then gave up.',
    'Empty shelves on a weekday afternoon is not a good look.',
  ],
  quality: [
    'The stock feels cheap for what they charge.',
    'Bought something here once. Will not repeat it.',
    'Quality is a step below what I expected.',
  ],
  premises: [
    'The place needs a proper clean and a coat of paint.',
    'Tired-looking inside. Put me off browsing.',
    'Feels neglected. Hard to enjoy shopping in it.',
  ],
};

/** Works out what most influenced today's rating at this location. */
function dominantDriver(
  state: GameState,
  business: Business,
  availability: number,
): { driver: Driver; positive: boolean } {
  const building = buildingById(state, business.buildingId);
  const index = priceIndex(business);
  const type = businessTypeOrThrow(business.typeId);

  // Score each driver from -1 (terrible) to +1 (excellent).
  const scores: { driver: Driver; score: number }[] = [
    { driver: 'price', score: (1 - index) * 2.2 },
    { driver: 'service', score: (business.serviceQuality - 55) / 45 },
    { driver: 'availability', score: (availability - 0.85) * 5 },
    { driver: 'premises', score: building ? (building.condition - 65) / 35 : 0 },
  ];
  if (type.productIds.length > 0) {
    // What the shop is like, plus what the company is known for. A firm with a
    // name for good work is given the benefit of the doubt on an average day,
    // and one without it is not.
    scores.push({ driver: 'quality', score: (business.reputation - 50) / 50 + qualityBias(state) });
  }

  // The loudest voice wins, whichever direction it points in.
  let best = scores[0];
  for (const entry of scores) {
    if (Math.abs(entry.score) > Math.abs(best.score)) best = entry;
  }
  return { driver: best.driver, positive: best.score >= 0 };
}

/** Called once a day for a trading business, after the star rating is known. */
export function writeReviews(state: GameState, business: Business, stars: number, availability: number): void {
  if (business.yesterday.customers < 5 && business.today.customers < 5) return;
  const { driver, positive } = dominantDriver(state, business, availability);
  // A quiet day produces one review; a busy one occasionally produces two.
  const count = business.today.customers > 220 && gameRng.chance(0.45) ? 2 : 1;

  for (let i = 0; i < count; i += 1) {
    const lines = positive ? POSITIVE[driver] : NEGATIVE[driver];
    const review: Review = {
      id: makeId('rev'),
      businessId: business.id,
      day: state.day,
      // Individual reviews scatter around the day's average.
      stars: Math.max(1, Math.min(5, Math.round(stars + gameRng.range(-0.6, 0.6)))),
      text: gameRng.pick(lines),
      driver,
    };
    state.reviews.unshift(review);
  }
  if (state.reviews.length > REVIEW_LIMIT) state.reviews.length = REVIEW_LIMIT;
}

export function reviewsFor(state: GameState, businessId: string, limit = 6): Review[] {
  return state.reviews.filter((review) => review.businessId === businessId).slice(0, limit);
}

/** The complaint the player hears most often at a location. */
export function topComplaint(state: GameState, businessId: string): { driver: Driver; count: number } | null {
  const recent = state.reviews.filter((review) => review.businessId === businessId && review.stars <= 3);
  if (recent.length === 0) return null;
  const counts = new Map<Driver, number>();
  for (const review of recent) counts.set(review.driver, (counts.get(review.driver) ?? 0) + 1);
  let best: { driver: Driver; count: number } | null = null;
  for (const [driver, count] of counts) {
    if (!best || count > best.count) best = { driver, count };
  }
  return best;
}

export const DRIVER_LABELS: Record<Driver, string> = {
  price: 'value for money',
  service: 'service',
  availability: 'availability',
  quality: 'product quality',
  premises: 'the premises',
};
