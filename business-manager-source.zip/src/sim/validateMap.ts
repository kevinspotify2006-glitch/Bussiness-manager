import type { Filler, Pt, Rect, Road } from './cityLayout';
import { cityLayout } from './cityLayout';
import { crossesStructure, parkingSpaces, roadGraph, route } from './traffic';
import { ATLAS } from '../data/atlas';

/**
 * Does the city hold together?
 *
 * A generated map fails quietly: two buildings a metre into each other, a street
 * that leads nowhere, a shop with no road to it, a car park a van can only reach
 * by driving through a factory. None of that throws — it just looks wrong, and
 * only if you happen to be looking at that corner.
 *
 * So the map checks itself. This runs over the whole of Northgate and reports
 * what is wrong with it, and the map's debug overlay draws what it found.
 */

export interface MapProblem {
  kind:
    | 'overlap'
    | 'no-road-access'
    | 'out-of-bounds'
    | 'unreachable'
    | 'blocked-approach'
    | 'missing-asset'
    | 'orphan-road';
  what: string;
  at: Pt;
}

export interface MapReport {
  problems: MapProblem[];
  counts: {
    roads: number;
    structures: number;
    plots: number;
    amenities: number;
    nodes: number;
    edges: number;
    /** Car parks a vehicle can actually get into. */
    parking: number;
  };
}

const BOUNDS = { x: -0.24, y: -0.24, w: 1.5, h: 1.45 };

/** Structures, as opposed to the ground they stand on. */
const GROUND = new Set(['park', 'plaza', 'parking', 'pitch', 'quay', 'field', 'orchard', 'pasture', 'solar']);

function overlaps(a: Rect, b: Rect, slack: number): boolean {
  return (
    a.x + a.w > b.x + slack &&
    b.x + b.w > a.x + slack &&
    a.y + a.h > b.y + slack &&
    b.y + b.h > a.y + slack
  );
}

function inside(r: Rect, bounds: Rect): boolean {
  return r.x >= bounds.x && r.y >= bounds.y && r.x + r.w <= bounds.x + bounds.w && r.y + r.h <= bounds.y + bounds.h;
}

/** Distance from a point to a road's nearest carriageway. */
function distanceToRoad(p: Pt, road: Road): number {
  let best = Infinity;
  for (let i = 0; i + 1 < road.pts.length; i += 1) {
    const a = road.pts[i];
    const b = road.pts[i + 1];
    const dx = b.x - a.x;
    const dy = b.y - a.y;
    const lengthSquared = dx * dx + dy * dy;
    const t = lengthSquared > 0 ? Math.max(0, Math.min(1, ((p.x - a.x) * dx + (p.y - a.y) * dy) / lengthSquared)) : 0;
    const d = Math.hypot(p.x - (a.x + dx * t), p.y - (a.y + dy * t));
    if (d < best) best = d;
  }
  return best;
}

export function validateMap(): MapReport {
  const layout = cityLayout();
  const graph = roadGraph();
  const problems: MapProblem[] = [];

  const structures = layout.fillers.filter((f) => !GROUND.has(f.kind));

  // ------------------------------------------------ every asset must exist
  const known = new Set(ATLAS.map((a) => a.id));
  for (const filler of layout.fillers) {
    if (!known.has(filler.asset)) {
      problems.push({ kind: 'missing-asset', what: filler.asset, at: { x: filler.x, y: filler.y } });
    }
  }
  for (const item of layout.amenities) {
    if (!known.has(item.asset)) {
      problems.push({ kind: 'missing-asset', what: item.asset, at: item });
    }
  }

  // ----------------------------------------------- nothing built on itself
  // Buckets by grid cell, so this is not a quarter of a million comparisons.
  const cell = 0.02;
  const buckets = new Map<string, Filler[]>();
  for (const s of structures) {
    const x0 = Math.floor(s.x / cell);
    const x1 = Math.floor((s.x + s.w) / cell);
    const y0 = Math.floor(s.y / cell);
    const y1 = Math.floor((s.y + s.h) / cell);
    for (let x = x0; x <= x1; x += 1) {
      for (let y = y0; y <= y1; y += 1) {
        const k = `${x},${y}`;
        const list = buckets.get(k);
        if (list) list.push(s);
        else buckets.set(k, [s]);
      }
    }
  }
  const reported = new Set<string>();
  for (const list of buckets.values()) {
    for (let i = 0; i < list.length; i += 1) {
      for (let j = i + 1; j < list.length; j += 1) {
        // A shared wall is a terrace, not a fault; a real overlap is deeper.
        if (!overlaps(list[i], list[j], 0.0008)) continue;
        const k = `${list[i].x.toFixed(5)}|${list[j].x.toFixed(5)}|${list[i].y.toFixed(5)}`;
        if (reported.has(k)) continue;
        reported.add(k);
        problems.push({
          kind: 'overlap',
          what: `${list[i].kind} and ${list[j].kind} stand on the same ground`,
          at: { x: list[i].x, y: list[i].y },
        });
      }
    }
  }

  // --------------------------------------------------- everything in bounds
  for (const filler of layout.fillers) {
    if (inside(filler, BOUNDS)) continue;
    problems.push({ kind: 'out-of-bounds', what: `${filler.kind} is off the map`, at: { x: filler.x, y: filler.y } });
  }

  // ------------------------------------------- every unit fronts onto a road
  for (const plot of layout.plots) {
    const centre = { x: plot.x + plot.w / 2, y: plot.y + plot.h / 2 };
    let best = Infinity;
    for (const road of layout.roads) {
      if (road.cls === 'rail' || road.cls === 'runway' || road.cls === 'taxiway') continue;
      const d = distanceToRoad(centre, road) - road.width / 2;
      if (d < best) best = d;
    }
    // A unit more than about forty metres from any pavement has no frontage.
    if (best > 0.012) {
      problems.push({ kind: 'no-road-access', what: `${plot.number} ${plot.street}`, at: centre });
    }
  }

  // ------------------------------------------------ the network is one network
  // Every junction must be reachable from every other, or traffic will strand.
  if (graph.nodes.length > 0) {
    const seen = new Uint8Array(graph.nodes.length);
    const queue = [0];
    seen[0] = 1;
    while (queue.length > 0) {
      const at = queue.pop() as number;
      for (const edgeId of graph.nodes[at].out) {
        const next = graph.edges[edgeId].to;
        if (seen[next]) continue;
        seen[next] = 1;
        queue.push(next);
      }
    }
    for (let i = 0; i < graph.nodes.length; i += 1) {
      if (seen[i]) continue;
      problems.push({ kind: 'unreachable', what: 'this junction is cut off from the network', at: graph.nodes[i] });
    }
    // A junction with one way in and out is a dead end, which is fine; a
    // junction with none is a road that was generated and then left.
    for (let i = 0; i < graph.nodes.length; i += 1) {
      if (graph.nodes[i].out.length === 0) {
        problems.push({ kind: 'orphan-road', what: 'a road that connects to nothing', at: graph.nodes[i] });
      }
    }
  }

  // ------------------------------- a van can reach every car park it is sent to
  // These are the spaces traffic actually uses; if any of them can only be
  // reached through a building, vehicles are driving through walls.
  const spaces = parkingSpaces(graph, layout.fillers);
  for (const space of spaces) {
    const kerb = graph.nodes[space.node];
    const through = crossesStructure(kerb, space.at, structures);
    if (through) {
      problems.push({ kind: 'blocked-approach', what: `a car park reached only through a ${through.kind}`, at: space.at });
    }
  }

  return {
    problems,
    counts: {
      roads: layout.roads.length,
      structures: structures.length,
      plots: layout.plots.length,
      amenities: layout.amenities.length,
      nodes: graph.nodes.length,
      edges: graph.edges.length,
      parking: spaces.length,
    },
  };
}

/** A quick end-to-end proof that the network routes: corner to opposite corner. */
export function routeAcrossCity(): number {
  const graph = roadGraph();
  if (graph.nodes.length < 2) return 0;
  let topLeft = 0;
  let bottomRight = 0;
  for (let i = 0; i < graph.nodes.length; i += 1) {
    const n = graph.nodes[i];
    if (n.x + n.y < graph.nodes[topLeft].x + graph.nodes[topLeft].y) topLeft = i;
    if (n.x + n.y > graph.nodes[bottomRight].x + graph.nodes[bottomRight].y) bottomRight = i;
  }
  const found = route(graph, topLeft, bottomRight);
  return found ? found.length : 0;
}
