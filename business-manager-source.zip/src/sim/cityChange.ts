import type { GameState } from './state';
import { playerBusinesses } from './state';
import type { DistrictId } from './types';
import { DISTRICTS, district } from '../data/districts';
import { pushNews } from './news';
import { pushAlert } from './alerts';
import { record } from './chronicle';
import { gameRng } from './rng';
import { clamp, makeId, sum } from './util';

/**
 * The city changes, and it stays changed.
 *
 * There were already city events — a street festival, a road closure, a
 * heatwave — and every one of them was temporary. They ran for a fortnight and
 * the city went back to exactly what it was. That is weather, and weather is
 * worth having, but it meant Northgate on day nine hundred was the same city as
 * Northgate on day one and nothing the player did or waited for ever altered
 * the ground they were trading on.
 *
 * These are the other kind. A metro line opens and that district is permanently
 * better connected. A university expands and there are permanently more people
 * in it. A shopping centre opens and the trade permanently moves. They are
 * announced before they land, so the player can buy ahead of them or get out of
 * the way, and they are written into the district's own indices rather than
 * held as a modifier that expires — which is what makes them permanent.
 *
 * A district is described by three numbers the rest of the simulation already
 * reads: how much demand there is, what rent costs, and what property is worth.
 * Everything here moves those. Nothing here invents a fourth.
 */

export interface DevelopmentDef {
  id: string;
  name: string;
  /** What is happening, in the player's words. */
  detail: string;
  /** What it means for somebody trading there. */
  means: string;
  /** Days between the announcement and the change landing. */
  notice: [number, number];
  /** Permanent multipliers on the district's own indices. */
  demand: number;
  rent: number;
  property: number;
  /** Which districts it can happen in. Empty means anywhere. */
  where: DistrictId[];
  /** Roughly how often, against the others. */
  weight: number;
  /** Good news or bad, for how it is announced. */
  tone: 'good' | 'bad';
}

export const DEVELOPMENTS: DevelopmentDef[] = [
  {
    id: 'metro',
    name: 'New metro line',
    detail: 'The transport authority is extending the line, with a station here.',
    means: 'Permanently easier to reach, so permanently busier — and the rent will follow.',
    notice: [90, 180], demand: 1.18, rent: 1.14, property: 1.22,
    where: ['transit', 'southside', 'university', 'midtown'], weight: 3, tone: 'good',
  },
  {
    id: 'mall',
    name: 'A shopping centre is opening',
    detail: 'A developer has a site and an anchor tenant.',
    means: 'It will pull trade towards it and away from the streets around it.',
    notice: [120, 220], demand: 1.24, rent: 1.2, property: 1.15,
    where: ['shopping', 'suburbs', 'midtown'], weight: 3, tone: 'good',
  },
  {
    id: 'mall-shadow',
    name: 'Trade is moving to the new centre',
    detail: 'The shopping centre that opened nearby has taken the passing trade with it.',
    means: 'Fewer people walking past, and it is not coming back on its own.',
    notice: [10, 30], demand: 0.86, rent: 0.94, property: 0.95,
    where: ['downtown', 'waterfront', 'southside'], weight: 2, tone: 'bad',
  },
  {
    id: 'university',
    name: 'The university is expanding',
    detail: 'A new faculty, and several thousand more people who live here term-time.',
    means: 'More customers, younger, and more people to hire.',
    notice: [120, 200], demand: 1.2, rent: 1.12, property: 1.12,
    where: ['university'], weight: 2, tone: 'good',
  },
  {
    id: 'airport',
    name: 'The airport is adding a terminal',
    detail: 'More flights, more freight, and a great deal more traffic through here.',
    means: 'Permanently busier, and permanently more expensive to be near.',
    notice: [150, 260], demand: 1.16, rent: 1.18, property: 1.2,
    where: ['airport', 'transit'], weight: 2, tone: 'good',
  },
  {
    id: 'regeneration',
    name: 'The district is being regenerated',
    detail: 'Public money, new frontages and somebody finally fixing the pavements.',
    means: 'It will be a better place to trade, and a dearer one.',
    notice: [90, 180], demand: 1.15, rent: 1.25, property: 1.3,
    where: ['southside', 'waterfront', 'industrial', 'warehouse'], weight: 2, tone: 'good',
  },
  {
    id: 'employer-leaves',
    name: 'The big employer is closing',
    detail: 'The largest employer in the district is moving its operation out of the city.',
    means: 'The people who worked there spent their money here. Most of that goes with them.',
    notice: [60, 120], demand: 0.8, rent: 0.86, property: 0.82,
    where: ['industrial', 'warehouse', 'southside', 'suburbs'], weight: 2, tone: 'bad',
  },
  {
    id: 'ringroad',
    name: 'The ring road is being rerouted',
    detail: 'The new alignment takes the through traffic around the district rather than into it.',
    means: 'Quieter streets, and a great many fewer people passing the door.',
    notice: [90, 160], demand: 0.85, rent: 0.9, property: 0.9,
    where: ['transit', 'industrial', 'suburbs', 'warehouse'], weight: 2, tone: 'bad',
  },
  {
    id: 'offices',
    name: 'An office quarter is going up',
    detail: 'Two towers and a plaza, with several thousand people in them by day.',
    means: 'A weekday lunch trade that did not exist before, at weekday rents.',
    notice: [120, 210], demand: 1.22, rent: 1.28, property: 1.24,
    where: ['financial', 'downtown', 'midtown'], weight: 2, tone: 'good',
  },
  {
    id: 'housing',
    name: 'A housing estate has been approved',
    detail: 'Twelve hundred homes on the old yard site.',
    means: 'More people living here, spending here, and available to work here.',
    notice: [150, 260], demand: 1.19, rent: 1.1, property: 1.14,
    where: ['suburbs', 'southside', 'midtown', 'warehouse'], weight: 2, tone: 'good',
  },
];

export function development(id: string): DevelopmentDef | undefined {
  return DEVELOPMENTS.find((d) => d.id === id);
}

/**
 * Something the city has announced but not yet done.
 *
 * The notice period is the whole point. A player who is paying attention can
 * take a lease in a district that is about to get a metro station, or get out
 * of one that is about to lose its biggest employer — and a player who is not
 * finds out when the rent changes.
 */
export interface Announcement {
  id: string;
  defId: string;
  districtId: DistrictId;
  announcedOnDay: number;
  landsOnDay: number;
}

/** Roughly one every four months, which over a long game reshapes the city. */
const CHANCE_PER_DAY = 1 / 120;

export function cityChangeDaily(state: GameState): void {
  land(state);
  if (!gameRng.chance(CHANCE_PER_DAY)) return;
  announce(state);
}

function announce(state: GameState): void {
  const pool = DEVELOPMENTS.filter((def) => {
    // Not the same development twice in the same district while one is pending.
    return !state.announcements.some((a) => a.defId === def.id);
  });
  if (pool.length === 0) return;

  const total = sum(pool, (def) => def.weight);
  let roll = gameRng.range(0, total);
  let chosen = pool[0];
  for (const def of pool) {
    roll -= def.weight;
    if (roll <= 0) { chosen = def; break; }
  }

  const where = chosen.where.length > 0 ? chosen.where : DISTRICTS.map((d) => d.id);
  const districtId = gameRng.pick(where);
  const notice = Math.round(gameRng.range(chosen.notice[0], chosen.notice[1]));

  state.announcements.push({
    id: makeId('dev'),
    defId: chosen.id,
    districtId,
    announcedOnDay: state.day,
    landsOnDay: state.day + notice,
  });

  const def = district(districtId);
  const mine = playerBusinesses(state).filter((b) => {
    const building = state.buildings.find((x) => x.id === b.buildingId);
    return building?.district === districtId && b.status === 'open';
  }).length;

  pushNews(
    state,
    'property',
    `${chosen.name} — ${def.name}`,
    `${chosen.detail} Expected in about ${Math.round(notice / 30)} months. ${chosen.means}`,
    { importance: mine > 0 ? 'high' : 'normal' },
  );
  // Only interrupt the player when it is about somewhere they actually trade,
  // or somewhere they might want to before it happens.
  if (mine > 0 || chosen.tone === 'good') {
    pushAlert(
      state,
      mine > 0 && chosen.tone === 'bad' ? 'warning' : 'info',
      `${chosen.name} in ${def.name}`,
      mine > 0
        ? `You have ${mine} location${mine === 1 ? '' : 's'} there. ${chosen.means}`
        : `${chosen.means} There are about ${Math.round(notice / 30)} months to take a lease before it is priced in.`,
      null,
      'map',
    );
  }
}

/** The day it actually happens, and the district is permanently different. */
function land(state: GameState): void {
  const due = state.announcements.filter((a) => state.day >= a.landsOnDay);
  if (due.length === 0) return;
  state.announcements = state.announcements.filter((a) => state.day < a.landsOnDay);

  for (const announcement of due) {
    const def = development(announcement.defId);
    if (!def) continue;
    const districtState = state.districts[announcement.districtId];
    if (!districtState) continue;

    // Written into the district's own indices, which is what makes it stick:
    // there is no modifier to expire, because the ground itself moved.
    districtState.demandIndex = clamp(districtState.demandIndex * def.demand, 0.4, 2.2);
    districtState.rentIndex = clamp(districtState.rentIndex * def.rent, 0.5, 2.4);
    districtState.propertyIndex = clamp(districtState.propertyIndex * def.property, 0.5, 2.6);

    const where = district(announcement.districtId);
    const mine = playerBusinesses(state).filter((b) => {
      const building = state.buildings.find((x) => x.id === b.buildingId);
      return building?.district === announcement.districtId && b.status === 'open';
    }).length;

    pushNews(
      state,
      'property',
      `${def.name.replace(/ is | are /, ' has ')} — ${where.name}`,
      `${def.means} This is permanent: ${where.name} is a different place to trade from today.`,
      { importance: mine > 0 ? 'high' : 'normal' },
    );
    if (mine > 0) {
      record(state, 'crisis', `${def.name} landed in ${where.name}, where you have ${mine} location${mine === 1 ? '' : 's'}`);
      pushAlert(
        state,
        def.tone === 'good' ? 'info' : 'warning',
        `${where.name} has changed`,
        `${def.means} You trade there, so this is now your problem or your good fortune.`,
        null,
        'map',
      );
    }
  }
}

// ------------------------------------------------------------- for the screen

export interface PendingChange {
  announcement: Announcement;
  def: DevelopmentDef;
  districtName: string;
  daysAway: number;
  /** How many of the player's locations sit in that district. */
  yours: number;
}

/** What the city has announced and not yet done, soonest first. */
export function pending(state: GameState): PendingChange[] {
  return state.announcements
    .map((announcement) => {
      const def = development(announcement.defId);
      if (!def) return null;
      const yours = playerBusinesses(state).filter((b) => {
        const building = state.buildings.find((x) => x.id === b.buildingId);
        return building?.district === announcement.districtId && b.status === 'open';
      }).length;
      return {
        announcement,
        def,
        districtName: district(announcement.districtId).name,
        daysAway: announcement.landsOnDay - state.day,
        yours,
      };
    })
    .filter((row): row is PendingChange => row !== null)
    .sort((a, b) => a.daysAway - b.daysAway);
}

/** Anything announced for this district, for the district panel. */
export function pendingIn(state: GameState, districtId: DistrictId): PendingChange[] {
  return pending(state).filter((row) => row.announcement.districtId === districtId);
}

/**
 * How far a district has moved from where it started.
 *
 * Read straight off the indices, so it is a description of the city as it
 * actually is rather than a log of what happened to it.
 */
export function drift(state: GameState, districtId: DistrictId): { demand: number; rent: number; property: number } {
  const it = state.districts[districtId] ?? { demandIndex: 1, rentIndex: 1, propertyIndex: 1 };
  return {
    demand: (it.demandIndex - 1) * 100,
    rent: (it.rentIndex - 1) * 100,
    property: (it.propertyIndex - 1) * 100,
  };
}
