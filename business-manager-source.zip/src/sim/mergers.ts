import type { Division, Employee, Merger, MergerStyleId } from './types';
import type { GameState } from './state';
import { employeesOf, playerBusinesses, playerCompany } from './state';
import { role } from '../data/roles';
import { divisionBusinesses, divisionById, divisionHead } from './holding';
import { staffingPlan, staffingSummary } from './staffing';
import { gradeOf, performanceOf } from './skills';
import { marketRate, removeEmployee } from './employees';
import { post } from './finance';
import { pushAlert } from './alerts';
import { pushNews } from './news';
import { learn, skillOf } from './founder';
import { DAYS_PER_MONTH, money } from './format';
import { approach, clamp, makeId, sum } from './util';
import { record } from './chronicle';

/**
 * Mergers.
 *
 * Buying a company and merging with it are two different things, and the game
 * has always only done the first. An acquisition hands you a division: their
 * locations, their people, their way of doing things, kept whole and kept apart.
 * That is deliberately the easy half — it costs money and nothing else.
 *
 * A merger is the hard half. It is the decision to stop running two companies
 * and run one, and it is where every real cost of growing by acquisition finally
 * lands: the integration itself has to be paid for while it happens, jobs exist
 * twice and somebody has to say which one goes, the two workforces discover they
 * are paid differently for the same work, and the whole thing sits on the desk
 * of whoever is running it.
 *
 * What you get for it is the only thing that makes buying companies better than
 * opening shops: scale. One back office instead of two, one set of systems, one
 * payroll — and it is permanent, which is why a merger that goes badly is still
 * usually worth having done.
 *
 * Nothing here is a second acquisition system. A merger can only be started on a
 * division that was somebody else's company, it is carried out with the game's
 * own severance, ledger and morale machinery, and everything it changes is read
 * by the systems that were already reading those numbers.
 */

// ------------------------------------------------------------------ the styles

export interface MergerStyleDef {
  id: MergerStyleId;
  name: string;
  /** The decision, in one line. */
  pitch: string;
  detail: string;
  /** Working days it takes before management makes it faster or slower. */
  days: number;
  /** The share of the duplicated jobs this style actually removes. */
  cutShare: number;
  /** How hard the change lands on the people going through it, in morale. */
  disruption: number;
  /** The share of the available overhead saving it locks in for good. */
  savingShare: number;
  /** What running the integration costs, per person per day. */
  costPerHeadPerDay: number;
  /** Awareness each location loses when the sign over the door changes. */
  rebrandCost: number;
}

export const MERGER_STYLES: MergerStyleDef[] = [
  {
    id: 'absorb',
    name: 'Absorb them',
    pitch: 'One company by the end of the month.',
    detail:
      'Your name over every door, your systems everywhere, and every job that exists twice goes. Fastest, cheapest to run afterwards, and the hardest on everybody who has to live through it — including the customers, who walked past a name they knew yesterday.',
    days: 30,
    cutShare: 1,
    disruption: 26,
    savingShare: 1,
    costPerHeadPerDay: 14,
    rebrandCost: 9,
  },
  {
    id: 'blend',
    name: 'Blend the two',
    pitch: 'Take the best of both, and take your time over it.',
    detail:
      'Keep what they were good at, move people rather than replace them, and let the two ways of working meet in the middle. It takes more than twice as long and costs more in total — you are paying consultants to do carefully what you could have done in a fortnight — but you keep most of the saving and most of the people.',
    days: 70,
    cutShare: 0.55,
    disruption: 11,
    savingShare: 0.75,
    costPerHeadPerDay: 9,
    rebrandCost: 4,
  },
  {
    id: 'federate',
    name: 'Leave them to it',
    pitch: 'Same owner, same everything else.',
    detail:
      'They keep their name, their staff and their way of running a shop; you join up the buying and file one set of accounts. Almost nobody notices, which is the point when you have bought something that is already working — but you are still paying for two of most things, so the saving is small.',
    days: 40,
    cutShare: 0,
    disruption: 3,
    savingShare: 0.22,
    costPerHeadPerDay: 4,
    rebrandCost: 0,
  },
];

export function mergerStyle(id: MergerStyleId): MergerStyleDef {
  return MERGER_STYLES.find((style) => style.id === id) ?? MERGER_STYLES[1];
}

/**
 * Central functions. One company needs one of each of these however many shops
 * it has, which is precisely why two companies joined together do not need two.
 */
const CENTRAL_ROLES = ['accountant', 'marketer', 'hr', 'it', 'legal'] as const;

/**
 * How much of a location's recommended staffing shared services take out.
 *
 * Not a fifth of the people — a fifth of the cover above the minimum the trade
 * actually needs. Nobody is ever a duplicate if the shop cannot open without
 * them, which is the line that stops a merger quietly wrecking the thing it
 * just bought.
 */
const SHARED_SERVICES = 0.2;

/** The most a lifetime of merging can take off the coordination bill. */
export const SCALE_FLOOR = 0.78;

// ------------------------------------------------------------- the culture gap

export interface CultureGap {
  /** 0..100. Nought is two companies that already worked the same way. */
  gap: number;
  /** Why, in the player's own figures. */
  reasons: string[];
}

/**
 * How far apart the two ways of working are.
 *
 * Culture is not a hidden die roll here. It is four things the player can
 * already look up — what each side is paid against the going rate, how each side
 * feels about being there, how well each side's shops are thought of, and how
 * senior each side's people are — and every one of them is a real reason two
 * companies grate against each other when they are put in one building.
 */
export function cultureGapOf(state: GameState, divisionId: string): CultureGap {
  const inside = divisionPeople(state, divisionId);
  const outside = state.employees.filter(
    (person) => person.companyId === state.playerCompanyId && !inside.some((p) => p.id === person.id),
  );
  if (inside.length === 0 || outside.length === 0) return { gap: 0, reasons: [] };

  const reasons: string[] = [];
  const payOf = (people: Employee[]): number =>
    sum(people, (person) => person.salary / Math.max(1, marketRate(state, person))) / people.length;
  const theirPay = payOf(inside);
  const ourPay = payOf(outside);
  const payGap = Math.abs(theirPay - ourPay);
  if (payGap > 0.04) {
    reasons.push(
      `They are paid ${Math.round((theirPay - 1) * 100)}% ${theirPay >= 1 ? 'over' : 'under'} the going rate and your side is on ${Math.round(
        (ourPay - 1) * 100,
      )}%. Everybody finds that out in the first week.`,
    );
  }

  const moraleOf = (people: Employee[]): number => sum(people, (p) => p.morale) / people.length;
  const moraleGap = Math.abs(moraleOf(inside) - moraleOf(outside));
  if (moraleGap > 8) {
    reasons.push(
      `Their teams are on ${Math.round(moraleOf(inside))} morale and yours are on ${Math.round(
        moraleOf(outside),
      )}. The happier side resents being told how to work by the other.`,
    );
  }

  const theirShops = divisionBusinesses(state, divisionId).filter((b) => b.status === 'open');
  const ourShops = playerBusinesses(state).filter((b) => b.status === 'open' && b.divisionId !== divisionId);
  let repGap = 0;
  if (theirShops.length > 0 && ourShops.length > 0) {
    const theirRep = sum(theirShops, (b) => b.reputation) / theirShops.length;
    const ourRep = sum(ourShops, (b) => b.reputation) / ourShops.length;
    repGap = Math.abs(theirRep - ourRep);
    if (repGap > 10) {
      reasons.push(
        `Their shops review ${Math.round(theirRep)} against your ${Math.round(
          ourRep,
        )}. Whichever side is behind is about to be told how it should be done.`,
      );
    }
  }

  const gradeOfSide = (people: Employee[]): number => sum(people, (p) => gradeOf(p).n) / people.length;
  const seniorityGap = Math.abs(gradeOfSide(inside) - gradeOfSide(outside));
  if (seniorityGap > 0.8) {
    reasons.push('The two sides are at very different stages of their careers, and titles will not line up.');
  }

  const gap = clamp(payGap * 180 + moraleGap * 0.8 + repGap * 0.5 + seniorityGap * 6, 0, 100);
  if (reasons.length === 0) reasons.push('Two companies that already worked much the same way. This should go quietly.');
  return { gap: Math.round(gap), reasons };
}

// -------------------------------------------------------------- the duplicates

/** Everybody working in a division's locations. */
export function divisionPeople(state: GameState, divisionId: string): Employee[] {
  return divisionBusinesses(state, divisionId).flatMap((business) => employeesOf(state, business.id));
}

/**
 * Whose job would exist twice.
 *
 * Two kinds of person. The first is somebody doing a central function in a shop
 * when the head office already does that function for the whole company — a
 * second book-keeper is a second book-keeper however good they are. The second
 * is the cover a location no longer needs once it is sharing systems with
 * everywhere else, weakest first, and never so far that the place drops below
 * what its trade actually requires.
 */
export function duplicatesIn(state: GameState, divisionId: string): Employee[] {
  const covered = centralFunctionsCovered(state);
  const found: Employee[] = [];

  for (const business of divisionBusinesses(state, divisionId)) {
    const staff = employeesOf(state, business.id);
    if (staff.length === 0) continue;

    // Ranked by how clearly the job exists twice: a central function the head
    // office already runs for the whole company first, then the weakest of
    // whoever is left.
    const ranked = [...staff].sort((a, b) => {
      const aCentral = covered.has(a.role) ? 0 : 1;
      const bCentral = covered.has(b.role) ? 0 : 1;
      if (aCentral !== bCentral) return aCentral - bCentral;
      return performanceOf(a) - performanceOf(b);
    });

    const rows = staffingPlan(state, business);
    const needed = new Map(rows.map((row) => [row.role as string, row.required]));
    const summary = staffingSummary(state, business);
    // What this place needs once it is part of something bigger. Never below
    // the trade's own minimum: a shop that cannot open saves nobody anything.
    const keepTotal = Math.max(summary.required, Math.round(summary.recommended * (1 - SHARED_SERVICES)));

    const left = new Map<string, number>();
    for (const person of staff) left.set(person.role, (left.get(person.role) ?? 0) + 1);

    let remaining = staff.length;
    for (const person of ranked) {
      if (remaining <= keepTotal) break;
      // A function the head office runs for everybody can go to nothing here.
      // Every other role keeps the number its trade actually requires, which
      // is the line that stops a merger quietly wrecking what it just bought.
      const floor = covered.has(person.role) ? 0 : (needed.get(person.role) ?? 0);
      const here = left.get(person.role) ?? 0;
      if (here <= floor) continue;
      found.push(person);
      left.set(person.role, here - 1);
      remaining -= 1;
    }
  }
  return found;
}

/** Central functions the company already covers from a head office. */
function centralFunctionsCovered(state: GameState): Set<string> {
  const covered = new Set<string>();
  const office = state.headOffice;
  if (!office) return covered;
  for (const id of office.employeeIds) {
    const person = state.employees.find((e) => e.id === id);
    if (person && (CENTRAL_ROLES as readonly string[]).includes(person.role)) covered.add(person.role);
  }
  for (const [fn, out] of Object.entries(office.outsourced)) {
    if (out && (CENTRAL_ROLES as readonly string[]).includes(fn)) covered.add(fn);
  }
  return covered;
}

/** Statutory redundancy terms: longer served, more owed. */
export function redundancyPay(state: GameState, person: Employee): number {
  const years = (state.day - person.hiredOnDay) / 360;
  return Math.round(person.salary * clamp(0.75 + years * 0.25, 0.75, 3.5));
}

// -------------------------------------------------------------------- the plan

export interface MergerPlan {
  division: Division;
  style: MergerStyleDef;
  locations: number;
  headcount: number;
  duplicates: Employee[];
  /** How many of them this style would actually let go. */
  cuts: number;
  /** What those redundancies cost, paid as they happen. */
  severance: number;
  /** What running the integration costs across its whole life. */
  integrationCost: number;
  /** Days it will take with the management the company has today. */
  days: number;
  culture: CultureGap;
  /** Wages that stop being paid, per month. */
  wageSaving: number;
  /** What the shared overhead is worth, per month. */
  overheadSaving: number;
  /** Months before the saving has paid for the whole thing, or null if never. */
  payback: number | null;
  /** Who is carrying it, and what that costs if it is you. */
  head: Employee | null;
  blocked: string | null;
}

/**
 * Everything the player needs before committing, with no figure invented.
 *
 * The payback month is the one that matters and the one every other business
 * game leaves out: a merger is a capital project, and a capital project that
 * never pays back is a decision, not an achievement.
 */
export function mergerPlan(state: GameState, divisionId: string, styleId: MergerStyleId): MergerPlan | null {
  const division = divisionById(state, divisionId);
  if (!division) return null;
  const style = mergerStyle(styleId);
  const businesses = divisionBusinesses(state, divisionId);
  const people = divisionPeople(state, divisionId);
  const duplicates = duplicatesIn(state, divisionId);
  const culture = cultureGapOf(state, divisionId);
  const head = divisionHead(state, division);

  const cuts = Math.round(duplicates.length * style.cutShare);
  const going = duplicates.slice(0, cuts);
  const severance = sum(going, (person) => redundancyPay(state, person));
  const days = plannedDays(state, division, style, culture.gap);
  const headcount = people.length;
  const integrationCost = Math.round(style.costPerHeadPerDay * Math.max(1, headcount) * days);

  const wageSaving = sum(going, (person) => person.salary);
  const overheadSaving = Math.round(overheadSavingPerMonth(state, businesses.length) * style.savingShare);
  const perMonth = wageSaving + overheadSaving;
  const total = severance + integrationCost;
  const payback = perMonth > 0 ? Math.ceil(total / perMonth) : null;

  return {
    division,
    style,
    locations: businesses.length,
    headcount,
    duplicates,
    cuts,
    severance,
    integrationCost,
    days,
    culture,
    wageSaving,
    overheadSaving,
    payback,
    head,
    blocked: blockedReason(state, division),
  };
}

/**
 * How long it will really take.
 *
 * The style sets the pace; two things move it. Somebody senior running the
 * division carries the integration, and an owner who knows how to manage one
 * gets it done sooner — so the answer to a merger dragging on is the same as
 * the answer to everything else at this scale, which is to delegate it.
 */
function plannedDays(state: GameState, division: Division, style: MergerStyleDef, gap: number): number {
  const head = divisionHead(state, division);
  const carried = head ? 0.78 + (1 - clamp(performanceOf(head) / 100, 0, 1)) * 0.22 : 1.3;
  const owner = 1 - ((skillOf(state, 'management') - 50) / 50) * 0.2;
  // Two companies that work differently take longer to become one.
  const friction = 1 + (gap / 100) * 0.45;
  return Math.max(10, Math.round(style.days * carried * owner * friction));
}

/** What one set of central functions instead of two is worth, per month. */
function overheadSavingPerMonth(state: GameState, locations: number): number {
  const office = state.headOffice;
  const central = office
    ? sum(
        office.employeeIds
          .map((id) => state.employees.find((e) => e.id === id))
          .filter((person): person is Employee => person !== undefined),
        (person) => person.salary,
      )
    : sum(
        (CENTRAL_ROLES as readonly string[]).map((id) => role(id as Employee['role']).baseSalary),
        (salary) => salary,
      ) * 0.35;
  // A bigger group shares a bigger overhead, and the share it can shed levels
  // off — the second shop saves a great deal, the twentieth barely notices.
  return central * clamp(locations * 0.05, 0.05, 0.3);
}

function blockedReason(state: GameState, division: Division): string | null {
  if (division.acquiredFrom === GROUPED_BY_HAND) {
    return 'You made this division yourself. There is no second company here to merge with — it is already one.';
  }
  if (division.mergedOnDay !== null) return `Already merged, on day ${division.mergedOnDay}.`;
  const open = activeMerger(state);
  if (open && open.divisionId !== division.id) {
    const other = divisionById(state, open.divisionId);
    return `${other?.name ?? 'Another integration'} is still going. One at a time — nobody integrates two companies at once and gets either of them right.`;
  }
  if (divisionBusinesses(state, division.id).length === 0) return 'Nothing left in it to merge.';
  return null;
}

/** The label createDivision uses for a group the player made themselves. */
export const GROUPED_BY_HAND = 'grouped by you';

// ------------------------------------------------------------------ the actions

export function activeMerger(state: GameState): Merger | null {
  return state.mergers.find((merger) => merger.completedOnDay === null) ?? null;
}

export function mergerFor(state: GameState, divisionId: string): Merger | null {
  return state.mergers.find((merger) => merger.divisionId === divisionId && merger.completedOnDay === null) ?? null;
}

/** Divisions that were once somebody else's company, and so can be merged with. */
export function mergerCandidates(state: GameState): Division[] {
  return state.divisions.filter(
    (division) => division.acquiredFrom !== GROUPED_BY_HAND && division.mergedOnDay === null,
  );
}

export function startMerger(
  state: GameState,
  divisionId: string,
  styleId: MergerStyleId,
): { ok: boolean; message: string } {
  const plan = mergerPlan(state, divisionId, styleId);
  if (!plan) return { ok: false, message: 'Unknown division.' };
  if (plan.blocked) return { ok: false, message: plan.blocked };

  const company = playerCompany(state);
  // Enough for the first month of it. The rest is paid as it happens, which is
  // how an integration actually bites — it is not a cheque, it is a year.
  const upfront = Math.round(plan.integrationCost / Math.max(1, plan.days / DAYS_PER_MONTH));
  if (company.cash < upfront) {
    return {
      ok: false,
      message: `An integration costs about ${money(upfront)} a month while it runs, and you have ${money(
        company.cash,
      )}. Borrow it or wait.`,
    };
  }

  const merger: Merger = {
    id: makeId('merge'),
    divisionId,
    fromCompany: plan.division.acquiredFrom,
    style: styleId,
    startedOnDay: state.day,
    days: plan.days,
    progress: 0,
    cultureGap: plan.culture.gap,
    duplicateIds: plan.duplicates.slice(0, plan.cuts).map((person) => person.id),
    headcountAtStart: plan.headcount,
    spent: 0,
    severanceSpent: 0,
    letGo: 0,
    completedOnDay: null,
    savingLockedIn: 0,
  };
  state.mergers.push(merger);

  // The sign over the door changes on day one, and the customers who knew the
  // old name have to find the new one.
  if (plan.style.rebrandCost > 0) {
    for (const business of divisionBusinesses(state, divisionId)) {
      business.awareness = clamp(business.awareness - plan.style.rebrandCost, 0, 100);
      business.reputation = clamp(business.reputation - plan.style.rebrandCost * 0.4, 0, 100);
      if (plan.style.id === 'absorb') {
        business.name = business.name.replace(plan.division.acquiredFrom, company.name).slice(0, 60);
      }
    }
  }

  pushNews(
    state,
    'company',
    `${plan.division.name} is being merged in`,
    `${plan.style.name}. ${plan.days} days, about ${money(plan.integrationCost)} to run it${
      plan.cuts > 0 ? `, and ${plan.cuts} job${plan.cuts === 1 ? '' : 's'} that now exist twice` : ''
    }.`,
    { importance: 'high' },
  );
  return {
    ok: true,
    message: `Integration started. ${plan.days} days, ${money(plan.integrationCost)} to run, ${
      plan.payback === null ? 'and no saving to pay it back' : `paid back in about ${plan.payback} months`
    }.`,
  };
}

/**
 * Stopping halfway.
 *
 * You keep the redundancies you have already made and the share of the saving
 * you have already earned, and you have paid for the rest of it for nothing.
 * That is what calling off an integration costs in life, and it is worth having
 * as an option — a merger that is destroying the thing you bought should be
 * stoppable.
 */
export function abandonMerger(state: GameState, mergerId: string): { ok: boolean; message: string } {
  const merger = state.mergers.find((m) => m.id === mergerId);
  if (!merger || merger.completedOnDay !== null) return { ok: false, message: 'Nothing to call off.' };
  const style = mergerStyle(merger.style);
  const division = divisionById(state, merger.divisionId);

  merger.completedOnDay = state.day;
  merger.savingLockedIn = availableSaving(state, merger) * style.savingShare * merger.progress;
  if (division) division.mergedOnDay = state.day;

  pushNews(
    state,
    'company',
    `The ${division?.name ?? 'integration'} merger has been called off`,
    `${Math.round(merger.progress * 100)}% of the way through, ${money(
      merger.spent + merger.severanceSpent,
    )} spent. What was done stays done; the rest will not happen.`,
    { importance: 'high' },
  );
  return {
    ok: true,
    message: `Called off at ${Math.round(merger.progress * 100)}%. ${money(
      merger.spent + merger.severanceSpent,
    )} spent, and you keep ${Math.round(merger.savingLockedIn * 100)}% of the saving.`,
  };
}

// --------------------------------------------------------------------- the day

/** What the completed part of an integration is worth off the coordination bill. */
function availableSaving(state: GameState, merger: Merger): number {
  const locations = Math.max(1, divisionBusinesses(state, merger.divisionId).length);
  return clamp(locations * 0.02, 0.02, 0.09);
}

export function mergersDaily(state: GameState): void {
  const company = playerCompany(state);
  for (const merger of state.mergers) {
    if (merger.completedOnDay !== null) continue;
    const style = mergerStyle(merger.style);
    const division = divisionById(state, merger.divisionId);
    // The division closed its last location while the integration was running.
    // There is nothing left to merge, and what was already done still counts.
    if (!division) {
      merger.completedOnDay = state.day;
      merger.savingLockedIn = 0.02 * style.savingShare * merger.progress;
      continue;
    }

    const people = divisionPeople(state, merger.divisionId);

    // What it costs to run today. Consultants, systems, two of everything for
    // as long as it takes — and it is an operating cost, because it is.
    const cost = Math.round(style.costPerHeadPerDay * Math.max(1, people.length));
    if (cost > 0) {
      post(state, company.id, 'management', `Integration — ${division.name}`, -cost, null);
      merger.spent += cost;
    }

    merger.progress = clamp(merger.progress + 1 / Math.max(1, merger.days), 0, 1);
    // The two ways of working converge as people work alongside each other.
    merger.cultureGap = approach(merger.cultureGap, 0, 0.015 + merger.progress * 0.03);

    // Redundancies, paced across the first four fifths of it, one at a time.
    // Doing them all on day one would be cheaper and is not how it happens.
    const due = Math.round(merger.duplicateIds.length * clamp(merger.progress / 0.8, 0, 1));
    while (merger.letGo < due) {
      if (!makeOneRedundant(state, merger, division.name)) break;
    }

    if (merger.progress >= 1) complete(state, merger, division);
  }
}

/** Lets one duplicate go, on redundancy terms, through the game's own ledger. */
function makeOneRedundant(state: GameState, merger: Merger, divisionName: string): boolean {
  const company = playerCompany(state);
  const id = merger.duplicateIds[merger.letGo];
  if (!id) return false;
  const person = state.employees.find((e) => e.id === id);
  // Somebody who resigned before the letter arrived still counts as dealt with.
  if (!person) {
    merger.letGo += 1;
    return true;
  }
  const pay = redundancyPay(state, person);
  if (company.cash < pay) return false;

  removeEmployee(state, person.id);
  post(state, company.id, 'severance', `Redundancy — ${person.name}`, -pay, person.businessId);
  merger.severanceSpent += pay;
  merger.letGo += 1;
  learn(state, 'letGo');

  // Everybody left in the division reads the letter as being about them.
  for (const colleague of divisionPeople(state, merger.divisionId)) {
    colleague.morale = clamp(colleague.morale - 3, 0, 100);
    colleague.loyalty = clamp(colleague.loyalty - 2, 0, 100);
  }
  pushNews(
    state,
    'staff',
    `${person.name} made redundant`,
    `${role(person.role).name}. The job existed twice after the ${divisionName} merger, and ${money(
      pay,
    )} went out with them.`,
    { businessId: person.businessId, importance: 'normal' },
  );
  return true;
}

function complete(state: GameState, merger: Merger, division: Division): void {
  const company = playerCompany(state);
  const style = mergerStyle(merger.style);
  merger.completedOnDay = state.day;
  merger.savingLockedIn = availableSaving(state, merger) * style.savingShare;
  division.mergedOnDay = state.day;

  // One brand instead of two: what they were known for is now known about you.
  const shops = divisionBusinesses(state, merger.divisionId);
  if (shops.length > 0) {
    const theirs = sum(shops, (b) => b.awareness) / shops.length;
    company.brandAwareness = clamp(company.brandAwareness + theirs * 0.25 * style.savingShare, 0, 100);
  }

  const remaining = divisionPeople(state, merger.divisionId).length;
  const resigned = Math.max(0, merger.headcountAtStart - merger.letGo - remaining);
  // Getting two companies to be one company is the largest single thing a
  // person running one ever learns how to do.
  learn(state, 'merged');
  record(state, 'merged', `Finished merging ${division.name} in`, { amount: -(merger.spent + merger.severanceSpent) });

  pushNews(
    state,
    'company',
    `${division.name} is part of the company now`,
    `${merger.days} days and ${money(merger.spent + merger.severanceSpent)}. ${
      merger.letGo > 0 ? `${merger.letGo} made redundant` : 'Nobody was made redundant'
    }${resigned > 0 ? `, ${resigned} left of their own accord` : ''}. Coordination across the group costs ${Math.round(
      merger.savingLockedIn * 100,
    )}% less from today, and that does not go away.`,
    { importance: 'high' },
  );
  pushAlert(
    state,
    'info',
    `${division.name} is merged`,
    `Two companies are one. The saving is permanent; the people who lived through it will take a while longer.`,
    null,
    'holding',
  );
}

// -------------------------------------------------------- what the rest reads

/**
 * What being in the middle of a merger does to morale, in points.
 *
 * Read by the same daily settlement that reads pay, workload and stress, so a
 * merger shows up in the morale figure the player has always been watching
 * rather than in a number of its own. The side being merged in feels it four
 * times as hard as the side doing the merging, which is the whole of why these
 * go wrong.
 */
export function mergerMoraleDrag(state: GameState, employee: Employee): number {
  let drag = 0;
  for (const merger of state.mergers) {
    if (merger.completedOnDay !== null) continue;
    const style = mergerStyle(merger.style);
    const inside = divisionBusinesses(state, merger.divisionId).some((b) => b.id === employee.businessId);
    const weight = inside ? 1 : 0.25;
    // Worst at the start, and easing as it becomes the way things are.
    const fade = 1 - merger.progress * 0.55;
    drag += (style.disruption * 0.55 + (merger.cultureGap / 100) * style.disruption * 0.9) * weight * fade;
  }
  return -clamp(drag, 0, 24);
}

/**
 * The attention an integration takes off the person at the top.
 *
 * Expressed in locations, because that is the currency the holding model
 * already uses: running a merger is like having another two shops on your desk,
 * unless you have put somebody senior over the division, in which case it is
 * mostly theirs. This is the §48 management problem, and it is not a new one —
 * it is the same attention every other part of the company competes for.
 */
export function mergerAttentionLoad(state: GameState): number {
  let load = 0;
  for (const merger of state.mergers) {
    if (merger.completedOnDay !== null) continue;
    const division = divisionById(state, merger.divisionId);
    const head = division ? divisionHead(state, division) : null;
    load += head ? 0.6 : 2.2;
  }
  return load;
}

/**
 * What every completed merger has taken off the coordination bill, for good.
 *
 * This is the economies of scale, and it is the only reason growing by
 * acquisition beats growing by opening shops. It compounds across mergers and
 * stops at a floor, because there is a limit to how much of running a company
 * can be shared away.
 */
export function mergerScaleFactor(state: GameState): number {
  let factor = 1;
  for (const merger of state.mergers) factor *= 1 - clamp(merger.savingLockedIn, 0, 0.2);
  return clamp(factor, SCALE_FLOOR, 1);
}

/** Finished mergers, newest first, for the record. */
export function mergerHistory(state: GameState): Merger[] {
  return state.mergers.filter((m) => m.completedOnDay !== null).sort((a, b) => (b.completedOnDay ?? 0) - (a.completedOnDay ?? 0));
}
