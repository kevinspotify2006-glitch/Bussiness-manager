import type { GameState } from './state';
import { buildingById, employeesOf, playerBusinesses, playerCompany } from './state';
import type { Business, Goal, GoalMetric } from './types';
import { businessTypeOrThrow } from '../data/businessTypes';
import { district } from '../data/districts';
import { attractiveness, backgroundOutlets, typeShare } from './demand';
import { netWorth } from './finance';
import { pushNews } from './news';
import { pushAlert } from './alerts';
import { post } from './finance';
import { money } from './format';
import { clamp, makeId, sum } from './util';
import { gameRng } from './rng';

/**
 * Goals.
 *
 * Not a checklist of achievements — these are generated from what the company
 * actually looks like today, they run out, and finishing one pays. A goal is
 * only ever offered if it is a step up from where the player already is, so
 * "reach 4.2 stars" appears when the shop is on 3.6, not when it is on 4.5.
 */

export const MAX_ACTIVE_GOALS = 3;

// ------------------------------------------------------------------ metrics

/** Reads whatever a goal is measuring, right now. */
export function readMetric(state: GameState, metric: GoalMetric, businessId: string | null): number {
  const business = businessId ? state.businesses.find((b) => b.id === businessId) : null;
  switch (metric) {
    case 'netWorth':
      return netWorth(state);
    case 'cash':
      return playerCompany(state).cash;
    case 'locations':
      return playerBusinesses(state).filter((b) => b.status === 'open').length;
    case 'weeklyProfit':
      return sum(state.dayHistory.slice(-7), (d) => d.profit);
    case 'reviewScore':
      return business?.reviewScore ?? 0;
    case 'dailyCustomers':
      return business?.yesterday.customers ?? 0;
    case 'awareness':
      return business?.awareness ?? 0;
    case 'reputation':
      return business?.reputation ?? 0;
    case 'marketShare':
      return business ? shareOf(state, business) * 100 : 0;
    case 'staffMorale': {
      const staff = business ? employeesOf(state, business.id) : state.employees;
      return staff.length === 0 ? 0 : sum(staff, (e) => e.morale) / staff.length;
    }
    default:
      return 0;
  }
}

/** The same share maths the market screen shows, so a goal cannot lie. */
function shareOf(state: GameState, business: Business): number {
  const building = buildingById(state, business.buildingId);
  if (!building) return 0;
  const type = businessTypeOrThrow(business.typeId);
  const share = typeShare(business.typeId);
  const peers = state.businesses.filter((other) => {
    if (other.status !== 'open' || other.typeId !== business.typeId) return false;
    return buildingById(state, other.buildingId)?.district === building.district;
  });
  const total =
    sum(peers, (peer) => attractiveness(state, peer).score) +
    backgroundOutlets(building.district, type.category, 0) * share;
  return total > 0 ? attractiveness(state, business).score / total : 0;
}

/** 0..1 — how far along a goal is, measured from where it started. */
export function goalProgress(state: GameState, goal: Goal): number {
  const now = readMetric(state, goal.metric, goal.businessId);
  const span = goal.target - goal.startValue;
  if (span <= 0) return now >= goal.target ? 1 : 0;
  return clamp((now - goal.startValue) / span, 0, 1);
}

// -------------------------------------------------------------------- defs

interface GoalDef {
  id: string;
  /** Builds the goal, or returns null when it does not suit the company yet. */
  create(state: GameState): Goal | null;
}

function goal(
  defId: string,
  state: GameState,
  fields: {
    title: string;
    detail: string;
    metric: GoalMetric;
    target: number;
    businessId?: string | null;
    days: number;
    rewardCash: number;
    rewardText: string;
  },
): Goal {
  const businessId = fields.businessId ?? null;
  return {
    id: makeId('goal'),
    defId,
    title: fields.title,
    detail: fields.detail,
    metric: fields.metric,
    businessId,
    target: fields.target,
    startValue: readMetric(state, fields.metric, businessId),
    day: state.day,
    expiresOnDay: state.day + fields.days,
    rewardCash: fields.rewardCash,
    rewardText: fields.rewardText,
  };
}

/** An open business the player runs, picked at random. */
function anyOpen(state: GameState): Business | null {
  const open = playerBusinesses(state).filter((b) => b.status === 'open');
  return open.length === 0 ? null : gameRng.pick(open);
}

const DEFS: GoalDef[] = [
  {
    // Get a shop's reviews up. The most common thing a real operator works on.
    id: 'reviews',
    create(state) {
      const business = anyOpen(state);
      if (!business || business.reviewCount < 8 || business.reviewScore > 4.3) return null;
      const target = Math.min(4.6, Math.round((business.reviewScore + 0.5) * 10) / 10);
      return goal('reviews', state, {
        title: `Get ${business.name} to ${target.toFixed(1)}★`,
        detail: `It sits at ${business.reviewScore.toFixed(1)}★ today. Price, service, stock and the state of the premises are what customers are scoring.`,
        metric: 'reviewScore',
        target,
        businessId: business.id,
        days: 24,
        rewardCash: 3500,
        rewardText: 'A local business award comes with €3,500 and a write-up in the paper.',
      });
    },
  },
  {
    // Trade your way to a busier shop.
    id: 'customers',
    create(state) {
      const business = anyOpen(state);
      if (!business || business.yesterday.customers < 5) return null;
      const target = Math.round(business.yesterday.customers * 1.6);
      return goal('customers', state, {
        title: `Serve ${target} customers a day at ${business.name}`,
        detail: `Yesterday it served ${Math.round(business.yesterday.customers)}. Awareness, price and the state of the shelves all move this number.`,
        metric: 'dailyCustomers',
        target,
        businessId: business.id,
        days: 21,
        rewardCash: 4000,
        rewardText: 'The district trade association pays €4,000 towards your next fit-out.',
      });
    },
  },
  {
    // Take share off the competition in one district.
    id: 'share',
    create(state) {
      const business = anyOpen(state);
      if (!business) return null;
      const current = shareOf(state, business) * 100;
      if (current < 2 || current > 34) return null;
      const target = Math.round(current * 1.5);
      const building = buildingById(state, business.buildingId);
      return goal('share', state, {
        title: `Take ${target}% of the ${building ? district(building.district).name : 'local'} market`,
        detail: `${business.name} holds ${current.toFixed(1)}% of the customers for what it sells here. Every point comes off somebody else.`,
        metric: 'marketShare',
        target,
        businessId: business.id,
        days: 30,
        rewardCash: 6000,
        rewardText: 'A supplier signs you as their flagship stockist: €6,000 up front.',
      });
    },
  },
  {
    // A week in profit, which is a different thing from a good day.
    id: 'weekly-profit',
    create(state) {
      const open = playerBusinesses(state).filter((b) => b.status === 'open');
      if (open.length === 0) return null;
      const recent = sum(state.dayHistory.slice(-7), (d) => d.profit);
      const target = Math.max(1200, Math.round((recent > 0 ? recent * 1.5 : 1500) / 100) * 100);
      return goal('weekly-profit', state, {
        title: `Clear ${money(target)} of profit in a week`,
        detail:
          recent > 0
            ? `The last seven days made ${money(recent)}. Costs are as much of the answer as revenue.`
            : `The last seven days lost ${money(Math.abs(recent))}. Getting to ${money(target)} means fixing something structural.`,
        metric: 'weeklyProfit',
        target,
        days: 18,
        rewardCash: 2500,
        rewardText: 'Your bank cuts your arrangement fees and refunds €2,500.',
      });
    },
  },
  {
    // Expansion.
    id: 'expand',
    create(state) {
      const open = playerBusinesses(state).filter((b) => b.status === 'open').length;
      if (open === 0 || open > 6) return null;
      return goal('expand', state, {
        title: `Run ${open + 1} businesses at once`,
        detail: `You have ${open} trading. A second site spreads the risk and shares the overhead — if the first one can carry the setup cost.`,
        metric: 'locations',
        target: open + 1,
        days: 40,
        rewardCash: 8000,
        rewardText: 'The city development fund pays €8,000 towards opening in a new district.',
      });
    },
  },
  {
    // Somewhere for a struggling player to aim that is not growth.
    id: 'reserve',
    create(state) {
      const cash = playerCompany(state).cash;
      if (cash < 2000 || cash > 120_000) return null;
      const target = Math.round((cash * 1.4) / 1000) * 1000;
      return goal('reserve', state, {
        title: `Build a cash reserve of ${money(target)}`,
        detail: `You are holding ${money(cash)}. A business with no reserve cannot survive a bad month, however good the trading looks.`,
        metric: 'cash',
        target,
        days: 30,
        rewardCash: 0,
        rewardText: 'Your credit rating improves, which makes borrowing cheaper.',
      });
    },
  },
  {
    // People.
    id: 'morale',
    create(state) {
      const business = anyOpen(state);
      if (!business) return null;
      const staff = employeesOf(state, business.id);
      if (staff.length < 2) return null;
      const morale = sum(staff, (e) => e.morale) / staff.length;
      if (morale > 68) return null;
      return goal('morale', state, {
        title: `Get the team at ${business.name} to 70 morale`,
        detail: `The average is ${Math.round(morale)}/100. Pay, workload and recognition are the three levers, and unhappy staff serve worse.`,
        metric: 'staffMorale',
        target: 70,
        businessId: business.id,
        days: 21,
        rewardCash: 1500,
        rewardText: 'Lower turnover saves you €1,500 in recruitment you no longer need.',
      });
    },
  },
];

const defById = new Map(DEFS.map((def) => [def.id, def]));

// ------------------------------------------------------------------- daily

/**
 * Completes, expires and offers goals. Called once a day, after the books are
 * settled, so a goal that was met today is paid today.
 */
export function goalsDaily(state: GameState): void {
  for (const active of [...state.goals]) {
    // The business it was about may have been shut down.
    if (active.businessId && !state.businesses.some((b) => b.id === active.businessId)) {
      state.goals = state.goals.filter((g) => g.id !== active.id);
      continue;
    }

    if (readMetric(state, active.metric, active.businessId) >= active.target) {
      state.goals = state.goals.filter((g) => g.id !== active.id);
      state.goalsCompleted += 1;
      if (active.rewardCash > 0) {
        post(state, state.playerCompanyId, 'other', `Goal reward — ${active.title}`, active.rewardCash, active.businessId);
      }
      if (active.defId === 'reserve') {
        const company = playerCompany(state);
        company.creditRating = clamp(company.creditRating + 6, 0, 100);
      }
      pushNews(state, 'company', `Goal met: ${active.title}`, active.rewardText, {
        businessId: active.businessId,
        importance: 'high',
      });
      pushAlert(state, 'success', `Goal met: ${active.title}`, active.rewardText, active.businessId, 'progress');
      continue;
    }

    if (state.day >= active.expiresOnDay) {
      state.goals = state.goals.filter((g) => g.id !== active.id);
      pushNews(state, 'company', `Goal missed: ${active.title}`, 'The deadline passed. Another one will come along.', {
        businessId: active.businessId,
      });
    }
  }

  // Offer a new goal when there is room, but never two on the same day.
  if (state.goals.length >= MAX_ACTIVE_GOALS) return;
  if (playerBusinesses(state).length === 0) return;
  if (!gameRng.chance(0.45)) return;

  const taken = new Set(state.goals.map((g) => g.defId));
  const candidates = DEFS.filter((def) => !taken.has(def.id));
  if (candidates.length === 0) return;

  const chosen = defById.get(gameRng.pick(candidates).id);
  const created = chosen?.create(state) ?? null;
  if (!created) return;
  state.goals.push(created);
  pushNews(state, 'company', `New goal: ${created.title}`, created.detail, {
    businessId: created.businessId,
  });
}
