import type { GameState } from './state';
import type { DistrictState } from './state';
import { DEFAULT_ECONOMY, DEFAULT_SETTINGS, SAVE_VERSION, defaultDistrictState, emptyPeriod } from './state';
import type { DistrictId, Employee } from './types';
import { DISTRICTS } from '../data/districts';
import { netWorth } from './finance';
import { reprojectBuildings } from './city';
import { emptyMix } from './segments';
import { reseedGameRng } from './rng';
import { emptyResearch } from './research';
import { GRADES, SKILL_IDS, emptySkills, overallSkill, profileFor } from './skills';
import { STANCES, emptyAutomation, emptyOutsourcing } from './headOffice';
import { emptyFounder } from './founder';
import { STANDING_FACETS, emptyStanding } from './standing';
import { emptyRecords } from './chronicle';
import { emptyOfficers } from './executives';
import { MAX_OUTSIDE_STAKE } from './board';
import { POLICIES, emptyPolicies } from './policies';
import { FOUNDER_SKILL_IDS } from '../data/founders';
import { bool, isRecord, num, str } from './util';

/** Stance ids as strings, for validating what a save file claims. */
const STANCE_IDS: string[] = STANCES.map((stance) => stance.id);

const INDEX_KEY = 'business-manager:saves';
const SLOT_PREFIX = 'business-manager:save:';
export const AUTOSAVE_ID = 'autosave';

export interface SaveSlot {
  id: string;
  name: string;
  day: number;
  savedAt: number;
  netWorth: number;
  company: string;
  auto: boolean;
}

/** localStorage can be unavailable (private mode, blocked cookies); never throw. */
function storage(): Storage | null {
  try {
    const probe = '__bm_probe__';
    window.localStorage.setItem(probe, '1');
    window.localStorage.removeItem(probe);
    return window.localStorage;
  } catch {
    return null;
  }
}

export function listSaves(): SaveSlot[] {
  const store = storage();
  if (!store) return [];
  try {
    const raw = store.getItem(INDEX_KEY);
    if (!raw) return [];
    const parsed: unknown = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    return parsed
      .filter(isRecord)
      .map((entry) => ({
        id: str(entry.id, ''),
        name: str(entry.name, 'Save'),
        day: num(entry.day, 1),
        savedAt: num(entry.savedAt, 0),
        netWorth: num(entry.netWorth, 0),
        company: str(entry.company, ''),
        auto: bool(entry.auto, false),
      }))
      .filter((slot) => slot.id !== '')
      .sort((a, b) => b.savedAt - a.savedAt);
  } catch {
    return [];
  }
}

function writeIndex(slots: SaveSlot[]): void {
  const store = storage();
  if (!store) return;
  try {
    store.setItem(INDEX_KEY, JSON.stringify(slots));
  } catch {
    /* quota exceeded — the caller reports the failed save */
  }
}

export function saveGame(state: GameState, id: string, name: string, auto = false): { ok: boolean; message: string } {
  const store = storage();
  if (!store) return { ok: false, message: 'This browser is blocking local storage, so saving is unavailable.' };
  try {
    store.setItem(SLOT_PREFIX + id, JSON.stringify(state));
  } catch {
    return { ok: false, message: 'Saving failed: browser storage is full.' };
  }
  const company = state.companies.find((c) => c.id === state.playerCompanyId);
  const slots = listSaves().filter((slot) => slot.id !== id);
  slots.push({
    id,
    name,
    day: state.day,
    savedAt: Date.now(),
    netWorth: netWorth(state),
    company: company?.name ?? '',
    auto,
  });
  writeIndex(slots);
  return { ok: true, message: auto ? 'Autosaved.' : `Saved as “${name}”.` };
}

export function loadGame(id: string): GameState | null {
  const store = storage();
  if (!store) return null;
  try {
    const raw = store.getItem(SLOT_PREFIX + id);
    if (!raw) return null;
    const parsed: unknown = JSON.parse(raw);
    const state = migrate(parsed);
    if (state) reseedGameRng(state.seed || Date.now() >>> 0);
    return state;
  } catch {
    return null;
  }
}

export function deleteSave(id: string): void {
  const store = storage();
  if (!store) return;
  try {
    store.removeItem(SLOT_PREFIX + id);
  } catch {
    /* ignore */
  }
  writeIndex(listSaves().filter((slot) => slot.id !== id));
}

export function renameSave(id: string, name: string): void {
  const slots = listSaves().map((slot) => (slot.id === id ? { ...slot, name: name.trim().slice(0, 40) || slot.name } : slot));
  writeIndex(slots);
}

/**
 * Turns unknown JSON into a usable GameState, or null if it is too broken to
 * repair. Missing fields are filled with defaults so an older save still loads
 * after new systems are added.
 */
/**
 * Older saves predate the people-2.0 fields and the skill profile. Fill them in
 * rather than letting `undefined` leak into the simulation, where it would turn
 * into NaN — and fill the profile in around the job they already hold, so
 * nobody loads a save to find their best technician is suddenly mediocre.
 */
/**
 * Where a rung from an older save sits on the ladder now.
 *
 * Version 3 inserted Specialist above Senior and Director above Senior Manager,
 * so everything from the old Team Lead upwards shifted. Mapped by name rather
 * than by arithmetic, because that is what the numbers actually meant.
 */
const GRADE_V2_TO_V3: Record<number, number> = {
  0: 0, // Junior
  1: 1, // Employee
  2: 2, // Senior
  3: 4, // Team Lead
  4: 5, // Manager
  5: 6, // Senior Manager
  6: 8, // Executive
};

function people(input: unknown, version: number): Employee[] {
  if (!Array.isArray(input)) return [];
  return input.filter(isRecord).map((entry) => {
    const employee = {
      ...(entry as unknown as Employee),
      sickUntilDay: typeof entry.sickUntilDay === 'number' ? entry.sickUntilDay : null,
      promotions: num(entry.promotions, 0),
      lastRecognisedOnDay: num(entry.lastRecognisedOnDay, num(entry.hiredOnDay, 0)),
      trainingCourseId: typeof entry.trainingCourseId === 'string' ? entry.trainingCourseId : null,
      workload: num(entry.workload, 45),
      // A save from before people knew each other opens with nobody knowing
      // anybody, which is the honest reading: those relationships were never
      // formed, and they will form now from working alongside each other.
      bonds: Array.isArray(entry.bonds)
        ? (entry.bonds as Employee['bonds']).filter(
            (bond) => isRecord(bond) && typeof bond.withId === 'string' && Number.isFinite(bond.strength),
          )
        : [],
    };
    // The spread comes from their own id, so the same save always reloads the
    // same person rather than re-rolling them every time it is opened.
    let seed = 0;
    for (const character of employee.id) seed = (seed * 31 + character.charCodeAt(0)) >>> 0;
    const roll = (min: number, max: number): number => {
      seed = (seed * 1664525 + 1013904223) >>> 0;
      return min + (seed / 4294967296) * (max - min);
    };

    if (!isRecord(entry.skills)) {
      employee.skills = profileFor(num(entry.skill, 50), employee.role, roll);
      employee.skill = overallSkill(employee.skills);
    } else {
      // A save from before finance and communication were separate skills has
      // six numbers where there are now eight. The two new ones are built from
      // the profile that role would have produced, so an accountant who was
      // good at their job before is still good at it after — rather than
      // waking up on zero in the skill their whole job now runs on.
      const saved = entry.skills as Record<string, unknown>;
      const inferred = profileFor(num(entry.skill, 50), employee.role, roll);
      const skills = emptySkills();
      for (const id of SKILL_IDS) {
        skills[id] = typeof saved[id] === 'number' ? num(saved[id], 50) : inferred[id];
      }
      employee.skills = skills;
      employee.skill = overallSkill(skills);
    }

    // Saves from before the career ladder stored a promotion count and nothing
    // else. Two promotions in the old game meant Senior, and a manager was a
    // manager; both map onto the ladder without anybody losing standing.
    if (typeof entry.grade !== 'number') {
      // No ladder at all in version 1: a manager was a manager, and everybody
      // else is placed by how far up the trade they had got.
      // Version 1 named only two things: manager, and how many promotions
      // somebody had. Two promotions meant Senior, so that is where they land —
      // Specialist is a rung nobody in a version 1 save was ever told they had.
      employee.grade =
        employee.role === 'manager' ? 5 : Math.min(2, num(entry.promotions, 0) + (employee.skill >= 55 ? 1 : 0));
    } else if (version < 3) {
      // Version 2 had seven rungs; nobody should be demoted by an update.
      employee.grade = GRADE_V2_TO_V3[Math.max(0, Math.min(6, num(entry.grade, 0)))] ?? 0;
    } else {
      employee.grade = Math.max(0, Math.min(GRADES.length - 1, num(entry.grade, 0)));
    }
    return employee;
  });
}

export function migrate(input: unknown): GameState | null {
  if (!isRecord(input)) return null;
  const version = num(input.version, 0);
  if (version > SAVE_VERSION) return null; // saved by a newer build

  // Everything the game cannot rebuild must be present.
  if (!Array.isArray(input.buildings) || !Array.isArray(input.companies)) return null;
  if (typeof input.playerCompanyId !== 'string') return null;

  const districts = {} as Record<DistrictId, DistrictState>;
  const savedDistricts = isRecord(input.districts) ? input.districts : {};
  for (const def of DISTRICTS) {
    const entry = savedDistricts[def.id];
    districts[def.id] = isRecord(entry)
      ? {
          demandIndex: num(entry.demandIndex, 1),
          rentIndex: num(entry.rentIndex, 1),
          propertyIndex: num(entry.propertyIndex, 1),
        }
      : defaultDistrictState();
  }

  const economy = isRecord(input.economy) ? input.economy : {};
  const settings = isRecord(input.settings) ? input.settings : {};
  const stats = isRecord(input.stats) ? input.stats : {};

  const state = {
    version: SAVE_VERSION,
    seed: num(input.seed, Date.now() >>> 0),
    day: Math.max(1, num(input.day, 1)),
    hour: Math.min(23, Math.max(0, num(input.hour, 8))),
    speed: Math.min(4, Math.max(0, num(input.speed, 0))),
    playerCompanyId: input.playerCompanyId,
    companies: input.companies,
    businesses: Array.isArray(input.businesses)
      ? (input.businesses as GameState['businesses']).map((business) => ({
          ...business,
          // Older saves predate customer segments.
          todayMix: isRecord(business.todayMix) ? business.todayMix : emptyMix(),
          yesterdayMix: isRecord(business.yesterdayMix) ? business.yesterdayMix : emptyMix(),
          // And divisions, which every location starts outside of — reporting
          // directly to the owner, which is what was happening anyway.
          divisionId: typeof business.divisionId === 'string' ? business.divisionId : null,
        }))
      : [],
    buildings: Array.isArray(input.buildings) ? (input.buildings as GameState['buildings']) : [],
    employees: people(input.employees, version),
    applicants: people(input.applicants, version),
    orders: Array.isArray(input.orders) ? input.orders : [],
    campaigns: Array.isArray(input.campaigns) ? input.campaigns : [],
    // A loan saved before borrowing had kinds opens as an ordinary business
    // loan, with nothing yet paid early and its interest history starting now.
    loans: Array.isArray(input.loans)
      ? (input.loans as GameState['loans']).map((loan) => ({
          ...loan,
          typeId: typeof loan.typeId === 'string' ? loan.typeId : 'business',
          interestPaid: num(loan.interestPaid, 0),
          earlyRepaid: num(loan.earlyRepaid, 0),
        }))
      : [],
    ledger: Array.isArray(input.ledger) ? input.ledger : [],
    dayHistory: Array.isArray(input.dayHistory) ? input.dayHistory : [],
    alerts: Array.isArray(input.alerts) ? input.alerts : [],
    events: Array.isArray(input.events) ? input.events : [],
    news: Array.isArray(input.news) ? input.news : [],
    decisions: Array.isArray(input.decisions) ? input.decisions : [],
    decisionHistory: isRecord(input.decisionHistory) ? (input.decisionHistory as Record<string, number>) : {},
    reviews: Array.isArray(input.reviews) ? input.reviews : [],
    warehouses: Array.isArray(input.warehouses) ? input.warehouses : [],
    research: isRecord(input.research) && Array.isArray(input.research.done)
      ? { done: input.research.done as string[], active: (input.research.active as GameState['research']['active']) ?? null }
      : emptyResearch(),
    // A head office saved before it had floors, a stance and systems opens as
    // what it was: a back office, run the middle way, with nothing automated.
    headOffice: isRecord(input.headOffice)
      ? {
          ...(input.headOffice as unknown as GameState['headOffice'] & object),
          outsourced: isRecord(input.headOffice.outsourced)
            ? { ...emptyOutsourcing(), ...(input.headOffice.outsourced as Record<string, boolean>) }
            : emptyOutsourcing(),
          level: Math.max(1, Math.min(5, num(input.headOffice.level, 1))),
          stance: STANCE_IDS.includes(str(input.headOffice.stance, '')) ? input.headOffice.stance : 'hybrid',
          automation: isRecord(input.headOffice.automation)
            ? { ...emptyAutomation(), ...(input.headOffice.automation as Record<string, number>) }
            : emptyAutomation(),
          // A head office from before the rooms existed has none of them, which
          // is the correct reading: nobody ever built one.
          facilities: Array.isArray(input.headOffice.facilities)
            ? (input.headOffice.facilities as string[]).filter((id) => typeof id === 'string')
            : [],
        }
      : null,
    // A save from before the player was a person gets one, with no particular
    // background — which is exactly how every game before this played.
    founder: isRecord(input.founder)
      ? (() => {
          const saved = input.founder as Record<string, unknown>;
          const base = emptyFounder(
            str(saved.name, 'You'),
            str(saved.traitId, 'allrounder'),
            str(saved.scenarioId, 'entrepreneur'),
          );
          const skills = isRecord(saved.skills) ? (saved.skills as Record<string, unknown>) : {};
          const progress = isRecord(saved.progress) ? (saved.progress as Record<string, unknown>) : {};
          for (const id of FOUNDER_SKILL_IDS) {
            base.skills[id] = Math.max(0, Math.min(100, num(skills[id], base.skills[id])));
            base.progress[id] = Math.max(0, Math.min(1, num(progress[id], 0)));
          }
          return base;
        })()
      : emptyFounder('You', 'allrounder', 'entrepreneur'),
    divisions: Array.isArray(input.divisions)
      ? (input.divisions as GameState['divisions']).map((division) => ({
          ...division,
          headEmployeeId: typeof division.headEmployeeId === 'string' ? division.headEmployeeId : null,
          // A save made before mergers existed has divisions that were bought
          // and never integrated, which is exactly what a null means.
          mergedOnDay: typeof division.mergedOnDay === 'number' ? division.mergedOnDay : null,
        }))
      : [],
    mergers: Array.isArray(input.mergers) ? (input.mergers as GameState['mergers']) : [],
    // A save from before working capital has no sales or purchase ledger, and
    // that is the correct reading of it: everything that company ever earned
    // was settled on the day. It opens with both empty and nothing owed.
    invoices: Array.isArray(input.invoices) ? (input.invoices as GameState['invoices']) : [],
    bills: Array.isArray(input.bills) ? (input.bills as GameState['bills']) : [],
    // A save from before standing existed gets a middling one rather than a
    // flattering one: the company has not earned a name either way yet.
    standing: (() => {
      const saved = isRecord(input.standing) ? (input.standing as Record<string, unknown>) : {};
      const base = emptyStanding();
      for (const facet of STANDING_FACETS) base[facet.id] = Math.max(0, Math.min(100, num(saved[facet.id], base[facet.id])));
      return base;
    })(),
    // A save from before the company kept a history opens with an empty one
    // rather than an invented one. What it did before this existed is not
    // recoverable, and making something up would be worse than saying nothing.
    projects: Array.isArray(input.projects) ? (input.projects as GameState['projects']) : [],
    // A save from before the city could change has nothing announced. That is
    // the correct reading: whatever it has already done is written into the
    // district indices the save does carry, and there is no pending work to
    // invent. The city simply starts announcing things from today.
    announcements: Array.isArray(input.announcements) ? (input.announcements as GameState['announcements']) : [],
    // The posts are filled field by field: a save that names somebody who is
    // no longer employed leaves the post empty, which is what the post being
    // empty means everywhere else.
    officers: (() => {
      const saved = isRecord(input.officers) ? (input.officers as Record<string, unknown>) : {};
      const base = emptyOfficers();
      for (const key of Object.keys(base) as (keyof typeof base)[]) {
        base[key] = typeof saved[key] === 'string' ? (saved[key] as string) : null;
      }
      return base;
    })(),
    outsideStake: Math.max(0, Math.min(MAX_OUTSIDE_STAKE, num(input.outsideStake, 0))),
    // A save from before the company had rules opens on the rules a company
    // has before anybody sets any, which is what it was in fact running on.
    policies: (() => {
      const saved = isRecord(input.policies) ? (input.policies as Record<string, unknown>) : {};
      const base = emptyPolicies();
      for (const def of POLICIES) {
        const value = saved[def.id];
        if (typeof value === 'string' && def.options.some((option) => option.id === value)) base[def.id] = value;
      }
      return base;
    })(),
    chronicle: Array.isArray(input.chronicle) ? (input.chronicle as GameState['chronicle']).slice(-400) : [],
    records: (() => {
      // Filled field by field rather than trusted wholesale: a record with a
      // missing high-water mark would read as a company that never traded.
      const saved = isRecord(input.records) ? (input.records as Record<string, unknown>) : {};
      const base = emptyRecords();
      for (const key of Object.keys(base) as (keyof typeof base)[]) {
        const entry = isRecord(saved[key]) ? (saved[key] as Record<string, unknown>) : {};
        base[key] = { value: num(entry.value, 0), day: num(entry.day, 0) };
      }
      return base;
    })(),
    taxReserve: Math.max(0, num(input.taxReserve, 0)),
    liquidityBand:
      input.liquidityBand === 'warning' || input.liquidityBand === 'critical' ? input.liquidityBand : 'clear',
    contracts: Array.isArray(input.contracts) ? input.contracts : [],
    contractOffers: Array.isArray(input.contractOffers) ? input.contractOffers : [],
    accounts: Array.isArray(input.accounts) ? input.accounts : [],
    period: isRecord(input.period) ? (input.period as unknown as GameState['period']) : emptyPeriod(num(input.day, 1)),
    approaches: isRecord(input.approaches) ? (input.approaches as Record<string, number>) : {},
    goals: Array.isArray(input.goals) ? input.goals : [],
    goalsCompleted: num(input.goalsCompleted, 0),
    levelReached: num(input.levelReached, 1),
    economy: {
      confidence: num(economy.confidence, DEFAULT_ECONOMY.confidence),
      inflation: num(economy.inflation, DEFAULT_ECONOMY.inflation),
      interestRate: num(economy.interestRate, DEFAULT_ECONOMY.interestRate),
      unemployment: num(economy.unemployment, DEFAULT_ECONOMY.unemployment),
      growth: num(economy.growth, DEFAULT_ECONOMY.growth),
      lastLabel: str(economy.lastLabel, DEFAULT_ECONOMY.lastLabel),
    },
    districts,
    supplierSpend: isRecord(input.supplierSpend) ? (input.supplierSpend as Record<string, number>) : {},
    achievements: Array.isArray(input.achievements) ? input.achievements : [],
    tutorialStep: num(input.tutorialStep, 0),
    settings: {
      autosave: bool(settings.autosave, DEFAULT_SETTINGS.autosave),
      showTutorial: bool(settings.showTutorial, DEFAULT_SETTINGS.showTutorial),
      compactNumbers: bool(settings.compactNumbers, DEFAULT_SETTINGS.compactNumbers),
      confirmLargeSpend: bool(settings.confirmLargeSpend, DEFAULT_SETTINGS.confirmLargeSpend),
    },
    stats: {
      revenueTotal: num(stats.revenueTotal, 0),
      costsTotal: num(stats.costsTotal, 0),
      customersTotal: num(stats.customersTotal, 0),
      unitsTotal: num(stats.unitsTotal, 0),
      peakNetWorth: num(stats.peakNetWorth, 0),
      bankrupt: bool(stats.bankrupt, false),
    },
  } as unknown as GameState;

  // The player's company must exist, or nothing else makes sense.
  if (!state.companies.some((company) => company.id === state.playerCompanyId)) return null;

  // The city is generated, not stored. A save made against an older street
  // layout keeps every bit of its own state and is simply moved onto the
  // current streets.
  reprojectBuildings(state.buildings);
  return state;
}
