import type { GameState } from './state';
import { playerCompany } from './state';
import { post } from './finance';
import { pushNews } from './news';
import { pushAlert } from './alerts';
import { money } from './format';
import { levelOf, researchBranches } from './progress';
import { learn, researchSpeed } from './founder';
import { record } from './chronicle';
import { labFactor } from './facilities';

/**
 * Research.
 *
 * Five branches, three steps each, and every one of them changes a number the
 * simulation already uses — how many customers an hour the floor can serve,
 * what a wage costs, what a supplier charges, how far a van goes, how much a
 * warehouse holds, how long a campaign is remembered, what the lights cost.
 * Nothing here is a badge: if a project is finished and nothing moves, it
 * should not be in the tree.
 *
 * Projects take real days and real money, one at a time, so choosing what to
 * work on is a decision rather than a shopping list.
 */

export type ResearchEffect =
  | 'throughput'
  | 'wages'
  | 'purchasing'
  | 'logistics'
  | 'trips'
  | 'capacity'
  | 'awareness'
  | 'utilities';

export interface ResearchBranch {
  id: string;
  name: string;
  detail: string;
}

export const BRANCHES: ResearchBranch[] = [
  { id: 'operations', name: 'Operations', detail: 'How much work the same people get through.' },
  { id: 'logistics', name: 'Logistics', detail: 'Moving goods for less, and holding more of them.' },
  { id: 'marketing', name: 'Marketing', detail: 'Being remembered for longer by more people.' },
  { id: 'technology', name: 'Technology', detail: 'Machines doing what people were doing.' },
  { id: 'sustainability', name: 'Sustainability', detail: 'Costs that never come back once they are gone.' },
];

export interface ResearchNode {
  id: string;
  branch: string;
  name: string;
  detail: string;
  cost: number;
  days: number;
  /** The project that must be finished first, if any. */
  after: string | null;
  effect: ResearchEffect;
  /** Fractional change, e.g. 0.08 is eight per cent better. */
  amount: number;
  /** What the player is told it does, in the same words the effect works in. */
  says: string;
}

export const RESEARCH: ResearchNode[] = [
  // ------------------------------------------------------------ operations
  {
    id: 'efficiency', branch: 'operations', name: 'Efficiency review', after: null,
    cost: 18_000, days: 14, effect: 'throughput', amount: 0.08,
    detail: 'Time-and-motion on the shop floor: fewer steps between the door and the till.',
    says: 'Staff serve 8% more customers an hour',
  },
  {
    id: 'automation', branch: 'operations', name: 'Automation', after: 'efficiency',
    cost: 55_000, days: 21, effect: 'wages', amount: -0.07,
    detail: 'Self-service, scheduling and stock counts that do not need a person.',
    says: 'The wage bill falls 7%',
  },
  {
    id: 'lean', branch: 'operations', name: 'Lean production', after: 'automation',
    cost: 120_000, days: 28, effect: 'purchasing', amount: -0.06,
    detail: 'Order what sells, when it sells. Less money sitting on the racks.',
    says: 'Stock costs 6% less to buy',
  },
  // ------------------------------------------------------------- logistics
  {
    id: 'fleet', branch: 'logistics', name: 'Fleet management', after: null,
    cost: 22_000, days: 14, effect: 'logistics', amount: -0.1,
    detail: 'Maintenance intervals, fuel cards and drivers who are not lost.',
    says: 'Delivery and haulage cost 10% less',
  },
  {
    id: 'routing', branch: 'logistics', name: 'Route optimisation', after: 'fleet',
    cost: 60_000, days: 21, effect: 'trips', amount: 0.25,
    detail: 'One van, one round, in an order that makes sense.',
    says: 'Each driver makes 25% more trips a day',
  },
  {
    id: 'warehousing', branch: 'logistics', name: 'High-bay warehousing', after: 'routing',
    cost: 140_000, days: 28, effect: 'capacity', amount: 0.2,
    detail: 'Taller racks, narrower aisles, and the trucks to reach the top.',
    says: 'Distribution centres hold 20% more',
  },
  // ------------------------------------------------------------- marketing
  {
    id: 'branding', branch: 'marketing', name: 'Branding', after: null,
    cost: 20_000, days: 14, effect: 'awareness', amount: 0.15,
    detail: 'A name people can picture, on everything you own.',
    says: 'Awareness fades 15% more slowly',
  },
  {
    id: 'advertising', branch: 'marketing', name: 'Advertising science', after: 'branding',
    cost: 65_000, days: 21, effect: 'awareness', amount: 0.15,
    detail: 'Knowing which half of the budget is the wasted half.',
    says: 'Awareness fades another 15% more slowly',
  },
  {
    id: 'analytics', branch: 'marketing', name: 'Customer analytics', after: 'advertising',
    cost: 150_000, days: 28, effect: 'throughput', amount: 0.06,
    detail: 'Stocking and staffing for who actually walks in, and when.',
    says: 'Staff serve another 6% more customers an hour',
  },
  // ------------------------------------------------------------ technology
  {
    id: 'ai', branch: 'technology', name: 'Forecasting models', after: null,
    cost: 90_000, days: 21, effect: 'purchasing', amount: -0.05,
    detail: 'Buying to a forecast instead of to a hunch.',
    says: 'Stock costs another 5% less to buy',
  },
  {
    id: 'robotics', branch: 'technology', name: 'Robotics', after: 'ai',
    cost: 240_000, days: 35, effect: 'capacity', amount: 0.25,
    detail: 'Pickers that do not need a break, in racking they can reach.',
    says: 'Distribution centres hold another 25%',
  },
  {
    id: 'manufacturing', branch: 'technology', name: 'Advanced manufacturing', after: 'robotics',
    cost: 480_000, days: 42, effect: 'wages', amount: -0.08,
    detail: 'Making more of what you sell, with fewer hands on it.',
    says: 'The wage bill falls another 8%',
  },
  // -------------------------------------------------------- sustainability
  {
    id: 'solar', branch: 'sustainability', name: 'Rooftop solar', after: null,
    cost: 45_000, days: 21, effect: 'utilities', amount: -0.18,
    detail: 'Panels on every roof you own or lease long enough to matter.',
    says: 'Utilities cost 18% less',
  },
  {
    id: 'battery', branch: 'sustainability', name: 'Battery storage', after: 'solar',
    cost: 110_000, days: 28, effect: 'utilities', amount: -0.14,
    detail: 'Buy power when it is cheap, use it when it is not.',
    says: 'Utilities cost another 14% less',
  },
  {
    id: 'green-logistics', branch: 'sustainability', name: 'Electric fleet', after: 'battery',
    cost: 260_000, days: 35, effect: 'logistics', amount: -0.14,
    detail: 'Electric vans, charged off your own roofs.',
    says: 'Delivery and haulage cost another 14% less',
  },
];

export const RESEARCH_BY_ID = new Map(RESEARCH.map((node) => [node.id, node]));

export interface ResearchState {
  /** Ids of finished projects. */
  done: string[];
  /** The one project in progress. */
  active: { id: string; endsOnDay: number } | null;
}

export function emptyResearch(): ResearchState {
  return { done: [], active: null };
}

/** Which branches this company is big enough to work in. */
export function openBranches(state: GameState): ResearchBranch[] {
  return BRANCHES.slice(0, researchBranches(state));
}

export function isDone(state: GameState, id: string): boolean {
  return state.research.done.includes(id);
}

export interface Availability {
  ok: boolean;
  reason: string;
}

/** Whether a project can be started right now, and why not if not. */
export function canStart(state: GameState, id: string): Availability {
  const node = RESEARCH_BY_ID.get(id);
  if (!node) return { ok: false, reason: 'Unknown project.' };
  if (isDone(state, id)) return { ok: false, reason: 'Already done.' };
  if (state.research.active) return { ok: false, reason: 'Another project is running.' };
  if (!openBranches(state).some((branch) => branch.id === node.branch)) {
    return { ok: false, reason: `${levelOf(state).name} companies do not have a ${node.branch} department yet.` };
  }
  if (node.after && !isDone(state, node.after)) {
    return { ok: false, reason: `${RESEARCH_BY_ID.get(node.after)?.name ?? 'The previous project'} comes first.` };
  }
  if (playerCompany(state).cash < node.cost) {
    return { ok: false, reason: `It costs ${money(node.cost)} and you have ${money(playerCompany(state).cash)}.` };
  }
  return { ok: true, reason: '' };
}

export function startResearch(state: GameState, id: string): { ok: boolean; message: string } {
  const check = canStart(state, id);
  if (!check.ok) return { ok: false, message: check.reason };
  const node = RESEARCH_BY_ID.get(id);
  if (!node) return { ok: false, message: 'Unknown project.' };
  post(state, state.playerCompanyId, 'training', `R&D — ${node.name}`, -node.cost, null);
  // Somebody who knows which project matters gets to the end of it sooner.
  // Who is choosing it, and whether there is anywhere to do it.
  const days = Math.max(1, Math.round((node.days * labFactor(state)) / researchSpeed(state)));
  state.research.active = { id, endsOnDay: state.day + days };
  return { ok: true, message: `${node.name} started. ${days} days.` };
}

/** Called once a day: finishes whatever is due. */
export function researchDaily(state: GameState): void {
  const active = state.research.active;
  if (!active || state.day < active.endsOnDay) return;
  const node = RESEARCH_BY_ID.get(active.id);
  state.research.active = null;
  if (!node) return;
  state.research.done.push(node.id);
  learn(state, 'researched');
  record(state, 'research', `Completed ${node.name}`, { amount: -node.cost });
  pushNews(state, 'company', `${node.name} goes live`, `${node.says}. ${node.detail}`, { importance: 'high' });
  pushAlert(state, 'success', `R&D complete: ${node.name}`, node.says, null, 'research');
}

/**
 * The multiplier a finished project applies, compounded across everything that
 * touches the same number. This is the only way research reaches the
 * simulation, so a project with no call site here does nothing — which is why
 * there are no projects without one.
 */
export function researchFactor(state: GameState, effect: ResearchEffect): number {
  let factor = 1;
  for (const id of state.research?.done ?? []) {
    const node = RESEARCH_BY_ID.get(id);
    if (node && node.effect === effect) factor *= 1 + node.amount;
  }
  return factor;
}

/** 0..1 through the project in progress, for the interface. */
export function researchProgress(state: GameState): number {
  const active = state.research.active;
  if (!active) return 0;
  const node = RESEARCH_BY_ID.get(active.id);
  if (!node) return 0;
  const left = active.endsOnDay - state.day;
  return Math.max(0, Math.min(1, 1 - left / node.days));
}
