import type { GameState } from './state';
import { emptyPeriod, playerBusinesses, playerCompany } from './state';
import type { LedgerCategory, MonthlyAccount } from './types';
import { debtTotal, goodwillValue, inventoryValue, netWorth, payablesValue, propertyValue, receivablesValue } from './finance';
import { sum } from './util';
import { learn } from './founder';

/**
 * Management accounts.
 *
 * Closed once a month from the ledger, which every euro in the game passes
 * through, so these are the company's real books rather than a summary written
 * alongside them. They are what turns "we made money" into "we made money
 * because the gross margin held while the wage bill fell", which is the
 * difference between a number and a management report.
 */

export const ACCOUNT_LIMIT = 24;

const REVENUE: LedgerCategory[] = ['sales', 'service'];
const DIRECT: LedgerCategory[] = ['cogs'];
const OVERHEAD: LedgerCategory[] = [
  'wages',
  'rent',
  'utilities',
  'marketing',
  'logistics',
  'training',
  'severance',
  'recruitment',
  'management',
  'outsourcing',
];

/** Sums a set of categories from the month's running totals. */
function total(state: GameState, categories: LedgerCategory[]): number {
  return sum(categories, (category) => state.period.categories[category] ?? 0);
}

function byCategory(state: GameState, category: LedgerCategory): number {
  return state.period.categories[category] ?? 0;
}

/**
 * Closes the month and files the accounts. Called from the monthly settlement,
 * after loans and tax, so everything that belongs to the month is in the ledger.
 */
export function closeMonth(state: GameState, days = 30): MonthlyAccount | null {
  const to = state.day;
  const from = Math.max(1, state.period.fromDay);
  const trading = state.dayHistory.filter((record) => record.day >= from && record.day <= to);
  if (trading.length < 5) return null;

  const revenue = total(state, REVENUE);
  const costOfSales = total(state, DIRECT);
  const overheads = total(state, OVERHEAD);
  const interest = byCategory(state, 'interest');
  const tax = byCategory(state, 'tax');

  const company = playerCompany(state);
  const businesses = playerBusinesses(state);

  const account: MonthlyAccount = {
    id: `m${Math.ceil(to / days)}`,
    fromDay: from,
    toDay: to,
    revenue,
    costOfSales,
    grossProfit: revenue - costOfSales,
    wages: byCategory(state, 'wages'),
    rent: byCategory(state, 'rent'),
    utilities: byCategory(state, 'utilities'),
    marketing: byCategory(state, 'marketing'),
    logistics: byCategory(state, 'logistics'),
    training: byCategory(state, 'training') + byCategory(state, 'severance'),
    people: byCategory(state, 'wages') + byCategory(state, 'training') + byCategory(state, 'severance') +
      byCategory(state, 'recruitment') + byCategory(state, 'management'),
    recruitment: byCategory(state, 'recruitment'),
    management: byCategory(state, 'management'),
    outsourcing: byCategory(state, 'outsourcing'),
    overheads,
    interest,
    tax,
    netProfit: revenue - costOfSales - overheads - interest - tax,
    customers: sum(trading, (record) => record.customers),
    cash: company.cash,
    receivables: receivablesValue(state),
    stock: inventoryValue(state),
    property: propertyValue(state),
    goodwill: goodwillValue(state),
    debt: debtTotal(state),
    payables: payablesValue(state),
    netWorth: netWorth(state),
    headcount: state.employees.length,
    locations: businesses.filter((b) => b.status === 'open').length,
    byBusiness: businesses.map((business) => {
      const took = state.period.revenueByBusiness[business.id] ?? 0;
      const spent = state.period.costsByBusiness[business.id] ?? 0;
      return { businessId: business.id, name: business.name, revenue: took, costs: spent, profit: took - spent };
    }),
  };

  state.accounts.push(account);
  learn(state, 'closedMonth');
  if (state.accounts.length > ACCOUNT_LIMIT) state.accounts.shift();
  // The month is closed: start counting the next one from tomorrow.
  state.period = emptyPeriod(to + 1);
  return account;
}

export interface Movement {
  label: string;
  now: number;
  before: number;
  change: number;
  /** True when a rise is a good thing. */
  higherIsBetter: boolean;
}

/** What moved between two months, largest change first. */
export function movements(account: MonthlyAccount, before: MonthlyAccount): Movement[] {
  const rows: Movement[] = [
    { label: 'Turnover', now: account.revenue, before: before.revenue, change: 0, higherIsBetter: true },
    { label: 'Cost of sales', now: account.costOfSales, before: before.costOfSales, change: 0, higherIsBetter: false },
    { label: 'Wages', now: account.wages, before: before.wages, change: 0, higherIsBetter: false },
    { label: 'Rent', now: account.rent, before: before.rent, change: 0, higherIsBetter: false },
    { label: 'Utilities', now: account.utilities, before: before.utilities, change: 0, higherIsBetter: false },
    { label: 'Marketing', now: account.marketing, before: before.marketing, change: 0, higherIsBetter: false },
    { label: 'Logistics', now: account.logistics, before: before.logistics, change: 0, higherIsBetter: false },
    { label: 'Interest', now: account.interest, before: before.interest, change: 0, higherIsBetter: false },
  ];
  for (const row of rows) row.change = row.now - row.before;
  return rows.sort((a, b) => Math.abs(b.change) - Math.abs(a.change));
}

/** Gross margin as a share of turnover: the number a retailer lives by. */
export function grossMarginOf(account: MonthlyAccount): number {
  return account.revenue > 0 ? account.grossProfit / account.revenue : 0;
}

/** Average spend per customer through the door. */
export function basketOf(account: MonthlyAccount): number {
  return account.customers > 0 ? account.revenue / account.customers : 0;
}

/**
 * One sentence explaining the month, built from whichever figure actually moved
 * the result. This is the line the newsroom carries.
 */
export function monthInALine(account: MonthlyAccount, before: MonthlyAccount | undefined): string {
  const result = account.netProfit >= 0 ? 'profit' : 'loss';
  if (!before) {
    return `Turnover ${Math.round(account.revenue).toLocaleString('en-GB')}, ${result} of ${Math.round(Math.abs(account.netProfit)).toLocaleString('en-GB')} at a gross margin of ${Math.round(grossMarginOf(account) * 100)}%.`;
  }
  const moved = movements(account, before)[0];
  const direction = moved.change > 0 ? 'up' : 'down';
  return `${result === 'profit' ? 'Profit' : 'Loss'} of ${Math.round(Math.abs(account.netProfit)).toLocaleString('en-GB')} against ${Math.round(Math.abs(before.netProfit)).toLocaleString('en-GB')} last month. ${moved.label} ${direction} ${Math.round(Math.abs(moved.change)).toLocaleString('en-GB')}.`;
}
