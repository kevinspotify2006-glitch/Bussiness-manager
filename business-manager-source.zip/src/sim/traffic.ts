import type { Filler, Pt, Road, RoadClass } from './cityLayout';
import { cityLayout } from './cityLayout';
import { CITY_SEED, Rng } from './rng';

/**
 * Traffic.
 *
 * The roads Northgate is drawn with are a pile of polylines: good enough to
 * paint, useless to drive on. This turns them into a graph — a node wherever
 * two roads cross or a road ends, an edge for every stretch of carriageway
 * between two nodes — and then drives vehicles over it with A*.
 *
 * That matters because the alternative is faking it, and faking it shows. A van
 * sliding along a straight line passes through buildings, turns without a
 * junction and arrives nowhere. A van on this graph leaves a depot in the
 * warehouse district, takes the ring road because it is quicker than the back
 * streets, turns at a real junction, and parks in a real car park, because
 * every point it visits is a point the city actually has.
 */

export interface GraphNode extends Pt {
  /** Indices into `edges`. */
  out: number[];
}

export interface GraphEdge {
  from: number;
  to: number;
  /** Seconds to drive it at the class's speed. */
  cost: number;
  length: number;
  cls: RoadClass;
  width: number;
}

export interface RoadGraph {
  nodes: GraphNode[];
  edges: GraphEdge[];
}

/** How fast each class of road moves traffic, in world units per second. */
const SPEED: Partial<Record<RoadClass, number>> = {
  arterial: 0.0125,
  street: 0.008,
  lane: 0.0058,
};

const FASTEST = 0.0125;

/** Only these carry motor traffic. Footpaths, rails and runways do not. */
function drivable(road: Road): boolean {
  return road.cls === 'arterial' || road.cls === 'street' || road.cls === 'lane';
}

const QUANTUM = 1e5;

function key(p: Pt): string {
  return `${Math.round(p.x * QUANTUM)},${Math.round(p.y * QUANTUM)}`;
}

function dist(a: Pt, b: Pt): number {
  return Math.hypot(b.x - a.x, b.y - a.y);
}

/**
 * Where two stretches of carriageway cross, as a fraction along each. Returns
 * null for parallel roads and for crossings past the ends of either.
 */
function crossing(a1: Pt, a2: Pt, b1: Pt, b2: Pt): { t: number; u: number } | null {
  const ax = a2.x - a1.x;
  const ay = a2.y - a1.y;
  const bx = b2.x - b1.x;
  const by = b2.y - b1.y;
  const denominator = ax * by - ay * bx;
  if (Math.abs(denominator) < 1e-12) return null;
  const t = ((b1.x - a1.x) * by - (b1.y - a1.y) * bx) / denominator;
  const u = ((b1.x - a1.x) * ay - (b1.y - a1.y) * ax) / denominator;
  if (t < 1e-6 || t > 1 - 1e-6 || u < 1e-6 || u > 1 - 1e-6) return null;
  return { t, u };
}

let cachedGraph: RoadGraph | null = null;

/** The drivable city, built once. */
export function roadGraph(): RoadGraph {
  if (!cachedGraph) cachedGraph = buildGraph();
  return cachedGraph;
}

function buildGraph(): RoadGraph {
  const roads = cityLayout().roads.filter(drivable);

  // Every straight stretch of every road, as an independent segment.
  interface Seg {
    a: Pt;
    b: Pt;
    cls: RoadClass;
    width: number;
    /** Fractions along the segment where another road crosses it. */
    cuts: number[];
  }
  const segments: Seg[] = [];
  for (const road of roads) {
    for (let i = 0; i + 1 < road.pts.length; i += 1) {
      segments.push({ a: road.pts[i], b: road.pts[i + 1], cls: road.cls, width: road.width, cuts: [] });
    }
  }

  // Junctions: wherever two segments cross, both get a node there.
  for (let i = 0; i < segments.length; i += 1) {
    for (let j = i + 1; j < segments.length; j += 1) {
      const hit = crossing(segments[i].a, segments[i].b, segments[j].a, segments[j].b);
      if (!hit) continue;
      segments[i].cuts.push(hit.t);
      segments[j].cuts.push(hit.u);
    }
  }

  const nodes: GraphNode[] = [];
  const edges: GraphEdge[] = [];
  const index = new Map<string, number>();

  const nodeAt = (p: Pt): number => {
    const k = key(p);
    const found = index.get(k);
    if (found !== undefined) return found;
    const id = nodes.length;
    nodes.push({ x: p.x, y: p.y, out: [] });
    index.set(k, id);
    return id;
  };

  const link = (from: number, to: number, cls: RoadClass, width: number): void => {
    if (from === to) return;
    const length = dist(nodes[from], nodes[to]);
    if (length < 1e-6) return;
    const cost = length / (SPEED[cls] ?? 0.006);
    // Both ways: every street in Northgate is two-way.
    nodes[from].out.push(edges.length);
    edges.push({ from, to, cost, length, cls, width });
    nodes[to].out.push(edges.length);
    edges.push({ from: to, to: from, cost, length, cls, width });
  };

  for (const seg of segments) {
    const stops = [0, ...seg.cuts, 1].sort((a, b) => a - b);
    let previous = -1;
    for (const t of stops) {
      const point = { x: seg.a.x + (seg.b.x - seg.a.x) * t, y: seg.a.y + (seg.b.y - seg.a.y) * t };
      const id = nodeAt(point);
      if (previous >= 0) link(previous, id, seg.cls, seg.width);
      previous = id;
    }
  }

  return { nodes, edges };
}

// ---------------------------------------------------------------- routing

/**
 * A* over the road graph. The heuristic is the straight-line distance at the
 * speed of the fastest road in the city, which never overestimates, so the
 * route it finds is the quickest one there is.
 */
export function route(graph: RoadGraph, from: number, to: number): number[] | null {
  if (from === to) return [from];
  const count = graph.nodes.length;
  const best = new Float64Array(count).fill(Infinity);
  const cameFrom = new Int32Array(count).fill(-1);
  const done = new Uint8Array(count);
  const target = graph.nodes[to];

  // The city has a few thousand nodes, so a binary heap is worth having.
  const heap: { node: number; f: number }[] = [];
  const push = (node: number, f: number): void => {
    heap.push({ node, f });
    let i = heap.length - 1;
    while (i > 0) {
      const parent = (i - 1) >> 1;
      if (heap[parent].f <= heap[i].f) break;
      [heap[parent], heap[i]] = [heap[i], heap[parent]];
      i = parent;
    }
  };
  const pop = (): { node: number; f: number } | undefined => {
    if (heap.length === 0) return undefined;
    const top = heap[0];
    const last = heap.pop();
    if (heap.length > 0 && last) {
      heap[0] = last;
      let i = 0;
      for (;;) {
        const l = i * 2 + 1;
        const r = l + 1;
        let small = i;
        if (l < heap.length && heap[l].f < heap[small].f) small = l;
        if (r < heap.length && heap[r].f < heap[small].f) small = r;
        if (small === i) break;
        [heap[small], heap[i]] = [heap[i], heap[small]];
        i = small;
      }
    }
    return top;
  };

  best[from] = 0;
  push(from, dist(graph.nodes[from], target) / FASTEST);

  while (heap.length > 0) {
    const current = pop();
    if (!current) break;
    if (done[current.node]) continue;
    done[current.node] = 1;
    if (current.node === to) break;
    for (const edgeId of graph.nodes[current.node].out) {
      const edge = graph.edges[edgeId];
      const through = best[current.node] + edge.cost;
      if (through >= best[edge.to]) continue;
      best[edge.to] = through;
      cameFrom[edge.to] = current.node;
      push(edge.to, through + dist(graph.nodes[edge.to], target) / FASTEST);
    }
  }

  if (best[to] === Infinity) return null;
  const path: number[] = [to];
  let step = to;
  while (step !== from) {
    step = cameFrom[step];
    if (step < 0) return null;
    path.push(step);
  }
  return path.reverse();
}

/** The node closest to a point, for putting a trip end on the network. */
export function nearestNode(graph: RoadGraph, p: Pt): number {
  let best = 0;
  let bestDistance = Infinity;
  for (let i = 0; i < graph.nodes.length; i += 1) {
    const d = (graph.nodes[i].x - p.x) ** 2 + (graph.nodes[i].y - p.y) ** 2;
    if (d < bestDistance) {
      bestDistance = d;
      best = i;
    }
  }
  return best;
}

// --------------------------------------------------------------- vehicles

export type VehicleClass = 'car' | 'van' | 'lorry' | 'bike';

export interface Vehicle {
  id: number;
  /** Which asset from the pack it is drawn as. */
  asset: string;
  cls: VehicleClass;
  /** World-unit length and width. A car is not the square its atlas cell is. */
  length: number;
  width: number;
  /** Node indices, start to finish. */
  path: number[];
  /** Which leg of the path it is on. */
  leg: number;
  /** How far along that leg, 0..1. */
  t: number;
  speed: number;
  /** Where it is now, and which way it is pointing. */
  x: number;
  y: number;
  heading: number;
  /** Half the carriageway width, so it keeps to its own side. */
  offset: number;
  /** Seconds left standing still. Parked vehicles are not drawn moving. */
  waiting: number;
  /** The trip ends this vehicle draws from: a lorry does not run errands. */
  ends: number[];
  /** Where it is parked, when it is. */
  park: Pt | null;
  /** 0..1 — how far into the manoeuvre off the road and into the space. */
  parking: number;
}

const CAR_ASSETS = ['saloon-car', 'suv', 'hatchback', 'electric-car', 'hatchback', 'saloon-car', 'sports-car'];
const VAN_ASSETS = ['van', 'van', 'lorry'];
const LORRY_ASSETS = ['lorry', 'articulated-lorry'];
const BIKE_ASSETS = ['scooter', 'bicycle'];

const SIZE: Record<VehicleClass, number> = {
  car: 0.0030,
  van: 0.0042,
  lorry: 0.0062,
  bike: 0.0018,
};

/** Length over width, as the thing actually is rather than as it was framed. */
const SLENDER: Record<VehicleClass, number> = {
  car: 2.4,
  van: 2.6,
  lorry: 3.4,
  bike: 3,
};

const PACE: Record<VehicleClass, number> = {
  car: 1,
  van: 0.92,
  lorry: 0.78,
  bike: 0.62,
};

export interface Traffic {
  graph: RoadGraph;
  vehicles: Vehicle[];
  /** Car parks the simulation may send a vehicle into. */
  spaces: { at: Pt; node: number }[];
}

/**
 * Somewhere to park: the middle of a car park, and the road node it is reached
 * from. Only car parks close to a road are used, so the run-in from the kerb to
 * the space never crosses a building.
 */
export function parkingSpaces(graph: RoadGraph, fillers: Filler[]): { at: Pt; node: number }[] {
  const structures = fillers.filter((f) => !GROUND_USES.has(f.kind));
  const out: { at: Pt; node: number }[] = [];
  for (const filler of fillers) {
    if (filler.kind !== 'parking') continue;
    const at = { x: filler.x + filler.w / 2, y: filler.y + filler.h / 2 };
    const node = nearestNode(graph, at);
    // A space whose approach is longer than the car park is wide is not a
    // space off that road, so it is left out rather than driven to through
    // whatever stands in between.
    if (dist(graph.nodes[node], at) > Math.max(filler.w, filler.h) * 0.95) continue;
    // And a space that could only be reached by driving through the shop in
    // front of it is not a space either.
    if (crossesStructure(graph.nodes[node], at, structures)) continue;
    out.push({ at, node });
  }
  return out;
}

/** Ground you can drive over; everything else is a building. */
const GROUND_USES = new Set([
  'park', 'plaza', 'parking', 'pitch', 'quay', 'field', 'orchard', 'pasture', 'solar',
]);

/**
 * What the run-in from the kerb to a space passes through, if anything. Used
 * both to keep vehicles out of buildings and to report it when one could not be.
 */
export function crossesStructure(from: Pt, to: Pt, structures: Filler[]): Filler | null {
  const steps = 12;
  for (let i = 1; i < steps; i += 1) {
    const t = i / steps;
    const x = from.x + (to.x - from.x) * t;
    const y = from.y + (to.y - from.y) * t;
    for (const s of structures) {
      if (x > s.x && x < s.x + s.w && y > s.y && y < s.y + s.h) return s;
    }
  }
  return null;
}

/**
 * The traffic the city carries.
 *
 * The mix follows the map: lorries run between the docks, the industrial
 * district and the warehouses, vans everywhere a business takes deliveries,
 * bikes around the university and the old town, cars the rest. It is a fixed
 * fleet rather than a spawner, so the cost of traffic is known and flat.
 */
export function createTraffic(count = 160): Traffic {
  const graph = roadGraph();
  const layout = cityLayout();
  const spaces = parkingSpaces(graph, layout.fillers);
  const rng = new Rng(CITY_SEED ^ 0x7a11);
  const vehicles: Vehicle[] = [];

  // Trip ends, weighted by what the district is for.
  const freight: number[] = [];
  const general: number[] = [];
  const campus: number[] = [];
  for (let i = 0; i < graph.nodes.length; i += 1) {
    general.push(i);
  }
  for (const filler of layout.fillers) {
    const at = { x: filler.x + filler.w / 2, y: filler.y + filler.h / 2 };
    if (filler.kind === 'shed' || filler.kind === 'hangar' || filler.kind === 'quay') {
      freight.push(nearestNode(graph, at));
    }
    if (filler.district === 'university' || filler.district === 'tourist') {
      campus.push(nearestNode(graph, at));
    }
  }

  for (let i = 0; i < count; i += 1) {
    const roll = rng.next();
    const cls: VehicleClass = roll < 0.12 ? 'lorry' : roll < 0.34 ? 'van' : roll < 0.44 ? 'bike' : 'car';
    const pool = cls === 'lorry' ? LORRY_ASSETS : cls === 'van' ? VAN_ASSETS : cls === 'bike' ? BIKE_ASSETS : CAR_ASSETS;
    const ends = cls === 'lorry' && freight.length > 1 ? freight : cls === 'bike' && campus.length > 1 ? campus : general;
    const vehicle: Vehicle = {
      id: i,
      asset: pool[Math.floor(rng.next() * pool.length)],
      cls,
      length: SIZE[cls],
      width: SIZE[cls] / SLENDER[cls],
      path: [],
      leg: 0,
      t: 0,
      speed: PACE[cls] * rng.range(0.85, 1.15),
      x: 0,
      y: 0,
      heading: 0,
      offset: 0,
      ends,
      waiting: rng.range(0, 6),
      park: null,
      parking: 0,
    };
    retarget(graph, vehicle, rng, spaces);
    vehicles.push(vehicle);
  }

  return { graph, vehicles, spaces };
}

/** Sends a vehicle somewhere new, and parks it at the end if there is space. */
function retarget(
  graph: RoadGraph,
  vehicle: Vehicle,
  rng: Rng,
  spaces: { at: Pt; node: number }[],
): void {
  const ends = vehicle.ends;
  for (let attempt = 0; attempt < 6; attempt += 1) {
    const from = vehicle.path.length > 0 ? vehicle.path[vehicle.path.length - 1] : ends[Math.floor(rng.next() * ends.length)];
    const to = ends[Math.floor(rng.next() * ends.length)];
    if (from === to) continue;
    const found = route(graph, from, to);
    if (!found || found.length < 2) continue;
    vehicle.path = found;
    vehicle.leg = 0;
    vehicle.t = 0;
    vehicle.park = null;
    vehicle.parking = 0;
    // A quarter of trips end in a car park rather than on the kerb.
    if (rng.chance(0.25)) {
      const near = spaces.find((space) => space.node === to);
      if (near) vehicle.park = near.at;
    }
    const a = graph.nodes[found[0]];
    vehicle.x = a.x;
    vehicle.y = a.y;
    return;
  }
  // Nowhere to go: stand still rather than teleport.
  vehicle.waiting = 5;
}

function edgeBetween(graph: RoadGraph, from: number, to: number): GraphEdge | null {
  for (const id of graph.nodes[from].out) {
    if (graph.edges[id].to === to) return graph.edges[id];
  }
  return null;
}

/**
 * Moves the fleet on by `dt` seconds.
 *
 * Vehicles keep to the left of the centre line by a quarter of the carriageway,
 * which is what makes two lanes of traffic read as two lanes. Nothing here can
 * leave the road: a vehicle's position is always a point on an edge of the
 * graph, and every edge is a stretch of carriageway.
 */
export function advanceTraffic(traffic: Traffic, dt: number): void {
  const { graph, vehicles, spaces } = traffic;
  const rng = advanceRng;
  for (const vehicle of vehicles) {
    if (vehicle.waiting > 0) {
      vehicle.waiting -= dt;
      if (vehicle.waiting > 0) {
        // Reversing out of the space takes as long as pulling into it.
        if (vehicle.park) vehicle.parking = Math.min(1, vehicle.parking + dt * 0.8);
        continue;
      }
      vehicle.parking = 0;
      vehicle.park = null;
      retarget(graph, vehicle, rng, spaces);
      continue;
    }
    if (vehicle.path.length < 2) {
      vehicle.waiting = 3;
      continue;
    }

    const from = vehicle.path[vehicle.leg];
    const to = vehicle.path[vehicle.leg + 1];
    const edge = edgeBetween(graph, from, to);
    if (!edge) {
      vehicle.waiting = 2;
      continue;
    }
    const speed = (SPEED[edge.cls] ?? 0.006) * vehicle.speed;
    vehicle.t += (speed * dt) / edge.length;
    while (vehicle.t >= 1) {
      vehicle.t -= 1;
      vehicle.leg += 1;
      if (vehicle.leg + 1 >= vehicle.path.length) {
        // Arrived. Either pull into the space or stand at the kerb a while.
        vehicle.t = 0;
        vehicle.waiting = vehicle.park ? 14 + (vehicle.id % 7) * 3 : 2 + (vehicle.id % 5);
        break;
      }
    }
    const legFrom = graph.nodes[vehicle.path[Math.min(vehicle.leg, vehicle.path.length - 1)]];
    const legTo = graph.nodes[vehicle.path[Math.min(vehicle.leg + 1, vehicle.path.length - 1)]];
    const dx = legTo.x - legFrom.x;
    const dy = legTo.y - legFrom.y;
    const length = Math.hypot(dx, dy) || 1;
    vehicle.heading = Math.atan2(dy, dx);
    vehicle.offset = edge.width * 0.24;
    // Left of the centre line, which is the side Northgate drives on.
    const nx = -dy / length;
    const ny = dx / length;
    vehicle.x = legFrom.x + dx * vehicle.t + nx * vehicle.offset;
    vehicle.y = legFrom.y + dy * vehicle.t + ny * vehicle.offset;
  }
}

/** One shared stream for the movement decisions; the city itself is fixed. */
const advanceRng = new Rng(CITY_SEED ^ 0x5e11);

/** Where a vehicle is actually drawn, once the parking manoeuvre is counted. */
export function vehiclePosition(vehicle: Vehicle): { x: number; y: number; heading: number } {
  if (!vehicle.park || vehicle.parking <= 0) {
    return { x: vehicle.x, y: vehicle.y, heading: vehicle.heading };
  }
  const k = vehicle.parking;
  return {
    x: vehicle.x + (vehicle.park.x - vehicle.x) * k,
    y: vehicle.y + (vehicle.park.y - vehicle.y) * k,
    heading: vehicle.heading + k * 0.6,
  };
}
