import type { GameState } from './state';
import { buildingById, playerBusinesses, playerCompany } from './state';
import type { Business } from './types';
import { businessTypeOrThrow } from '../data/businessTypes';
import { product } from '../data/products';
import { district } from '../data/districts';
import { attractiveness, priceIndex, rivalsOf } from './demand';
import { grossMargin, hourlyCapacity } from './business';
import { employeesOf } from './state';
import { topComplaint, DRIVER_LABELS } from './reviews';
import { isOffSick, quotePromotion } from './employees';
import { BASE_TRIPS, TRIPS_PER_DRIVER, stockValue, warehousesOf } from './warehouse';
import { monthlyProfit } from './finance';
import { attentionFactor, divisionBusinesses, eligibleHeads, ownerAttention } from './holding';
import { titleOf } from './skills';
import { money, pct } from './format';
import { sum } from './util';

/**
 * The advisor.
 *
 * Every screen in the game shows numbers; this turns those same numbers into
 * the three things a manager actually wants: what happened, why, and what to do
 * about it. Nothing here invents data — each note is derived from state the
 * simulation already keeps, and each one points at the screen where it can be
 * acted on.
 */

export type AdviceSeverity = 'critical' | 'warning' | 'opportunity';

export interface Advice {
  id: string;
  businessId: string | null;
  severity: AdviceSeverity;
  /** What is wrong, in one line. */
  headline: string;
  /** Why, with the number that proves it. */
  detail: string;
  /** What to do about it. */
  action: string;
  route: string;
  params: Record<string, string>;
  /** Higher sorts first. */
  weight: number;
}

const SEVERITY_RANK: Record<AdviceSeverity, number> = { critical: 3, warning: 2, opportunity: 1 };

function note(
  business: Business | null,
  id: string,
  severity: AdviceSeverity,
  headline: string,
  detail: string,
  action: string,
  route: string,
  weight: number,
  params: Record<string, string> = {},
): Advice {
  return {
    id: business ? `${business.id}:${id}` : id,
    businessId: business?.id ?? null,
    severity,
    headline,
    detail,
    action,
    route,
    params: business && route === 'businesses' ? { business: business.id, ...params } : params,
    weight,
  };
}

/** Everything worth saying about one business, most urgent first. */
export function adviceFor(state: GameState, business: Business): Advice[] {
  const out: Advice[] = [];
  const type = businessTypeOrThrow(business.typeId);
  const building = buildingById(state, business.buildingId);
  const yesterday = business.yesterday;
  const dayCosts =
    yesterday.cogs + yesterday.wages + yesterday.rent + yesterday.marketing + yesterday.otherCosts;

  // ------------------------------------------------------------- not trading
  if (business.status === 'setup') {
    const stocked = sum(Object.values(business.stock), (units) => units) > 0 || type.productIds.length === 0;
    const staffed = employeesOf(state, business.id).length > 0;
    const missing = !stocked ? 'stock on the shelves' : !staffed ? 'somebody to work there' : null;
    out.push(
      note(
        business,
        'not-open',
        'critical',
        `${business.name} is not open yet`,
        missing
          ? `It still needs ${missing}. Until then it pays rent and earns nothing.`
          : 'Everything it needs is in place — it is only waiting on you.',
        missing === 'stock on the shelves' ? 'Order stock' : missing ? 'Hire somebody' : 'Open the doors',
        missing === 'stock on the shelves' ? 'inventory' : missing ? 'employees' : 'businesses',
        100,
      ),
    );
    return out;
  }
  if (business.status !== 'open') return out;

  // ------------------------------------------------------------- the location
  const own = attractiveness(state, business);
  const factor = (label: string): number => own.factors.find((f) => f.label === label)?.value ?? 1;

  if (factor('Location') < 0.45 && building) {
    out.push(
      note(
        business,
        'location',
        'warning',
        'This unit gets almost no passing trade',
        `Only ${building.footTraffic.toLocaleString('en-GB')} people a day walk past ${building.address}, which is the weakest thing about ${business.name}. A ${type.name.toLowerCase()} lives on footfall.`,
        'Advertise hard to pull people in, or move to a busier unit',
        'property',
        72,
      ),
    );
  }

  // A services business is not a shop: its customers come from the catchment,
  // not the pavement outside. Paying a prime-pitch rent for footfall the demand
  // model never reads is one of the quietest ways to lose money in the game.
  const walkIn = type.category === 'retail' || type.category === 'food';
  if (!walkIn && building && building.footTraffic > 18000) {
    out.push(
      note(
        business,
        'wrong-pitch',
        'warning',
        'You are paying for passing trade you cannot use',
        `${building.footTraffic.toLocaleString('en-GB')} people a day walk past ${building.address}, and ${money(building.rent)} a month of your rent is for that footfall. A ${type.name.toLowerCase()} draws on the people who live and work in ${district(building.district).name}, not the ones walking by.`,
        'A quieter unit in the same district would trade the same and cost less',
        'property',
        70,
      ),
    );
  }

  if (business.awareness < 25 && business.marketingBudget <= 0) {
    out.push(
      note(
        business,
        'awareness',
        'warning',
        'Hardly anyone knows you are there',
        `${Math.round(business.awareness)}% of ${building ? district(building.district).name : 'the district'} has heard of ${business.name}, and you are spending nothing on marketing.`,
        'Set a daily marketing budget',
        'marketing',
        78,
      ),
    );
  }

  // ------------------------------------------------------------------ trading
  const losingStreak = business.profitHistory.slice(-3);
  if (losingStreak.length === 3 && losingStreak.every((p) => p < 0)) {
    const worst = [
      { label: 'wages', value: yesterday.wages },
      { label: 'rent', value: yesterday.rent },
      { label: 'stock', value: yesterday.cogs },
      { label: 'marketing', value: yesterday.marketing },
    ].reduce((best, entry) => (entry.value > best.value ? entry : best));
    out.push(
      note(
        business,
        'losing',
        'critical',
        `${business.name} is losing money every day`,
        `Yesterday it took ${money(yesterday.revenue)} and spent ${money(dayCosts)}. The largest cost was ${worst.label} at ${money(worst.value)}.`,
        yesterday.revenue < dayCosts * 0.5 ? 'Fix demand before cutting costs' : 'Trim the biggest cost or raise prices',
        'businesses',
        95,
      ),
    );
  }

  // Turning people away is the most expensive thing a shop can do.
  if (yesterday.lostCustomers > Math.max(4, yesterday.customers * 0.12)) {
    out.push(
      note(
        business,
        'capacity',
        'warning',
        `${business.name} is turning customers away`,
        `${Math.round(yesterday.lostCustomers)} people left without buying yesterday against ${Math.round(yesterday.customers)} served — roughly ${Math.round(hourlyCapacity(state, business))} customers an hour is all it can handle.`,
        'Hire another pair of hands, or widen the opening hours',
        'employees',
        80,
      ),
    );
  }

  // Empty shelves during trading hours.
  const stockouts = type.productIds.filter((id) => (business.stock[id] ?? 0) <= 0.5);
  if (stockouts.length > 0) {
    const names = stockouts
      .map((id) => product(id)?.name)
      .filter(Boolean)
      .slice(0, 3)
      .join(', ');
    out.push(
      note(
        business,
        'stockout',
        stockouts.length >= type.productIds.length / 2 ? 'critical' : 'warning',
        `${business.name} has sold out of ${stockouts.length} line${stockouts.length === 1 ? '' : 's'}`,
        `${names} ${stockouts.length === 1 ? 'is' : 'are'} off the shelf. Every customer who came for ${stockouts.length === 1 ? 'it' : 'them'} walked out again.`,
        business.autoRestock ? 'Raise the reorder points' : 'Order stock and turn on automatic reordering',
        'inventory',
        88,
      ),
    );
  }

  // ------------------------------------------------------------------- prices
  const rivals = rivalsOf(state, business);
  if (rivals.length > 0 && type.productIds.length > 0) {
    const mine = priceIndex(business);
    const theirs = sum(rivals, (r) => priceIndex(r)) / rivals.length;
    if (mine > theirs * 1.12) {
      out.push(
        note(
          business,
          'expensive',
          'warning',
          'You are the expensive option here',
          `Your prices sit at ${pct(mine * 100)} of the market while your rivals average ${pct(theirs * 100)}. Price is the strongest single pull for a ${type.name.toLowerCase()}.`,
          'Cut prices, or give people a reason to pay more',
          'businesses',
          66,
        ),
      );
    } else if (mine < theirs * 0.9 && business.yesterday.lostCustomers > 3) {
      out.push(
        note(
          business,
          'underpriced',
          'opportunity',
          'You are cheap and already full',
          `Your prices are ${pct(mine * 100)} of the market, you are turning people away, and margin is ${pct(grossMargin(business) * 100)}. You are leaving money on the counter.`,
          'Raise prices — demand can take it',
          'businesses',
          58,
        ),
      );
    }
  }

  const margin = grossMargin(business);
  if (type.productIds.length > 0 && margin < 0.16 && business.today.revenue + yesterday.revenue > 0) {
    out.push(
      note(
        business,
        'margin',
        'warning',
        'Almost nothing is left after the stock cost',
        `Your gross margin is ${pct(margin * 100)}. Every sale barely covers what the goods cost, so wages and rent come straight out of your pocket.`,
        'Raise prices or find a cheaper supplier',
        'inventory',
        70,
      ),
    );
  }

  // Rent that the trade cannot carry.
  const monthRevenue = sum(business.profitHistory.slice(-30), () => 0) + yesterday.revenue * 30;
  if (building && monthRevenue > 0 && building.rent > monthRevenue * 0.3) {
    out.push(
      note(
        business,
        'rent',
        'warning',
        'The rent is too big for the trade',
        `${money(building.rent)} a month against roughly ${money(monthRevenue)} of takings. Anything over about 30% is very hard to trade out of.`,
        'Grow the takings or find cheaper premises',
        'property',
        62,
      ),
    );
  }

  // ------------------------------------------------------------------- people
  const staff = employeesOf(state, business.id);
  if (staff.length === 0) {
    out.push(
      note(
        business,
        'nobody',
        'critical',
        `Nobody works at ${business.name}`,
        'You are covering the floor yourself, which caps it at about half of what one member of staff could serve. Everything above that walks out of the door.',
        'Hire somebody',
        'employees',
        92,
      ),
    );
  }
  if (staff.length > 0) {
    const morale = sum(staff, (e) => e.morale) / staff.length;
    const stress = sum(staff, (e) => e.stress) / staff.length;
    if (morale < 42 || stress > 72) {
      out.push(
        note(
          business,
          'morale',
          'warning',
          'Your team is close to walking out',
          `Average morale is ${Math.round(morale)}/100 and stress ${Math.round(stress)}/100. Unhappy staff serve worse and hand in their notice.`,
          'Give them a rise, more hands, or shorter hours',
          'employees',
          74,
        ),
      );
    }
  }

  // Illness is capacity you have already paid for and are not getting.
  const sick = staff.filter((e) => isOffSick(state, e));
  if (sick.length > 0) {
    out.push(
      note(
        business,
        'sick',
        sick.length >= Math.max(1, staff.length / 2) ? 'critical' : 'warning',
        `${sick.length} of ${staff.length} are off sick`,
        `${sick.map((e) => e.name).join(', ')} ${sick.length === 1 ? 'is' : 'are'} at home. You are paying them and serving fewer customers. Stress is what makes this repeat.`,
        'Cover the shift, or take the pressure off the rest of the team',
        'employees',
        76,
      ),
    );
  }

  // Somebody who has earned a step up is cheap to keep and expensive to lose.
  const ready = staff.find((e) => quotePromotion(state, e).blocked === null && e.skill > 62);
  if (ready) {
    out.push(
      note(
        business,
        'promote',
        'opportunity',
        `${ready.name} is ready for more`,
        `Skill ${Math.round(ready.skill)}, ${Math.round(ready.loyalty)}/100 loyal, and long enough in the job. Promoting them lifts the whole team${ready.traits.includes('ambitious') ? ' — and they are ambitious, so they will not wait forever' : ''}.`,
        'Promote them',
        'employees',
        ready.traits.includes('ambitious') ? 60 : 45,
      ),
    );
  }

  // ----------------------------------------------------------- what they said
  const complaint = topComplaint(state, business.id);
  if (complaint && complaint.count >= 3) {
    out.push(
      note(
        business,
        'reviews',
        'warning',
        `Customers keep complaining about ${DRIVER_LABELS[complaint.driver].toLowerCase()}`,
        `${complaint.count} of the last few reviews say the same thing, and the score is ${business.reviewScore.toFixed(1)}★. Reputation feeds straight back into how many people walk in.`,
        'Fix that one thing before anything else',
        'businesses',
        68,
      ),
    );
  }

  return out.sort((a, b) => SEVERITY_RANK[b.severity] - SEVERITY_RANK[a.severity] || b.weight - a.weight);
}

/** Company-wide advice, including everything the individual businesses raised. */
export function topAdvice(state: GameState, limit = 5): Advice[] {
  const out: Advice[] = [];
  const company = playerCompany(state);
  const businesses = playerBusinesses(state);

  // Runway comes first: nothing else matters if the money runs out.
  const month = monthlyProfit(state, 30);
  const burn = (month.costs - month.revenue) / 30;
  if (burn > 0 && company.cash > 0) {
    const days = company.cash / burn;
    if (days < 30) {
      out.push(
        note(
          null,
          'runway',
          'critical',
          `About ${Math.round(days)} days of cash left`,
          `You are spending ${money(burn)} a day more than you take. At this rate the account is empty on day ${state.day + Math.round(days)}.`,
          days < 12 ? 'Cut costs now, or borrow to buy time' : 'Fix the losses while you still have room',
          'finance',
          120,
        ),
      );
    }
  }

  if (businesses.length === 0) {
    out.push(
      note(
        null,
        'start',
        'opportunity',
        'You have no businesses yet',
        `You are sitting on ${money(company.cash)} and paying for nothing. Rent a unit and open something.`,
        'Find premises on the map',
        'map',
        90,
      ),
    );
  }

  // ------------------------------------------------------------ structure
  // Past a handful of locations the limit stops being money and starts being
  // one person's attention. Both halves of that are worth saying out loud.
  const attention = ownerAttention(state);
  if (attention < 1) {
    const loose = state.divisions.filter((division) => division.headEmployeeId === null);
    const ready = eligibleHeads(state)[0];
    out.push(
      note(
        null,
        'attention',
        attention < 0.75 ? 'critical' : 'warning',
        `You are running more than one person can hold`,
        `Attention is at ${attention.toFixed(2)} of 1, and every location is paying about ${Math.round(
          (attentionFactor(state) - 1) * 100,
        )}% more in coordination because of it.${
          ready ? ` ${ready.name} is a ${titleOf(ready)} and is not running anything.` : ''
        }`,
        loose.length > 0 ? 'Put somebody senior over a division' : 'Group the locations and delegate',
        'holding',
        95,
      ),
    );
  }
  for (const division of state.divisions) {
    if (division.headEmployeeId !== null) continue;
    const count = divisionBusinesses(state, division.id).length;
    if (count < 2) continue;
    out.push(
      note(
        null,
        `division:${division.id}`,
        'opportunity',
        `${division.name} has nobody answerable for it`,
        `${count} locations with no head. A Senior Manager or an Executive would take them off your desk entirely.`,
        'Appoint somebody to run it',
        'holding',
        70,
      ),
    );
  }

  // Somebody who has earned a step up is a cheaper answer than a new hire, and
  // somebody who has hit the leadership wall is a training decision.
  const promotable = state.employees
    .filter((person) => person.companyId === state.playerCompanyId && quotePromotion(state, person).blocked === null)
    .sort((a, b) => b.skill - a.skill)[0];
  if (promotable) {
    const quote = quotePromotion(state, promotable);
    out.push(
      note(
        null,
        'promotable',
        'opportunity',
        `${promotable.name} has earned a step up`,
        `${titleOf(promotable)} on ${Math.round(promotable.skill)} overall. ${quote.title} costs ${money(
          quote.extra,
        )} more a month and buys loyalty money alone does not.`,
        'Promote them before somebody else does',
        'employees',
        55,
        promotable.businessId ? { business: promotable.businessId } : {},
      ),
    );
  }

  // Distribution: worth having, worth running properly, worth closing.
  for (const warehouse of warehousesOf(state)) {
    const drivers = employeesOf(state, warehouse.id).filter((e) => e.role === 'driver').length;
    if (drivers === 0) {
      out.push(
        note(
          null,
          `wh-driver-${warehouse.id}`,
          'warning',
          `${warehouse.name} has no driver`,
          `It can manage ${BASE_TRIPS} runs a night instead of ${BASE_TRIPS + TRIPS_PER_DRIVER}, so shops go short while stock sits on the racks.`,
          'Hire a driver',
          'logistics',
          72,
        ),
      );
    }
    if (stockValue(warehouse) < 200 && businesses.some((b) => b.status === 'open')) {
      out.push(
        note(
          null,
          `wh-empty-${warehouse.id}`,
          'warning',
          `${warehouse.name} is empty`,
          'You are paying rent, wages and standing charges on a building holding nothing, and your shops are buying from suppliers at shop prices.',
          'Order stock in bulk, or close the centre',
          'logistics',
          75,
        ),
      );
    }
  }

  // One shop does not need a distribution network.
  if (warehousesOf(state).length > 0 && businesses.filter((b) => b.status === 'open').length < 2) {
    out.push(
      note(
        null,
        'wh-premature',
        'warning',
        'A distribution centre for one shop',
        'The rent, the wages and the vans cost more than the deliveries they save until you are running about three locations.',
        'Open more shops, or close the centre',
        'logistics',
        58,
      ),
    );
  } else if (
    warehousesOf(state).length === 0 &&
    businesses.filter((b) => b.status === 'open' && Object.keys(b.stock).length > 0).length >= 3
  ) {
    out.push(
      note(
        null,
        'wh-worth-it',
        'opportunity',
        'Your shops are each buying separately',
        `${businesses.length} locations, every one paying its own call-out charge and its own minimum order. Buying in bulk into a warehouse and running your own van is usually cheaper at this size.`,
        'Look at distribution',
        'logistics',
        50,
      ),
    );
  }

  for (const business of businesses) out.push(...adviceFor(state, business));

  // With everything healthy, point at growth rather than saying nothing.
  if (out.length === 0 && businesses.length > 0) {
    const best = businesses.reduce((a, b) =>
      sum(b.profitHistory.slice(-7), (p) => p) > sum(a.profitHistory.slice(-7), (p) => p) ? b : a,
    );
    out.push(
      note(
        null,
        'expand',
        'opportunity',
        'Everything is running well',
        `${best.name} has been your strongest performer this week and nothing is on fire. This is the moment to open a second location.`,
        'Look for a unit',
        'map',
        40,
      ),
    );
  }

  return out
    .sort((a, b) => SEVERITY_RANK[b.severity] - SEVERITY_RANK[a.severity] || b.weight - a.weight)
    .slice(0, limit);
}

/**
 * The same advisor, asked a different question.
 *
 * Problems outrank opportunities in one sorted list, which is right on a single
 * list and wrong when the screen shows two: a company with four things wrong
 * would never be told what is worth doing. So the two are drawn separately from
 * the same notes rather than sliced off one ranking.
 */
export function topProblems(state: GameState, limit = 3): Advice[] {
  return topAdvice(state, 60).filter((item) => item.severity !== 'opportunity').slice(0, limit);
}

export function topOpportunities(state: GameState, limit = 4): Advice[] {
  return topAdvice(state, 60).filter((item) => item.severity === 'opportunity').slice(0, limit);
}
