import type { CentralisationStance, Employee, EmployeeRoleId, HeadOffice } from './types';
import type { GameState } from './state';
import { buildingById, playerBusinesses, playerCompany } from './state';
import { role } from '../data/roles';
import { post } from './finance';
import { pushNews } from './news';
import { money } from './format';
import { performanceOf } from './skills';
import { employerPull } from './standing';
import { RECRUITMENT_FEE, generateApplicant } from './employees';
import { officerLift } from './executives';
import { hiringFeeFactor } from './policies';
import { clamp, makeId, sum } from './util';
import { automationCeiling, facilitiesBill, utilisationPenalty } from './facilities';

/**
 * The head office.
 *
 * A shop is a place that serves customers. A head office serves the shops: one
 * personnel department instead of five, one set of books, one marketing team.
 * That is the whole point of it — three businesses do not need three times the
 * central staff, so centralising is cheaper than not, and the game should let
 * the player find that out.
 *
 * Every function here can also be bought in instead of staffed. Outsourcing is
 * cheaper to start and never as good: somebody who works for you cares what
 * happens next week.
 */

export type FunctionId = 'hr' | 'finance' | 'marketing' | 'it' | 'legal';

export interface FunctionDef {
  id: FunctionId;
  name: string;
  detail: string;
  /** The role that staffs it. */
  role: EmployeeRoleId;
  /**
   * People needed for full cover, per trading location — plus a standing half,
   * because the first one covers a great deal on their own. This is the scale
   * advantage: five shops need three people centrally, not five.
   */
  perLocation: number;
  /** Monthly fee to buy it in instead, per location. */
  outsourcePerLocation: number;
  /** A bought-in function is worth this much of a staffed one. */
  outsourceEffect: number;
  /** What full cover does, in the same words the effect works in. */
  says: string;
}

export const FUNCTIONS: FunctionDef[] = [
  {
    id: 'hr',
    name: 'Human resources',
    detail: 'Finding people, keeping people, and noticing before they go.',
    role: 'hr',
    perLocation: 0.4,
    outsourcePerLocation: 900,
    outsourceEffect: 0.55,
    says: 'Recruitment costs half as much and people are far less likely to walk',
  },
  {
    id: 'finance',
    name: 'Finance',
    detail: 'The books, the bills, and the part of the tax return nobody enjoys.',
    role: 'accountant',
    perLocation: 0.35,
    outsourcePerLocation: 1100,
    outsourceEffect: 0.6,
    says: 'Coordination costs 45% less and the tax bill 10%',
  },
  {
    id: 'marketing',
    name: 'Marketing',
    detail: 'One brand across every shop, instead of each one shouting alone.',
    role: 'marketer',
    perLocation: 0.45,
    outsourcePerLocation: 1400,
    outsourceEffect: 0.5,
    says: 'Every euro of campaign spend buys 35% more awareness',
  },
  {
    id: 'it',
    name: 'IT and systems',
    detail: 'Ordering, rotas and stock counts that do not need a person.',
    role: 'it',
    perLocation: 0.35,
    outsourcePerLocation: 1250,
    outsourceEffect: 0.6,
    says: 'Support roles need one fewer person, and coordination costs 25% less',
  },
  {
    id: 'legal',
    name: 'Legal',
    detail: 'Contracts read before they are signed rather than after.',
    role: 'legal',
    perLocation: 0.3,
    outsourcePerLocation: 950,
    outsourceEffect: 0.65,
    says: 'Contract penalties are halved',
  },
];

export const FUNCTION_BY_ID = new Map(FUNCTIONS.map((f) => [f.id, f]));

export function emptyOutsourcing(): Record<FunctionId, boolean> {
  return { hr: false, finance: false, marketing: false, it: false, legal: false };
}

export function emptyAutomation(): Record<FunctionId, number> {
  return { hr: 0, finance: 0, marketing: 0, it: 0, legal: 0 };
}

export const HQ_FIT_OUT = 24_000;

// ------------------------------------------------------------- HQ levels

/**
 * How much head office there is.
 *
 * A head office is a building with people in it, and a room with five desks
 * cannot do what a floor with forty can. Each level is a fit-out: it costs
 * capital, it costs more to run, and it raises the ceiling on what the centre
 * can carry. The point of levelling up is never the level — it is that a
 * company with eleven shops needs somewhere for the work to actually happen.
 */
export interface HqLevelDef {
  n: number;
  name: string;
  /** Capital cost of getting to this level from the one below. */
  upgrade: number;
  /** Monthly running cost of the floor itself. */
  running: number;
  /** People the centre can hold. */
  desks: number;
  /** Multiplier on what the same people cover. */
  reach: number;
  /** Highest automation tier that can be bought at this level. */
  automationCap: number;
  /**
   * Floor area the building has to have, in m², before this much head office
   * will fit in it. A company cannot be a group headquarters in a back room —
   * which is what made relocating a real decision rather than a change of
   * address.
   */
  needsArea: number;
  detail: string;
}

export const HQ_LEVELS: HqLevelDef[] = [
  { n: 1, name: 'Back office', upgrade: 0, running: 0, desks: 4, reach: 1, automationCap: 1, needsArea: 0, detail: 'A room with desks in it. Enough for a company of two or three shops.' },
  { n: 2, name: 'Support floor', upgrade: 38_000, running: 1_400, desks: 8, reach: 1.12, automationCap: 2, needsArea: 130, detail: 'Separate desks for separate jobs, and somewhere to put a server.' },
  { n: 3, name: 'Head office', upgrade: 95_000, running: 3_200, desks: 14, reach: 1.26, automationCap: 2, needsArea: 240, detail: 'A floor of its own. The shops start ringing here instead of each other.' },
  { n: 4, name: 'Corporate centre', upgrade: 240_000, running: 7_500, desks: 24, reach: 1.42, automationCap: 3, needsArea: 400, detail: 'Departments rather than people. Things get decided here now.' },
  { n: 5, name: 'Group headquarters', upgrade: 620_000, running: 16_000, desks: 40, reach: 1.6, automationCap: 3, needsArea: 640, detail: 'The company has an address, and this is it.' },
];

export function hqLevel(state: GameState): HqLevelDef {
  const n = clamp(state.headOffice?.level ?? 1, 1, HQ_LEVELS.length);
  return HQ_LEVELS[n - 1];
}

export function nextHqLevel(state: GameState): HqLevelDef | null {
  return HQ_LEVELS[hqLevel(state).n] ?? null;
}

/** Usable floor area of the building the head office is in, in m². */
export function hqArea(state: GameState): number {
  const building = state.headOffice ? buildingById(state, state.headOffice.buildingId) : undefined;
  if (!building) return 0;
  return Math.round(building.size * building.floors);
}

/** Whether the building could hold a given amount of head office. */
export function fitsIn(building: { size: number; floors: number }, level: HqLevelDef): boolean {
  return building.size * building.floors >= level.needsArea;
}

/** Takes the head office up a floor. Capital now, a bigger standing bill after. */
export function upgradeHeadOffice(state: GameState): { ok: boolean; message: string } {
  const hq = state.headOffice;
  if (!hq) return { ok: false, message: 'You have no head office.' };
  const next = nextHqLevel(state);
  if (!next) return { ok: false, message: 'This is already a group headquarters.' };
  const company = playerCompany(state);
  // The building has to be able to hold it. This is the whole reason a company
  // ever moves: the floor it wants does not fit in the address it has.
  if (hqArea(state) < next.needsArea) {
    return {
      ok: false,
      message: `A ${next.name.toLowerCase()} needs about ${next.needsArea} m². This building has ${hqArea(state)} m², so you would have to move first.`,
    };
  }
  if (company.cash < next.upgrade) {
    return { ok: false, message: `Fitting out a ${next.name.toLowerCase()} costs ${money(next.upgrade)}.` };
  }
  post(state, company.id, 'equipment', `Head office fit-out — ${next.name}`, -next.upgrade, null);
  hq.level = next.n;
  pushNews(state, 'company', `${hq.name} is now a ${next.name.toLowerCase()}`, `${next.detail} ${money(next.running)} a month to run, and ${next.desks} desks.`, {
    importance: 'high',
  });
  return { ok: true, message: `${hq.name} is now a ${next.name.toLowerCase()}. ${next.desks} desks.` };
}

// ----------------------------------------------------------- centralisation

export interface StanceDef {
  id: CentralisationStance;
  name: string;
  detail: string;
  /** Multiplier on what central cover is worth. */
  central: number;
  /** Multiplier on how well a shop reads its own street. */
  local: number;
  /** Multiplier on the coordination bill. */
  coordination: number;
}

/**
 * The oldest argument in business, with no right answer.
 *
 * Run it from the centre and everything is consistent, cheap to coordinate and
 * slightly deaf to the street outside each shop. Leave it to the shops and each
 * one reads its own customers, at the cost of five people solving the same
 * problem five times. The middle does a bit of both and is best at neither.
 */
export const STANCES: StanceDef[] = [
  {
    id: 'local',
    name: 'Run by the shops',
    detail: 'Each manager decides for their own street. Quick to react, expensive to coordinate, and nothing is ever done the same way twice.',
    central: 0.6,
    local: 1.12,
    coordination: 1.25,
  },
  {
    id: 'hybrid',
    name: 'Shared',
    detail: 'The centre owns the systems, the shops own the customers. Neither the cheapest nor the sharpest.',
    central: 1,
    local: 1,
    coordination: 1,
  },
  {
    id: 'central',
    name: 'Run from the centre',
    detail: 'One way of doing things everywhere. Cheap to run and slow to notice that one district is not like the others.',
    central: 1.3,
    local: 0.88,
    coordination: 0.72,
  },
];

export function stanceOf(state: GameState): StanceDef {
  const id = state.headOffice?.stance ?? 'hybrid';
  return STANCES.find((s) => s.id === id) ?? STANCES[1];
}

export function setStance(state: GameState, id: CentralisationStance): { ok: boolean; message: string } {
  const hq = state.headOffice;
  if (!hq) return { ok: false, message: 'You have no head office.' };
  const def = STANCES.find((s) => s.id === id);
  if (!def) return { ok: false, message: 'Unknown way of running it.' };
  hq.stance = id;
  // Changing how a company is run unsettles the people it is run by.
  for (const person of state.employees.filter((e) => e.companyId === state.playerCompanyId)) {
    person.morale = clamp(person.morale - 2, 0, 100);
  }
  return { ok: true, message: `${def.name}. ${def.detail}` };
}

/**
 * How well the shops read their own customers.
 *
 * This is what centralising costs, and it is a real number: it moves how
 * accurately a business converts the attention it has into customers through
 * the door.
 */
export function localResponsiveness(state: GameState): number {
  if (!state.headOffice) return 1;
  return stanceOf(state).local;
}

// -------------------------------------------------------------- automation

/** What each tier of systems costs to install, per function. */
export const AUTOMATION_TIERS = [
  { n: 0, name: 'By hand', cost: 0, running: 0, detail: 'Somebody does it, every time.' },
  { n: 1, name: 'Assisted', cost: 26_000, running: 320, detail: 'The repetitive half is done for them.' },
  { n: 2, name: 'Automated', cost: 88_000, running: 900, detail: 'It happens without anybody starting it.' },
  { n: 3, name: 'Self-running', cost: 260_000, running: 2_400, detail: 'Nobody thinks about it until it breaks.' },
];

export function automationTier(state: GameState, id: FunctionId): number {
  return clamp(state.headOffice?.automation[id] ?? 0, 0, 3);
}

/**
 * What systems add to a function, as cover somebody does not have to provide.
 *
 * Automation is not a person: a self-running payroll still cannot notice that
 * somebody is unhappy. So it caps out well short of full cover, and the
 * interesting decision is whether a tier is cheaper than the head it replaces.
 */
export function automationCover(state: GameState, id: FunctionId): number {
  return automationTier(state, id) * 0.18;
}

export function canAutomate(state: GameState, id: FunctionId): { ok: boolean; message: string } {
  const hq = state.headOffice;
  if (!hq) return { ok: false, message: 'Systems like that need a head office to run from.' };
  const tier = automationTier(state, id);
  const next = AUTOMATION_TIERS[tier + 1];
  if (!next) return { ok: false, message: 'This function is as automated as it gets.' };
  // The building sets the ceiling, and a data centre raises it by one.
  const cap = automationCeiling(state);
  if (next.n > cap) {
    return { ok: false, message: `A ${hqLevel(state).name.toLowerCase()} cannot carry that. Upgrade the head office first.` };
  }
  if (playerCompany(state).cash < next.cost) {
    return { ok: false, message: `${next.name} systems cost ${money(next.cost)} to put in.` };
  }
  return { ok: true, message: '' };
}

export function investInAutomation(state: GameState, id: FunctionId): { ok: boolean; message: string } {
  const check = canAutomate(state, id);
  if (!check.ok) return check;
  const hq = state.headOffice;
  const def = FUNCTION_BY_ID.get(id);
  if (!hq || !def) return { ok: false, message: 'Unknown function.' };
  const next = AUTOMATION_TIERS[automationTier(state, id) + 1];
  post(state, state.playerCompanyId, 'equipment', `${def.name} systems — ${next.name}`, -next.cost, null);
  hq.automation[id] = next.n;
  pushNews(state, 'company', `${def.name} is now ${next.name.toLowerCase()}`, `${next.detail} ${money(next.cost)} to put in, ${money(next.running)} a month to keep running.`, {});
  return { ok: true, message: `${def.name}: ${next.name.toLowerCase()}. ${next.detail}` };
}

/** What the running systems and the floor itself cost every month. */
export function overheadBill(state: GameState): number {
  if (!state.headOffice) return 0;
  const systems = sum(FUNCTIONS, (def) => AUTOMATION_TIERS[automationTier(state, def.id)].running);
  // The building, the systems, and every room built in it — a facility costs
  // its running bill whether or not anybody walked into it this month.
  return hqLevel(state).running + systems + facilitiesBill(state);
}

export function headOffice(state: GameState): HeadOffice | null {
  return state.headOffice;
}

/** Everybody who works centrally. */
export function centralStaff(state: GameState): Employee[] {
  const hq = state.headOffice;
  if (!hq) return [];
  return state.employees.filter((person) => person.businessId === hq.id);
}

/** How many people a function needs for full cover at the company's size. */
export function coverNeeded(state: GameState, def: FunctionDef): number {
  const locations = Math.max(1, playerBusinesses(state).filter((b) => b.status === 'open').length);
  return Math.max(1, Math.ceil(0.4 + locations * def.perLocation));
}

/** What a bought-in function costs per month at the company's size. */
export function outsourceCost(state: GameState, def: FunctionDef): number {
  const locations = Math.max(1, playerBusinesses(state).filter((b) => b.status === 'open').length);
  return Math.round(def.outsourcePerLocation * (0.6 + locations * 0.55));
}

export interface FunctionState {
  def: FunctionDef;
  /** People in the seat centrally. */
  people: Employee[];
  needed: number;
  /** 0..1 — how much of the function the company actually has. */
  cover: number;
  /** How much of that cover is systems rather than people. */
  fromSystems: number;
  /** Systems tier, 0..3. */
  automation: number;
  outsourced: boolean;
  /** Monthly cost of however it is being covered. */
  cost: number;
}

/**
 * How well each central function is covered.
 *
 * Staffed cover is how many suitable people are in the seat against how many
 * the company's size asks for, weighted by how well they do the job — a poor
 * fit is poor cover. Outsourced cover is a flat fraction: it is bought, not
 * built, and it shows.
 */
export function functionState(state: GameState, id: FunctionId): FunctionState {
  const def = FUNCTION_BY_ID.get(id);
  if (!def) throw new Error(`Unknown central function: ${id}`);
  const hq = state.headOffice;
  const outsourced = hq?.outsourced[id] ?? false;
  const people = centralStaff(state).filter((person) => person.role === def.role);
  const needed = coverNeeded(state, def);
  // Systems carry part of the job whatever else is happening, and they carry it
  // whether the function is staffed, bought in or neither.
  const fromSystems = hq ? automationCover(state, id) : 0;
  const automation = automationTier(state, id);
  const stance = stanceOf(state);

  if (outsourced) {
    return {
      def,
      people,
      needed,
      cover: clamp(def.outsourceEffect * stance.central + fromSystems, 0, 1),
      fromSystems,
      automation,
      outsourced: true,
      cost: outsourceCost(state, def),
    };
  }
  if (!hq) {
    return { def, people, needed, cover: 0, fromSystems: 0, automation: 0, outsourced: false, cost: 0 };
  }
  // Quality counts: two people who are wrong for the job are not full cover.
  // The floor they work on counts too — the same three people get more done in
  // a corporate centre than in a back room, which is what levelling up buys.
  const quality = people.length > 0 ? sum(people, (person) => performanceOf(person) / 70) / people.length : 0;
  const staffed =
    people.length > 0 ? (people.length / needed) * clamp(quality, 0.4, 1.15) * hqLevel(state).reach : 0;
  const cover = clamp(staffed * stance.central + fromSystems, 0, 1);
  return {
    def,
    people,
    needed,
    cover,
    fromSystems,
    automation,
    outsourced: false,
    cost: sum(people, (p) => p.salary),
  };
}

/** Every function's state, for the screen and for the effects below. */
export function functionStates(state: GameState): FunctionState[] {
  return FUNCTIONS.map((def) => functionState(state, def.id));
}

/** 0..1 cover of one function, which is all the effects need. */
export function cover(state: GameState, id: FunctionId): number {
  if (!state.headOffice) return 0;
  return functionState(state, id).cover;
}

/**
 * Cover, with whoever runs the department taken into account.
 *
 * Every effect below reads this rather than raw cover, which is what keeps an
 * officer from being a second, parallel way of getting the same thing: there is
 * still one number describing how well a function is served, and leadership
 * moves it rather than adding alongside it. It can pass one — that is the point
 * of having somebody good — but not by much, and not at all if the department
 * underneath them is empty.
 */
export function led(state: GameState, id: FunctionId): number {
  return clamp(cover(state, id) * officerLift(state, id), 0, 1.2);
}

// --------------------------------------------------------------- the effects
// Each of these is read somewhere in the simulation. A function with no call
// site would be a promise the game does not keep.

/** What taking somebody on costs, after HR has done its job. */
export function recruitmentFee(state: GameState): number {
  // Two things move it: a personnel department that does its own finding, and
  // whether anybody wants to work here. A bad employer pays a recruiter more
  // and still gets a worse field, which is exactly how it goes.
  return Math.round(RECRUITMENT_FEE * (1 - led(state, 'hr') * 0.5) * employerPull(state).fee * hiringFeeFactor(state));
}

/** How much less likely somebody is to resign because HR is paying attention. */
export function retentionFactor(state: GameState): number {
  return 1 - led(state, 'hr') * 0.35;
}

/**
 * What finance and IT between them take off the coordination bill — and what
 * the way the company is run adds back on or takes further off.
 */
export function coordinationFactor(state: GameState): number {
  const central = clamp(1 - led(state, 'finance') * 0.45 - led(state, 'it') * 0.25, 0.3, 1);
  // And how well the building is being used. A corporate centre with six
  // people in it is mostly empty rent, and that is a real cost of having
  // upgraded too early — which is the decision this is here to make honest.
  const room = utilisationPenalty(state);
  return clamp(central * (state.headOffice ? stanceOf(state).coordination : 1) * room, 0.2, 1.45);
}

/** The accountant's promise, finally kept: a smaller tax bill. */
export function taxFactor(state: GameState): number {
  return 1 - led(state, 'finance') * 0.1;
}

/** The marketer's promise: every euro goes further. */
export function marketingFactor(state: GameState): number {
  return 1 + led(state, 'marketing') * 0.35;
}

/** Systems doing what a person used to: fewer support roles needed. */
export function automationRelief(state: GameState): number {
  return led(state, 'it');
}

/** Contracts read before they are signed. */
export function penaltyFactor(state: GameState): number {
  return 1 - cover(state, 'legal') * 0.5;
}

// ------------------------------------------------------------------ actions

export function canOpenHeadOffice(state: GameState, buildingId: string): { ok: boolean; message: string } {
  if (state.headOffice) return { ok: false, message: 'You already have a head office.' };
  const building = buildingById(state, buildingId);
  if (!building) return { ok: false, message: 'Unknown building.' };
  if (building.occupantCompanyId !== state.playerCompanyId) {
    return { ok: false, message: 'Rent or buy the building first.' };
  }
  if (building.businessId) return { ok: false, message: 'There is a business trading in this unit.' };
  if (state.warehouses.some((w) => w.buildingId === buildingId)) {
    return { ok: false, message: 'This unit is a distribution centre.' };
  }
  if (playerCompany(state).cash < HQ_FIT_OUT) {
    return { ok: false, message: `Fitting out a head office costs ${money(HQ_FIT_OUT)}.` };
  }
  return { ok: true, message: '' };
}

export function openHeadOffice(state: GameState, buildingId: string, name: string): { ok: boolean; message: string } {
  const check = canOpenHeadOffice(state, buildingId);
  if (!check.ok) return check;
  const company = playerCompany(state);
  const building = buildingById(state, buildingId);
  if (!building) return { ok: false, message: 'Unknown building.' };

  post(state, company.id, 'equipment', `Head office fit-out — ${building.address}`, -HQ_FIT_OUT, null);
  state.headOffice = {
    id: makeId('hq'),
    companyId: company.id,
    buildingId,
    name: name.trim().slice(0, 40) || `${company.name} Head Office`,
    openedOnDay: state.day,
    employeeIds: [],
    outsourced: emptyOutsourcing(),
    level: 1,
    stance: 'hybrid',
    automation: emptyAutomation(),
    facilities: [],
  };
  pushNews(
    state,
    'company',
    `${state.headOffice.name} opens at ${building.address}`,
    'Personnel, the books, the brand and the systems can be run once for the whole company instead of separately in every shop.',
    { importance: 'high' },
  );
  return { ok: true, message: `${state.headOffice.name} is open at ${building.address}.` };
}

export function closeHeadOffice(state: GameState): { ok: boolean; message: string } {
  const hq = state.headOffice;
  if (!hq) return { ok: false, message: 'There is no head office.' };
  const staff = centralStaff(state);
  if (staff.length > 0) {
    return { ok: false, message: `Move or let go of the ${staff.length} people there first.` };
  }
  state.headOffice = null;
  pushNews(state, 'company', `${hq.name} has closed`, 'Everything it did centrally goes back to being done in the shops, or not at all.', {});
  return { ok: true, message: `${hq.name} is closed.` };
}

/**
 * Moving the head office.
 *
 * Everything comes with it — the people, the departments, the rooms that were
 * built, the level it had reached. What changes is the address, which is to say
 * the rent and the amount of building there is to grow into. A company that has
 * outgrown its floor has exactly two options, and this is the one that is not
 * "stop growing".
 *
 * It is not free and it is not instant to earn back: the fit-out has to be paid
 * for again, at a share of what the floor cost to build in the first place. The
 * old premises stay yours until you end the lease or sell them, because walking
 * out of a lease is not something moving office does for you.
 */
export function relocationCost(state: GameState): number {
  const level = hqLevel(state);
  const spent = HQ_LEVELS.filter((step) => step.n <= level.n).reduce((total, step) => total + step.upgrade, HQ_FIT_OUT);
  return Math.round(spent * 0.4);
}

export function canRelocate(state: GameState, buildingId: string): { ok: boolean; message: string } {
  const hq = state.headOffice;
  if (!hq) return { ok: false, message: 'You have no head office to move.' };
  if (hq.buildingId === buildingId) return { ok: false, message: 'The head office is already there.' };
  const building = buildingById(state, buildingId);
  if (!building) return { ok: false, message: 'Unknown building.' };
  if (building.occupantCompanyId !== state.playerCompanyId) {
    return { ok: false, message: 'Rent or buy the building first.' };
  }
  if (building.businessId) return { ok: false, message: 'There is a business trading in this unit.' };
  if (state.warehouses.some((w) => w.buildingId === buildingId)) {
    return { ok: false, message: 'This unit is a distribution centre.' };
  }
  const level = hqLevel(state);
  if (!fitsIn(building, level)) {
    return {
      ok: false,
      message: `A ${level.name.toLowerCase()} needs about ${level.needsArea} m² and this building has ${Math.round(building.size * building.floors)} m².`,
    };
  }
  const cost = relocationCost(state);
  if (playerCompany(state).cash < cost) {
    return { ok: false, message: `Moving costs ${money(cost)} to fit the new floor out.` };
  }
  return { ok: true, message: `Move to ${building.address} for ${money(cost)}.` };
}

/** Buildings the head office could move into, roomiest first. */
export function relocationOptions(state: GameState): { id: string; address: string; area: number; ok: boolean; reason: string }[] {
  if (!state.headOffice) return [];
  return state.buildings
    .filter((building) => building.occupantCompanyId === state.playerCompanyId && building.id !== state.headOffice?.buildingId)
    .map((building) => {
      const check = canRelocate(state, building.id);
      return {
        id: building.id,
        address: building.address,
        area: Math.round(building.size * building.floors),
        ok: check.ok,
        reason: check.message,
      };
    })
    // Somewhere you could actually go, first. A list that leads with six units
    // you cannot use is a list that has to be read before it is useful.
    .sort((a, b) => (a.ok === b.ok ? b.area - a.area : a.ok ? -1 : 1));
}

export function relocateHeadOffice(state: GameState, buildingId: string): { ok: boolean; message: string } {
  const check = canRelocate(state, buildingId);
  if (!check.ok) return check;
  const hq = state.headOffice!;
  const building = buildingById(state, buildingId)!;
  const from = buildingById(state, hq.buildingId);
  const cost = relocationCost(state);

  post(state, state.playerCompanyId, 'equipment', `Head office move — ${building.address}`, -cost, null);
  hq.buildingId = buildingId;
  pushNews(
    state,
    'company',
    `${hq.name} has moved to ${building.address}`,
    `${Math.round(building.size * building.floors)} m² instead of ${from ? Math.round(from.size * from.floors) : 0}. Everybody and everything came with it.${from ? ` ${from.address} is still yours until you end the lease or sell it.` : ''}`,
    { importance: 'high' },
  );
  return { ok: true, message: `${hq.name} is now at ${building.address}.` };
}

/** Takes somebody on centrally. Mirrors hiring into a shop or a warehouse. */
export function hireToHeadOffice(state: GameState, applicantId: string): { ok: boolean; message: string } {
  const hq = state.headOffice;
  if (!hq) return { ok: false, message: 'You have no head office.' };
  const applicant = state.applicants.find((a) => a.id === applicantId);
  if (!applicant) return { ok: false, message: 'That applicant is no longer available.' };
  if (!FUNCTIONS.some((def) => def.role === applicant.role)) {
    return { ok: false, message: 'A head office needs HR, finance, marketing, IT or legal people.' };
  }
  const desks = hqLevel(state).desks;
  if (centralStaff(state).length >= desks) {
    return {
      ok: false,
      message: `A ${hqLevel(state).name.toLowerCase()} has ${desks} desks and they are all taken. Upgrade the head office to make room.`,
    };
  }
  const company = playerCompany(state);
  const fee = recruitmentFee(state);
  const upfront = fee + (applicant.salary / 30) * 7;
  if (company.cash < upfront) {
    return { ok: false, message: `You need ${money(upfront)} in cash to take someone on.` };
  }

  applicant.businessId = hq.id;
  applicant.companyId = company.id;
  applicant.hiredOnDay = state.day;
  applicant.lastRecognisedOnDay = state.day;
  state.employees.push(applicant);
  hq.employeeIds.push(applicant.id);
  state.applicants = state.applicants.filter((a) => a.id !== applicantId);
  state.applicants.push(generateApplicant(state));
  post(state, company.id, 'recruitment', `Recruitment — ${applicant.name}`, -fee, null);
  return { ok: true, message: `${applicant.name} joins ${hq.name} as ${role(applicant.role).name}.` };
}

/** Buys a function in, or stops. Staff in that seat are unaffected either way. */
export function setOutsourced(state: GameState, id: FunctionId, on: boolean): { ok: boolean; message: string } {
  const hq = state.headOffice;
  if (!hq) return { ok: false, message: 'You have no head office.' };
  const def = FUNCTION_BY_ID.get(id);
  if (!def) return { ok: false, message: 'Unknown function.' };
  hq.outsourced[id] = on;
  return {
    ok: true,
    message: on
      ? `${def.name} is now bought in for ${money(outsourceCost(state, def))} a month.`
      : `${def.name} is back in house.`,
  };
}

/** The monthly bill for everything bought in. */
export function outsourcingBill(state: GameState): number {
  if (!state.headOffice) return 0;
  return sum(
    FUNCTIONS.filter((def) => state.headOffice?.outsourced[def.id]),
    (def) => outsourceCost(state, def),
  );
}

/** Charged daily, like every other standing cost in the game. */
export function headOfficeDaily(state: GameState): void {
  const bought = outsourcingBill(state);
  if (bought > 0) {
    post(state, state.playerCompanyId, 'outsourcing', 'Outsourced central services', -bought / 30, null);
  }
  // The floor itself and the systems running on it. This is the bill that makes
  // a big head office a decision rather than a free upgrade.
  const overheads = overheadBill(state);
  if (overheads > 0) {
    post(state, state.playerCompanyId, 'management', `${hqLevel(state).name} and systems`, -overheads / 30, null);
  }
}
