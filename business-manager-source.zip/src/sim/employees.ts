import type { GameState } from './state';
import { employeesOf, playerCompany } from './state';
import type { Business, Employee, EmployeeRoleId, EmployeeTrait } from './types';
import { FIRST_NAMES, LAST_NAMES, ROLES, TRAITS, role, trait } from '../data/roles';
import { businessTypeOrThrow } from '../data/businessTypes';
import { post } from './finance';
import { pushAlert } from './alerts';
import { pushNews } from './news';
import { approach, clamp, makeId, sum } from './util';
import { money } from './format';
import { gameRng } from './rng';
import { recruitmentFee, retentionFactor } from './headOffice';
import { employerPull } from './standing';
import { applicantCountFactor, applicantSkillBias, hoursFactor, hoursMoraleDrag, sicknessFactor } from './policies';
import { bondMorale, mentorBoost, teamFriction } from './relationships';
import { mergerMoraleDrag } from './mergers';
import type { CourseDef, GradeDef } from './skills';
import {
  COURSE_BY_ID,
  GRADES,
  SKILLS,
  SKILL_IDS,
  TOP_OF_TRADE,
  gradeBlocker,
  gradeOf,
  overallSkill,
  performanceOf,
  profileFor,
  rungRate,
  suggestedCourse,
  syncOverall,
  titleOf,
  workloadOf,
} from './skills';
import { researchFactor } from './research';
import { learn, moraleFromOwner } from './founder';
import { record } from './chronicle';
import { trainingFactor } from './facilities';

export const APPLICANT_POOL = 14;
/** One-off recruitment cost, charged when an applicant is hired. */
export const RECRUITMENT_FEE = 420;

export function dailyWage(employee: Employee): number {
  return employee.salary / 30;
}

/**
 * What somebody in this seat, at this rung, is worth on the open market today.
 *
 * One definition, read by morale, by the salary field and by what the interface
 * tells the player — so the number a player is asked to beat is the same one
 * the simulation judges them against.
 */
export function marketRate(state: GameState, employee: Employee): number {
  return Math.round(
    rungRate(role(employee.role).baseSalary, gradeOf(employee).n, employee.skill) * state.economy.inflation,
  );
}

function rollTraits(): EmployeeTrait[] {
  const count = gameRng.chance(0.35) ? 2 : 1;
  const picked = gameRng.sample(TRAITS, count);
  return picked.map((t) => t.id);
}

export function generateApplicant(state: GameState, forcedRole?: EmployeeRoleId): Employee {
  const roleDef = forcedRole ? role(forcedRole) : gameRng.pick(ROLES);
  // A company people want to work for gets a better field, and one with a bad
  // name gets what is left. This is the whole reason employer standing exists.
  const skill = Math.round(
    clamp(gameRng.around(52 + employerPull(state).skill + applicantSkillBias(state), 26), 8, 99),
  );
  // Somebody applying for a job arrives with a career behind them. Where they
  // got to is what they were good enough for, not what they hope for — so the
  // ladder is walked from the bottom exactly as it is inside the company.
  let startGrade = 0;
  for (const step of GRADES) {
    if (step.n === 0) continue;
    if (skill >= step.skill && (step.leadership === 0 || skill >= step.leadership)) startGrade = step.n;
    else break;
  }
  // Managers apply as managers; everybody else tops out below the fork unless
  // they are being hired into the job of running people.
  if (roleDef.id !== 'manager') startGrade = Math.min(startGrade, TOP_OF_TRADE);
  else startGrade = Math.max(5, Math.min(startGrade, 6));
  const experience = Math.round(clamp(gameRng.around(skill / 12, 4), 0, 30));
  const traits = rollTraits();
  const traitDefs = traits.map(trait);

  const productivityMod = traitDefs.reduce((acc, t) => acc * t.productivity, 1);
  const reliabilityMod = traitDefs.reduce((acc, t) => acc * t.reliability, 1);
  const salaryMod = traitDefs.reduce((acc, t) => acc * t.salaryExpectation, 1);

  // Scarce labour pushes wages up across the board.
  const marketPressure = 1 + clamp(0.08 - state.economy.unemployment, -0.05, 0.09) * 2.2;

  // Their skill profile is built around their general level and the job they
  // are applying for, so somebody offering themselves as a cook is good at
  // cooking — but what else they can do varies, and that is what makes one
  // applicant worth more than another with the same headline number.
  const skills = profileFor(skill, roleDef.id, (min, max) => gameRng.range(min, max));

  return {
    id: makeId('emp'),
    name: `${gameRng.pick(FIRST_NAMES)} ${gameRng.pick(LAST_NAMES)}`,
    age: Math.round(clamp(19 + experience + gameRng.range(0, 14), 18, 64)),
    role: roleDef.id,
    grade: startGrade,
    salary:
      Math.round(
        (rungRate(roleDef.baseSalary, startGrade, skill) * salaryMod * marketPressure * state.economy.inflation) / 10,
      ) * 10,
    skill: Math.round(overallSkill(skills)),
    skills,
    workload: 40,
    experience,
    productivity: Math.round(clamp(gameRng.around(skill, 14) * productivityMod, 10, 100)),
    reliability: Math.round(clamp(gameRng.around(80, 16) * reliabilityMod, 25, 100)),
    morale: Math.round(clamp(gameRng.around(72, 12), 30, 100)),
    stress: Math.round(clamp(gameRng.around(24, 12), 0, 70)),
    loyalty: Math.round(clamp(gameRng.around(50, 20), 5, 100)),
    traits,
    businessId: null,
    companyId: null,
    hiredOnDay: 0,
    trainingDays: 0,
    trainingEndsOnDay: null,
    trainingCourseId: null,
    sickUntilDay: null,
    promotions: 0,
    lastRecognisedOnDay: 0,
    bonds: [],
  };
}

/**
 * Refreshes the applicant pool.
 *
 * Part of the pool is drawn from the roles the player's own businesses use, so
 * a shop is never stuck unable to hire a cashier because the dice said no.
 */
export function refreshApplicants(state: GameState): void {
  const needed: EmployeeRoleId[] = [];
  for (const business of state.businesses) {
    if (business.companyId !== state.playerCompanyId) continue;
    for (const roleId of businessTypeOrThrow(business.typeId).roles) {
      if (!needed.includes(roleId)) needed.push(roleId);
    }
  }

  const pool: Employee[] = [];
  for (const roleId of needed.slice(0, Math.floor(APPLICANT_POOL / 2))) {
    pool.push(generateApplicant(state, roleId));
  }
  // Holding out for the right person means a shorter list of better people.
  const wanted = Math.max(2, Math.round(APPLICANT_POOL * applicantCountFactor(state)));
  while (pool.length < wanted) pool.push(generateApplicant(state));
  if (pool.length > wanted) pool.length = wanted;
  state.applicants = pool;
}

/** Applicants whose role is useful to a given business type. */
export function applicantsFor(state: GameState, business: Business): Employee[] {
  const type = businessTypeOrThrow(business.typeId);
  const wanted = new Set<EmployeeRoleId>(type.roles);
  return state.applicants.filter((applicant) => wanted.has(applicant.role));
}

export function staffCapacityOf(business: Business): number {
  const type = businessTypeOrThrow(business.typeId);
  // Roughly one head per role slot, scaled by how busy the type is.
  return Math.max(2, type.roles.length * 3);
}

export function hire(state: GameState, applicantId: string, businessId: string): { ok: boolean; message: string } {
  const applicant = state.applicants.find((a) => a.id === applicantId);
  if (!applicant) return { ok: false, message: 'That applicant is no longer available.' };
  const business = state.businesses.find((b) => b.id === businessId);
  if (!business) return { ok: false, message: 'Unknown business.' };
  if (business.companyId !== state.playerCompanyId) return { ok: false, message: 'That is not your business.' };
  if (employeesOf(state, businessId).length >= staffCapacityOf(business)) {
    return { ok: false, message: `${business.name} cannot take on more staff.` };
  }
  const company = playerCompany(state);
  const fee = recruitmentFee(state);
  const upfront = fee + dailyWage(applicant) * 7;
  if (company.cash < upfront) {
    return { ok: false, message: `You need €${Math.round(upfront)} in cash to take someone on.` };
  }

  applicant.businessId = businessId;
  applicant.companyId = company.id;
  applicant.hiredOnDay = state.day;
  applicant.lastRecognisedOnDay = state.day;
  state.employees.push(applicant);
  business.employeeIds.push(applicant.id);
  state.applicants = state.applicants.filter((a) => a.id !== applicantId);
  state.applicants.push(generateApplicant(state));
  learn(state, 'hired');
  // The figure is what they cost every month from now on, so it reads as a
  // commitment rather than as money arriving.
  record(state, 'hired', `Hired ${applicant.name} as ${role(applicant.role).name}`, { amount: -applicant.salary, businessId });
  post(state, company.id, 'recruitment', `Recruitment — ${applicant.name}`, -fee, businessId);
  return { ok: true, message: `${applicant.name} hired as ${role(applicant.role).name}.` };
}

export function fire(state: GameState, employeeId: string): { ok: boolean; message: string } {
  const employee = state.employees.find((e) => e.id === employeeId);
  if (!employee) return { ok: false, message: 'Employee not found.' };
  const company = playerCompany(state);
  // Statutory notice: one month per five years of service, minimum two weeks.
  const years = (state.day - employee.hiredOnDay) / 360;
  const severance = Math.round(employee.salary * clamp(0.5 + years * 0.2, 0.5, 3));
  if (company.cash < severance) {
    return { ok: false, message: `Severance of €${severance.toLocaleString('en-GB')} exceeds available cash.` };
  }
  removeEmployee(state, employeeId);
  learn(state, 'letGo');
  record(state, 'letGo', `Let ${employee.name} go`, { amount: -severance, businessId: employee.businessId });
  post(state, company.id, 'severance', `Severance — ${employee.name}`, -severance, employee.businessId);
  // Firing people is noticed by the rest of the team.
  for (const colleague of state.employees.filter((e) => e.businessId === employee.businessId)) {
    colleague.morale = clamp(colleague.morale - 4, 0, 100);
  }
  return { ok: true, message: `${employee.name} left. Severance €${severance.toLocaleString('en-GB')}.` };
}

export function removeEmployee(state: GameState, employeeId: string): void {
  const employee = state.employees.find((e) => e.id === employeeId);
  state.employees = state.employees.filter((e) => e.id !== employeeId);
  if (!employee?.businessId) return;
  const business = state.businesses.find((b) => b.id === employee.businessId);
  if (business) business.employeeIds = business.employeeIds.filter((id) => id !== employeeId);
}

export function setSalary(state: GameState, employeeId: string, salary: number): { ok: boolean; message: string } {
  const employee = state.employees.find((e) => e.id === employeeId);
  if (!employee) return { ok: false, message: 'Employee not found.' };
  // The band moves with the rung: an executive cannot be held to a junior's
  // ceiling, and a junior cannot be quietly put on an executive's money.
  const band = marketRate(state, employee);
  const next = Math.round(clamp(salary, band * 0.5, band * 2.6) / 10) * 10;
  const change = next - employee.salary;
  employee.salary = next;
  if (change > 0) {
    employee.morale = clamp(employee.morale + (change / band) * 45, 0, 100);
    employee.loyalty = clamp(employee.loyalty + (change / band) * 30, 0, 100);
    return { ok: true, message: `${employee.name} accepted the raise.` };
  }
  employee.morale = clamp(employee.morale + (change / band) * 70, 0, 100);
  employee.loyalty = clamp(employee.loyalty + (change / band) * 60, 0, 100);
  return { ok: true, message: `${employee.name} was not pleased about the pay cut.` };
}

/**
 * Puts somebody on a course.
 *
 * A course is a particular skill, a number of days off the floor while the rest
 * of the team covers, and a bill. Which course is a management decision,
 * because the skill that helps depends on the seat they are in — so if none is
 * named, the one that would do them the most good where they are is chosen.
 */
export function startTraining(
  state: GameState,
  employeeId: string,
  courseId?: string,
): { ok: boolean; message: string } {
  const employee = state.employees.find((e) => e.id === employeeId);
  if (!employee) return { ok: false, message: 'Employee not found.' };
  if (employee.trainingEndsOnDay !== null) return { ok: false, message: 'Already in training.' };
  if (isOffSick(state, employee)) return { ok: false, message: `${employee.name} is off sick.` };
  const course = (courseId ? COURSE_BY_ID.get(courseId) : undefined) ?? suggestedCourse(employee);
  // A training centre makes the same course cost less and finish sooner.
  const cost = Math.round(trainingCost(course) * trainingFactor(state));
  const company = playerCompany(state);
  if (company.cash < cost) return { ok: false, message: `${course.name} costs ${money(cost)}.` };
  learn(state, 'trained');
  employee.trainingEndsOnDay = state.day + Math.max(1, Math.round(course.days * trainingFactor(state)));
  employee.trainingCourseId = course.id;
  post(state, company.id, 'training', `${course.name} — ${employee.name}`, -cost, employee.businessId);
  return {
    ok: true,
    message: `${employee.name} starts ${course.name.toLowerCase()} — ${course.days} days off the floor, ${money(cost)}.`,
  };
}

/** What a course costs all in. */
export function trainingCost(course: CourseDef): number {
  return course.days * course.costPerDay;
}

export function transfer(state: GameState, employeeId: string, businessId: string): { ok: boolean; message: string } {
  const employee = state.employees.find((e) => e.id === employeeId);
  const target = state.businesses.find((b) => b.id === businessId);
  if (!employee || !target) return { ok: false, message: 'Unknown employee or business.' };
  if (target.companyId !== state.playerCompanyId) return { ok: false, message: 'That is not your business.' };
  if (employeesOf(state, businessId).length >= staffCapacityOf(target)) {
    return { ok: false, message: `${target.name} is fully staffed.` };
  }
  const previous = state.businesses.find((b) => b.id === employee.businessId);
  if (previous) previous.employeeIds = previous.employeeIds.filter((id) => id !== employeeId);
  employee.businessId = businessId;
  target.employeeIds.push(employeeId);
  employee.morale = clamp(employee.morale - 3, 0, 100);
  return { ok: true, message: `${employee.name} moved to ${target.name}.` };
}

// ------------------------------------------------------------ derived power

/** Capacity and service weight per role. Managers multiply instead of adding. */
const ROLE_WEIGHTS: Record<EmployeeRoleId, { capacity: number; service: number; manager?: boolean }> = {
  cashier: { capacity: 1.15, service: 0.08 },
  sales: { capacity: 0.85, service: 0.45 },
  server: { capacity: 1.0, service: 0.55 },
  cook: { capacity: 1.1, service: 0.5 },
  technician: { capacity: 0.95, service: 0.5 },
  cleaner: { capacity: 0.75, service: 0.6 },
  warehouse: { capacity: 0.5, service: 0.05 },
  driver: { capacity: 0.75, service: 0.05 },
  marketer: { capacity: 0.1, service: 0.15 },
  accountant: { capacity: 0.1, service: 0.1 },
  manager: { capacity: 0.15, service: 0.4, manager: true },
  // Central people do almost nothing on a shop floor. What they are worth is
  // what they do for the whole company from a head office.
  hr: { capacity: 0.06, service: 0.12 },
  it: { capacity: 0.12, service: 0.06 },
  legal: { capacity: 0.04, service: 0.06 },
};

export interface StaffPower {
  /** Customers the team can serve per hour. */
  capacityPerHour: number;
  /** Average performance of the people on the payroll here, 0..100. */
  performance: number;
  /** 0..1.4 multiplier on service quality. */
  service: number;
  /** How many people actually turned up. */
  present: number;
  /** Total headcount. */
  headcount: number;
  /** 0..1 average morale. */
  morale: number;
}

/**
 * Converts the team into the two numbers the simulation needs: how many
 * customers can be served, and how good the experience is.
 */
export function staffPower(state: GameState, business: Business): StaffPower {
  const type = businessTypeOrThrow(business.typeId);
  const staff = employeesOf(state, business.id);
  const result: StaffPower = {
    capacityPerHour: 0,
    service: 0.55,
    present: 0,
    headcount: staff.length,
    morale: 0,
    performance: 0,
  };
  if (staff.length === 0) return result;

  let capacity = 0;
  let service = 0;
  let managers = 0;
  let moraleTotal = 0;

  for (const employee of staff) {
    moraleTotal += employee.morale;
    if (employee.trainingEndsOnDay !== null) continue; // away on a course
    if (isOffSick(state, employee)) continue; // at home ill
    // Attendance depends on reliability and how stressed they are.
    const attendance = clamp((employee.reliability - employee.stress * 0.35) / 100, 0.3, 0.99);
    if (!gameRng.chance(attendance)) continue;
    result.present += 1;

    // What they are worth today. This is the same figure their profile page
    // shows — skill in the job they are actually doing, weighed against their
    // morale, their workload, their experience and what kind of worker they
    // are — so there is no second, private calculation behind the screen.
    const contribution = performanceOf(employee) / 100;

    // Every role contributes something to throughput and something to the
    // quality of the experience; the split is what makes a team of cashiers
    // different from a team of cleaners. Who they are as a person sits on top
    // of that, from the same table the rest of the game reads.
    const weights = ROLE_WEIGHTS[employee.role];
    const manner = employee.traits.reduce((acc, id) => acc * trait(id).service, 1);
    // A team lead or manager is running people as well as serving customers.
    if (weights.manager || gradeOf(employee).managerial || gradeOf(employee).n === 3) {
      managers += contribution * gradeOf(employee).n * 0.25;
    }
    capacity += contribution * weights.capacity;
    service += contribution * weights.service * manner;
  }

  // A manager lifts everyone, with diminishing returns past the second one.
  const managerBoost = 1 + clamp(managers, 0, 2.5) * 0.16;
  result.capacityPerHour = capacity * type.customersPerStaffHour * managerBoost * hoursFactor(state);
  // A team working around each other serves people worse, and the customers
  // have no idea why — which is exactly how it looks from the other side of the
  // counter, and why this lands in the review scores rather than on an HR page.
  result.service = clamp(0.55 + service * 0.32 * managerBoost * teamFriction(state, business), 0.35, 1.45);
  result.morale = moraleTotal / staff.length / 100;
  result.performance = sum(staff, (person) => performanceOf(person)) / staff.length;
  return result;
}

// ------------------------------------------------------------- people 2.0

/** True while an employee is at home ill. */
export function isOffSick(state: GameState, employee: Employee): boolean {
  return employee.sickUntilDay !== null && state.day < employee.sickUntilDay;
}

/** How much longer they are off, in days. */
export function sickDaysLeft(state: GameState, employee: Employee): number {
  if (!isOffSick(state, employee)) return 0;
  return Math.max(0, (employee.sickUntilDay ?? 0) - state.day);
}

/**
 * The step up.
 *
 * A career here runs Junior → Employee → Senior → Team Lead → Manager → Senior
 * Manager → Executive. The first three rungs are the trade they already do. The
 * fork is at Team Lead: from there on the job is other people, so the
 * requirement is leadership rather than more of what got them noticed. That is
 * why a technician on 95 technical and 42 leadership stops at Senior until
 * somebody sends them on a leadership course — and why promoting the best
 * craftsman is not automatically the right call.
 */
export function promotionTarget(employee: Employee): GradeDef | null {
  const next = GRADES[gradeOf(employee).n + 1];
  return next ?? null;
}

/** The title they hold: their rung, in the trade they do it in. */
export function roleTitle(employee: Employee): string {
  return titleOf(employee);
}

export interface PromotionQuote {
  /** Rung they would hold afterwards. */
  grade: GradeDef | null;
  /** Role they would hold afterwards — managerial rungs change the job itself. */
  role: EmployeeRoleId;
  /** What they would be called afterwards. */
  title: string;
  /** New monthly salary. */
  salary: number;
  /** Extra cost per month. */
  extra: number;
  /** Why they cannot be promoted, if they cannot. */
  blocked: string | null;
}

/** What promoting this person would cost, and whether they have earned it. */
export function quotePromotion(state: GameState, employee: Employee): PromotionQuote {
  const target = promotionTarget(employee);
  if (!target) {
    return {
      grade: null,
      role: employee.role,
      title: titleOf(employee),
      salary: employee.salary,
      extra: 0,
      blocked: 'There is nothing above Executive.',
    };
  }

  // From Manager upwards the job is running the place, so the role changes with
  // the rung. Below that they stay in their trade.
  const nextRole: EmployeeRoleId = target.managerial ? 'manager' : employee.role;
  const base = role(nextRole).baseSalary * state.economy.inflation;
  const salary = Math.max(
    employee.salary + 40,
    Math.round(rungRate(base, target.n, employee.skill) / 10) * 10,
  );
  const preview = { ...employee, grade: target.n, role: nextRole };

  const quote: PromotionQuote = {
    grade: target,
    role: nextRole,
    title: titleOf(preview),
    salary,
    extra: salary - employee.salary,
    blocked: gradeBlocker(employee, target),
  };
  if (!quote.blocked && state.day - employee.hiredOnDay < 20) {
    quote.blocked = 'They have not been here long enough.';
  } else if (!quote.blocked && state.day - employee.lastRecognisedOnDay < 30) {
    quote.blocked = 'They were recognised recently.';
  }
  return quote;
}

/** Promotes someone. Costs money every month, and buys real loyalty. */
export function promote(state: GameState, employeeId: string): { ok: boolean; message: string } {
  const employee = state.employees.find((e) => e.id === employeeId);
  if (!employee) return { ok: false, message: 'Unknown employee.' };
  const quote = quotePromotion(state, employee);
  if (quote.blocked) return { ok: false, message: quote.blocked };
  if (!quote.grade) return { ok: false, message: 'There is nothing above Executive.' };

  const from = titleOf(employee);
  const steppingUp = quote.role !== employee.role;
  employee.grade = quote.grade.n;
  employee.role = quote.role;
  employee.salary = quote.salary;
  employee.promotions += 1;
  learn(state, 'promoted');
  record(state, 'promoted', `Promoted ${employee.name} to ${titleOf(employee)}`, { businessId: employee.businessId });
  employee.lastRecognisedOnDay = state.day;
  employee.morale = clamp(employee.morale + 20, 0, 100);
  employee.loyalty = clamp(employee.loyalty + 26, 0, 100);
  // A bigger job is a heavier one, and moving trade entirely is heavier still.
  employee.stress = clamp(employee.stress + (steppingUp ? 12 : 6), 0, 100);
  const title = titleOf(employee);
  pushNews(state, 'staff', `${employee.name} promoted to ${title}`, `From ${from}, on ${money(employee.salary)} a month.`, {
    businessId: employee.businessId,
  });
  return { ok: true, message: `${employee.name} is now ${title} on ${money(employee.salary)} a month.` };
}

export const BONUS_MONTHS = 0.5;

/** A one-off payment. Buys morale and loyalty now, changes nothing structurally. */
export function payBonus(state: GameState, employeeId: string): { ok: boolean; message: string } {
  const employee = state.employees.find((e) => e.id === employeeId);
  if (!employee) return { ok: false, message: 'Unknown employee.' };
  const amount = Math.round((employee.salary * BONUS_MONTHS) / 10) * 10;
  const company = playerCompany(state);
  if (company.cash < amount) return { ok: false, message: `You need ${money(amount)} in the bank for that.` };
  post(state, company.id, 'wages', `Bonus — ${employee.name}`, -amount, employee.businessId);
  employee.morale = clamp(employee.morale + 16, 0, 100);
  employee.loyalty = clamp(employee.loyalty + 12, 0, 100);
  employee.stress = clamp(employee.stress - 8, 0, 100);
  employee.lastRecognisedOnDay = state.day;
  return { ok: true, message: `${employee.name} received ${money(amount)}.` };
}

/** Days off when someone falls ill, weighted by how run down they are. */
function sicknessSpell(employee: Employee): number {
  const base = employee.stress > 70 ? 3 : 2;
  return base + (gameRng.chance(0.25) ? 1 : 0);
}

/**
 * Illness, ambition and friction.
 *
 * Run once a day per employee, after morale and stress have moved. Each of
 * these changes something the player can see and act on: fewer hands today, a
 * demand for recognition, or a team that has stopped getting along.
 */
function peopleEvents(state: GameState, employee: Employee): void {
  // ------------------------------------------------------------- sickness
  if (employee.sickUntilDay !== null && state.day >= employee.sickUntilDay) {
    employee.sickUntilDay = null;
    employee.stress = clamp(employee.stress - 12, 0, 100);
  }
  if (employee.sickUntilDay === null && employee.businessId) {
    // Stress and long hours make illness far more likely; a rested team is
    // barely ever off.
    // Overtime is paid for here as well as in morale: people worked past the
    // end of a day are ill more often, and that is the honest cost of it.
    const chance = clamp(
      (0.004 + (employee.stress / 100) * 0.03 + (60 - employee.morale) / 4000) * sicknessFactor(state),
      0.002,
      0.06,
    );
    if (gameRng.chance(chance)) {
      const days = sicknessSpell(employee);
      employee.sickUntilDay = state.day + days;
      pushNews(state, 'staff', `${employee.name} has called in sick`, `Off for about ${days} day${days === 1 ? '' : 's'}. Stress was ${Math.round(employee.stress)}/100.`, {
        businessId: employee.businessId,
      });
      if (employee.stress > 70) {
        pushAlert(
          state,
          'warning',
          `${employee.name} is off sick`,
          'They were running at very high stress. Another pair of hands or shorter hours would stop this repeating.',
          employee.businessId,
        );
      }
      return;
    }
  }

  if (!employee.businessId) return;

  // ------------------------------------------------------------- ambition
  // Ambitious people expect to move up. Left alone, they lose heart and go.
  if (employee.traits.includes('ambitious')) {
    const waited = state.day - Math.max(employee.lastRecognisedOnDay, employee.hiredOnDay);
    if (waited > 45 && employee.skill > 50) {
      employee.morale = clamp(employee.morale - 0.8, 0, 100);
      employee.loyalty = clamp(employee.loyalty - 0.6, 0, 100);
      if (waited === 60) {
        pushNews(state, 'staff', `${employee.name} wants to know where this is going`, 'Two months without a promotion or a rise, and they are ambitious. Recognise them or lose them.', {
          businessId: employee.businessId,
          importance: 'high',
        });
        pushAlert(
          state,
          'warning',
          `${employee.name} is looking for a step up`,
          'Promote them, give them a bonus, or expect a resignation.',
          employee.businessId,
        );
      }
    }
  }

  // ------------------------------------------------------------ friction
  // A difficult colleague costs the team morale every single day — that is the
  // trait, and it is applied with everybody else's. What happens here is that
  // it occasionally becomes visible, so the player can see where it comes from
  // rather than watching a number sag for no stated reason.
  if (employee.traits.includes('difficult') && employee.morale < 45 && gameRng.chance(0.05)) {
    const colleagues = employeesOf(state, employee.businessId).filter((e) => e.id !== employee.id);
    if (colleagues.length > 0) {
      const worst = colleagues.reduce((a, b) => (b.morale < a.morale ? b : a));
      pushNews(state, 'staff', `A row at ${state.businesses.find((b) => b.id === employee.businessId)?.name ?? 'work'}`, `${employee.name} fell out with ${worst.name}. Morale across the team has taken a knock.`, {
        businessId: employee.businessId,
      });
    }
  }
}

// --------------------------------------------------------------- daily tick

export function employeesDaily(state: GameState): void {
  for (const employee of [...state.employees]) {
    const traitDefs = employee.traits.map(trait);
    const business = state.businesses.find((b) => b.id === employee.businessId);

    if (employee.trainingEndsOnDay !== null && state.day >= employee.trainingEndsOnDay) {
      // Diminishing returns: the tenth course is worth far less than the first.
      const learning = traitDefs.reduce((acc, t) => acc * t.learning, 1);
      // Somebody senior taking an interest is worth more than the course is.
      // It does not make them better on the spot; it makes the time count.
      const gain = (13 * learning * mentorBoost(state, employee)) / (1 + employee.trainingDays * 0.4);
      const course = employee.trainingCourseId ? COURSE_BY_ID.get(employee.trainingCourseId) : undefined;
      // The course was about one skill, and that is the one that moves. A week
      // of leadership training does not make somebody a better mechanic.
      if (course) {
        employee.skills[course.skill] = clamp(employee.skills[course.skill] + gain, 0, 100);
      } else {
        for (const id of SKILL_IDS) employee.skills[id] = clamp(employee.skills[id] + gain / 3, 0, 100);
      }
      syncOverall(employee);
      employee.productivity = clamp(employee.productivity + gain * 0.5, 0, 100);
      employee.trainingDays += 1;
      employee.trainingEndsOnDay = null;
      employee.trainingCourseId = null;
      employee.morale = clamp(employee.morale + 5, 0, 100);
      pushAlert(
        state,
        'info',
        `${employee.name} finished ${course ? course.name.toLowerCase() : 'training'}`,
        course
          ? `${SKILLS.find((s) => s.id === course.skill)?.name ?? 'Their skill'} is now ${Math.round(employee.skills[course.skill])}.`
          : `Skill is now ${Math.round(employee.skill)}.`,
        employee.businessId,
      );
    }

    // Pay relative to the market is the main driver of morale, and it is
    // measured against the same market rate the interface puts on the screen —
    // not a near-enough version of it. Measuring against the role's bottom rung
    // made everybody who had ever been promoted read as generously paid and
    // drift to full morale; measuring against a rate that was close but not the
    // published one left the whole payroll a shade underpaid for ever, which
    // emptied a shop in three months of resignations.
    const payRatio = employee.salary / Math.max(1, marketRate(state, employee));
    const payEffect = clamp((payRatio - 1) * 30, -16, 14);
    const moraleDrift = traitDefs.reduce((acc, t) => acc + t.moraleDrift, 0);

    // How hard they were actually worked yesterday — the same figure their
    // profile shows, kept on the person so the interface and the simulation
    // cannot disagree about it.
    employee.workload = business ? workloadOf(state, business) : 20;
    const pressure = clamp((employee.workload - 55) * 0.32, -5, 14);
    // Some people take pressure better than others, and it is the single
    // biggest reason two identical rotas produce one burnout and one shrug.
    const takesIt = traitDefs.reduce((acc, t) => acc * t.stress, 1);
    employee.stress = clamp(employee.stress + pressure * 0.5 * takesIt - 2 + gameRng.range(-2, 2), 0, 100);
    // What the people around them do to them. A team player is worth real
    // morale to everybody on the rota; a difficult colleague costs it.
    const colleagues = business ? employeesOf(state, business.id) : [];
    const fromColleagues = clamp(
      sum(
        colleagues.filter((other) => other.id !== employee.id),
        (other) => sum(other.traits.map(trait), (t) => t.teamMorale),
      ),
      -1.6,
      1.2,
    );

    // How somebody feels about the job settles at a level their conditions
    // justify, and drifts toward it rather than accumulating for ever. That is
    // the difference between a number that means something and a number pinned
    // at a hundred: a shop where nothing is going wrong used to ratchet its
    // whole team to full morale within a month and stay there, which told the
    // player nothing and made the figure safe to ignore.
    //
    // Recognition still lands as a jump — a promotion or a bonus adds morale on
    // the spot — and then fades back toward what the conditions support, which
    // is exactly how being pleased about a rise works.
    const settlesAt = clamp(
      68 +
        moraleFromOwner(state) +
        mergerMoraleDrag(state, employee) +
        payEffect * 1.6 +
        moraleDrift * 10 +
        fromColleagues * 8 +
        // And the particular people they work beside, which is not the same
        // thing as the average of everybody's temperament.
        bondMorale(state, employee) -
        // And what being asked to stay late, every time it is busy, does.
        hoursMoraleDrag(state) * 40 -
        Math.max(0, employee.workload - 60) * 0.5 -
        employee.stress * 0.22,
      0,
      100,
    );
    employee.morale = clamp(approach(employee.morale, settlesAt, 0.06) + gameRng.range(-1.2, 1.2), 0, 100);
    employee.loyalty = clamp(employee.loyalty + (employee.morale - 55) * 0.05, 0, 100);
    employee.experience += 1 / 360;

    peopleEvents(state, employee);

    // Resignations: unhappy, disloyal people leave.
    // Somebody whose job it is to notice people drifting keeps a good many of
    // them. That is the whole of what an HR department is for.
    const leaving = traitDefs.reduce((acc, t) => acc * t.turnover, 1);
    const risk =
      clamp((35 - employee.morale) / 260 + (30 - employee.loyalty) / 900, 0, 0.22) *
      retentionFactor(state) *
      leaving;
    if (employee.morale < 38 && gameRng.chance(risk)) {
      removeEmployee(state, employee.id);
      pushNews(state, 'staff', `${employee.name} has resigned`, `Morale had fallen to ${Math.round(employee.morale)}/100.`, {
        businessId: employee.businessId,
        importance: 'high',
      });
      const left = state.businesses.find((b) => b.id === employee.businessId);
      if (left && left.status === 'open' && employeesOf(state, left.id).length === 0) {
        pushAlert(
          state,
          'critical',
          `${left.name} has nobody working there`,
          'You are covering it yourself, which serves about half of what one member of staff could. Hire somebody today.',
          left.id,
        );
      }
      pushAlert(
        state,
        'warning',
        `${employee.name} resigned`,
        `Morale had fallen to ${Math.round(employee.morale)}. Pay, workload or management is the usual cause.`,
        employee.businessId,
      );
    }
  }

  // Refresh a slice of the applicant pool every day, keeping the mix useful.
  const replace = Math.min(4, state.applicants.length);
  state.applicants.splice(0, replace);
  refreshTail(state, replace);
}

/** Wages are paid daily so cash flow is visible day by day. */
export function payWages(state: GameState): number {
  let total = 0;
  for (const business of state.businesses) {
    if (business.companyId !== state.playerCompanyId) continue;
    const staff = employeesOf(state, business.id);
    // Automation does not sack anybody; it means the same team covers more, so
    // the wage bill per day of trading falls.
    const amount = staff.reduce((acc, e) => acc + dailyWage(e), 0) * researchFactor(state, 'wages');
    if (amount <= 0) continue;
    business.today.wages += amount;
    post(state, business.companyId, 'wages', `Wages — ${business.name}`, -amount, business.id);
    total += amount;
  }
  return total;
}

/** Tops the pool back up, favouring roles the player's businesses can use. */
function refreshTail(state: GameState, count: number): void {
  const needed: EmployeeRoleId[] = [];
  for (const business of state.businesses) {
    if (business.companyId !== state.playerCompanyId) continue;
    for (const roleId of businessTypeOrThrow(business.typeId).roles) {
      if (!needed.includes(roleId)) needed.push(roleId);
    }
  }
  for (let i = 0; i < count; i += 1) {
    const forced = needed.length > 0 && gameRng.chance(0.55) ? gameRng.pick(needed) : undefined;
    state.applicants.push(generateApplicant(state, forced));
  }
}
