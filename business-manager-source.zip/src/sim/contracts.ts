import type { GameState } from './state';
import { playerBusinesses, playerCompany } from './state';
import type { Contract, ContractOffer } from './types';
import { product } from '../data/products';
import { warehousesOf } from './warehouse';
import { post, postNonCash } from './finance';
import { contractTerms, raiseInvoice } from './workingCapital';
import { pushNews } from './news';
import { pushAlert } from './alerts';
import { money } from './format';
import { levelOf } from './progress';
import { penaltyFactor } from './headOffice';
import { gameRng } from './rng';
import { clamp, makeId, sum } from './util';
import { learn } from './founder';
import { record } from './chronicle';

/**
 * Supply contracts.
 *
 * Retail is a shop waiting for people to walk in. A contract is the opposite:
 * somebody else's business depends on you, every week, whether or not you feel
 * like it. That is the trade — a known price for a known quantity, paid on
 * time, against a penalty if the pallet is not there.
 *
 * It is deliberately the same stock the shops sell, drawn from the same
 * warehouses, so taking one on is a real decision about where the goods go
 * rather than a separate currency in a separate screen.
 */

export const OFFER_LIMIT = 3;
/** Three misses and the client goes elsewhere. */
export const STRIKES = 3;

const CLIENTS = [
  'Halstead Hospitality', 'Northgate Schools Trust', 'Vandermeer Facilities',
  'Orwell Care Homes', 'Kestrel Hotels', 'Pemberton Catering',
  'Sable Events', 'Merrick Logistics', 'Thornbury Council',
  'Ravensworth Stadium', 'Langmere Airlines', 'Quarry Construction',
];

/** What the client is willing to pay over the shelf-cost of the goods. */
const MARGINS = [0.14, 0.19, 0.26, 0.34];

export function contractsOf(state: GameState): Contract[] {
  return state.contracts.filter((c) => c.status === 'active');
}

/** Everything the company could supply: whatever its shops already stock. */
function supplyable(state: GameState): string[] {
  const ids = new Set<string>();
  for (const warehouse of warehousesOf(state)) {
    for (const [productId, units] of Object.entries(warehouse.stock)) {
      if (units > 0) ids.add(productId);
    }
  }
  for (const business of playerBusinesses(state)) {
    for (const productId of Object.keys(business.prices)) {
      if (productId !== 'service') ids.add(productId);
    }
  }
  return [...ids];
}

/**
 * A new offer, sized to the company. A starter is not asked for ten thousand
 * units a week, and a corporation is not offered a hundred.
 */
export function makeOffer(state: GameState): ContractOffer | null {
  const pool = supplyable(state);
  if (pool.length === 0) return null;
  const productId = gameRng.pick(pool);
  const def = product(productId);
  if (!def) return null;

  const level = levelOf(state);
  const scale = 24 * level.n ** 1.5;
  const units = Math.max(20, Math.round(gameRng.range(scale * 0.7, scale * 1.6) / 5) * 5);
  const margin = gameRng.pick(MARGINS);
  const unitPrice = Math.round(def.wholesalePrice * (1 + margin) * 100) / 100;
  const weeks = gameRng.int(4, 13);
  const weekly = Math.round(units * unitPrice);

  // The bigger the margin, the more the client expects of you.
  const demanding = MARGINS.indexOf(margin) / (MARGINS.length - 1);
  const headcount = Math.round(1 + demanding * 3 + level.n * 0.6);
  const needsWarehouse = demanding > 0.5 || units > 120;
  const penalty = Math.round(weekly * (0.3 + demanding * 0.5));

  return {
    id: makeId('offer'),
    client: gameRng.pick(CLIENTS),
    productId,
    unitsPerWeek: units,
    unitPrice,
    weeks,
    requiresHeadcount: headcount,
    requiresWarehouse: needsWarehouse,
    penalty,
    reputationPerWeek: Math.round(1 + demanding * 2),
    offeredOnDay: state.day,
    expiresOnDay: state.day + 7,
  };
}

export interface Eligibility {
  ok: boolean;
  /** Why not, if not. */
  reasons: string[];
}

/** Whether the company could actually service this, said plainly. */
export function eligibility(state: GameState, offer: ContractOffer): Eligibility {
  const reasons: string[] = [];
  if (state.employees.length < offer.requiresHeadcount) {
    reasons.push(`${offer.requiresHeadcount} staff (you have ${state.employees.length})`);
  }
  if (offer.requiresWarehouse && warehousesOf(state).length === 0) {
    reasons.push('a distribution centre to hold the stock');
  }
  return { ok: reasons.length === 0, reasons };
}

/** Where the goods would come from, and whether there are enough of them. */
export function available(state: GameState, productId: string): number {
  let units = 0;
  for (const warehouse of warehousesOf(state)) units += warehouse.stock[productId] ?? 0;
  for (const business of playerBusinesses(state)) units += business.stock[productId] ?? 0;
  return units;
}

export function accept(state: GameState, offerId: string): { ok: boolean; message: string } {
  const offer = state.contractOffers.find((o) => o.id === offerId);
  if (!offer) return { ok: false, message: 'That offer is no longer on the table.' };
  const check = eligibility(state, offer);
  if (!check.ok) return { ok: false, message: `You would need ${check.reasons.join(' and ')}.` };

  learn(state, 'signed');
  record(state, 'contract', `Signed a contract with ${offer.client}`, { amount: offer.unitsPerWeek * offer.unitPrice * offer.weeks });
  state.contracts.push({
    id: makeId('contract'),
    client: offer.client,
    productId: offer.productId,
    unitsPerWeek: offer.unitsPerWeek,
    unitPrice: offer.unitPrice,
    weeksTotal: offer.weeks,
    weeksDone: 0,
    missed: 0,
    penalty: offer.penalty,
    reputationPerWeek: offer.reputationPerWeek,
    startedOnDay: state.day,
    status: 'active',
  });
  state.contractOffers = state.contractOffers.filter((o) => o.id !== offerId);
  const def = product(offer.productId);
  pushNews(
    state,
    'company',
    `${playerCompany(state).name} signs with ${offer.client}`,
    `${offer.unitsPerWeek} ${def?.name.toLowerCase() ?? 'units'} a week for ${offer.weeks} weeks at ${money(offer.unitPrice)} a unit.`,
  );
  return { ok: true, message: `Signed with ${offer.client}.` };
}

export function decline(state: GameState, offerId: string): void {
  state.contractOffers = state.contractOffers.filter((o) => o.id !== offerId);
}

/**
 * Weekly delivery.
 *
 * Stock comes off the warehouse racks first and out of the shops only if it has
 * to, because taking it off a shelf costs a sale. Short is short: the client is
 * paid for what arrived and charges the penalty anyway.
 */
/**
 * Contract money: earned this week, paid when the client gets round to it.
 *
 * A business client does not hand over cash across a counter. They take the
 * delivery, they take their terms, and the bigger the contract the longer those
 * terms are — which is why the contract that saves the company can also be the
 * one that sinks it.
 */
function invoiceClient(state: GameState, client: string, amount: number, what: string): void {
  if (amount <= 0) return;
  postNonCash(state, state.playerCompanyId, 'sales', `${client} — ${what}`, amount, null);
  raiseInvoice(state, {
    from: `${client} — ${what}`,
    amount,
    days: contractTerms(amount),
    businessId: null,
    source: 'contract',
  });
}

export function contractsWeekly(state: GameState): void {
  for (const contract of contractsOf(state)) {
    const def = product(contract.productId);
    const wanted = contract.unitsPerWeek;
    const taken = draw(state, contract.productId, wanted);

    if (taken >= wanted) {
      const paid = Math.round(wanted * contract.unitPrice);
      invoiceClient(state, contract.client, paid, 'contract delivery');
      contract.weeksDone += 1;
      bumpReputation(state, contract.reputationPerWeek);
    } else {
      const paid = Math.round(taken * contract.unitPrice);
      if (paid > 0) invoiceClient(state, contract.client, paid, 'short delivery');
      // A legal department reads the contract before it is signed, which is
      // where a penalty clause is negotiated down.
      const penalty = Math.round(contract.penalty * penaltyFactor(state));
      post(state, state.playerCompanyId, 'other', `${contract.client} — shortfall penalty`, -penalty, null);
      contract.missed += 1;
      contract.weeksDone += 1;
      bumpReputation(state, -contract.reputationPerWeek * 2);
      pushAlert(
        state,
        contract.missed >= STRIKES ? 'critical' : 'warning',
        `Short on the ${contract.client} contract`,
        `${taken} of ${wanted} ${def?.name.toLowerCase() ?? 'units'} went out. ${money(penalty)} penalty, ${contract.missed} of ${STRIKES} strikes.`,
        null,
        'contracts',
      );
    }

    if (contract.missed >= STRIKES) {
      contract.status = 'failed';
      pushNews(
        state,
        'company',
        `${contract.client} cancels its contract`,
        `Three short weeks and the work has gone elsewhere. ${money(contract.penalty)} a week no longer comes in.`,
        { importance: 'high' },
      );
    } else if (contract.weeksDone >= contract.weeksTotal) {
      contract.status = 'completed';
      const bonus = Math.round(contract.unitsPerWeek * contract.unitPrice * 0.5);
      invoiceClient(state, contract.client, bonus, 'completion bonus');
      bumpReputation(state, 4);
      pushNews(
        state,
        'company',
        `${contract.client} contract completed`,
        `${contract.weeksTotal} weeks delivered. A ${money(bonus)} completion bonus, and a client who will come back.`,
      );
    }
  }
  state.contracts = state.contracts.filter((c) => c.status === 'active' || c.startedOnDay > state.day - 120);
}

/** Takes units from the racks first, then off the shelves. */
function draw(state: GameState, productId: string, wanted: number): number {
  let left = wanted;
  for (const warehouse of warehousesOf(state)) {
    if (left <= 0) break;
    const have = warehouse.stock[productId] ?? 0;
    const take = Math.min(have, left);
    if (take > 0) {
      warehouse.stock[productId] = have - take;
      left -= take;
    }
  }
  for (const business of playerBusinesses(state)) {
    if (left <= 0) break;
    if (business.status !== 'open') continue;
    // Never strip a shop bare for a contract: half the shelf is the limit.
    const have = business.stock[productId] ?? 0;
    const take = Math.min(Math.floor(have / 2), left);
    if (take > 0) {
      business.stock[productId] = have - take;
      left -= take;
    }
  }
  return wanted - left;
}

function bumpReputation(state: GameState, amount: number): void {
  for (const business of playerBusinesses(state)) {
    if (business.status !== 'open') continue;
    business.reputation = clamp(business.reputation + amount * 0.4, 0, 100);
  }
}

/** Offers arrive weekly once the company is big enough to be asked. */
export function contractOffersWeekly(state: GameState): void {
  state.contractOffers = state.contractOffers.filter((offer) => offer.expiresOnDay > state.day);
  if (state.contractOffers.length >= OFFER_LIMIT) return;
  const offer = makeOffer(state);
  if (!offer) return;
  state.contractOffers.push(offer);
  pushNews(
    state,
    'company',
    `${offer.client} is looking for a supplier`,
    `${offer.unitsPerWeek} units a week for ${offer.weeks} weeks, ${money(offer.unitsPerWeek * offer.unitPrice)} a week.`,
  );
}

/** What the active contracts are worth per week, for the interface. */
export function weeklyContractValue(state: GameState): number {
  return sum(contractsOf(state), (c) => c.unitsPerWeek * c.unitPrice);
}
