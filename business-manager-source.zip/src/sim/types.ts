import type { SegmentMix } from './segments';

/**
 * Domain model for BUSINESS MANAGER.
 *
 * Anything ending in `Def` is static content loaded from `src/data` — it never
 * changes at runtime. Everything else is mutable simulation state and is what
 * the save file persists.
 */

// ---------------------------------------------------------------- city

export type DistrictId =
  | 'downtown'
  | 'financial'
  | 'highend'
  | 'midtown'
  | 'southside'
  | 'shopping'
  | 'entertainment'
  | 'industrial'
  | 'warehouse'
  | 'suburbs'
  | 'university'
  | 'tourist'
  | 'waterfront'
  | 'airport'
  | 'transit';

export interface AgeMix {
  young: number;
  adult: number;
  senior: number;
}

export interface DistrictDef {
  id: DistrictId;
  name: string;
  short: string;
  /** Map footprint in normalised city space (0..1). */
  x: number;
  y: number;
  w: number;
  h: number;
  population: number;
  /** People per square kilometre, drives how close customers live. */
  density: number;
  /** Average yearly household income in euros. */
  averageIncome: number;
  /** 0..1 — how unevenly income is spread; high means rich and poor together. */
  incomeSpread: number;
  ageMix: AgeMix;
  /** Pedestrians passing a prime address on an average day. */
  footTraffic: number;
  vehicleTraffic: number;
  /** 0..2 — visitors from outside the city. */
  tourism: number;
  /** 0..2 — how much commercial activity already happens here. */
  commercialActivity: number;
  /** Euro per m² per month for commercial space. */
  rentPerSqm: number;
  /** Euro per m² to buy. */
  pricePerSqm: number;
  /** Yearly growth rate, e.g. 0.03. */
  growth: number;
  /** Category preference multipliers keyed by business category. */
  preferences: Partial<Record<BusinessCategory, number>>;
  colour: string;
  description: string;
}

export type BuildingStatus = 'available' | 'rented' | 'owned' | 'competitor';

export interface Building {
  id: string;
  address: string;
  district: DistrictId;
  /** Footprint on the map, in normalised city space (0..1). */
  x: number;
  y: number;
  w: number;
  h: number;
  /** Floor area in m². */
  size: number;
  floors: number;
  /** Monthly rent in euros. */
  rent: number;
  /** Asking price in euros. */
  price: number;
  /** Current market value; moves with the district. */
  value: number;
  /** Customers that fit inside at once. */
  customerCapacity: number;
  /** Units of stock the back room holds. */
  storageCapacity: number;
  parking: number;
  /** 0..100 — poor condition costs more upkeep and puts customers off. */
  condition: number;
  /** Pedestrians per day at this specific address. */
  footTraffic: number;
  /** Business categories that suit the building. */
  suitableFor: BusinessCategory[];
  status: BuildingStatus;
  /** Company that rents or owns it, if any. */
  occupantCompanyId: string | null;
  /** Business operating here, if any. */
  businessId: string | null;
  /** Set while a renovation is running. */
  renovationEndsOnDay: number | null;
}

// ------------------------------------------------------------ businesses

export type BusinessCategory = 'retail' | 'food' | 'services' | 'specialized';

export interface BusinessTypeDef {
  id: string;
  name: string;
  category: BusinessCategory;
  description: string;
  /** Minimum floor area the type needs. */
  minSize: number;
  /** One-off fit-out cost before opening. */
  setupCost: number;
  /** Equipment the business needs; part of setup. */
  equipmentCost: number;
  /** Product ids this type sells. Empty for pure service businesses. */
  productIds: string[];
  /** Service businesses earn per served customer instead of selling stock. */
  serviceFee: number;
  /** Baseline customers per day at an average address before any modifiers. */
  baseCustomers: number;
  /** How many customers one employee can serve per hour. */
  customersPerStaffHour: number;
  /** Roles this business type needs, in hiring priority order. */
  roles: EmployeeRoleId[];
  /** Opening and closing hour in local time. */
  defaultOpenFrom: number;
  defaultOpenTo: number;
  /** 0..1 — how strongly customers here care about price versus quality. */
  priceSensitivity: number;
  /**
   * The share of takings invoiced rather than taken at the counter.
   *
   * A shop is paid when the customer walks out; work done for other businesses
   * is invoiced and paid later, and that gap is what a trade of this kind has
   * to finance. Absent means a till trade, which is most of them.
   */
  tradeCredit?: number;
  /** How long those customers take to pay. */
  tradeCreditDays?: number;
  /**
   * 1..5 — how many moving parts the trade has. A newsagent is one thing done
   * over and over; a restaurant is a kitchen, a floor, a supplier and a
   * licence. Complexity drives what coordination costs and how much managing
   * the same number of people needs.
   */
  complexity: number;
  /**
   * Monthly upkeep of the equipment the trade needs, as a share of what that
   * equipment cost. Ovens and lifts need servicing; a clothes rail does not.
   */
  equipmentUpkeep: number;
  /** 0.6..1.5 — how violently reputation moves on the back of a review. */
  reputationSensitivity: number;
  /** 0..1 — how much of the work systems can genuinely take over. */
  automatable: number;
  /** What somebody has to be good at to be worth having here. */
  keySkills: SkillId[];
  icon: string;
}

export type BusinessStatus = 'setup' | 'open' | 'closed';

export interface Business {
  id: string;
  companyId: string;
  typeId: string;
  buildingId: string;
  name: string;
  status: BusinessStatus;
  openFrom: number;
  openTo: number;
  /** 0..100 customer-facing reputation. */
  reputation: number;
  /** 0..100 how well the place is run right now. */
  serviceQuality: number;
  /** Running average review score, 1..5. */
  reviewScore: number;
  reviewCount: number;
  /** Product id -> price the player charges. */
  prices: Record<string, number>;
  /** Product id -> units on the shelf. */
  stock: Record<string, number>;
  /** Product id -> units on order. */
  incoming: Record<string, number>;
  /** Product id -> weighted average purchase cost, so COGS is honest. */
  costBasis: Record<string, number>;
  /** Product id -> reorder trigger level. */
  reorderPoints: Record<string, number>;
  employeeIds: string[];
  /** Marketing spend allocated per day. */
  marketingBudget: number;
  /** 0..100 how many people in the district know the business. */
  awareness: number;
  /** Who came in today, as shares that sum to one. */
  todayMix: SegmentMix;
  /** Yesterday's crowd, kept so the interface has something to show. */
  yesterdayMix: SegmentMix;
  /** Rolling daily figures, reset at the daily settlement. */
  today: BusinessDayStats;
  /** Yesterday's figures, kept for the trend arrows. */
  yesterday: BusinessDayStats;
  /** Lifetime totals. */
  totals: { revenue: number; costs: number; customers: number; units: number };
  /** Last 30 daily profit values, newest last. */
  profitHistory: number[];
  openedOnDay: number;
  autoRestock: boolean;
  /** The division this location belongs to, if the company has divisions. */
  divisionId: string | null;
}

export interface BusinessDayStats {
  revenue: number;
  cogs: number;
  wages: number;
  rent: number;
  marketing: number;
  otherCosts: number;
  customers: number;
  lostCustomers: number;
  units: number;
}

export function emptyDayStats(): BusinessDayStats {
  return {
    revenue: 0,
    cogs: 0,
    wages: 0,
    rent: 0,
    marketing: 0,
    otherCosts: 0,
    customers: 0,
    lostCustomers: 0,
    units: 0,
  };
}

// -------------------------------------------------------------- products

export type ProductCategory =
  | 'groceries'
  | 'beverages'
  | 'prepared'
  | 'electronics'
  | 'apparel'
  | 'home'
  | 'sports'
  | 'pet'
  | 'beauty';

export interface ProductDef {
  id: string;
  name: string;
  category: ProductCategory;
  /** What a supplier charges at list price. */
  wholesalePrice: number;
  /** What the market considers a normal shelf price. */
  marketPrice: number;
  /** 0..1 build quality / brand tier. */
  quality: number;
  /** 0..1 how much people want it before any modifiers. */
  appeal: number;
  /**
   * Average units sold per visitor — across everyone who walks in, not just
   * the ones who buy. For bread that is above one; for a laptop it is a small
   * fraction, because most people browsing do not leave with one.
   */
  unitsPerBasket: number;
  weight: number;
  /** Storage units one item occupies. */
  volume: number;
  /** Days before the product spoils. 0 = non-perishable. */
  shelfLife: number;
}

export interface SupplierDef {
  id: string;
  name: string;
  /** Multiplier on wholesale price. */
  priceMultiplier: number;
  /** 0..1 chance a delivery arrives on schedule. */
  reliability: number;
  /** 0..1 quality of the goods delivered. */
  quality: number;
  /** Delivery time in hours. */
  leadTimeHours: number;
  minimumOrderValue: number;
  /** Product categories the supplier carries. */
  categories: ProductCategory[];
  /** Discount granted once the player passes a spend threshold. */
  volumeDiscount: number;
  volumeThreshold: number;
  description: string;
}

export interface PurchaseOrder {
  id: string;
  supplierId: string;
  /** Destination business, or the warehouse's id when `warehouseId` is set. */
  businessId: string;
  /** Set when the delivery goes to a distribution centre rather than a shop. */
  warehouseId?: string | null;
  lines: { productId: string; quantity: number; unitPrice: number }[];
  goodsCost: number;
  deliveryCost: number;
  total: number;
  placedOnTick: number;
  arrivesOnTick: number;
  status: 'transit' | 'delayed' | 'delivered';
}

// ------------------------------------------------------------- employees

export type EmployeeRoleId =
  | 'cashier'
  | 'sales'
  | 'manager'
  | 'warehouse'
  | 'driver'
  | 'cook'
  | 'server'
  | 'technician'
  | 'cleaner'
  | 'accountant'
  | 'marketer'
  | 'hr'
  | 'it'
  | 'legal';

export interface EmployeeRoleDef {
  id: EmployeeRoleId;
  name: string;
  /** Monthly salary at skill 50. */
  baseSalary: number;
  description: string;
}

export type EmployeeTrait =
  | 'hardworker'
  | 'lazy'
  | 'ambitious'
  | 'loyal'
  | 'unreliable'
  | 'fastlearner'
  | 'perfectionist'
  | 'teamplayer'
  | 'difficult'
  | 'friendly'
  | 'independent'
  | 'stressresistant'
  | 'creative';

/**
 * The eight things a person can be good at.
 *
 * Finance and communication are separate from administration on purpose: an
 * accountant, a solicitor and a personnel officer all do paperwork, and they
 * are not interchangeable. Splitting them is what stops one number deciding
 * whether somebody is any good at every desk job in the company.
 */
export type SkillId =
  | 'technical'
  | 'sales'
  | 'service'
  | 'logistics'
  | 'admin'
  | 'finance'
  | 'communication'
  | 'leadership';

export type SkillSet = Record<SkillId, number>;

/**
 * A working relationship with a named colleague.
 *
 * Not a score over the team: a particular person, and how things stand with
 * them. Strength runs -100..100 and the sign is the whole of it.
 */
export interface Bond {
  withId: string;
  strength: number;
  kind: 'mentor' | 'friend' | 'rival';
}

export interface Employee {
  id: string;
  name: string;
  age: number;
  role: EmployeeRoleId;
  /** Monthly salary in euros. */
  salary: number;
  /** 0..100 — the average of the six skills, and their general level. */
  skill: number;
  /** What they are actually good at, 0..100 each. */
  skills: SkillSet;
  /** 0..100 — how hard they were worked yesterday. */
  workload: number;
  experience: number;
  productivity: number;
  reliability: number;
  morale: number;
  stress: number;
  loyalty: number;
  traits: EmployeeTrait[];
  /** Business id, or null while in the applicant pool. */
  businessId: string | null;
  companyId: string | null;
  hiredOnDay: number;
  /** Days of training completed; drives diminishing returns. */
  trainingDays: number;
  /** Day the current training finishes, if any. */
  trainingEndsOnDay: number | null;
  /** Which course they are on, so the right skill moves when it ends. */
  trainingCourseId: string | null;
  /** Day they are back from sick leave, if they are off. */
  sickUntilDay: number | null;
  /** How many times they have been promoted here. */
  promotions: number;
  /**
   * Where they stand on the ladder, 0..8: junior, employee, senior, specialist,
   * team lead, manager, senior manager, director, executive. The first four
   * rungs are the trade they already do and never ask for leadership —
   * specialist is the top of that track and a perfectly good place to stop.
   * Everything above it is management, and getting there needs leadership
   * rather than more of the same skill.
   */
  grade: number;
  /** Day they were last promoted or given a rise, for ambition pressure. */
  lastRecognisedOnDay: number;
  /** Who they get on with, and who they do not. At most three. */
  bonds: Bond[];
}

// -------------------------------------------------------------- companies

/**
 * The head office: one set of central functions serving every business, rather
 * than each shop doing its own personnel, books and marketing.
 */
export interface HeadOffice {
  id: string;
  companyId: string;
  buildingId: string;
  name: string;
  openedOnDay: number;
  employeeIds: string[];
  /** Which central functions are bought in rather than staffed. */
  outsourced: Record<string, boolean>;
  /** 1..5. A bigger head office carries more before it creaks. */
  level: number;
  /** How much the centre decides rather than the shops. */
  stance: CentralisationStance;
  /** Function id -> systems investment, 0..3. */
  automation: Record<string, number>;
  /** Rooms that have been built. Departments are people; these are places. */
  facilities: string[];
}

/**
 * Who decides.
 *
 * Not a label: the centre is cheaper and more consistent, the shops are quicker
 * to read their own street. Picking one means giving up the other.
 */
export type CentralisationStance = 'local' | 'hybrid' | 'central';

/**
 * A group of locations that came in together, usually because the company that
 * ran them was bought whole. A division can be handed to an executive, which is
 * the only way a company gets too big for one person to run.
 */
export interface Division {
  id: string;
  name: string;
  /** The company it was bought from, for the record. */
  acquiredFrom: string;
  createdOnDay: number;
  /** The executive running it, if anybody is. */
  headEmployeeId: string | null;
  /**
   * The day it stopped being another company and became part of this one.
   * Null while it is still somebody else's business wearing your name.
   */
  mergedOnDay: number | null;
}

/** How hard a merger is driven through. */
export type MergerStyleId = 'absorb' | 'blend' | 'federate';

/**
 * An integration in progress, or the record of one that finished.
 *
 * An acquisition buys a company; this is the work of making it one company with
 * yours. It is deliberately a thing that takes time rather than a purchase: the
 * cost is paid day by day while it runs, the redundancies happen one at a time,
 * and everybody on both sides is living through it the whole while.
 */
export interface Merger {
  id: string;
  divisionId: string;
  /** The name that was over the door before. */
  fromCompany: string;
  style: MergerStyleId;
  startedOnDay: number;
  /** Days it was expected to take, given who was running it at the start. */
  days: number;
  /** 0..1 */
  progress: number;
  /** 0..100, falling as the two sides get used to each other. */
  cultureGap: number;
  /** People whose job exists twice, settled one at a time. */
  duplicateIds: string[];
  /** Headcount in the division on day one, so departures can be counted. */
  headcountAtStart: number;
  /** What running it has cost so far. */
  spent: number;
  severanceSpent: number;
  letGo: number;
  /** Null while it is still running. */
  completedOnDay: number | null;
  /** The permanent share off the coordination bill it earned, 0..1. */
  savingLockedIn: number;
}

export interface Company {
  id: string;
  name: string;
  isPlayer: boolean;
  cash: number;
  /** 0..100 — banks lend more to a good credit rating. */
  creditRating: number;
  /** 0..100 — how well known the brand is across the city. */
  brandAwareness: number;
  foundedOnDay: number;
  /** AI only. */
  personality: CompetitorPersonality | null;
}

/** The seven things the person running the company can be good at. */
export type FounderSkillId =
  | 'management'
  | 'finance'
  | 'sales'
  | 'operations'
  | 'strategy'
  | 'leadership'
  | 'negotiation';

export type FounderSkills = Record<FounderSkillId, number>;

/**
 * The player, as somebody rather than a pair of hands.
 *
 * Skills start where their background put them and grow from what they
 * actually do — borrowing teaches finance, hiring teaches management, and a
 * year of trading teaches operations. Nothing here is spent; it is earned by
 * playing, and it is what makes a second run of the same scenario feel
 * different from the first.
 */
export interface Founder {
  name: string;
  /** What they did before this. */
  traitId: string;
  skills: FounderSkills;
  /** Progress toward the next point in each skill, 0..1. */
  progress: FounderSkills;
  /** Which scenario this company started from. */
  scenarioId: string;
}

export type CompetitorPersonality =
  | 'lowcost'
  | 'premium'
  | 'aggressive'
  | 'conservative'
  | 'marketer'
  | 'quality'
  | 'opportunist';

// ---------------------------------------------------------------- finance

export type LedgerCategory =
  | 'sales'
  | 'service'
  | 'stock'
  // Cash arriving from a settled invoice, and cash leaving to settle a
  // supplier bill. Neither is revenue or a cost — the profit and loss account
  // saw both on the day the work was done.
  | 'invoice'
  | 'billpay'
  | 'cogs'
  | 'wages'
  | 'rent'
  | 'utilities'
  | 'marketing'
  | 'logistics'
  | 'setup'
  | 'equipment'
  | 'property'
  | 'renovation'
  | 'loan'
  // Money in from selling part of the company, and money out to the people who
  // bought it. Neither is trading: an investment is capital and a distribution
  // is a share of profit already counted, so both move cash and neither touches
  // the profit and loss account.
  | 'equity'
  | 'dividend'
  | 'interest'
  | 'tax'
  | 'training'
  | 'severance'
  | 'recruitment'
  | 'management'
  | 'outsourcing'
  | 'other';

export interface LedgerEntry {
  day: number;
  hour: number;
  category: LedgerCategory;
  label: string;
  amount: number;
  businessId: string | null;
}

export interface DayRecord {
  day: number;
  revenue: number;
  costs: number;
  profit: number;
  cash: number;
  netWorth: number;
  customers: number;
}

/**
 * A standing order from somebody else's business: a known quantity every week
 * at a known price, against a penalty if it is not there.
 */
/**
 * Work done and not yet paid for.
 *
 * The sales ledger is an asset the company owns and cannot spend, which is the
 * entire difference between being profitable and being solvent.
 */
export interface Invoice {
  id: string;
  /** Who owes it, written as it should read on the screen. */
  from: string;
  amount: number;
  raisedOnDay: number;
  dueOnDay: number;
  businessId: string | null;
  source: 'trade' | 'contract';
  /** How many times it has gone past its date without being paid. */
  chased: number;
}

/** Stock taken on terms: yours today, paid for on the due day. */
export interface Bill {
  id: string;
  supplierId: string;
  to: string;
  amount: number;
  raisedOnDay: number;
  dueOnDay: number;
  businessId: string | null;
  /** Days it has gone unpaid past its date. Suppliers remember this. */
  lateDays: number;
}

export interface Contract {
  id: string;
  client: string;
  productId: string;
  unitsPerWeek: number;
  unitPrice: number;
  weeksTotal: number;
  weeksDone: number;
  /** Weeks delivered short. Three and the client leaves. */
  missed: number;
  penalty: number;
  reputationPerWeek: number;
  startedOnDay: number;
  status: 'active' | 'completed' | 'failed';
}

/** A contract on the table, before it is signed. */
export interface ContractOffer {
  id: string;
  client: string;
  productId: string;
  unitsPerWeek: number;
  unitPrice: number;
  weeks: number;
  requiresHeadcount: number;
  requiresWarehouse: boolean;
  penalty: number;
  reputationPerWeek: number;
  offeredOnDay: number;
  expiresOnDay: number;
}

export interface Loan {
  id: string;
  lender: string;
  /** Which kind of borrowing this is; decides what it is secured against. */
  typeId: string;
  principal: number;
  outstanding: number;
  /** Yearly nominal interest, e.g. 0.079. */
  annualRate: number;
  termMonths: number;
  monthlyPayment: number;
  takenOnDay: number;
  missedPayments: number;
  /** Interest paid so far, so the cost of borrowing is never guesswork. */
  interestPaid: number;
  /** Principal repaid ahead of schedule, which is what shortens the term. */
  earlyRepaid: number;
}

// -------------------------------------------------------------- marketing

export interface MarketingChannelDef {
  id: string;
  name: string;
  /** Cost per day while the campaign runs. */
  dailyCost: number;
  /** Share of the district that can be reached, 0..1. */
  reach: number;
  /** How efficiently reach turns into awareness, 0..1. */
  conversion: number;
  /** Which audience the channel is good at hitting. */
  targets: ('young' | 'adult' | 'senior')[];
  minimumDays: number;
  description: string;
}

export interface Campaign {
  id: string;
  companyId: string;
  businessId: string;
  channelId: string;
  daysLeft: number;
  dailyCost: number;
}

// ----------------------------------------------------------------- events

export interface CityEventDef {
  id: string;
  name: string;
  description: string;
  /** Districts affected; empty means the whole city. */
  districts: DistrictId[];
  /** Multiplier on customer demand. */
  demand: number;
  /** Multiplier on wholesale prices. */
  supplyCost: number;
  /** Multiplier on rent. */
  rent: number;
  durationDays: [number, number];
  weight: number;
}

export interface ActiveEvent {
  id: string;
  defId: string;
  daysLeft: number;
}

// ------------------------------------------------------------------- news

export type NewsCategory =
  | 'economy'
  | 'competitor'
  | 'company'
  | 'staff'
  | 'market'
  | 'supplier'
  | 'property';

export interface NewsItem {
  id: string;
  day: number;
  hour: number;
  category: NewsCategory;
  headline: string;
  body: string;
  businessId: string | null;
  /** High-importance items are pinned to the top of the feed for a day. */
  importance: 'low' | 'normal' | 'high';
}

// -------------------------------------------------------------- decisions

export interface DecisionOptionView {
  id: string;
  label: string;
  detail: string;
  /** Set when the option cannot be taken right now, explaining why. */
  blocked?: string;
}

export interface PendingDecision {
  id: string;
  /** Which decision template this came from; drives how options resolve. */
  defId: string;
  title: string;
  body: string;
  day: number;
  /** The decision disappears after this day, with the default outcome. */
  expiresOnDay: number;
  options: DecisionOptionView[];
  /** Ids the resolution needs: employee, business, supplier, building. */
  context: Record<string, string>;
  /** Numbers the resolution needs, e.g. a bonus amount or a rent rise. */
  numbers: Record<string, number>;
}

// ---------------------------------------------------------------- reviews

/**
 * A distribution centre: a building the company holds, racked out, that buys in
 * bulk and restocks the shops overnight.
 */
export interface Warehouse {
  id: string;
  companyId: string;
  buildingId: string;
  name: string;
  /** Product id -> units on the racks. */
  stock: Record<string, number>;
  /** Product id -> weighted average purchase cost, so margins stay honest. */
  costBasis: Record<string, number>;
  employeeIds: string[];
  /** Whether the vans run by themselves each night. */
  autoDispatch: boolean;
  openedOnDay: number;
  /** Shops restocked on the last run, for the interface. */
  dispatchedToday: number;
}

/**
 * Running totals for the month in progress.
 *
 * The ledger is trimmed so the finance screen stays quick, which makes it the
 * wrong place to close a month's books from. These totals are accumulated as
 * the money moves, so the accounts are complete however long the month was and
 * however many shops were trading.
 */
export interface PeriodTotals {
  fromDay: number;
  categories: Partial<Record<LedgerCategory, number>>;
  revenueByBusiness: Record<string, number>;
  costsByBusiness: Record<string, number>;
}

/** One month's management accounts, closed from the running totals. */
export interface MonthlyAccount {
  id: string;
  fromDay: number;
  toDay: number;
  revenue: number;
  costOfSales: number;
  grossProfit: number;
  wages: number;
  rent: number;
  utilities: number;
  marketing: number;
  logistics: number;
  training: number;
  /** Recruitment fees. */
  recruitment: number;
  /** Coordination cost of a team that has grown past knowing each other. */
  management: number;
  /** Central functions bought in rather than staffed. */
  outsourcing: number;
  /** Everything the people cost, all in. */
  people: number;
  overheads: number;
  interest: number;
  tax: number;
  netProfit: number;
  customers: number;
  /** Balance sheet at the close. */
  cash: number;
  /** Owed to the company by its customers and not yet collected. */
  receivables: number;
  stock: number;
  property: number;
  /** What the trading businesses themselves are worth, over and above assets. */
  goodwill: number;
  debt: number;
  /** Owed by the company to its suppliers, plus tax already set aside. */
  payables: number;
  netWorth: number;
  headcount: number;
  locations: number;
  byBusiness: { businessId: string; name: string; revenue: number; costs: number; profit: number }[];
}

export type GoalMetric =
  | 'netWorth'
  | 'cash'
  | 'locations'
  | 'weeklyProfit'
  | 'reviewScore'
  | 'dailyCustomers'
  | 'awareness'
  | 'reputation'
  | 'marketShare'
  | 'staffMorale';

/** A time-limited target generated from the state of the company. */
export interface Goal {
  id: string;
  defId: string;
  title: string;
  detail: string;
  metric: GoalMetric;
  /** The business it is about, or null for company-wide goals. */
  businessId: string | null;
  target: number;
  /** Where the metric stood when the goal was set, so progress is honest. */
  startValue: number;
  day: number;
  expiresOnDay: number;
  rewardCash: number;
  rewardText: string;
}

export interface Review {
  id: string;
  businessId: string;
  day: number;
  stars: number;
  text: string;
  /** What drove this review, so the UI can group complaints. */
  driver: 'price' | 'service' | 'availability' | 'quality' | 'premises';
}

export type AlertPriority = 'info' | 'warning' | 'critical' | 'success';

export interface Alert {
  id: string;
  priority: AlertPriority;
  title: string;
  detail: string;
  day: number;
  hour: number;
  businessId: string | null;
  read: boolean;
  /** The screen this alert is about, so clicking it goes somewhere useful. */
  view?: string;
}
