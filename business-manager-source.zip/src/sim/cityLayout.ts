import type { DistrictDef, DistrictId } from './types';
import { DISTRICTS } from '../data/districts';
import { CITY_SEED, Rng } from './rng';
import { clamp } from './util';

/**
 * The shape of Northgate.
 *
 * This builds the city itself — roads, blocks, buildings, parks, water, the
 * railway, the airport — once, from a fixed seed, so every player walks the
 * same streets. Nothing here knows about the game: it produces geometry, and
 * both the commercial plots the simulation trades in and the scenery around
 * them come out of the same pass, which is why shops sit on street corners
 * rather than floating on a grid.
 *
 * Coordinates are the same normalised city space the districts use: x and y
 * run 0..1 across the map, and a world unit is about 18 km.
 */

export interface Pt {
  x: number;
  y: number;
}

export interface Rect {
  x: number;
  y: number;
  w: number;
  h: number;
}

export type RoadClass = 'arterial' | 'street' | 'lane' | 'pedestrian' | 'path' | 'rail' | 'runway' | 'taxiway';

export interface Road {
  cls: RoadClass;
  /** Polyline through the centre of the carriageway. */
  pts: Pt[];
  /** Total width, kerb to kerb. */
  width: number;
  name: string | null;
  /** True for the few roads that carry traffic across the whole city. */
  major: boolean;
}

export type FillerKind =
  | 'house'
  | 'terrace'
  | 'apartment'
  | 'tower'
  | 'office'
  | 'retail'
  | 'shed'
  | 'hangar'
  | 'civic'
  | 'hotel'
  | 'parking'
  | 'park'
  | 'plaza'
  | 'pitch'
  | 'platform'
  | 'terminal'
  | 'quay'
  // Beyond the ring road: the country the city was built on.
  | 'field'
  | 'orchard'
  | 'pasture'
  | 'glasshouse'
  | 'solar'
  | 'turbine'
  | 'farmstead';

/** A district, or the farmland outside all of them. */
export type LandId = DistrictId | 'outskirts';

/** A structure that is scenery: it is drawn, but the game never trades in it. */
export interface Filler extends Rect {
  kind: FillerKind;
  floors: number;
  /** 0..1 — small per-building variation so a street is not one flat colour. */
  tone: number;
  district: LandId;
  /** Which asset from the pack this is built as. Assigned once, never at draw time. */
  asset: string;
}

export type AmenityKind =
  | 'tree'
  | 'light'
  | 'bus'
  | 'crossing'
  | 'signal'
  | 'fountain'
  | 'mast'
  | 'bench'
  | 'planter'
  | 'hedge'
  | 'shrub'
  | 'bin'
  | 'railings';

export interface Amenity extends Pt {
  kind: AmenityKind;
  /** Radius for round things, half-length for crossings. */
  r: number;
  /** Crossings and platforms need to know which way they run. */
  vertical?: boolean;
  /** Which asset from the pack: an oak is not a pine. */
  asset: string;
}

/** What the generator produces before the asset pass dresses it. */
type RawFiller = Omit<Filler, 'asset'>;
type RawAmenity = Omit<Amenity, 'asset'>;

export type Frontage = 'arterial' | 'street' | 'back';

/** Geometry for one of the commercial units the game actually trades in. */
export interface Plot extends Rect {
  id: string;
  district: DistrictId;
  frontage: Frontage;
  corner: boolean;
  /** Relative footprint, 0..1, used to scale the unit's floor area. */
  weight: number;
  street: string;
  number: number;
}

export interface CityLayout {
  roads: Road[];
  fillers: Filler[];
  amenities: Amenity[];
  water: Rect[];
  plots: Plot[];
  /** Where district labels sit, and the greens worth naming. */
  parks: (Rect & { name: string })[];
}

// ------------------------------------------------------------------- naming

const STREET_NAMES = [
  'Marlow', 'Kestrel', 'Ashford', 'Bellamy', 'Cormorant', 'Dunmore', 'Ellery',
  'Fenwick', 'Garrick', 'Halstead', 'Ivory', 'Jasper', 'Kingsley', 'Langmere',
  'Merrick', 'Northgate', 'Orwell', 'Pemberton', 'Quarry', 'Ravensworth',
  'Sable', 'Thornbury', 'Underhill', 'Vandermeer', 'Whitlock', 'Yarrow',
];

const STREET_SUFFIX = ['Street', 'Avenue', 'Road', 'Lane', 'Way', 'Square', 'Terrace'];

// -------------------------------------------------------------- district styles

interface Style {
  /** Target block size before rounding, in world units. */
  block: number;
  /** Width of the local streets between blocks. */
  street: number;
  /** Weights for what a block is used for. */
  mix: Partial<Record<BlockUse, number>>;
  /** How the residential blocks are built. */
  housing: 'detached' | 'terrace' | 'apartment' | 'tower' | 'none';
  /** 0..1 street-tree density. */
  trees: number;
  /** Typical storeys for the built form here. */
  floors: [number, number];
}

type BlockUse = 'commercial' | 'residential' | 'industrial' | 'civic' | 'park' | 'parking' | 'plaza';

/**
 * How far a local street runs past the blocks it serves. It has to reach the
 * arterial along the district boundary — a street that stops short of the main
 * road is a street nothing can drive off, and a district full of them is an
 * island.
 */
const STUB = 0.014;

const STYLES: Record<DistrictId, Style> = {
  downtown: {
    block: 0.028, street: 0.0052,
    mix: { commercial: 6, civic: 1.2, plaza: 0.8, residential: 1.6, parking: 0.5 },
    housing: 'tower', trees: 0.3, floors: [4, 14],
  },
  financial: {
    block: 0.032, street: 0.0056,
    mix: { commercial: 5, civic: 1.4, plaza: 1, residential: 1, parking: 0.6 },
    housing: 'tower', trees: 0.25, floors: [6, 18],
  },
  shopping: {
    block: 0.026, street: 0.005,
    mix: { commercial: 7, plaza: 1.2, parking: 1.2, residential: 1.4 },
    housing: 'apartment', trees: 0.45, floors: [2, 5],
  },
  highend: {
    block: 0.042, street: 0.0048,
    mix: { residential: 7, park: 1.6, commercial: 1.2, civic: 0.6 },
    housing: 'detached', trees: 0.95, floors: [1, 3],
  },
  midtown: {
    block: 0.03, street: 0.0046,
    mix: { residential: 6, commercial: 2, park: 0.9, civic: 0.7, parking: 0.5 },
    housing: 'terrace', trees: 0.7, floors: [2, 5],
  },
  southside: {
    block: 0.027, street: 0.0044,
    mix: { residential: 7, commercial: 2, parking: 1, civic: 0.6, park: 0.5 },
    housing: 'apartment', trees: 0.35, floors: [3, 8],
  },
  suburbs: {
    block: 0.045, street: 0.0046,
    mix: { residential: 7, park: 1.4, commercial: 1.1, parking: 0.6 },
    housing: 'detached', trees: 0.85, floors: [1, 2],
  },
  industrial: {
    block: 0.058, street: 0.0068,
    mix: { industrial: 7, parking: 1.6, commercial: 1, civic: 0.3 },
    housing: 'none', trees: 0.1, floors: [1, 2],
  },
  warehouse: {
    block: 0.055, street: 0.0064,
    mix: { industrial: 6, parking: 2, commercial: 1.2 },
    housing: 'none', trees: 0.12, floors: [1, 2],
  },
  university: {
    block: 0.036, street: 0.0048,
    mix: { civic: 4, residential: 3, park: 2.2, commercial: 1.6, plaza: 0.8 },
    housing: 'apartment', trees: 0.9, floors: [2, 6],
  },
  entertainment: {
    block: 0.025, street: 0.005,
    mix: { commercial: 6, plaza: 1.6, residential: 1.6, parking: 1.2, civic: 0.8 },
    housing: 'apartment', trees: 0.4, floors: [2, 6],
  },
  tourist: {
    block: 0.019, street: 0.0038,
    mix: { commercial: 5, civic: 1.4, plaza: 1.6, residential: 2.4 },
    housing: 'terrace', trees: 0.55, floors: [2, 4],
  },
  waterfront: {
    block: 0.034, street: 0.005,
    mix: { commercial: 3.5, residential: 2.6, industrial: 1.6, plaza: 1, park: 0.8 },
    housing: 'apartment', trees: 0.5, floors: [2, 7],
  },
  airport: {
    block: 0.06, street: 0.0062,
    mix: { industrial: 3, parking: 3, commercial: 1.4, civic: 1 },
    housing: 'none', trees: 0.15, floors: [1, 3],
  },
  transit: {
    block: 0.03, street: 0.0052,
    mix: { commercial: 4, civic: 2, parking: 2, residential: 2, plaza: 1 },
    housing: 'apartment', trees: 0.4, floors: [2, 7],
  },
};

// ------------------------------------------------------------------ helpers

function unique(values: number[], tolerance = 0.004): number[] {
  const sorted = [...values].sort((a, b) => a - b);
  const out: number[] = [];
  for (const value of sorted) {
    if (out.length === 0 || Math.abs(value - out[out.length - 1]) > tolerance) out.push(value);
  }
  return out;
}

/** Splits a span into runs of random length between min and max. */
function runs(rng: Rng, start: number, span: number, min: number, max: number): { a: number; b: number }[] {
  const out: { a: number; b: number }[] = [];
  let cursor = start;
  const end = start + span;
  while (end - cursor > min * 0.8) {
    const width = Math.min(end - cursor, rng.range(min, max));
    out.push({ a: cursor, b: cursor + width });
    cursor += width;
  }
  // Push the last run out to the end rather than leaving a sliver.
  if (out.length > 0) out[out.length - 1].b = end;
  return out;
}

function weightedUse(rng: Rng, mix: Partial<Record<BlockUse, number>>): BlockUse {
  const entries = Object.entries(mix) as [BlockUse, number][];
  const total = entries.reduce((acc, [, weight]) => acc + weight, 0);
  let roll = rng.next() * total;
  for (const [use, weight] of entries) {
    roll -= weight;
    if (roll <= 0) return use;
  }
  return entries[0][0];
}

// ------------------------------------------------------------------ the city

/** How many trading units each district gets. Unchanged: the economy depends on it. */
export function plotCount(def: DistrictDef): number {
  const area = def.w * def.h;
  return Math.round(clamp(area * 900 * (0.6 + def.commercialActivity * 0.7), 8, 26));
}

let cached: CityLayout | null = null;

/** The city. Built once and shared; it never changes. */
export function cityLayout(): CityLayout {
  if (!cached) cached = build();
  return cached;
}

function build(): CityLayout {
  const rng = new Rng(CITY_SEED);
  const roads: Road[] = [];
  const fillers: RawFiller[] = [];
  const amenities: RawAmenity[] = [];
  const water: Rect[] = [];
  const plots: Plot[] = [];
  const parks: (Rect & { name: string })[] = [];
  const reserved: Rect[] = [];

  const left = Math.min(...DISTRICTS.map((d) => d.x));
  const right = Math.max(...DISTRICTS.map((d) => d.x + d.w));
  const top = Math.min(...DISTRICTS.map((d) => d.y));
  const bottom = Math.max(...DISTRICTS.map((d) => d.y + d.h));

  // ----------------------------------------------------------- water first
  // A river down the western edge, opening into the harbour the waterfront
  // district is named after. Everything else is laid out around it.
  const riverX = left - 0.028;
  water.push({ x: riverX - 0.03, y: top - 0.05, w: 0.05, h: bottom - top + 0.14 });
  const waterfront = DISTRICTS.find((d) => d.id === 'waterfront');
  if (waterfront) {
    water.push({ x: riverX - 0.01, y: waterfront.y + 0.02, w: 0.062, h: waterfront.h - 0.05 });
  }

  // ------------------------------------------------------- arterial grid
  // The gaps between districts are the main roads: every district is a
  // superblock, which is how most cities actually read from above.
  // Both edges of every district, not just the far one: where two districts do
  // not quite touch, the gap between them is a main road as well, and without
  // it the near side of one of them fronts onto nothing.
  const verticals = unique([left, ...DISTRICTS.flatMap((d) => [d.x, d.x + d.w]), right], 0.009);
  const horizontals = unique([top, ...DISTRICTS.flatMap((d) => [d.y, d.y + d.h]), bottom], 0.009);

  const ARTERIAL_W = 0.0092;
  const usedNames = new Set<string>();
  const roadName = (): string => {
    for (let attempt = 0; attempt < 40; attempt += 1) {
      const name = `${rng.pick(STREET_NAMES)} ${rng.pick(STREET_SUFFIX)}`;
      if (!usedNames.has(name)) {
        usedNames.add(name);
        return name;
      }
    }
    return `${rng.pick(STREET_NAMES)} Street`;
  };

  // The arterial runs along the boundary itself. Anything else and the local
  // streets either miss it or drive into the district next door.
  for (const x of verticals) {
    const centre = x;
    roads.push({
      cls: 'arterial',
      pts: [
        { x: centre, y: top - 0.045 },
        { x: centre, y: bottom + 0.045 },
      ],
      width: ARTERIAL_W,
      name: roadName(),
      major: true,
    });
  }
  for (const y of horizontals) {
    const centre = y;
    roads.push({
      cls: 'arterial',
      pts: [
        { x: left - 0.05, y: centre },
        { x: right + 0.05, y: centre },
      ],
      width: ARTERIAL_W,
      name: roadName(),
      major: true,
    });
  }

  // Two diagonals, because a city laid out purely on a grid looks like a
  // spreadsheet. They cut corners off the blocks they pass through.
  const diagonals: Road[] = [
    {
      cls: 'arterial',
      pts: [
        { x: left - 0.04, y: top + 0.02 },
        { x: 0.44, y: 0.33 },
        { x: 0.62, y: 0.48 },
        { x: right + 0.04, y: 0.66 },
      ],
      width: 0.0078,
      name: roadName(),
      major: true,
    },
    {
      cls: 'arterial',
      pts: [
        { x: 0.2, y: bottom + 0.04 },
        { x: 0.36, y: 0.73 },
        { x: 0.52, y: 0.6 },
        { x: 0.66, y: 0.3 },
        { x: 0.74, y: top - 0.04 },
      ],
      width: 0.0072,
      name: roadName(),
      major: true,
    },
  ];
  roads.push(...diagonals);

  // Roundabouts where the diagonals meet the grid, and signals elsewhere.
  amenities.push({ kind: 'fountain', x: 0.44, y: 0.33, r: 0.0075 });
  amenities.push({ kind: 'fountain', x: 0.66, y: 0.3, r: 0.0068 });
  amenities.push({ kind: 'fountain', x: 0.36, y: 0.73, r: 0.0062 });

  for (const x of verticals) {
    for (const y of horizontals) {
      amenities.push({ kind: 'signal', x, y, r: 0.0016 });
    }
  }

  // ----------------------------------------------------------- the railway
  // In from the north, into the transport hub, then east–west across the city
  // in its own corridor just above the central arterial.
  const railY = 0.2985;
  roads.push({
    cls: 'rail',
    pts: [
      { x: left - 0.05, y: railY },
      { x: right + 0.05, y: railY },
    ],
    width: 0.0042,
    name: 'Northgate Main Line',
    major: true,
  });
  roads.push({
    cls: 'rail',
    pts: [
      { x: 0.503, y: top - 0.05 },
      { x: 0.503, y: railY },
    ],
    width: 0.0042,
    name: null,
    major: true,
  });

  const transit = DISTRICTS.find((d) => d.id === 'transit');
  if (transit) {
    // The station takes its land out of the district before the blocks are
    // laid out, so nothing is built on the platforms.
    reserved.push({ x: transit.x + 0.016, y: transit.y + 0.08, w: 0.1, h: 0.125 });
    // The station: platforms along the branch, a concourse beside them.
    for (let i = 0; i < 4; i += 1) {
      fillers.push({
        kind: 'platform',
        x: 0.4915 + i * 0.0055,
        y: transit.y + 0.085,
        w: 0.0032,
        h: 0.115,
        floors: 1,
        tone: 0.5,
        district: 'transit',
      });
    }
    fillers.push({
      kind: 'terminal',
      x: transit.x + 0.02,
      y: transit.y + 0.09,
      w: 0.036,
      h: 0.07,
      floors: 3,
      tone: 0.62,
      district: 'transit',
    });
    fillers.push({
      kind: 'plaza',
      x: transit.x + 0.02,
      y: transit.y + 0.165,
      w: 0.05,
      h: 0.03,
      floors: 0,
      tone: 0.5,
      district: 'transit',
    });
  }

  // ------------------------------------------------------------- the airport
  const airport = DISTRICTS.find((d) => d.id === 'airport');
  if (airport) {
    // The airfield: runway, taxiways, hangars and terminal. Nothing else is
    // built on it, so the blocks stop at the fence.
    reserved.push({ x: airport.x, y: airport.y, w: airport.w * 0.6, h: airport.h });
  }
  if (airport) {
    const runwayY = airport.y + airport.h * 0.34;
    roads.push({
      cls: 'runway',
      pts: [
        { x: airport.x + 0.006, y: runwayY },
        { x: airport.x + airport.w - 0.006, y: runwayY },
      ],
      width: 0.011,
      name: 'Runway 09/27',
      major: false,
    });
    roads.push({
      cls: 'taxiway',
      pts: [
        { x: airport.x + 0.012, y: runwayY + 0.036 },
        { x: airport.x + airport.w - 0.012, y: runwayY + 0.036 },
      ],
      width: 0.005,
      name: null,
      major: false,
    });
    for (let i = 0; i < 3; i += 1) {
      const x = airport.x + 0.03 + i * 0.05;
      roads.push({
        cls: 'taxiway',
        pts: [
          { x, y: runwayY },
          { x, y: runwayY + 0.036 },
        ],
        width: 0.004,
        name: null,
        major: false,
      });
    }
    fillers.push({
      kind: 'terminal',
      x: airport.x + 0.028,
      y: runwayY + 0.045,
      w: 0.11,
      h: 0.035,
      floors: 3,
      tone: 0.66,
      district: 'airport',
    });
    for (let i = 0; i < 4; i += 1) {
      fillers.push({
        kind: 'hangar',
        x: airport.x + 0.014 + i * 0.038,
        y: airport.y + 0.018,
        w: 0.031,
        h: 0.03,
        floors: 1,
        tone: 0.42 + i * 0.04,
        district: 'airport',
      });
    }
    fillers.push({
      kind: 'parking',
      x: airport.x + 0.028,
      y: runwayY + 0.088,
      w: 0.11,
      h: 0.042,
      floors: 0,
      tone: 0.5,
      district: 'airport',
    });
    amenities.push({ kind: 'mast', x: airport.x + airport.w - 0.02, y: runwayY + 0.05, r: 0.004 });
  }

  // -------------------------------------------------------------- districts
  for (const def of DISTRICTS) {
    buildDistrict(def, rng, { reserved, roads, fillers, amenities, water, plots, parks }, roadName);
  }

  buildCountryside(rng, fillers, amenities, { left, right, top, bottom });

  return {
    roads,
    fillers: fillers.map((f, i) => ({ ...f, asset: assetForFiller(f, i) })),
    amenities: amenities.map((a, i) => ({ ...a, asset: assetForAmenity(a, i) })),
    water,
    plots,
    parks,
  };
}

/**
 * The land the city stands on.
 *
 * Northgate does not stop at a hard edge. Beyond the ring road there are
 * fields, orchards, pasture, glasshouses, a solar farm and a line of turbines
 * on the ridge — the pack's whole agriculture and energy set, put where those
 * things actually are. It also gives the map somewhere to zoom out to.
 */
function buildCountryside(
  rng: Rng,
  fillers: RawFiller[],
  amenities: RawAmenity[],
  bounds: { left: number; right: number; top: number; bottom: number },
): void {
  const { left, right, top, bottom } = bounds;
  // The solar farm and the line of turbines go down first, and the fields are
  // laid out around them rather than through them.
  const taken: Rect[] = [
    { x: left - 0.175, y: bottom - 0.12, w: 0.09, h: 0.08 },
  ];
  fillers.push({
    kind: 'solar', x: left - 0.175, y: bottom - 0.12, w: 0.09, h: 0.08,
    floors: 0, tone: 0.5, district: 'outskirts',
  });
  for (let i = 0; i < 7; i += 1) {
    const x = right + 0.07 + (i % 2) * 0.045;
    const y = top + 0.04 + i * 0.1;
    taken.push({ x: x - 0.006, y: y - 0.006, w: 0.034, h: 0.034 });
    fillers.push({
      kind: 'turbine', x, y, w: 0.022, h: 0.022,
      floors: 0, tone: 0.5, district: 'outskirts',
    });
  }
  const clash = (r: Rect): boolean =>
    taken.some((t) => r.x + r.w > t.x && t.x + t.w > r.x && r.y + r.h > t.y && t.y + t.h > r.y);

  const belts = [
    { x: left - 0.2, y: top - 0.18, w: 0.17, h: bottom - top + 0.36 },
    { x: right + 0.03, y: top - 0.18, w: 0.18, h: bottom - top + 0.36 },
    { x: left - 0.03, y: top - 0.18, w: right - left + 0.06, h: 0.15 },
    { x: left - 0.03, y: bottom + 0.03, w: right - left + 0.06, h: 0.15 },
  ];
  const uses: FillerKind[] = ['field', 'field', 'pasture', 'field', 'orchard', 'pasture', 'field', 'glasshouse'];
  let n = 0;

  /**
   * Fields are not a chequerboard. Each parcel is split along its longer side
   * at a point the dice choose, down to something the size of a real field, so
   * the land beyond the ring road reads as farmland rather than graph paper.
   */
  const parcel = (r: Rect, depth: number): void => {
    const small = r.w < 0.055 && r.h < 0.055;
    if (!small && depth < 4) {
      const alongX = r.w >= r.h;
      const cut = rng.range(0.34, 0.66);
      const gap = 0.0024;
      if (alongX) {
        parcel({ x: r.x, y: r.y, w: r.w * cut - gap, h: r.h }, depth + 1);
        parcel({ x: r.x + r.w * cut + gap, y: r.y, w: r.w * (1 - cut) - gap, h: r.h }, depth + 1);
      } else {
        parcel({ x: r.x, y: r.y, w: r.w, h: r.h * cut - gap }, depth + 1);
        parcel({ x: r.x, y: r.y + r.h * cut + gap, w: r.w, h: r.h * (1 - cut) - gap }, depth + 1);
      }
      return;
    }
    if (r.w < 0.012 || r.h < 0.012) return;
    if (clash(r)) return;
    // A third of the land is left rough: copses, scrub, nothing in particular.
    if (rng.chance(0.3)) {
      const clump = 2 + Math.floor(rng.next() * 5);
      for (let t = 0; t < clump; t += 1) {
        amenities.push({
          kind: 'tree',
          x: r.x + rng.next() * r.w,
          y: r.y + rng.next() * r.h,
          r: rng.range(0.0024, 0.0046),
        });
      }
      return;
    }
    const kind = uses[n % uses.length];
    n += 1;
    fillers.push({
      kind, x: r.x, y: r.y, w: r.w, h: r.h,
      floors: kind === 'glasshouse' ? 1 : 0,
      tone: rng.next(),
      district: 'outskirts',
    });
    // A hedge line along one boundary, and a farmstead on the bigger holdings.
    if (rng.chance(0.45)) {
      const vertical = rng.chance(0.5);
      amenities.push({
        kind: 'hedge',
        x: vertical ? r.x : r.x + r.w / 2,
        y: vertical ? r.y + r.h / 2 : r.y,
        r: (vertical ? r.h : r.w) * 0.25,
        vertical,
      });
    }
    if (kind !== 'glasshouse' && r.w > 0.03 && r.h > 0.025 && rng.chance(0.22)) {
      fillers.push({
        kind: 'farmstead',
        x: r.x + r.w * 0.08, y: r.y + r.h * 0.08,
        w: Math.min(r.w * 0.3, 0.014), h: Math.min(r.h * 0.28, 0.011),
        floors: 1, tone: rng.next(), district: 'outskirts',
      });
    }
  };

  for (const belt of belts) parcel(belt, 0);
}

/**
 * Which asset from the pack a structure is built as.
 *
 * The choice is made once, when the city is generated, and it is deterministic:
 * the same warehouse is the same warehouse every session. Districts pull on it,
 * so the financial district is offices and towers while Southside is social
 * housing and terraces — the pack has all of them, and putting the right one in
 * the right place is most of what makes a map read as a city.
 */
function assetForFiller(f: RawFiller, index: number): string {
  const key = `${f.kind}|${f.district}|${index}`;
  switch (f.kind) {
    case 'house':
      return pick(f.district === 'highend' || f.district === 'suburbs'
        ? ['detached-house', 'villa', 'semi-detached']
        : ['semi-detached', 'detached-house', 'tiny-house'], key);
    case 'terrace':
      return pick(['terrace', 'social-housing', 'student-house'], key);
    case 'apartment':
      return pick(f.district === 'university'
        ? ['student-house', 'apartment-block', 'social-housing']
        : ['apartment-block', 'social-housing'], key);
    case 'tower':
      return pick(['curtain-wall-tower', 'head-office', 'office-block'], key);
    case 'office':
      return pick(OFFICES, key);
    case 'retail':
      return pick(SHOPS, key);
    case 'shed':
      return pick(f.district === 'industrial'
        ? ['brick-works', 'foundry', 'assembly-plant', 'machine-shop', 'steelworks', 'textile-mill', 'food-processing', 'recycling-centre']
        : ['small-warehouse', 'warehouse', 'large-warehouse', 'distribution-centre', 'cold-store', 'sorting-office'], key);
    case 'hangar':
      return pick(['transhipment-yard', 'container-terminal', 'large-warehouse'], key);
    case 'civic':
      return pick(CIVIC, key);
    case 'hotel':
      return pick(['hotel', 'small-hotel', 'restaurant', 'cinema', 'gym'], key);
    case 'terminal':
      return f.district === 'airport' ? 'airport' : 'station';
    case 'platform':
      return 'station';
    case 'quay':
      return 'harbour';
    case 'park':
      return pick(['city-park', 'city-park', 'petting-farm', 'cemetery'], key);
    case 'plaza':
      return pick(['market-square', 'terrace-seating'], key);
    case 'pitch':
      return 'city-park';
    case 'parking':
      return 'market-square';
    case 'field':
      return 'arable-field';
    case 'orchard':
      return pick(['orchard', 'fruit-plantation'], key);
    case 'pasture':
      return 'pasture';
    case 'glasshouse':
      return 'glasshouse';
    case 'solar':
      return 'solar-farm';
    case 'turbine':
      return 'wind-turbine';
    case 'farmstead':
      return pick(['farmhouse', 'poultry-shed', 'livestock-shed'], key);
    default:
      return 'office-block';
  }
}

const OFFICES = [
  'glass-office', 'courtyard-office', 'business-centre', 'corner-office',
  'head-office', 'rooftop-garden-office', 'office-block', 'chambers', 'riverside-office',
];
const SHOPS = [
  'supermarket', 'electronics-store', 'clothing-store', 'furniture-store',
  'builders-merchant', 'sports-shop', 'pharmacy', 'car-showroom', 'shopping-centre',
  'filling-station', 'cafe', 'restaurant', 'bank',
];
const CIVIC = [
  'school', 'town-hall', 'courthouse', 'police-station', 'fire-station',
  'hospital', 'university', 'bank', 'events-hall', 'research-centre', 'data-centre',
];
const TREES = ['oak', 'beech', 'pine', 'birch', 'oak', 'beech'];

function assetForAmenity(a: RawAmenity, index: number): string {
  switch (a.kind) {
    case 'tree':
      return pick(TREES, `tree|${index}`);
    case 'light':
      return 'street-light';
    case 'bus':
      return 'bus-stop';
    case 'signal':
      return 'traffic-light';
    case 'fountain':
      return 'fountain';
    case 'mast':
      return 'telecom-mast';
    case 'bench':
      return 'bench';
    case 'planter':
      return pick(['planter', 'flowers'], `planter|${index}`);
    case 'hedge':
      return 'hedge';
    case 'shrub':
      return pick(['shrubs', 'rocks'], `shrub|${index}`);
    case 'bin':
      return 'litter-bin';
    case 'railings':
      return 'railings';
    default:
      return 'shrubs';
  }
}

/** A stable choice from a list, by name rather than by dice. */
function pick(pool: string[], key: string): string {
  let h = 2166136261;
  for (let i = 0; i < key.length; i += 1) {
    h ^= key.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return pool[(h >>> 0) % pool.length];
}

interface Sink {
  /** Land already spoken for: the station, the airfield, the quays. */
  reserved: Rect[];
  roads: Road[];
  fillers: RawFiller[];
  amenities: RawAmenity[];
  water: Rect[];
  plots: Plot[];
  parks: (Rect & { name: string })[];
}

function buildDistrict(def: DistrictDef, rng: Rng, sink: Sink, roadName: () => string): void {
  const style = STYLES[def.id];
  const inset = 0.005;
  const area: Rect = {
    x: def.x + inset,
    y: def.y + inset,
    w: def.w - inset * 2,
    h: def.h - inset * 2,
  };

  // Waterfront gives up its western strip to the harbour, and gets a quay.
  if (def.id === 'waterfront') {
    const quayW = 0.03;
    sink.fillers.push({
      kind: 'quay',
      x: area.x,
      y: area.y,
      w: quayW,
      h: area.h,
      floors: 0,
      tone: 0.5,
      district: def.id,
    });
    for (let i = 0; i < 5; i += 1) {
      sink.fillers.push({
        kind: 'shed',
        x: area.x + 0.004,
        y: area.y + 0.012 + i * 0.042,
        w: 0.021,
        h: 0.03,
        floors: 1,
        tone: 0.4 + i * 0.05,
        district: def.id,
      });
    }
    area.x += quayW + 0.004;
    area.w -= quayW + 0.004;
  }

  // The airport keeps most of its land for aviation; only the eastern strip
  // is ordinary streets.
  if (def.id === 'airport') {
    area.x += area.w * 0.6;
    area.w *= 0.4;
  }

  // Always at least two of each, so every block has a street on all four sides
  // and no shop ends up in the middle of a superblock with no road to it.
  const columns = Math.max(2, Math.round(area.w / style.block));
  const rows = Math.max(2, Math.round(area.h / style.block));
  const cellW = area.w / columns;
  const cellH = area.h / rows;
  const sw = style.street;

  // Local streets between the blocks, named per district.
  const nameA = roadName();
  const nameB = roadName();
  for (let c = 1; c < columns; c += 1) {
    const x = area.x + c * cellW;
    sink.roads.push({
      cls: c % 2 === 0 ? 'street' : 'lane',
      pts: [
        { x, y: area.y - STUB },
        { x, y: area.y + area.h + STUB },
      ],
      width: c % 2 === 0 ? sw : sw * 0.78,
      name: c === Math.floor(columns / 2) ? nameA : null,
      major: false,
    });
  }
  for (let r = 1; r < rows; r += 1) {
    const y = area.y + r * cellH;
    sink.roads.push({
      cls: r % 2 === 0 ? 'street' : 'lane',
      pts: [
        { x: area.x - STUB, y },
        { x: area.x + area.w + STUB, y },
      ],
      width: r % 2 === 0 ? sw : sw * 0.78,
      name: r === Math.floor(rows / 2) ? nameB : null,
      major: false,
    });
  }

  // Every block, and what it is used for.
  interface Block extends Rect {
    use: BlockUse;
    edge: boolean;
    corner: boolean;
    /** Whether the block's north or south side faces one of the main roads. */
    topEdge: boolean;
    bottomEdge: boolean;
  }
  const blocks: Block[] = [];
  for (let r = 0; r < rows; r += 1) {
    for (let c = 0; c < columns; c += 1) {
      const x = area.x + c * cellW + sw / 2;
      const y = area.y + r * cellH + sw / 2;
      const w = cellW - sw;
      const h = cellH - sw;
      if (w < 0.004 || h < 0.004) continue;
      // Land already taken by the station or the airfield is not built on.
      if (sink.reserved.some((res) => x + w > res.x && res.x + res.w > x && y + h > res.y && res.y + res.h > y)) continue;
      const edge = c === 0 || c === columns - 1 || r === 0 || r === rows - 1;
      const corner = (c === 0 || c === columns - 1) && (r === 0 || r === rows - 1);
      // Commercial uses cluster on the main roads, which is where the trade is.
      const mix = { ...style.mix };
      if (edge && mix.commercial) mix.commercial *= 1.35;
      if (!edge && mix.commercial) mix.commercial *= 0.85;
      blocks.push({
        x, y, w, h,
        use: weightedUse(rng, mix),
        edge,
        corner,
        topEdge: r === 0,
        bottomEdge: r === rows - 1,
      });
    }
  }

  // The trading units come out of the commercial frontages, best first.
  const quota = plotCount(def);
  const candidates = blocks
    .filter((b) => b.use === 'commercial')
    .sort((a, b) => Number(b.corner) - Number(a.corner) || Number(b.edge) - Number(a.edge));
  // If the dice gave too few commercial blocks, convert the best others.
  if (candidates.length * 2.4 < quota) {
    for (const block of blocks) {
      if (candidates.length * 2.4 >= quota) break;
      if (block.use === 'commercial' || block.use === 'park' || block.use === 'civic') continue;
      block.use = 'commercial';
      candidates.push(block);
    }
    candidates.sort((a, b) => Number(b.corner) - Number(a.corner) || Number(b.edge) - Number(a.edge));
  }

  const streetA = `${rng.pick(STREET_NAMES)} ${rng.pick(STREET_SUFFIX)}`;
  const streetB = `${rng.pick(STREET_NAMES)} ${rng.pick(STREET_SUFFIX)}`;
  let made = 0;

  for (const block of candidates) {
    if (made >= quota) {
      // Left-over commercial blocks still get built on — as scenery.
      fillCommercialBlock(block, def, style, rng, sink, null);
      continue;
    }
    made = fillCommercialBlock(block, def, style, rng, sink, {
      quota,
      made,
      streetA,
      streetB,
    });
  }

  // If the dice still left the district short, the next best blocks become
  // parades of shops too. The quota is what the economy is balanced against,
  // so it is never allowed to slip.
  const rest = blocks.filter((b) => b.use !== 'commercial');
  for (const block of rest) {
    if (made >= quota) break;
    if (block.use === 'park' || block.use === 'plaza') continue;
    block.use = 'commercial';
    made = fillCommercialBlock(block, def, style, rng, sink, { quota, made, streetA, streetB });
  }

  for (const block of blocks) {
    if (block.use === 'commercial') continue;
    fillBlock(block, def, style, rng, sink);
  }

  // Street trees and lighting, thinned by district character.
  const treeBudget = Math.round(style.trees * 120);
  for (let i = 0; i < treeBudget; i += 1) {
    const vertical = rng.chance(0.5);
    const along = vertical ? area.y + rng.next() * area.h : area.x + rng.next() * area.w;
    const line = vertical
      ? area.x + Math.max(1, Math.round(rng.next() * columns)) * cellW
      : area.y + Math.max(1, Math.round(rng.next() * rows)) * cellH;
    const offset = (rng.chance(0.5) ? -1 : 1) * (sw * 0.62 + 0.0012);
    const point = vertical ? { x: line + offset, y: along } : { x: along, y: line + offset };
    if (point.x < def.x || point.x > def.x + def.w || point.y < def.y || point.y > def.y + def.h) continue;
    sink.amenities.push({ kind: 'tree', x: point.x, y: point.y, r: rng.range(0.0014, 0.0026) });
  }

  // Bus stops on the district's own main street.
  for (let i = 0; i < 3; i += 1) {
    sink.amenities.push({
      kind: 'bus',
      x: area.x + area.w * ((i + 0.5) / 3),
      y: area.y + Math.floor(rows / 2) * cellH + 0.0032,
      r: 0.0022,
    });
  }
}

/**
 * Lays a commercial block out as a parade of shops around the street frontage,
 * with servicing behind. Returns how many trading units have been created.
 */
function fillCommercialBlock(
  block: { x: number; y: number; w: number; h: number; edge: boolean; corner: boolean; topEdge: boolean; bottomEdge: boolean },
  def: DistrictDef,
  style: Style,
  rng: Rng,
  sink: Sink,
  quotaState: { quota: number; made: number; streetA: string; streetB: string } | null,
): number {
  const depth = Math.min(block.h * 0.4, 0.011);
  const minWidth = def.id === 'tourist' ? 0.0052 : 0.0075;
  const maxWidth = def.id === 'industrial' || def.id === 'warehouse' ? 0.03 : 0.016;

  // The front row faces the street at the top of the block, the back row the
  // street below it; the strip between them is servicing and parking.
  // Which side a unit faces is the whole of its location value. The north side
  // of a block on the district boundary is a main road; the south side of the
  // same block is the service road behind the shops.
  const rows: { y: number; h: number; frontage: Frontage }[] = [
    { y: block.y, h: depth, frontage: block.topEdge ? 'arterial' : 'street' },
  ];
  if (block.h > depth * 1.9) {
    rows.push({
      y: block.y + block.h - depth,
      h: depth,
      frontage: block.bottomEdge ? 'arterial' : 'back',
    });
  }

  let made = quotaState?.made ?? 0;

  for (const row of rows) {
    for (const run of runs(rng, block.x, block.w, minWidth, maxWidth)) {
      const w = run.b - run.a - 0.0006;
      if (w < 0.003) continue;
      const isCorner = run.a <= block.x + 0.0001 || run.b >= block.x + block.w - 0.0001;

      if (quotaState && made < quotaState.quota) {
        made += 1;
        const number = made * 2 + rng.int(0, 1);
        sink.plots.push({
          id: `${def.id}-${made}`,
          district: def.id,
          x: run.a,
          y: row.y,
          w,
          h: row.h,
          frontage: row.frontage,
          corner: isCorner && row.frontage !== 'back',
          weight: clamp((w * row.h) / (0.013 * 0.011), 0.25, 1),
          street: made % 2 === 0 ? quotaState.streetA : quotaState.streetB,
          number,
        });
      } else {
        sink.fillers.push({
          kind: 'retail',
          x: run.a,
          y: row.y,
          w,
          h: row.h,
          floors: rng.int(style.floors[0], style.floors[1]),
          tone: rng.next(),
          district: def.id,
        });
      }
    }
  }

  // What sits behind the shops.
  const backY = block.y + depth + 0.0012;
  const backH = block.h - depth * (rows.length === 2 ? 2 : 1) - 0.0024;
  if (backH > 0.004) {
    sink.fillers.push({
      kind: rng.chance(0.62) ? 'parking' : 'office',
      x: block.x + 0.001,
      y: backY,
      w: block.w - 0.002,
      h: backH,
      floors: rng.int(1, 3),
      tone: rng.next(),
      district: def.id,
    });
  }

  return made;
}

/** Everything that is not a shop: housing, works, parks, civic buildings. */
function fillBlock(
  block: { x: number; y: number; w: number; h: number; use: BlockUse; edge: boolean },
  def: DistrictDef,
  style: Style,
  rng: Rng,
  sink: Sink,
): void {
  const { x, y, w, h, use } = block;

  if (use === 'park') {
    sink.fillers.push({ kind: 'park', x, y, w, h, floors: 0, tone: rng.next(), district: def.id });
    if (w * h > 0.0009) {
      sink.parks.push({ x, y, w, h, name: `${rng.pick(STREET_NAMES)} ${rng.chance(0.5) ? 'Park' : 'Gardens'}` });
    }
    const trees = Math.round(clamp((w * h) / 0.000012, 6, 90));
    for (let i = 0; i < trees; i += 1) {
      sink.amenities.push({
        kind: 'tree',
        x: x + rng.range(0.0015, w - 0.0015),
        y: y + rng.range(0.0015, h - 0.0015),
        r: rng.range(0.0016, 0.0032),
      });
    }
    if (w > 0.02 && h > 0.02 && rng.chance(0.4)) {
      sink.fillers.push({
        kind: 'pitch',
        x: x + w * 0.2,
        y: y + h * 0.3,
        w: w * 0.55,
        h: h * 0.38,
        floors: 0,
        tone: 0.5,
        district: def.id,
      });
    }
    return;
  }

  if (use === 'plaza') {
    sink.fillers.push({ kind: 'plaza', x, y, w, h, floors: 0, tone: rng.next(), district: def.id });
    if (rng.chance(0.5)) sink.amenities.push({ kind: 'fountain', x: x + w / 2, y: y + h / 2, r: Math.min(w, h) * 0.16 });
    for (let i = 0; i < 5; i += 1) {
      sink.amenities.push({
        kind: 'tree',
        x: x + rng.range(0.002, w - 0.002),
        y: y + rng.range(0.002, h - 0.002),
        r: rng.range(0.0014, 0.0022),
      });
    }
    return;
  }

  if (use === 'parking') {
    sink.fillers.push({ kind: 'parking', x, y, w, h, floors: 0, tone: rng.next(), district: def.id });
    return;
  }

  if (use === 'industrial') {
    // One or two big sheds with a yard.
    const count = w > 0.04 ? 2 : 1;
    for (let i = 0; i < count; i += 1) {
      sink.fillers.push({
        kind: rng.chance(0.25) ? 'hangar' : 'shed',
        x: x + 0.002 + (i * (w - 0.004)) / count,
        y: y + 0.002,
        w: (w - 0.004) / count - 0.002,
        h: h * rng.range(0.5, 0.72),
        floors: rng.int(1, 2),
        tone: rng.next(),
        district: def.id,
      });
    }
    sink.fillers.push({
      kind: 'parking',
      x: x + 0.002,
      y: y + h * 0.78,
      w: w - 0.004,
      h: h * 0.2,
      floors: 0,
      tone: rng.next(),
      district: def.id,
    });
    return;
  }

  if (use === 'civic') {
    const inset = Math.min(w, h) * 0.16;
    sink.fillers.push({
      kind: rng.chance(0.3) ? 'hotel' : 'civic',
      x: x + inset,
      y: y + inset,
      w: w - inset * 2,
      h: h - inset * 2,
      floors: rng.int(style.floors[0] + 1, style.floors[1]),
      tone: rng.next(),
      district: def.id,
    });
    for (let i = 0; i < 6; i += 1) {
      sink.amenities.push({
        kind: 'tree',
        x: x + rng.range(0.001, w - 0.001),
        y: y + rng.range(0.001, h - 0.001),
        r: rng.range(0.0014, 0.0024),
      });
    }
    return;
  }

  // Residential, built the way this district builds.
  switch (style.housing) {
    case 'detached': {
      const plot = 0.0088;
      const cols = Math.max(1, Math.floor(w / plot));
      const rws = Math.max(1, Math.floor(h / plot));
      for (let c = 0; c < cols; c += 1) {
        for (let r = 0; r < rws; r += 1) {
          if (rng.chance(0.12)) continue; // gaps, gardens, the odd empty plot
          const cw = w / cols;
          const ch = h / rws;
          const size = rng.range(0.45, 0.62);
          sink.fillers.push({
            kind: 'house',
            x: x + c * cw + cw * (1 - size) * 0.5,
            y: y + r * ch + ch * (1 - size) * 0.5,
            w: cw * size,
            h: ch * size,
            floors: rng.int(1, 2),
            tone: rng.next(),
            district: def.id,
          });
          if (rng.chance(0.5)) {
            sink.amenities.push({
              kind: 'tree',
              x: x + c * cw + cw * rng.range(0.1, 0.9),
              y: y + r * ch + ch * rng.range(0.1, 0.9),
              r: rng.range(0.0014, 0.0024),
            });
          }
        }
      }
      return;
    }
    case 'terrace': {
      const depth = Math.min(h * 0.34, 0.009);
      for (const row of [y, y + h - depth]) {
        for (const run of runs(rng, x, w, 0.0026, 0.0042)) {
          sink.fillers.push({
            kind: 'terrace',
            x: run.a,
            y: row,
            w: run.b - run.a - 0.0003,
            h: depth,
            floors: rng.int(2, 3),
            tone: rng.next(),
            district: def.id,
          });
        }
      }
      return;
    }
    case 'apartment': {
      const count = Math.max(1, Math.round(w / 0.016));
      for (let i = 0; i < count; i += 1) {
        const bw = (w - 0.003 * (count + 1)) / count;
        sink.fillers.push({
          kind: 'apartment',
          x: x + 0.003 + i * (bw + 0.003),
          y: y + 0.0025,
          w: bw,
          h: h - 0.005,
          floors: rng.int(style.floors[0], style.floors[1]),
          tone: rng.next(),
          district: def.id,
        });
      }
      return;
    }
    case 'tower': {
      const inset = Math.min(w, h) * rng.range(0.1, 0.2);
      sink.fillers.push({
        kind: 'tower',
        x: x + inset,
        y: y + inset,
        w: w - inset * 2,
        h: h - inset * 2,
        floors: rng.int(style.floors[0], style.floors[1]),
        tone: rng.next(),
        district: def.id,
      });
      return;
    }
    default: {
      sink.fillers.push({
        kind: 'shed',
        x: x + 0.002,
        y: y + 0.002,
        w: w - 0.004,
        h: h - 0.004,
        floors: 1,
        tone: rng.next(),
        district: def.id,
      });
    }
  }
}
