import type { GameState } from './state';
import { absoluteHour, buildingById, businessById, employeesOf, playerBusinesses, playerCompany } from './state';
import type { Business, PurchaseOrder, Warehouse } from './types';
import { businessTypeOrThrow } from '../data/businessTypes';
import { supplier } from '../data/suppliers';
import { product } from '../data/products';
import { storageFree } from './business';
import { unitPrice } from './procurement';
import { post, postNonCash } from './finance';
import { generateApplicant } from './employees';
import { recruitmentFee } from './headOffice';
import { role } from '../data/roles';
import { pushAlert } from './alerts';
import { pushNews } from './news';
import { money } from './format';
import { clamp, makeId, sum } from './util';
import { researchFactor } from './research';

/**
 * Distribution.
 *
 * One shop buys from suppliers. Several shops buying separately is how a small
 * chain quietly loses money: every order pays its own delivery, misses the
 * volume discount, and waits on its own lead time.
 *
 * A warehouse changes that shape. You buy in bulk into one building and your
 * shops pull from it overnight — no lead time, no minimum order, no supplier
 * letting you down mid-week. What it costs is rent, wages, vans, and the cash
 * tied up in stock sitting on a rack instead of on a shelf. With one shop it is
 * a straightforward waste of money; with four it is usually the difference
 * between a chain and four shops.
 */

/** Racking means a warehouse holds several times what a shop's back room does. */
export const RACKING_FACTOR = 4;

/** What one van run costs, whoever drives it. */
export const TRIP_COST = 28;

/** Deliveries a warehouse can make in a day before it needs another driver. */
export const TRIPS_PER_DRIVER = 4;
export const BASE_TRIPS = 2;

export function warehousesOf(state: GameState): Warehouse[] {
  return state.warehouses.filter((w) => w.companyId === state.playerCompanyId);
}

export function warehouseById(state: GameState, id: string): Warehouse | undefined {
  return state.warehouses.find((w) => w.id === id);
}

export function capacityOf(state: GameState, warehouse: Warehouse): number {
  const building = buildingById(state, warehouse.buildingId);
  if (!building) return 0;
  // Taller racks and machines that can reach them hold more in the same shed.
  return building.storageCapacity * RACKING_FACTOR * researchFactor(state, 'capacity');
}

export function usedSpace(warehouse: Warehouse): number {
  return sum(Object.entries(warehouse.stock), ([productId, units]) => {
    const def = product(productId);
    return def ? units * def.volume : 0;
  });
}

export function freeSpace(state: GameState, warehouse: Warehouse): number {
  return Math.max(0, capacityOf(state, warehouse) - usedSpace(warehouse));
}

/** Value of everything on the racks, at what it cost to buy. */
export function stockValue(warehouse: Warehouse): number {
  return sum(Object.entries(warehouse.stock), ([productId, units]) => {
    const def = product(productId);
    return units * (warehouse.costBasis[productId] ?? def?.wholesalePrice ?? 0);
  });
}

/** How many runs this warehouse can make today. */
export function tripsPerDay(state: GameState, warehouse: Warehouse): number {
  const drivers = employeesOf(state, warehouse.id).filter((e) => e.role === 'driver').length;
  return Math.floor(BASE_TRIPS + drivers * TRIPS_PER_DRIVER * researchFactor(state, 'trips'));
}

/** Everything a player needs to decide whether a building can be a warehouse. */
export function canConvert(state: GameState, buildingId: string): { ok: boolean; message: string } {
  const building = buildingById(state, buildingId);
  if (!building) return { ok: false, message: 'Unknown building.' };
  if (building.occupantCompanyId !== state.playerCompanyId) {
    return { ok: false, message: 'You have to lease or buy the unit first.' };
  }
  if (building.businessId) return { ok: false, message: 'There is a business trading here.' };
  if (state.warehouses.some((w) => w.buildingId === buildingId)) {
    return { ok: false, message: 'This is already a distribution centre.' };
  }
  if (building.storageCapacity < 400) {
    return { ok: false, message: `Too small to be worth racking out — ${building.storageCapacity} units of storage.` };
  }
  return { ok: true, message: `Racking out ${building.address} gives you ${building.storageCapacity * RACKING_FACTOR} units of space.` };
}

export const FIT_OUT_COST = 6500;

/** Turns a building the company already holds into a distribution centre. */
export function openWarehouse(state: GameState, buildingId: string, name: string): { ok: boolean; message: string } {
  const check = canConvert(state, buildingId);
  if (!check.ok) return check;
  const company = playerCompany(state);
  if (company.cash < FIT_OUT_COST) {
    return { ok: false, message: `Racking, a loading bay and a forklift cost ${money(FIT_OUT_COST)}.` };
  }
  const building = buildingById(state, buildingId);
  if (!building) return { ok: false, message: 'Unknown building.' };

  post(state, company.id, 'equipment', `Warehouse fit-out — ${building.address}`, -FIT_OUT_COST, null);
  const warehouse: Warehouse = {
    id: makeId('wh'),
    companyId: company.id,
    buildingId,
    name: name.trim().slice(0, 40) || `${company.name} Distribution`,
    stock: {},
    costBasis: {},
    employeeIds: [],
    autoDispatch: true,
    openedOnDay: state.day,
    dispatchedToday: 0,
  };
  state.warehouses.push(warehouse);
  pushNews(state, 'company', `${warehouse.name} is open`, `${building.address} is now racked out as a distribution centre. Order in bulk here and your shops can pull from it overnight.`, {
    importance: 'normal',
  });
  return { ok: true, message: `${warehouse.name} is open at ${building.address}.` };
}

/** Closes a distribution centre. Stock on the racks is cleared at half cost. */
export function closeWarehouse(state: GameState, warehouseId: string): { ok: boolean; message: string } {
  const warehouse = warehouseById(state, warehouseId);
  if (!warehouse) return { ok: false, message: 'Unknown warehouse.' };
  const value = stockValue(warehouse) * 0.5;
  if (value > 0) {
    post(state, warehouse.companyId, 'stock', `Clearance — ${warehouse.name}`, value, null);
  }
  for (const employee of employeesOf(state, warehouse.id)) {
    employee.businessId = null;
    employee.companyId = null;
    state.employees = state.employees.filter((e) => e.id !== employee.id);
  }
  state.warehouses = state.warehouses.filter((w) => w.id !== warehouseId);
  return {
    ok: true,
    message: `${warehouse.name} is closed. Remaining stock raised ${money(value)}.`,
  };
}

/** What a shop would want on its shelves — the same target the auto-restock uses. */
function shortfall(business: Business): Record<string, number> {
  const type = businessTypeOrThrow(business.typeId);
  const out: Record<string, number> = {};
  for (const productId of type.productIds) {
    const have = business.stock[productId] ?? 0;
    const incoming = business.incoming[productId] ?? 0;
    const reorder = business.reorderPoints[productId] ?? 0;
    const target = Math.max(reorder * 7, 60);
    const need = target - have - incoming;
    if (need > 1) out[productId] = need;
  }
  return out;
}

export interface DispatchLine {
  businessId: string;
  productId: string;
  units: number;
}

/**
 * Works out today's runs without changing anything, so the interface can show
 * the player what will happen tonight.
 */
export function planDispatch(state: GameState, warehouse: Warehouse): DispatchLine[] {
  const lines: DispatchLine[] = [];
  const trips = tripsPerDay(state, warehouse);
  const available: Record<string, number> = { ...warehouse.stock };
  let used = 0;

  // Shops that are furthest below their target get the van first.
  const shops = playerBusinesses(state)
    .filter((b) => b.status !== 'closed' && b.autoRestock)
    .map((business) => ({ business, need: shortfall(business) }))
    .filter((entry) => Object.keys(entry.need).length > 0)
    .sort((a, b) => sum(Object.values(b.need), (n) => n) - sum(Object.values(a.need), (n) => n));

  for (const { business, need } of shops) {
    if (used >= trips) break;
    let room = storageFree(state, business);
    let sentAnything = false;
    for (const [productId, wanted] of Object.entries(need)) {
      const def = product(productId);
      if (!def) continue;
      const onRack = available[productId] ?? 0;
      if (onRack < 1) continue;
      const fits = Math.floor(room / Math.max(0.01, def.volume));
      const units = Math.floor(Math.min(wanted, onRack, fits));
      if (units < 1) continue;
      available[productId] = onRack - units;
      room -= units * def.volume;
      lines.push({ businessId: business.id, productId, units });
      sentAnything = true;
    }
    if (sentAnything) used += 1;
  }

  return lines;
}

/**
 * The overnight run.
 *
 * Stock moves from the racks to the shelves at the cost it was bought for, so
 * nothing is created or destroyed — only the van run is an expense.
 */
export function dispatchDaily(state: GameState): void {
  for (const warehouse of warehousesOf(state)) {
    warehouse.dispatchedToday = 0;
    if (!warehouse.autoDispatch) continue;

    const lines = planDispatch(state, warehouse);
    if (lines.length === 0) continue;

    const byBusiness = new Map<string, DispatchLine[]>();
    for (const line of lines) {
      const list = byBusiness.get(line.businessId) ?? [];
      list.push(line);
      byBusiness.set(line.businessId, list);
    }

    for (const [businessId, group] of byBusiness) {
      const business = businessById(state, businessId);
      if (!business) continue;
      for (const line of group) {
        const def = product(line.productId);
        if (!def) continue;
        const cost = warehouse.costBasis[line.productId] ?? def.wholesalePrice;
        warehouse.stock[line.productId] = Math.max(0, (warehouse.stock[line.productId] ?? 0) - line.units);

        // The shop's cost basis has to absorb the arriving units, or its margin
        // would be wrong for everything it sells afterwards.
        const have = business.stock[line.productId] ?? 0;
        const currentCost = business.costBasis[line.productId] ?? cost;
        const total = have + line.units;
        business.costBasis[line.productId] = total > 0 ? (have * currentCost + line.units * cost) / total : cost;
        business.stock[line.productId] = total;
      }
      warehouse.dispatchedToday += 1;
      const runCost = TRIP_COST * researchFactor(state, 'logistics');
      post(state, warehouse.companyId, 'logistics', `Delivery run — ${business.name}`, -runCost, businessId);
      business.today.otherCosts += runCost;
    }

    if (warehouse.dispatchedToday > 0) {
      const units = Math.round(sum(lines, (line) => line.units));
      pushNews(state, 'supplier', `${warehouse.name} restocked ${warehouse.dispatchedToday} shop${warehouse.dispatchedToday === 1 ? '' : 's'}`, `${units} units left the racks overnight. No supplier lead time, no minimum order.`, {
        importance: 'low',
      });
    }
  }
}

/** Wages, rent and the standing costs of running a distribution centre. */
export function warehouseDaily(state: GameState): void {
  for (const warehouse of warehousesOf(state)) {
    const staff = employeesOf(state, warehouse.id);
    const wages = sum(staff, (e) => e.salary / 30);
    if (wages > 0) {
      post(state, warehouse.companyId, 'wages', `Wages — ${warehouse.name}`, -wages, null);
    }

    // A racked-out warehouse has a cold store, so perishables last far longer
    // here than on a shop shelf — but fresh goods are still the wrong thing to
    // hold in volume, and the write-off says so.
    let wasted = 0;
    for (const [productId, units] of Object.entries(warehouse.stock)) {
      if (units <= 0) continue;
      const def = product(productId);
      if (!def || def.shelfLife <= 0) continue;
      const rate = clamp(1 / (def.shelfLife * 9), 0.004, 0.09);
      const lost = units * rate;
      if (lost < 0.01) continue;
      warehouse.stock[productId] = Math.max(0, units - lost);
      wasted += lost * (warehouse.costBasis[productId] ?? def.wholesalePrice);
    }
    if (wasted > 0) {
      postNonCash(state, warehouse.companyId, 'cogs', `Waste — ${warehouse.name}`, -wasted, null);
    }
    if (wasted > 60) {
      pushAlert(
        state,
        'warning',
        `Stock is going off at ${warehouse.name}`,
        `About ${money(wasted)} of perishable stock was written off. A warehouse is the wrong place for anything short-dated.`,
        null,
        'logistics',
      );
    }
  }
}

// ------------------------------------------------------------ buying in bulk

/** Bulk deliveries are cheaper per kilo: one lorry, not six vans. */
const BULK_DELIVERY_RATE = 0.11;
const BULK_CALLOUT = 45;

/** Everything the company's shops sell, which is what a warehouse may hold. */
export function stockableProducts(state: GameState): string[] {
  const ids = new Set<string>();
  for (const business of playerBusinesses(state)) {
    for (const productId of businessTypeOrThrow(business.typeId).productIds) ids.add(productId);
  }
  return [...ids];
}

export interface BulkQuote {
  lines: { productId: string; quantity: number; unitPrice: number }[];
  units: number;
  volume: number;
  goodsCost: number;
  deliveryCost: number;
  total: number;
  leadTimeHours: number;
  /** What the same goods would have cost delivered to shops one at a time. */
  retailEquivalent: number;
  problems: string[];
}

export function quoteBulk(
  state: GameState,
  supplierId: string,
  warehouseId: string,
  requested: { productId: string; quantity: number }[],
): BulkQuote {
  const problems: string[] = [];
  const def = supplier(supplierId);
  const warehouse = warehouseById(state, warehouseId);
  const lines: BulkQuote['lines'] = [];
  let units = 0;
  let volume = 0;
  let weight = 0;
  let goodsCost = 0;

  if (!def) problems.push('Unknown supplier.');
  if (!warehouse) problems.push('Unknown warehouse.');

  if (def && warehouse) {
    const stockable = new Set(stockableProducts(state));
    for (const input of requested) {
      const quantity = Math.floor(input.quantity);
      if (!Number.isFinite(quantity) || quantity <= 0) continue;
      const productDef = product(input.productId);
      if (!productDef) continue;
      if (!stockable.has(input.productId)) {
        problems.push(`None of your shops sell ${productDef.name}.`);
        continue;
      }
      if (!def.categories.includes(productDef.category)) {
        problems.push(`${def.name} does not carry ${productDef.name}.`);
        continue;
      }
      const price = unitPrice(state, supplierId, input.productId);
      lines.push({ productId: input.productId, quantity, unitPrice: price });
      units += quantity;
      volume += quantity * productDef.volume;
      weight += quantity * productDef.weight;
      goodsCost += quantity * price;
    }

    if (units === 0) problems.push('Nothing selected to order.');
    if (goodsCost > 0 && goodsCost < def.minimumOrderValue) {
      problems.push(`${def.name} has a minimum order of €${def.minimumOrderValue.toLocaleString('en-GB')}.`);
    }
    const room = freeSpace(state, warehouse);
    if (volume > room) {
      problems.push(`That is ${Math.round(volume - room)} units more than the racks will hold.`);
    }
  }

  const deliveryCost = units > 0 ? Math.round(BULK_CALLOUT + weight * BULK_DELIVERY_RATE) : 0;
  const total = Math.round(goodsCost + deliveryCost);
  if (total > playerCompany(state).cash) problems.push('Not enough cash for this order.');

  return {
    lines,
    units,
    volume,
    goodsCost: Math.round(goodsCost),
    deliveryCost,
    total,
    leadTimeHours: def?.leadTimeHours ?? 0,
    // Six separate van deliveries, which is what the shops would otherwise pay.
    retailEquivalent: units > 0 ? Math.round(goodsCost + 15 * Math.max(1, lines.length) + weight * 0.18) : 0,
    problems,
  };
}

export function placeBulkOrder(
  state: GameState,
  supplierId: string,
  warehouseId: string,
  requested: { productId: string; quantity: number }[],
): { ok: boolean; message: string } {
  const quote = quoteBulk(state, supplierId, warehouseId, requested);
  if (quote.problems.length > 0) return { ok: false, message: quote.problems[0] };
  const def = supplier(supplierId);
  const warehouse = warehouseById(state, warehouseId);
  if (!def || !warehouse) return { ok: false, message: 'Order could not be placed.' };

  const now = absoluteHour(state);
  state.orders.push({
    id: makeId('po'),
    supplierId,
    businessId: warehouse.id,
    warehouseId: warehouse.id,
    lines: quote.lines,
    goodsCost: quote.goodsCost,
    deliveryCost: quote.deliveryCost,
    total: quote.total,
    placedOnTick: now,
    arrivesOnTick: now + def.leadTimeHours,
    status: 'transit',
  });
  state.supplierSpend[supplierId] = (state.supplierSpend[supplierId] ?? 0) + quote.total;

  post(state, warehouse.companyId, 'stock', `Bulk purchase — ${def.name}`, -quote.goodsCost, null);
  if (quote.deliveryCost > 0) {
    post(state, warehouse.companyId, 'logistics', `Bulk delivery — ${def.name}`, -quote.deliveryCost, null);
  }
  return {
    ok: true,
    message: `${quote.units} units ordered into ${warehouse.name}, arriving in about ${def.leadTimeHours} hours.`,
  };
}

/** A bulk delivery arriving at the racks. */
export function receiveBulk(state: GameState, order: PurchaseOrder): void {
  const warehouse = order.warehouseId ? warehouseById(state, order.warehouseId) : undefined;
  const def = supplier(order.supplierId);
  order.status = 'delivered';
  if (!warehouse || !def) return;

  let received = 0;
  let rejected = 0;
  let credit = 0;
  for (const line of order.lines) {
    const productDef = product(line.productId);
    if (!productDef) continue;
    const room = Math.floor(freeSpace(state, warehouse) / Math.max(0.01, productDef.volume));
    const accepted = Math.max(0, Math.min(line.quantity, room));
    if (accepted > 0) {
      const have = warehouse.stock[line.productId] ?? 0;
      const currentCost = warehouse.costBasis[line.productId] ?? line.unitPrice;
      const total = have + accepted;
      warehouse.costBasis[line.productId] = total > 0 ? (have * currentCost + accepted * line.unitPrice) / total : line.unitPrice;
      warehouse.stock[line.productId] = total;
      received += accepted;
    }
    const short = line.quantity - accepted;
    if (short > 0) {
      rejected += short;
      credit += short * line.unitPrice;
    }
  }

  if (credit > 0) {
    post(state, warehouse.companyId, 'stock', `Credit — ${def.name}`, credit, null);
    pushAlert(
      state,
      'warning',
      `${warehouse.name} could not take the whole delivery`,
      `${Math.round(rejected)} units went back on the lorry and were credited. The racks are full.`,
      null,
      'logistics',
    );
  }
  if (received > 0) {
    pushNews(state, 'supplier', `${Math.round(received)} units delivered to ${warehouse.name}`, `From ${def.name}. Your shops can draw on it from tonight.`, {
      importance: 'low',
    });
  }
}

/**
 * Whether the company's own racks can cover a shop's shortfall.
 *
 * This is what stops a shop ordering from a supplier for stock that is already
 * sitting in your warehouse waiting for tonight's van.
 */
export function warehouseCanSupply(state: GameState, productId: string, units: number): boolean {
  for (const warehouse of warehousesOf(state)) {
    if (!warehouse.autoDispatch) continue;
    if ((warehouse.stock[productId] ?? 0) >= units) return true;
  }
  return false;
}

/** Puts somebody on the warehouse payroll. */
export function hireToWarehouse(state: GameState, applicantId: string, warehouseId: string): { ok: boolean; message: string } {
  const warehouse = warehouseById(state, warehouseId);
  if (!warehouse) return { ok: false, message: 'Unknown warehouse.' };
  const applicant = state.applicants.find((a) => a.id === applicantId);
  if (!applicant) return { ok: false, message: 'That applicant is no longer available.' };
  if (applicant.role !== 'warehouse' && applicant.role !== 'driver' && applicant.role !== 'manager') {
    return { ok: false, message: 'A distribution centre needs warehouse staff, drivers or a manager.' };
  }
  const company = playerCompany(state);
  const fee = recruitmentFee(state);
  const upfront = fee + (applicant.salary / 30) * 7;
  if (company.cash < upfront) {
    return { ok: false, message: `You need ${money(upfront)} in cash to take someone on.` };
  }

  applicant.businessId = warehouse.id;
  applicant.companyId = company.id;
  applicant.hiredOnDay = state.day;
  applicant.lastRecognisedOnDay = state.day;
  state.employees.push(applicant);
  warehouse.employeeIds.push(applicant.id);
  state.applicants = state.applicants.filter((a) => a.id !== applicantId);
  state.applicants.push(generateApplicant(state));
  post(state, company.id, 'recruitment', `Recruitment — ${applicant.name}`, -fee, null);
  return { ok: true, message: `${applicant.name} joins ${warehouse.name} as ${role(applicant.role).name}.` };
}
