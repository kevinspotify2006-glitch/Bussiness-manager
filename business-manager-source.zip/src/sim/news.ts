import type { GameState } from './state';
import type { NewsCategory, NewsItem } from './types';
import { makeId } from './util';

/**
 * The news feed.
 *
 * Nothing here is written for flavour: every item is published by a system that
 * has just changed a number the player can act on. If it is in the feed, it
 * happened.
 */

export const NEWS_LIMIT = 90;

export const NEWS_LABELS: Record<NewsCategory, string> = {
  economy: 'Economy',
  competitor: 'Competition',
  company: 'Your company',
  staff: 'Staff',
  market: 'Market',
  supplier: 'Suppliers',
  property: 'Property',
};

export const NEWS_ICONS: Record<NewsCategory, string> = {
  economy: '📈',
  competitor: '⚔',
  company: '🏢',
  staff: '👥',
  market: '🛒',
  supplier: '🚚',
  property: '🏙',
};

export function pushNews(
  state: GameState,
  category: NewsCategory,
  headline: string,
  body: string,
  options: { businessId?: string | null; importance?: NewsItem['importance'] } = {},
): NewsItem {
  const item: NewsItem = {
    id: makeId('news'),
    day: state.day,
    hour: state.hour,
    category,
    headline,
    body,
    businessId: options.businessId ?? null,
    importance: options.importance ?? 'normal',
  };
  state.news.unshift(item);
  if (state.news.length > NEWS_LIMIT) state.news.length = NEWS_LIMIT;
  return item;
}

export function recentNews(state: GameState, limit = 20, category?: NewsCategory): NewsItem[] {
  const filtered = category ? state.news.filter((item) => item.category === category) : state.news;
  // High-importance items from the last two days float to the top.
  return [...filtered]
    .sort((a, b) => {
      const aHot = a.importance === 'high' && state.day - a.day <= 1 ? 1 : 0;
      const bHot = b.importance === 'high' && state.day - b.day <= 1 ? 1 : 0;
      if (aHot !== bHot) return bHot - aHot;
      return b.day * 24 + b.hour - (a.day * 24 + a.hour);
    })
    .slice(0, limit);
}
