import type { GameState } from './state';
import { playerBusinesses, playerCompany } from './state';
import { hasBoard } from './facilities';
import { netWorth, post } from './finance';
import { money } from './format';
import { pushNews } from './news';
import { pushAlert } from './alerts';
import { record } from './chronicle';
import { officers } from './executives';
import { clamp, sum } from './util';

/**
 * The board, and what having one is actually for.
 *
 * A board room was already buildable and it gated nothing, which made it the
 * clearest example of exactly the thing this game is not supposed to have: a
 * room you pay for because it is the next thing on the list. So here is what it
 * is for.
 *
 * A company with a board can sell part of itself. That is the whole mechanic,
 * and it matters because until now there was exactly one way to get money the
 * company had not earned, which was to borrow it — and borrowing is rationed by
 * a credit rating that is hardest to move at precisely the moment the money is
 * most needed. Equity is the other way. It costs no interest and it cannot be
 * called in. What it costs instead is a permanent share of everything the
 * company makes from now on, and a group of people who have opinions about how
 * it is run.
 *
 * The price is the interesting part. A company raising money when it is doing
 * well gives away a small slice for a large sum; the same company raising the
 * same sum in trouble gives away a great deal more. That is not a penalty
 * bolted on — it falls straight out of valuing the company on what it is
 * currently worth and currently earning, which is what an investor would do.
 *
 * Nothing here stores a "board happiness" number. Confidence is read from the
 * company's own results every time it is asked for, which is the same rule the
 * rest of 3.0 follows: one source of truth, and it is the thing that actually
 * happened.
 */

/** The most of itself a company will sell before the owner is not the owner. */
export const MAX_OUTSIDE_STAKE = 0.6;

/** Confidence below which nobody is writing a cheque. */
export const RAISE_FLOOR = 40;

/** What investors take of the profit, each month, as a share of their stake. */
export const PAYOUT_SHARE = 0.55;

/** Multiple of annual profit a confident board will value the company at. */
const EARNINGS_MULTIPLE = 6;

export interface ConfidenceRow {
  label: string;
  /** -100..100, what this is doing to confidence. */
  value: number;
  detail: string;
}

/**
 * What the board thinks, in the parts it is made of.
 *
 * Shown to the player as rows rather than a single number, because a board that
 * has gone cold for one reason is a different problem from one that has gone
 * cold for another, and the player can only act on the reason.
 */
export function confidenceRows(state: GameState): ConfidenceRow[] {
  const company = playerCompany(state);
  const recent = state.dayHistory.slice(-90);
  const profit = sum(recent, (d) => d.profit);
  const days = Math.max(1, recent.length);
  const daily = profit / days;

  const earlier = state.dayHistory.slice(-180, -90);
  const before = earlier.length > 0 ? sum(earlier, (d) => d.profit) / earlier.length : daily;
  const trend = daily - before;

  const worth = netWorth(state);
  const open = playerBusinesses(state).filter((b) => b.status === 'open').length;
  const posts = officers(state).length;

  return [
    {
      label: 'Profitability',
      value: clamp(daily / 40, -40, 40),
      detail: daily >= 0 ? `${money(daily)} a day over the last quarter.` : `Losing ${money(-daily)} a day.`,
    },
    {
      label: 'Direction',
      value: clamp(trend / 15, -25, 25),
      detail: trend > 1 ? 'Getting better quarter on quarter.' : trend < -1 ? 'Getting worse quarter on quarter.' : 'Flat.',
    },
    {
      label: 'Balance sheet',
      value: clamp(worth / 25_000, -25, 25),
      detail: worth >= 0 ? `The company is worth ${money(worth)}.` : `The company is ${money(-worth)} in the hole.`,
    },
    {
      label: 'Standing',
      value: clamp((state.standing.quality - 50) / 2.5, -20, 20),
      detail: `Quality stands at ${Math.round(state.standing.quality)}.`,
    },
    {
      label: 'Management',
      value: clamp(posts * 4 - (open > 6 && posts === 0 ? 12 : 0), -12, 20),
      detail: posts === 0 ? 'No executive posts filled.' : `${posts} executive post${posts === 1 ? '' : 's'} filled.`,
    },
    {
      label: 'Credit',
      value: clamp((company.creditRating - 50) / 3, -16, 16),
      detail: `Rated ${Math.round(company.creditRating)} by the banks.`,
    },
  ];
}

/** What the board thinks, 0..100, where fifty is neutral. */
export function boardConfidence(state: GameState): number {
  return clamp(50 + sum(confidenceRows(state), (row) => row.value), 0, 100);
}

export function confidenceLabel(value: number): string {
  if (value >= 78) return 'Behind you';
  if (value >= 60) return 'Supportive';
  if (value >= 42) return 'Watchful';
  if (value >= 25) return 'Uneasy';
  return 'Losing patience';
}

// -------------------------------------------------------------- the raise

/**
 * What the company is worth to somebody buying into it.
 *
 * Assets plus what it earns, the earnings weighted by what the board makes of
 * the company — which is why raising money in a good quarter is cheap and
 * raising it in a bad one is dear. There is a floor under it so that a company
 * with nothing can still sell something, and that something is worth very
 * little, which is the honest answer.
 */
export function valuation(state: GameState): number {
  const recent = state.dayHistory.slice(-90);
  const daily = recent.length > 0 ? sum(recent, (d) => d.profit) / recent.length : 0;
  const annual = daily * 360;
  const confidence = boardConfidence(state) / 100;
  const earnings = Math.max(0, annual) * EARNINGS_MULTIPLE * confidence;
  return Math.max(25_000, netWorth(state) + earnings);
}

/** How much of the company a given sum would buy today. */
export function stakeFor(state: GameState, amount: number): number {
  if (amount <= 0) return 0;
  const worth = valuation(state);
  return clamp(amount / (worth + amount), 0, 1);
}

export function outsideStake(state: GameState): number {
  return clamp(state.outsideStake ?? 0, 0, MAX_OUTSIDE_STAKE);
}

/** What the founder still owns. */
export function ownersStake(state: GameState): number {
  return 1 - outsideStake(state);
}

/**
 * The money that would buy a given slice of the whole company.
 *
 * The inverse of the pricing above, so the screen can offer a decision in the
 * terms the player actually thinks in — "a tenth of the company, for this
 * much" — rather than asking them to type a number and find out afterwards how
 * much of their company it cost.
 */
export function priceForShare(state: GameState, share: number): number {
  const owned = ownersStake(state);
  if (owned <= 0) return 0;
  const wanted = clamp(share / owned, 0, 0.95);
  return Math.round((valuation(state) * wanted) / (1 - wanted));
}

export interface RaiseCheck {
  ok: boolean;
  message: string;
}

export function canRaise(state: GameState, amount: number): RaiseCheck {
  if (!hasBoard(state)) {
    return { ok: false, message: 'Selling part of the company needs a board to sell it to. Build a board room.' };
  }
  if (!Number.isFinite(amount) || amount < 10_000) {
    return { ok: false, message: 'Nobody convenes a board for less than €10,000.' };
  }
  const confidence = boardConfidence(state);
  if (confidence < RAISE_FLOOR) {
    return {
      ok: false,
      message: `The board is ${confidenceLabel(confidence).toLowerCase()} at ${Math.round(confidence)}. Nobody is buying in until the figures improve.`,
    };
  }
  const after = outsideStake(state) + stakeFor(state, amount) * ownersStake(state);
  if (after > MAX_OUTSIDE_STAKE) {
    return {
      ok: false,
      message: `That would put outside investors over ${Math.round(MAX_OUTSIDE_STAKE * 100)}% and you would no longer be running your own company.`,
    };
  }
  return { ok: true, message: `${money(amount)} for ${(stakeFor(state, amount) * ownersStake(state) * 100).toFixed(1)}% of the company.` };
}

export function raiseEquity(state: GameState, amount: number): { ok: boolean; message: string } {
  const check = canRaise(state, amount);
  if (!check.ok) return check;

  // Diluting: the slice sold comes out of what is still unsold, which is why
  // raising twice costs more than raising once for the same total.
  const sold = stakeFor(state, amount) * ownersStake(state);
  state.outsideStake = clamp(outsideStake(state) + sold, 0, MAX_OUTSIDE_STAKE);

  post(state, state.playerCompanyId, 'equity', `Investment — ${(sold * 100).toFixed(1)}% of the company`, amount, null);
  record(state, 'borrowed', `Sold ${(sold * 100).toFixed(1)}% of the company for ${money(amount)}`, { amount });
  pushNews(
    state,
    'company',
    'The board has taken outside investment',
    `${money(amount)} in, for ${(sold * 100).toFixed(1)}% of the company. Outside investors now hold ${(outsideStake(state) * 100).toFixed(1)}%, and they take a share of the profit every month from here on.`,
    { importance: 'high' },
  );
  return { ok: true, message: `${money(amount)} raised. You now own ${(ownersStake(state) * 100).toFixed(1)}%.` };
}

/**
 * Buying investors back out.
 *
 * At the current valuation, which is the cruelty of it: a company that has done
 * well since the raise pays a great deal more to undo it than it took in. That
 * is the consequence the mechanic is for — equity is permanent unless you make
 * it expensive to yourself.
 */
export function buybackCost(state: GameState, share: number): number {
  return Math.round(valuation(state) * clamp(share, 0, 1));
}

export function buyBack(state: GameState, share: number): { ok: boolean; message: string } {
  const held = outsideStake(state);
  const taking = clamp(share, 0, held);
  if (taking <= 0) return { ok: false, message: 'There is nothing to buy back.' };
  const cost = buybackCost(state, taking);
  const company = playerCompany(state);
  if (company.cash < cost) {
    return { ok: false, message: `Buying that back costs ${money(cost)} and you have ${money(company.cash)}.` };
  }
  state.outsideStake = clamp(held - taking, 0, MAX_OUTSIDE_STAKE);
  post(state, state.playerCompanyId, 'equity', `Bought back ${(taking * 100).toFixed(1)}% of the company`, -cost, null);
  record(state, 'repaid', `Bought back ${(taking * 100).toFixed(1)}% of the company`, { amount: -cost });
  return { ok: true, message: `Bought back ${(taking * 100).toFixed(1)}% for ${money(cost)}. You own ${(ownersStake(state) * 100).toFixed(1)}%.` };
}

// ------------------------------------------------------------- the ongoing

/**
 * What the investors take.
 *
 * Charged daily like everything else, against the profit the day actually made.
 * A day that lost money pays nothing — investors take a share of profit, not a
 * rent — which means the cost of equity is genuinely tied to how well the
 * company does rather than being a second loan with a different name.
 */
export function boardDaily(state: GameState): void {
  const stake = outsideStake(state);
  if (stake <= 0) return;
  const today = state.dayHistory[state.dayHistory.length - 1];
  if (!today || today.profit <= 0) return;

  const payout = Math.round(today.profit * stake * PAYOUT_SHARE);
  if (payout <= 0) return;
  post(state, state.playerCompanyId, 'dividend', 'Investor distribution', -payout, null);
}

/**
 * The board's view, said out loud when it changes band.
 *
 * Only said to a company that actually has investors — a board room with nobody
 * in the register is a room, and it should not be nagging anybody.
 */
export function boardWatch(state: GameState): void {
  if (outsideStake(state) <= 0) return;
  if (state.day % 30 !== 0) return;
  const confidence = boardConfidence(state);
  if (confidence >= 42) return;
  const worst = [...confidenceRows(state)].sort((a, b) => a.value - b.value)[0];
  pushAlert(
    state,
    confidence < 25 ? 'critical' : 'warning',
    `The board is ${confidenceLabel(confidence).toLowerCase()}`,
    `Confidence stands at ${Math.round(confidence)} out of a hundred. Their worst objection is ${worst.label.toLowerCase()}: ${worst.detail}`,
    null,
    'headOffice',
  );
}

/** The register, for the screen. */
export interface Register {
  owner: number;
  outside: number;
  valuation: number;
  confidence: number;
  label: string;
  /** What investors took over the last thirty days. */
  paidOut: number;
}

export function register(state: GameState): Register {
  const paid = state.ledger
    .filter((entry) => entry.category === 'dividend' && entry.day > state.day - 30)
    .reduce((total, entry) => total - entry.amount, 0);
  const confidence = boardConfidence(state);
  return {
    owner: ownersStake(state),
    outside: outsideStake(state),
    valuation: valuation(state),
    confidence,
    label: confidenceLabel(confidence),
    paidOut: Math.round(paid),
  };
}
