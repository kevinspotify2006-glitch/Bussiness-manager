import type { Founder, FounderSkillId } from './types';
import type { GameState } from './state';
import { FOUNDER_SKILL_IDS, founderSkill, founderTrait, startingSkills } from '../data/founders';
import { pushNews } from './news';
import { clamp } from './util';

/**
 * The person running the company.
 *
 * Two things happen here. The effects turn each of the seven skills into a
 * number the simulation multiplies by — every one has a call site, because a
 * skill with no effect is a decoration on a profile page. And the learning
 * turns playing into getting better: you learn finance by borrowing, management
 * by managing, negotiation by haggling. Nothing is spent, nothing is allocated;
 * the company you end up running is shaped by the things you actually did.
 */

export function emptyFounder(name: string, traitId: string, scenarioId: string): Founder {
  const skills = startingSkills(traitId);
  const progress = {} as Founder['progress'];
  for (const id of FOUNDER_SKILL_IDS) progress[id] = 0;
  return { name: name.trim().slice(0, 40) || 'You', traitId, skills, progress, scenarioId };
}

/** One skill, 0..100. Reads zero-risk on a save that predates founders. */
export function skillOf(state: GameState, id: FounderSkillId): number {
  return clamp(state.founder?.skills[id] ?? 0, 0, 100);
}

/**
 * A skill as a factor around one.
 *
 * Fifty is the middle and changes nothing, so a founder of no particular
 * background plays the game the way it has always played. `spread` is how far
 * either side of that the skill can push it.
 */
function factor(state: GameState, id: FounderSkillId, spread: number): number {
  return 1 + ((skillOf(state, id) - 50) / 50) * spread;
}

// --------------------------------------------------------------- the effects

/**
 * How many locations the owner can personally hold before things start
 * drifting. This is the single most important one: it is what decides when the
 * player has to stop doing it all themselves and start delegating.
 */
export function attentionSpan(state: GameState): number {
  return 4 * factor(state, 'management', 0.5);
}

/** What a lender takes off the rate for somebody who knows the language. */
export function rateDiscount(state: GameState): number {
  return ((skillOf(state, 'finance') - 50) / 50) * 0.018;
}

/** And how much more they will lend against the same assets. */
export function lendingFactor(state: GameState): number {
  return factor(state, 'finance', 0.3);
}

/** What a euro of marketing is worth in the hands of somebody who can sell. */
export function marketingSkillFactor(state: GameState): number {
  return factor(state, 'sales', 0.3);
}

/** What an operator takes off the coordination bill. */
export function operationsFactor(state: GameState): number {
  return factor(state, 'operations', -0.3);
}

/** How much faster research finishes for somebody who picks the right one. */
export function researchSpeed(state: GameState): number {
  return factor(state, 'strategy', 0.3);
}

/** What working for this person is worth in morale, in points. */
export function moraleFromOwner(state: GameState): number {
  return ((skillOf(state, 'leadership') - 50) / 50) * 9;
}

/** What a negotiator takes off a supplier's price, and off a seller's reserve. */
export function negotiationFactor(state: GameState): number {
  return factor(state, 'negotiation', -0.12);
}

// -------------------------------------------------------------- the learning

/**
 * How much of a skill point each thing is worth.
 *
 * Deliberately slow. A founder should visibly improve across a long game and
 * never become good at everything, so the numbers are small and the curve
 * flattens: the first twenty points of finance come far faster than the last
 * twenty, which is both how learning works and what stops a long game ending
 * with a founder at a hundred in all seven.
 */
const LEARNS: Record<string, { skill: FounderSkillId; amount: number }> = {
  hired: { skill: 'management', amount: 0.5 },
  promoted: { skill: 'management', amount: 0.8 },
  letGo: { skill: 'management', amount: 0.4 },
  delegated: { skill: 'management', amount: 2.5 },
  merged: { skill: 'management', amount: 9 },
  borrowed: { skill: 'finance', amount: 1.2 },
  repaid: { skill: 'finance', amount: 1.6 },
  closedMonth: { skill: 'finance', amount: 0.35 },
  marketed: { skill: 'sales', amount: 0.25 },
  soldTo: { skill: 'sales', amount: 0.04 },
  traded: { skill: 'operations', amount: 0.22 },
  opened: { skill: 'operations', amount: 1.4 },
  researched: { skill: 'strategy', amount: 3 },
  levelled: { skill: 'strategy', amount: 2.2 },
  ordered: { skill: 'negotiation', amount: 0.2 },
  acquired: { skill: 'negotiation', amount: 4 },
  signed: { skill: 'negotiation', amount: 1.1 },
  keptTeamHappy: { skill: 'leadership', amount: 0.3 },
  trained: { skill: 'leadership', amount: 0.6 },
};

export type FounderEvent = keyof typeof LEARNS;

/**
 * Records that the player did something, and lets them get slightly better at
 * it. Called from wherever the thing actually happens, never from the interface.
 */
export function learn(state: GameState, event: FounderEvent, times = 1): void {
  const founder = state.founder;
  if (!founder) return;
  const entry = LEARNS[event];
  if (!entry) return;

  const level = founder.skills[entry.skill] ?? 0;
  // The last twenty points are roughly five times harder than the first twenty.
  const resistance = 1 + Math.pow(clamp(level, 0, 100) / 100, 2) * 4;
  founder.progress[entry.skill] += (entry.amount * times) / resistance;

  while (founder.progress[entry.skill] >= 1 && founder.skills[entry.skill] < 100) {
    founder.progress[entry.skill] -= 1;
    founder.skills[entry.skill] = clamp(founder.skills[entry.skill] + 1, 0, 100);
    announce(state, entry.skill);
  }
  if (founder.skills[entry.skill] >= 100) founder.progress[entry.skill] = 0;
}

/** Milestones are worth saying out loud; every other point passes quietly. */
function announce(state: GameState, id: FounderSkillId): void {
  const founder = state.founder;
  if (!founder) return;
  const level = founder.skills[id];
  if (level !== 50 && level !== 70 && level !== 85 && level !== 100) return;
  const def = founderSkill(id);
  pushNews(
    state,
    'company',
    `${founder.name} is getting good at ${def.name.toLowerCase()}`,
    `${level}/100. ${def.says}.`,
    { importance: level >= 85 ? 'high' : 'normal' },
  );
}

/** What the player started as, for the profile screen. */
export function background(state: GameState): string {
  return founderTrait(state.founder?.traitId ?? 'allrounder').name;
}
