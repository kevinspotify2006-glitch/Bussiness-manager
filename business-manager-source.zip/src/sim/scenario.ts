import type { GameState } from './state';
import { playerBusinesses, playerCompany } from './state';
import type { ScenarioDef } from '../data/scenarios';
import { scenario } from '../data/scenarios';
import { BUSINESS_TYPES } from '../data/businessTypes';
import { createNewGame } from './setup';
import { Engine } from './engine';
import { foundBusiness, openBusiness, rentBuilding } from './business';
import { applicantsFor, hire, refreshApplicants } from './employees';
import { placeOrder, rankedSuppliers, suggestOrder } from './procurement';
import { openHeadOffice, hireToHeadOffice, HQ_FIT_OUT } from './headOffice';
import { monthlyPayment, netWorth } from './finance';
import { emptyFounder } from './founder';
import { setHandoverMode } from './workingCapital';
import { gameRng } from './rng';
import { clamp, makeId, sum } from './util';

/**
 * Setting a scenario up.
 *
 * Everything here runs the game's own functions: leases are taken with
 * `rentBuilding`, businesses founded with `foundBusiness`, people hired with
 * `hire`, stock ordered through `placeOrder`, doors opened with `openBusiness`.
 * Then the clock is run forward for the scenario's warm-up so the company has a
 * real trading history rather than an invented one.
 *
 * That matters more than it sounds. A company handed to the player this way is
 * indistinguishable from one they built themselves — the same ledger entries,
 * the same reviews, the same people with the same histories — so nothing on any
 * screen is a special case, and no figure is decorative.
 */

export interface StartOptions {
  companyName: string;
  founderName: string;
  /** What the founder did before this. */
  traitId: string;
  scenarioId: string;
  seed?: number;
  /** Only used by the custom scenario, which lets every figure be chosen. */
  overrides?: Partial<ScenarioDef>;
}

export function startGame(options: StartOptions): GameState {
  // Everything built here is bought for cash, so the player inherits the
  // position the scenario describes rather than somebody else's credit account.
  setHandoverMode(true);
  try {
    return build(options);
  } finally {
    setHandoverMode(false);
  }
}

function build(options: StartOptions): GameState {
  const def: ScenarioDef = { ...scenario(options.scenarioId), ...(options.overrides ?? {}) };
  const state = createNewGame(options.companyName, options.seed ?? (Date.now() >>> 0));
  state.founder = emptyFounder(options.founderName, options.traitId, def.id);

  const company = playerCompany(state);
  company.cash = Math.max(1_000, Math.round(def.cash));
  company.creditRating = clamp(def.creditRating, 0, 100);
  company.brandAwareness = clamp(def.awareness, 0, 100);
  state.levelReached = clamp(Math.round(def.levelReached), 1, 8);
  state.stats.peakNetWorth = company.cash;

  // More rivals, for a scenario that says the city is already crowded.
  if (def.extraRivals > 0) addRivals(state, def.extraRivals);

  // The locations themselves, opened the long way round. Each gets its own
  // share of the starting capital, so the third one is not priced out by the
  // first two having already spent it.
  const engine = new Engine(state);
  const budget = def.locations > 0 ? (company.cash * 0.72) / def.locations : 0;
  for (let i = 0; i < def.locations; i += 1) {
    if (!openOneLocation(state, engine, def, i, budget)) break;
  }

  if (def.headOffice) setUpHeadOffice(state);
  if (def.debtShare > 0) inheritDebt(state, def);

  // A warm-up, so the company arrives with a past. Reviews, news, day history,
  // employee morale and competitor reactions are all real by the time the
  // player sees them because the simulation genuinely produced them.
  for (let day = 0; day < def.warmUpDays; day += 1) {
    for (let hour = 0; hour < 24; hour += 1) engine.stepHour();
  }

  // The card says "€300,000 — starting capital", and that is what the player
  // gets. The warm-up exists to give the company a past — reviews, trading
  // history, people with tenure — not to spend the stake before the player has
  // touched it. Squaring the position here is also what stops every future
  // change to the simulation quietly re-balancing every scenario: the promise
  // on the card is a fixed point, not an outcome.
  const handover = playerCompany(state);
  handover.cash = Math.max(1_000, Math.round(def.cash));
  for (const bill of state.bills) handover.cash -= bill.amount;
  state.bills = [];
  state.taxReserve = 0;
  // And the company is not in trouble before the player has made a decision.
  // A rough warm-up is history, not a verdict on them.
  state.stats.bankrupt = false;
  state.stats.peakNetWorth = Math.max(netWorth(state), handover.cash);
  state.liquidityBand = 'clear';

  // Whatever the warm-up shouted about happened before the player arrived.
  state.alerts = [];
  state.decisions = [];
  state.news = state.news.slice(0, 6);
  refreshApplicants(state);
  state.speed = 0;
  return state;
}

/** Leases a unit, founds a business in it, staffs it, stocks it and opens it. */
function openOneLocation(
  state: GameState,
  engine: Engine,
  def: ScenarioDef,
  index: number,
  budget: number,
): boolean {
  const company = playerCompany(state);
  const taken = new Set(playerBusinesses(state).map((b) => b.buildingId));
  // Never spend past the money actually in the bank, whatever the share said.
  const affordableAt = Math.min(budget, company.cash * 0.8);
  const fits = (building: (typeof state.buildings)[number], type: (typeof BUSINESS_TYPES)[number]): boolean =>
    building.size >= type.minSize &&
    building.suitableFor.includes(type.category) &&
    building.rent * 3 + type.setupCost + type.equipmentCost < affordableAt;

  const affordable = state.buildings.filter((building) => {
    if (building.status !== 'available' || taken.has(building.id)) return false;
    return BUSINESS_TYPES.some((type) => fits(building, type));
  });
  if (affordable.length === 0) return false;

  // Busy pitches first, so a scenario company is somewhere a player would have
  // chosen rather than wherever the loop happened to land.
  const shortlist = affordable.sort((a, b) => b.footTraffic - a.footTraffic).slice(0, 12);
  const building = shortlist[index % shortlist.length] ?? shortlist[0];

  const options = BUSINESS_TYPES.filter((type) => fits(building, type));
  if (options.length === 0) return false;
  const type = gameRng.pick(options);

  if (!rentBuilding(state, building.id).ok) return false;
  const founded = foundBusiness(state, type.id, building.id, `${company.name} ${type.name}`);
  if (!founded.ok) return false;
  const business = playerBusinesses(state).find((b) => b.buildingId === building.id);
  if (!business) return false;

  business.reputation = clamp(def.reputation, 0, 100);
  business.awareness = clamp(def.awareness, 0, 100);
  business.autoRestock = true;

  for (let i = 0; i < def.staffPerLocation; i += 1) {
    const wanted = type.roles[i % type.roles.length];
    const applicant = applicantsFor(state, business).find((a) => a.role === wanted) ?? applicantsFor(state, business)[0];
    if (!applicant) break;
    if (!hire(state, applicant.id, business.id).ok) break;
  }

  if (type.productIds.length > 0) {
    let ordered = false;
    for (const supplierId of rankedSuppliers(state, business)) {
      const lines = suggestOrder(state, business, supplierId);
      if (lines.length === 0) continue;
      if (placeOrder(state, supplierId, business.id, lines).ok) {
        ordered = true;
        break;
      }
    }
    // Let the delivery land before the doors open. Suppliers differ by days
    // rather than hours, so this waits long enough for the slowest of them —
    // a shop that opened with empty shelves would be a worse start than none.
    if (ordered) {
      for (let hour = 0; hour < 24 * 6; hour += 1) {
        engine.stepHour();
        if (sum(Object.values(business.stock), (units) => units) > 0) break;
      }
    }
  }

  const opened = openBusiness(state, business.id);
  if (!opened.ok) {
    // Opening is refused for exactly two reasons, and both are recoverable:
    // nothing on the shelves, or nobody to serve. Neither should leave a
    // scenario handing the player a shut shop it never explained.
    const spare = state.applicants.find((a) => type.roles.includes(a.role)) ?? state.applicants[0];
    if (spare) hire(state, spare.id, business.id);
    openBusiness(state, business.id);
  }
  return business.status === 'open';
}

/** Fits out a head office in a spare unit and puts a couple of people in it. */
function setUpHeadOffice(state: GameState): void {
  const company = playerCompany(state);
  const unit = state.buildings.find((b) => b.status === 'available' && b.size > 90);
  if (!unit) return;
  if (company.cash < HQ_FIT_OUT + unit.rent * 3) return;
  if (!rentBuilding(state, unit.id).ok) return;
  if (!openHeadOffice(state, unit.id, `${company.name} Head Office`).ok) return;

  for (const role of ['hr', 'accountant'] as const) {
    const applicant = state.applicants.find((a) => a.role === role);
    if (applicant) hireToHeadOffice(state, applicant.id);
  }
}

/**
 * A loan that was already there when the player arrived.
 *
 * Written straight onto the books rather than drawn down, because the money was
 * spent by whoever ran the place before — which is the point of inheriting one.
 */
function inheritDebt(state: GameState, def: ScenarioDef): void {
  const principal = Math.round((def.cash * def.debtShare) / 1000) * 1000;
  if (principal < 1000) return;
  const rate = state.economy.interestRate + 0.034;
  const term = 60;
  state.loans.push({
    id: makeId('loan'),
    lender: 'Meridian Business Bank',
    typeId: 'business',
    principal,
    outstanding: principal,
    annualRate: rate,
    termMonths: term,
    monthlyPayment: Math.round(monthlyPayment(principal, rate, term)),
    takenOnDay: 1,
    missedPayments: 0,
    interestPaid: 0,
    earlyRepaid: 0,
  });
}

/** A busier city, for the scenarios that say so. */
function addRivals(state: GameState, count: number): void {
  const rivals = state.companies.filter((c) => !c.isPlayer);
  if (rivals.length === 0) return;
  for (let i = 0; i < count; i += 1) {
    const company = rivals[i % rivals.length];
    company.cash += 80_000;
  }
}

