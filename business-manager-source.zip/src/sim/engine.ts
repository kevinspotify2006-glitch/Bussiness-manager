import type { GameState } from './state';
import { DAY_HISTORY_LIMIT, SPEEDS, playerBusinesses, playerCompany } from './state';
import { emit } from './bus';
import { allocateDemand } from './demand';
import { businessDaily, tradeHour,
  propertyDaily,
} from './business';
import { competitorDaily, competitorWeekly, tradeHourAI } from './competitors';
import { employeesDaily, payWages } from './employees';
import { mergersDaily } from './mergers';
import { checkLiquidity, reserveTax, workingCapitalDaily } from './workingCapital';
import { standingDaily } from './standing';
import { relationshipsDaily } from './relationships';
import { recordsDaily } from './chronicle';
import { projectsDaily } from './facilities';
import { cityChangeDaily } from './cityChange';
import { boardDaily, boardWatch } from './board';
import { policiesDaily } from './policies';
import { processOrders, runAutoRestock } from './procurement';
import { campaignsDaily } from './marketing';
import { decisionsDaily } from './decisions';
import { goalsDaily } from './goals';
import { checkPromotion, contractsUnlocked } from './progress';
import { contractOffersWeekly, contractsWeekly } from './contracts';
import { cashWarning } from './cashflow';
import { researchDaily } from './research';
import { headOfficeDaily } from './headOffice';
import { tidyDivisions } from './holding';
import { learn } from './founder';
import { closeMonth, monthInALine } from './accounts';
import { dispatchDaily, warehouseDaily } from './warehouse';
import { pushNews } from './news';
import { economyDaily, revalueProperty } from './economy';
import { chargeTax, dayTotals, netWorth, settleLoansMonthly, taxRateNow, updateCreditRating } from './finance';
import { checkAchievements } from './achievements';
import { pushAlert } from './alerts';
import { DAYS_PER_MONTH } from './format';
import { clamp, sum } from './util';

/**
 * The simulation engine.
 *
 * Real time drives an accumulator of in-game hours. Every whole hour runs the
 * hourly tick; crossing midnight runs the daily settlement, and day 1 of a week
 * or month runs the weekly and monthly work. The same code path runs at every
 * speed, so 8× produces exactly the same result as 1× — only faster.
 */
export class Engine {
  state: GameState;
  private accumulator = 0;
  private lastFrame = 0;
  private frame: number | null = null;
  private running = false;

  constructor(state: GameState) {
    this.state = state;
  }

  replaceState(state: GameState): void {
    this.state = state;
    this.accumulator = 0;
    emit('reset', undefined);
  }

  start(): void {
    if (this.running) return;
    this.running = true;
    this.lastFrame = performance.now();
    const loop = (now: number): void => {
      if (!this.running) return;
      // Cap the delta so a backgrounded tab does not fast-forward a week.
      const delta = clamp((now - this.lastFrame) / 1000, 0, 0.5);
      this.lastFrame = now;
      this.advance(delta);
      this.frame = requestAnimationFrame(loop);
    };
    this.frame = requestAnimationFrame(loop);
  }

  stop(): void {
    this.running = false;
    if (this.frame !== null) cancelAnimationFrame(this.frame);
    this.frame = null;
  }

  setSpeed(index: number): void {
    this.state.speed = clamp(Math.round(index), 0, SPEEDS.length - 1);
  }

  togglePause(): void {
    this.state.speed = this.state.speed === 0 ? 2 : 0;
  }

  /** Advances the simulation by `seconds` of real time. */
  advance(seconds: number): void {
    const hoursPerSecond = SPEEDS[this.state.speed] ?? 0;
    if (hoursPerSecond <= 0) return;
    this.accumulator += seconds * hoursPerSecond;

    let steps = 0;
    // Hard cap per frame so a long pause can never lock the browser up.
    while (this.accumulator >= 1 && steps < 48) {
      this.accumulator -= 1;
      steps += 1;
      this.stepHour();
    }
    if (steps > 0) emit('tick', { day: this.state.day, hour: this.state.hour });
  }

  /** Runs a single in-game hour. Exposed so tests and the debug panel can step. */
  stepHour(): void {
    const state = this.state;

    // 1. Everyone competes for the same customers.
    const allocations = allocateDemand(state);
    for (const business of state.businesses) {
      const allocation = allocations.get(business.id);
      if (business.companyId === state.playerCompanyId) tradeHour(state, business, allocation);
      else tradeHourAI(state, business, allocation);
    }

    // 2. Deliveries arrive.
    processOrders(state);

    state.hour += 1;
    if (state.hour < 24) return;

    // The day is settled while the clock still reads that day, so rent, wages
    // and every other closing entry land in the right day's ledger.
    this.settleDay();
    state.hour = 0;
    state.day += 1;
  }

  private settleDay(): void {
    const state = this.state;
    const company = playerCompany(state);

    payWages(state);

    let customers = 0;
    for (const business of playerBusinesses(state)) {
      customers += business.today.customers;
      businessDaily(state, business);
    }

    propertyDaily(state);
    warehouseDaily(state);
    dispatchDaily(state);
    campaignsDaily(state);
    competitorDaily(state);
    decisionsDaily(state);
    employeesDaily(state);
    runAutoRestock(state);
    economyDaily(state);
    revalueProperty(state);

    // Finish renovations that were due today.
    for (const building of state.buildings) {
      if (building.renovationEndsOnDay !== null && state.day >= building.renovationEndsOnDay) {
        building.renovationEndsOnDay = null;
        building.condition = 100;
        pushAlert(state, 'info', 'Renovation complete', `${building.address} is back to full condition.`, null, 'property');
      }
    }

    // Revenue and costs come from the ledger, so the reported profit and the
    // transactions the player can read always agree.
    const { revenue, costs } = dayTotals(state, state.day);
    const worth = netWorth(state);
    state.dayHistory.push({
      day: state.day,
      revenue,
      costs,
      profit: revenue - costs,
      cash: company.cash,
      netWorth: worth,
      customers,
    });
    if (state.dayHistory.length > DAY_HISTORY_LIMIT) state.dayHistory.shift();
    // Profit is not cash, and tax is the clearest case of it: the bill is
    // building up all month whether or not the money is still in the account.
    // Measured over the same thirty days the charge itself uses, so the reserve
    // falls again when a bad week wipes out a good one.
    reserveTax(state, sum(state.dayHistory.slice(-30), (d) => d.profit), taxRateNow(state));
    state.stats.peakNetWorth = Math.max(state.stats.peakNetWorth, worth);

    updateCreditRating(state);
    checkAchievements(state);
    // Goals are judged on the day that has just been settled, so a target met
    // today is paid today.
    goalsDaily(state);
    // A promotion is decided on the company as it stands after the day is
    // settled, so it can never be announced on a figure that is about to change.
    checkPromotion(state);
    researchDaily(state);
    headOfficeDaily(state);
    // A day of building work: the money goes out, the room gets closer.
    projectsDaily(state);
    // And a day of the city building its own things. Anything announced that
    // has come due lands now and the district is permanently different; once
    // in a while something new is announced, with months of notice.
    cityChangeDaily(state);

    // The founder learns from running the place. Trading teaches operations,
    // serving customers teaches selling, and a team that stays content teaches
    // whatever it is that makes people want to work for you.
    if (playerBusinesses(state).some((b) => b.status === 'open')) {
      learn(state, 'traded');
      learn(state, 'soldTo', Math.min(20, customers / 50));
      learn(state, 'marketed', Math.min(4, sum(playerBusinesses(state), (b) => b.marketingBudget) / 200));
      const team = state.employees.filter((e) => e.companyId === state.playerCompanyId);
      if (team.length > 0 && sum(team, (e) => e.morale) / team.length > 65) learn(state, 'keptTeamHappy');
    }
    // A division whose last location closed is not a division, and one whose
    // head resigned overnight is back on the owner's desk. Both are noticed
    // here rather than the next time a screen happens to be opened.
    tidyDivisions(state);
    // And an integration that is under way moves a day closer to being done,
    // costs what a day of it costs, and lets one more duplicate job go.
    mergersDaily(state);
    // Customers pay, suppliers get paid, and the gap between profit and cash
    // opens or closes. This runs before the day is totalled so the ledger the
    // reports read is the ledger the bank balance came from.
    workingCapitalDaily(state);
    checkLiquidity(state);
    // What the company is known for, which lags what it is actually doing.
    standingDaily(state);
    // Who got on with whom today. One pairing per location, which is enough
    // for the relationships that matter to form within a few weeks.
    relationshipsDaily(state);
    // The high-water marks, measured against figures the day has already
    // settled rather than against anything computed for the purpose.
    recordsDaily(state);
    // And if part of the company belongs to somebody else, they take their
    // share of what it made today. This runs after the day is totalled, so it
    // is a distribution of profit rather than a cost that changes it.
    boardDaily(state);
    boardWatch(state);
    // And wages moving a day closer to where the pay policy says they belong.
    policiesDaily(state);

    // Cash is not profit. A company can be profitable and still not be able to
    // pay for anything in a fortnight, and it should hear about that early.
    const warning = cashWarning(state);
    if (warning) pushAlert(state, 'critical', 'Cashflow warning', warning, null, 'finance');

    if (state.day % 7 === 0) this.settleWeek();
    if (state.day % DAYS_PER_MONTH === 0) this.settleMonth();

    this.checkSolvency();
    emit('day', { day: state.day });
  }

  private settleWeek(): void {
    const state = this.state;
    competitorWeekly(state);

    // Contracts settle weekly: the pallet either went out or it did not.
    if (contractsUnlocked(state) || state.contracts.length > 0) {
      contractsWeekly(state);
      if (contractsUnlocked(state)) contractOffersWeekly(state);
    }

    // A weekly trading summary, so the player has a rhythm to read against.
    const week = state.dayHistory.slice(-7);
    if (week.length >= 3) {
      const revenue = week.reduce((acc, d) => acc + d.revenue, 0);
      const profit = week.reduce((acc, d) => acc + d.profit, 0);
      const customers = week.reduce((acc, d) => acc + d.customers, 0);
      pushNews(
        state,
        'market',
        `Week in review: ${profit >= 0 ? 'profit' : 'loss'} of €${Math.abs(Math.round(profit)).toLocaleString('en-GB')}`,
        `€${Math.round(revenue).toLocaleString('en-GB')} of revenue from ${Math.round(customers).toLocaleString('en-GB')} customers across ${
          playerBusinesses(state).filter((b) => b.status === 'open').length
        } open locations.`,
        { importance: 'normal' },
      );
    }
  }

  private settleMonth(): void {
    const state = this.state;
    const { missed } = settleLoansMonthly(state);
    if (missed > 0) {
      pushAlert(
        state,
        'critical',
        'Missed loan payment',
        `${missed} loan payment${missed > 1 ? 's' : ''} could not be met. Interest has been added and your credit rating has fallen.`,
        null,
      );
    }
    const tax = chargeTax(state);
    if (tax > 0) {
      pushAlert(state, 'info', 'Corporation tax paid', `€${Math.round(tax).toLocaleString('en-GB')} on last month's profit.`, null, 'finance');
    }

    // The books are closed from the ledger, after everything that belongs to
    // the month is in it.
    const account = closeMonth(state, DAYS_PER_MONTH);
    if (account) {
      const before = state.accounts[state.accounts.length - 2];
      pushNews(
        state,
        'company',
        `Management accounts: €${Math.round(account.netProfit).toLocaleString('en-GB')} ${account.netProfit >= 0 ? 'profit' : 'loss'}`,
        monthInALine(account, before),
        { importance: 'high' },
      );
    }
  }

  /** Bankruptcy: the player is warned first, then the game ends. */
  private checkSolvency(): void {
    const state = this.state;
    const company = playerCompany(state);

    // Trading out of it is allowed to count. A company that was insolvent and
    // is now solvent again is not bankrupt, and saying otherwise for the rest
    // of the game would be a lie the player can see through.
    if (state.stats.bankrupt && company.cash >= 0 && netWorth(state) > 0) {
      state.stats.bankrupt = false;
      pushAlert(
        state,
        'info',
        'Back in the black',
        'The account is positive again and the company is worth more than it owes. You traded out of it.',
        null,
      );
      pushNews(state, 'company', 'The company has traded out of insolvency', 'Cash is positive and net worth is above zero again.', {
        importance: 'high',
      });
      return;
    }

    if (company.cash >= 0) return;

    const debt = -company.cash;
    const assets = netWorth(state) + debt;
    if (assets > 0 && debt < assets * 0.35) {
      pushAlert(
        state,
        'critical',
        'Your account is overdrawn',
        `You are €${Math.round(debt).toLocaleString('en-GB')} in the red. Sell stock or property, cut costs, or take a loan.`,
        null,
      );
      return;
    }

    if (!state.stats.bankrupt) {
      state.stats.bankrupt = true;
      state.speed = 0;
      const losing = playerBusinesses(state)
        .filter((b) => sum(b.profitHistory.slice(-7), (p) => p) < 0)
        .map((b) => b.name);
      pushAlert(
        state,
        'critical',
        'Bankrupt',
        losing.length > 0
          ? `Debts exceeded what the company is worth. The heaviest losses came from ${losing.join(', ')}.`
          : 'Debts exceeded what the company is worth.',
        null,
      );
    }
  }
}
