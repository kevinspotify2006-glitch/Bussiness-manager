import type { Business, Bond, Employee } from './types';
import type { GameState } from './state';
import { employeeById, employeesOf, playerBusinesses } from './state';
import { trait } from '../data/roles';
import { gradeOf, performanceOf } from './skills';
import { pushNews } from './news';
import { gameRng } from './rng';
import { clamp, sum } from './util';

/**
 * Who gets on with whom.
 *
 * Colleagues used to affect each other as an average: add up everybody's
 * team-morale trait, divide, apply to everybody equally. That is a weather
 * system, not a workplace. It could not produce the thing that actually happens
 * in a company — two particular people who cannot be in the same room, or the
 * senior who quietly makes everybody around them better — because it had no
 * notion of a particular person at all.
 *
 * Now people form bonds with named colleagues. There are three kinds and each
 * does something different:
 *
 *   mentor   somebody senior pulls somebody junior along
 *            → the junior learns faster, the senior gains leadership
 *   friend   two people who work well together
 *            → both are happier, and stay
 *   rival    two people who do not
 *            → both are unhappier, and the friction reaches the customers
 *
 * Which kind forms is not a die roll: it is decided by who the two people are,
 * and — this is the part that makes management mean something — by whether
 * anybody is managing them. A shop with a good manager turns friction into a
 * working relationship. A shop without one lets it fester, and a rivalry
 * between two strong people is one of the more expensive things that can
 * quietly happen to a company.
 *
 * Cost: one pairing considered per location per day, not every pair of every
 * employee. At fifty locations that is fifty rolls, which is nothing, and the
 * relationships that matter still form within a few weeks.
 */

/** The most people one person keeps a real working relationship with. */
export const MAX_BONDS = 3;

export function bondsOf(employee: Employee): Bond[] {
  return employee.bonds ?? [];
}

function bondWith(employee: Employee, otherId: string): Bond | undefined {
  return bondsOf(employee).find((b) => b.withId === otherId);
}

/**
 * A day in one shop.
 *
 * Two people are considered. What happens between them depends on what they are
 * like, how far apart they are on the ladder, and whether the place is managed.
 */
function shopDaily(state: GameState, business: Business): void {
  const staff = employeesOf(state, business.id).filter((e) => e.sickUntilDay === null || e.sickUntilDay <= state.day);
  if (staff.length < 2) return;

  const [a, b] = gameRng.sample(staff, 2);
  if (!a || !b || a.id === b.id) return;

  // How well the place is run. A manager who is good at leading people is the
  // difference between a disagreement and a feud.
  const leaders = staff.filter((person) => gradeOf(person).managerial);
  const leadership = leaders.length > 0
    ? sum(leaders, (person) => person.skills.leadership) / leaders.length
    : 25;
  const managed = clamp(leadership / 100, 0, 1);

  const gap = Math.abs(gradeOf(a).n - gradeOf(b).n);
  const senior = gradeOf(a).n >= gradeOf(b).n ? a : b;
  const junior = senior === a ? b : a;

  const traitsOf = (person: Employee): ReturnType<typeof trait>[] => person.traits.map(trait);
  const friction = (person: Employee): number => sum(traitsOf(person), (t) => -t.teamMorale);
  const generous = (person: Employee): number => sum(traitsOf(person), (t) => t.teamMorale);

  // Mentoring: a real gap in standing, and somebody senior willing to spend
  // their time on it. That willingness is leadership, and it is why a company
  // full of specialists with no leaders never brings anybody on.
  if (gap >= 2 && senior.skills.leadership > 45 && gameRng.chance(0.1 + managed * 0.12)) {
    deepen(state, senior, junior, 'mentor', 4);
    return;
  }

  // Friction: somebody difficult, two people both chasing the same rung, or a
  // place nobody is managing. A good manager heads most of this off.
  // Deliberately rare and slow. People who work together mostly rub along; a
  // real falling-out takes months, and a company that produced one a fortnight
  // would be describing a different and much worse workplace than this one.
  const rivalry = clamp(
    0.012 + friction(a) * 0.5 + friction(b) * 0.5 + (gap === 0 ? 0.02 : 0) - managed * 0.06,
    0,
    0.12,
  );
  if (gameRng.chance(rivalry)) {
    deepen(state, a, b, 'rival', -4);
    return;
  }

  // And otherwise, people who work alongside each other tend to get on. This is
  // the common case, and it should be, because most workplaces are fine.
  if (gameRng.chance(0.14 + generous(a) + generous(b) + managed * 0.08)) {
    deepen(state, a, b, 'friend', 4);
  }
}

/**
 * Moves two people closer together or further apart.
 *
 * A relationship that reverses sign changes kind, which is how a rivalry
 * becomes a working relationship once somebody starts managing the place — the
 * single most valuable thing a good manager does here.
 */
function deepen(state: GameState, a: Employee, b: Employee, kind: Bond['kind'], by: number): void {
  link(state, a, b, kind, by);
  // A mentorship is not symmetrical: the junior is being brought on, and the
  // senior is the one doing it.
  link(state, b, a, kind === 'mentor' ? 'mentor' : kind, by);
}

function link(state: GameState, from: Employee, to: Employee, kind: Bond['kind'], by: number): void {
  if (!from.bonds) from.bonds = [];
  const existing = bondWith(from, to.id);
  if (existing) {
    const was = existing.strength;
    existing.strength = clamp(existing.strength + by, -100, 100);
    // Crossing zero means the relationship has genuinely turned.
    if (was < 0 && existing.strength >= 0) {
      existing.kind = 'friend';
      announceRepair(state, from, to);
    } else if (was > 0 && existing.strength <= 0) {
      existing.kind = 'rival';
    } else if (Math.abs(existing.strength) > Math.abs(was)) {
      existing.kind = kind;
    }
    return;
  }
  if (from.bonds.length >= MAX_BONDS) {
    // Only so many people can be kept up with. The weakest gives way.
    from.bonds.sort((x, y) => Math.abs(x.strength) - Math.abs(y.strength));
    if (Math.abs(from.bonds[0].strength) >= Math.abs(by)) return;
    from.bonds.shift();
  }
  from.bonds.push({ withId: to.id, strength: clamp(by, -100, 100), kind });
  if (kind === 'rival') announceFriction(state, from, to);
}

function announceFriction(state: GameState, a: Employee, b: Employee): void {
  // Only worth telling the player about when it is between people who matter,
  // and only once it has gone past a grumble into something they should fix.
  const bond = bondWith(a, b.id);
  if (!bond || bond.strength > -35) return;
  if (performanceOf(a) < 60 && performanceOf(b) < 60) return;
  pushNews(
    state,
    'staff',
    `${a.name} and ${b.name} are not getting on`,
    'Two people who both matter here have started working around each other. Somebody senior enough to sort it out is the usual answer; left alone it costs morale on both sides and the customers notice.',
    { businessId: a.businessId, importance: 'normal' },
  );
}

function announceRepair(state: GameState, a: Employee, b: Employee): void {
  if (performanceOf(a) < 60 && performanceOf(b) < 60) return;
  pushNews(
    state,
    'staff',
    `${a.name} and ${b.name} have sorted it out`,
    'Whoever is managing that place has earned their money this week.',
    { businessId: a.businessId, importance: 'normal' },
  );
}

/** Relationships fade when the people are no longer working together. */
function tidy(state: GameState, employee: Employee): void {
  if (!employee.bonds || employee.bonds.length === 0) return;
  employee.bonds = employee.bonds.filter((bond) => {
    const other = employeeById(state, bond.withId);
    if (!other) return false;
    // Out of sight, out of mind: a bond only holds while they share a floor.
    if (other.businessId !== employee.businessId) {
      bond.strength *= 0.94;
      return Math.abs(bond.strength) > 4;
    }
    return true;
  });
}

export function relationshipsDaily(state: GameState): void {
  for (const business of playerBusinesses(state)) {
    if (business.status !== 'open') continue;
    shopDaily(state, business);
  }
  for (const employee of state.employees) tidy(state, employee);
}

// ------------------------------------------------------------- the effects

/**
 * What the people around somebody are worth to them, in morale points.
 *
 * Read by the same daily settlement that reads pay and workload, so a good
 * working relationship shows up in the figure the player already watches
 * rather than in one of its own.
 */
export function bondMorale(state: GameState, employee: Employee): number {
  const bonds = bondsOf(employee);
  if (bonds.length === 0) return 0;
  let total = 0;
  for (const bond of bonds) {
    const other = employeeById(state, bond.withId);
    if (!other || other.businessId !== employee.businessId) continue;
    // A rivalry hurts more than a friendship helps, which is the unfair and
    // entirely realistic shape of it.
    total += bond.strength > 0 ? bond.strength * 0.05 : bond.strength * 0.085;
  }
  return clamp(total, -14, 8);
}

/**
 * What a mentor is worth to the person they are bringing on.
 *
 * A multiplier on how fast that person learns, which is the only thing
 * mentoring should do — it does not make them instantly better, it makes the
 * time they spend count for more.
 */
export function mentorBoost(state: GameState, employee: Employee): number {
  let best = 0;
  for (const bond of bondsOf(employee)) {
    if (bond.kind !== 'mentor' || bond.strength <= 0) continue;
    const other = employeeById(state, bond.withId);
    if (!other || other.businessId !== employee.businessId) continue;
    if (gradeOf(other).n <= gradeOf(employee).n) continue;
    best = Math.max(best, (bond.strength / 100) * (other.skills.leadership / 100));
  }
  return 1 + best * 0.55;
}

/**
 * How much a shop's relationships are costing it in service.
 *
 * A team that works around each other serves people worse, and the customers
 * have no idea why — which is exactly how it feels from the outside, and is why
 * this reaches the review scores rather than sitting on an HR screen.
 */
export function teamFriction(state: GameState, business: Business): number {
  const staff = employeesOf(state, business.id);
  if (staff.length < 2) return 1;
  // Both directions. The first version of this only ever subtracted — a team
  // that worked badly together was punished and a team that worked well got
  // nothing — which is not a relationship system, it is a tax on having
  // colleagues. A shop where people get on serves people better, and that has
  // to be worth something or none of this is a decision.
  let net = 0;
  for (const person of staff) {
    for (const bond of bondsOf(person)) {
      const other = employeeById(state, bond.withId);
      if (!other || other.businessId !== business.id) continue;
      net += bond.strength / 100;
    }
  }
  // Halved because every relationship is counted from both sides. Friction
  // still bites harder than goodwill lifts, which is the honest asymmetry.
  const per = net / 2 / staff.length;
  return clamp(1 + (per > 0 ? per * 0.14 : per * 0.26), 0.82, 1.12);
}

/** Somebody's working relationships, for their profile. */
export function relationshipsOf(state: GameState, employee: Employee): { other: Employee; bond: Bond }[] {
  return bondsOf(employee)
    .map((bond) => ({ other: employeeById(state, bond.withId), bond }))
    .filter((row): row is { other: Employee; bond: Bond } => row.other !== undefined)
    .sort((a, b) => Math.abs(b.bond.strength) - Math.abs(a.bond.strength));
}

/** How a bond should be described on screen. */
export function describeBond(bond: Bond, other: Employee): { text: string; tone: 'good' | 'bad' | 'muted' } {
  const strong = Math.abs(bond.strength) > 45;
  if (bond.kind === 'mentor') {
    return { text: `Brought on by ${other.name}`, tone: 'good' };
  }
  if (bond.strength < 0) {
    return {
      text: strong ? `Will not work with ${other.name}` : `Friction with ${other.name}`,
      tone: 'bad',
    };
  }
  return { text: strong ? `Works closely with ${other.name}` : `Gets on with ${other.name}`, tone: 'good' };
}
