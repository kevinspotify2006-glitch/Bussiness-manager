import type { GameState } from './state';
import { buildingById, businessById, employeesOf, playerBusinesses, playerCompany } from './state';
import type { PendingDecision } from './types';
import { SUPPLIERS, supplier } from '../data/suppliers';
import { product } from '../data/products';
import { district } from '../data/districts';
import { businessTypeOrThrow } from '../data/businessTypes';
import { role } from '../data/roles';
import { post } from './finance';
import { rentBuilding } from './business';
import { storageFree } from './business';
import { rivalsOf, priceIndex } from './demand';
import { pushNews } from './news';
import { pushAlert } from './alerts';
import { clamp, makeId, sum } from './util';
import { gameRng } from './rng';
import { money, moneyCents } from './format';

/**
 * Decisions.
 *
 * These are the moments where the simulation stops and asks the player
 * something. Every option changes real state — a salary, a rent, a stock level,
 * a price — and the consequence is described before it is taken. A decision
 * that is ignored still resolves: doing nothing is a choice.
 */

interface DecisionDef {
  id: string;
  /** Relative likelihood when several decisions are possible. */
  weight: number;
  /** Days before this kind of decision can appear again. */
  cooldown: number;
  create(state: GameState): PendingDecision | null;
  resolve(state: GameState, decision: PendingDecision, optionId: string): string;
  /** What happens if the player never answers. */
  expire(state: GameState, decision: PendingDecision): string;
}

function base(
  defId: string,
  title: string,
  body: string,
  state: GameState,
  options: PendingDecision['options'],
  context: Record<string, string> = {},
  numbers: Record<string, number> = {},
  days = 4,
): PendingDecision {
  return {
    id: makeId('dec'),
    defId,
    title,
    body,
    day: state.day,
    expiresOnDay: state.day + days,
    options,
    context,
    numbers,
  };
}

// ------------------------------------------------------------------ defs

const POACH: DecisionDef = {
  id: 'poach',
  weight: 12,
  cooldown: 14,
  create(state) {
    const candidates = state.employees.filter((e) => e.skill > 55 && e.businessId);
    if (candidates.length === 0) return null;
    const employee = candidates.reduce((best, e) => (e.skill > best.skill ? e : best), candidates[0]);
    const business = businessById(state, employee.businessId ?? '');
    const bonus = Math.round(employee.salary * 1.5);
    const raise = Math.round(employee.salary * 0.12);
    const canPromote = employee.role !== 'manager';
    return base(
      'poach',
      `${employee.name} has an offer from a competitor`,
      `${employee.name} (${role(employee.role).name}, skill ${Math.round(employee.skill)}) has been approached by another company${
        business ? ` and works at ${business.name}` : ''
      }. Replacing them means recruitment costs and a less experienced team.`,
      state,
      [
        { id: 'bonus', label: `Pay a retention bonus of ${money(bonus)}`, detail: 'One-off cost. Buys loyalty now, changes nothing long term.' },
        { id: 'raise', label: `Raise their salary by ${money(raise)}/month`, detail: 'Permanent cost, but the strongest hold on someone good.' },
        canPromote
          ? { id: 'promote', label: 'Promote them to store manager', detail: 'Salary rises 25% and they lift the whole team — if you need a manager.' }
          : { id: 'promote', label: 'Promote them', detail: 'Already at the top of their track.', blocked: 'They are already a manager.' },
        { id: 'nothing', label: 'Let them decide for themselves', detail: 'Costs nothing. They may well leave.' },
      ],
      { employeeId: employee.id },
      { bonus, raise },
    );
  },
  resolve(state, decision, optionId) {
    const employee = state.employees.find((e) => e.id === decision.context.employeeId);
    if (!employee) return 'That employee has already left.';
    const company = playerCompany(state);

    if (optionId === 'bonus') {
      const bonus = decision.numbers.bonus ?? 0;
      if (company.cash < bonus) return 'Not enough cash for the bonus — they were not persuaded.';
      post(state, company.id, 'wages', `Retention bonus — ${employee.name}`, -bonus, employee.businessId);
      employee.morale = clamp(employee.morale + 22, 0, 100);
      employee.loyalty = clamp(employee.loyalty + 26, 0, 100);
      return `${employee.name} is staying. Morale and loyalty are up, but the offer will come round again.`;
    }
    if (optionId === 'raise') {
      employee.salary = Math.round(employee.salary * 1.12);
      employee.morale = clamp(employee.morale + 16, 0, 100);
      employee.loyalty = clamp(employee.loyalty + 34, 0, 100);
      return `${employee.name} accepted ${money(employee.salary)} a month and turned the offer down.`;
    }
    if (optionId === 'promote') {
      if (employee.role === 'manager') return 'They are already a manager.';
      employee.role = 'manager';
      employee.salary = Math.round(employee.salary * 1.25);
      employee.morale = clamp(employee.morale + 26, 0, 100);
      employee.loyalty = clamp(employee.loyalty + 40, 0, 100);
      return `${employee.name} is now store manager on ${money(employee.salary)} a month, and will lift everyone around them.`;
    }
    // Doing nothing is a real gamble.
    if (gameRng.chance(clamp(0.62 - employee.loyalty / 260, 0.15, 0.75))) {
      state.employees = state.employees.filter((e) => e.id !== employee.id);
      const business = businessById(state, employee.businessId ?? '');
      if (business) business.employeeIds = business.employeeIds.filter((id) => id !== employee.id);
      pushNews(state, 'staff', `${employee.name} has left for a competitor`, 'You chose not to match the offer.', {
        businessId: employee.businessId,
        importance: 'high',
      });
      return `${employee.name} took the other job.`;
    }
    employee.loyalty = clamp(employee.loyalty - 12, 0, 100);
    return `${employee.name} stayed anyway, but will remember that you did nothing.`;
  },
  expire(state, decision) {
    return this.resolve(state, decision, 'nothing');
  },
};

const SUPPLIER_DEAL: DecisionDef = {
  id: 'supplier-deal',
  weight: 10,
  cooldown: 20,
  create(state) {
    const used = SUPPLIERS.filter((def) => (state.supplierSpend[def.id] ?? 0) > 800);
    if (used.length === 0) return null;
    const def = gameRng.pick(used);
    // Priced so it pays for itself after roughly 40% of the spend you would
    // otherwise need to earn the discount outright: worth it if you keep
    // buying from them, wasted if you switch or close the shop.
    const commitment = Math.max(50, Math.round((def.volumeThreshold * def.volumeDiscount * 0.4) / 10) * 10);
    return base(
      'supplier-deal',
      `${def.name} is offering you preferred terms`,
      `${def.name} will grant you their volume discount of ${Math.round(def.volumeDiscount * 100)}% immediately, instead of making you spend ${money(
        def.volumeThreshold,
      )} to earn it. In return they want a commitment fee of ${money(commitment)} up front.`,
      state,
      [
        { id: 'accept', label: `Pay ${money(commitment)} and take the discount`, detail: `Every future order from ${def.name} is ${Math.round(def.volumeDiscount * 100)}% cheaper.` },
        { id: 'decline', label: 'Decline', detail: 'Keep the cash and earn the discount the slow way.' },
      ],
      { supplierId: def.id },
      { commitment },
    );
  },
  resolve(state, decision, optionId) {
    const def = supplier(decision.context.supplierId);
    if (!def) return 'That offer is no longer on the table.';
    if (optionId !== 'accept') return `You passed on ${def.name}'s offer.`;
    const commitment = decision.numbers.commitment ?? 0;
    const company = playerCompany(state);
    if (company.cash < commitment) return 'Not enough cash to take the deal.';
    post(state, company.id, 'other', `Commitment fee — ${def.name}`, -commitment);
    // Crossing the threshold is exactly how the discount is earned normally.
    state.supplierSpend[def.id] = Math.max(state.supplierSpend[def.id] ?? 0, def.volumeThreshold);
    pushNews(state, 'supplier', `Preferred terms agreed with ${def.name}`, `Orders are now ${Math.round(def.volumeDiscount * 100)}% cheaper.`, {
      importance: 'normal',
    });
    return `${def.name} has moved you onto discounted pricing.`;
  },
  expire(_state, _decision) {
    return 'The supplier withdrew the offer.';
  },
};

const RENT_REVIEW: DecisionDef = {
  id: 'rent-review',
  weight: 9,
  cooldown: 16,
  create(state) {
    const leased = state.buildings.filter(
      (b) => b.status === 'rented' && b.occupantCompanyId === state.playerCompanyId,
    );
    if (leased.length === 0) return null;
    const building = gameRng.pick(leased);
    const increase = Math.round(gameRng.range(6, 18));
    const newRent = Math.round((building.rent * (1 + increase / 100)) / 5) * 5;
    return base(
      'rent-review',
      `Rent review at ${building.address}`,
      `Your landlord wants to raise the rent by ${increase}%, from ${money(building.rent)} to ${money(newRent)} a month. ${
        district(building.district).name
      } has been getting busier.`,
      state,
      [
        { id: 'accept', label: 'Accept the new rent', detail: `${money(newRent)} a month from now on.` },
        { id: 'negotiate', label: 'Negotiate', detail: 'Might halve the increase. Might annoy them into holding firm.' },
        { id: 'leave', label: 'Give notice and leave', detail: 'Only possible if the unit is empty.', blocked: building.businessId ? 'There is a business trading here.' : undefined },
      ],
      { buildingId: building.id },
      { increase, newRent },
      5,
    );
  },
  resolve(state, decision, optionId) {
    const building = buildingById(state, decision.context.buildingId);
    if (!building) return 'That unit is no longer yours.';
    const newRent = decision.numbers.newRent ?? building.rent;

    if (optionId === 'negotiate') {
      if (gameRng.chance(0.5)) {
        const halved = Math.round(((building.rent + newRent) / 2) / 5) * 5;
        building.rent = halved;
        return `They settled at ${money(halved)} a month.`;
      }
      building.rent = newRent;
      return `They would not move. Rent is ${money(newRent)} a month.`;
    }
    if (optionId === 'leave') {
      if (building.businessId) return 'You cannot walk away while a business is trading there.';
      building.status = 'available';
      building.occupantCompanyId = null;
      post(state, state.playerCompanyId, 'rent', `Deposit returned — ${building.address}`, Math.round(building.rent * 1.5));
      return `You handed the keys back at ${building.address}.`;
    }
    building.rent = newRent;
    return `Rent at ${building.address} is now ${money(newRent)} a month.`;
  },
  expire(state, decision) {
    return this.resolve(state, decision, 'accept');
  },
};

const PRESS_FEATURE: DecisionDef = {
  id: 'press-feature',
  weight: 8,
  cooldown: 18,
  create(state) {
    const open = playerBusinesses(state).filter((b) => b.status === 'open');
    if (open.length === 0) return null;
    const business = gameRng.pick(open);
    const cost = Math.round(gameRng.range(900, 2600) / 50) * 50;
    return base(
      'press-feature',
      'A city magazine wants to feature you',
      `A local title is running a piece on independent businesses in ${
        district(buildingById(state, business.buildingId)?.district ?? 'downtown').name
      }. A paid feature on ${business.name} costs ${money(cost)} and would put you in front of a lot of people at once.`,
      state,
      [
        { id: 'pay', label: `Pay ${money(cost)} for the feature`, detail: 'A large one-off jump in local awareness.' },
        { id: 'decline', label: 'Decline politely', detail: 'Keep the cash.' },
      ],
      { businessId: business.id },
      { cost },
    );
  },
  resolve(state, decision, optionId) {
    const business = businessById(state, decision.context.businessId);
    if (!business) return 'That business no longer exists.';
    if (optionId !== 'pay') return 'You let the feature go.';
    const cost = decision.numbers.cost ?? 0;
    const company = playerCompany(state);
    if (company.cash < cost) return 'Not enough cash for the feature.';
    post(state, company.id, 'marketing', `Magazine feature — ${business.name}`, -cost, business.id);
    business.awareness = clamp(business.awareness + 22, 0, 100);
    business.reputation = clamp(business.reputation + 4, 0, 100);
    pushNews(state, 'company', `${business.name} featured in the local press`, 'Awareness jumped sharply in the district.', {
      businessId: business.id,
      importance: 'high',
    });
    return `The feature ran. Awareness at ${business.name} is now ${Math.round(business.awareness)}%.`;
  },
  expire() {
    return 'The magazine went to print without you.';
  },
};

const BULK_STOCK: DecisionDef = {
  id: 'bulk-stock',
  weight: 11,
  cooldown: 10,
  create(state) {
    const stocking = playerBusinesses(state).filter(
      (b) => businessTypeOrThrow(b.typeId).productIds.length > 0 && b.status !== 'setup',
    );
    if (stocking.length === 0) return null;
    const business = gameRng.pick(stocking);
    const type = businessTypeOrThrow(business.typeId);
    const productId = gameRng.pick(type.productIds);
    const def = product(productId);
    if (!def) return null;
    const room = Math.floor(storageFree(state, business) / Math.max(0.01, def.volume));
    if (room < 40) return null;
    const quantity = Math.min(room, Math.round(gameRng.range(80, 320)));
    const unit = Number((def.wholesalePrice * 0.65).toFixed(2));
    const total = Math.round(unit * quantity);
    return base(
      'bulk-stock',
      `Clearance ${def.name.toLowerCase()} offered to ${business.name}`,
      `A wholesaler is clearing ${quantity} units of ${def.name} at ${moneyCents(unit)} each — 35% below the going rate. It has to be collected today, and it will take ${Math.round(
        quantity * def.volume,
      )} units of your storage.`,
      state,
      [
        { id: 'buy', label: `Take all ${quantity} for ${money(total)}`, detail: 'Cheap stock, but cash and shelf space are tied up.' },
        { id: 'decline', label: 'Pass', detail: 'Keep the space and the cash.' },
      ],
      { businessId: business.id, productId },
      { quantity, unit, total },
      2,
    );
  },
  resolve(state, decision, optionId) {
    const business = businessById(state, decision.context.businessId);
    const def = product(decision.context.productId);
    if (!business || !def) return 'That offer has gone.';
    if (optionId !== 'buy') return 'You passed on the clearance stock.';
    const quantity = decision.numbers.quantity ?? 0;
    const unit = decision.numbers.unit ?? def.wholesalePrice;
    const total = decision.numbers.total ?? Math.round(unit * quantity);
    const company = playerCompany(state);
    if (company.cash < total) return 'Not enough cash to take the pallet.';
    const room = Math.floor(storageFree(state, business) / Math.max(0.01, def.volume));
    const accepted = Math.min(quantity, room);
    if (accepted <= 0) return 'There is no longer room for it.';

    const current = business.stock[def.id] ?? 0;
    const currentCost = business.costBasis[def.id] ?? def.wholesalePrice;
    const newTotal = current + accepted;
    business.costBasis[def.id] = newTotal > 0 ? (current * currentCost + accepted * unit) / newTotal : unit;
    business.stock[def.id] = newTotal;
    post(state, company.id, 'stock', `Clearance stock — ${def.name}`, -Math.round(unit * accepted), business.id);
    return `${accepted} units of ${def.name} are on the shelves at ${moneyCents(unit)} each.`;
  },
  expire() {
    return 'The pallet went to somebody else.';
  },
};

const PRICE_WAR: DecisionDef = {
  id: 'price-war',
  weight: 10,
  cooldown: 12,
  create(state) {
    const open = playerBusinesses(state).filter((b) => b.status === 'open');
    for (const business of open) {
      const rivals = rivalsOf(state, business);
      const cheaper = rivals.filter((rival) => priceIndex(rival) < priceIndex(business) * 0.93);
      if (cheaper.length === 0) continue;
      const rival = cheaper[0];
      const owner = state.companies.find((c) => c.id === rival.companyId);
      const gap = Math.round((1 - priceIndex(rival) / priceIndex(business)) * 100);
      return base(
        'price-war',
        `${owner?.name ?? 'A rival'} is undercutting ${business.name}`,
        `${rival.name} is trading about ${gap}% below your prices in the same district. Customers are already comparing.`,
        state,
        [
          { id: 'match', label: 'Cut your prices by 8%', detail: 'Protects share, cuts your margin on every sale.' },
          { id: 'marketing', label: 'Raise marketing by €120/day instead', detail: 'Defend on awareness rather than price.' },
          { id: 'hold', label: 'Hold your prices', detail: 'Bet that quality and location carry you.' },
        ],
        { businessId: business.id, rivalId: rival.id },
        { gap },
      );
    }
    return null;
  },
  resolve(state, decision, optionId) {
    const business = businessById(state, decision.context.businessId);
    if (!business) return 'That business no longer exists.';
    if (optionId === 'match') {
      for (const [productId, price] of Object.entries(business.prices)) {
        business.prices[productId] = Number((price * 0.92).toFixed(2));
      }
      return `Prices at ${business.name} are down 8%. Watch the margin.`;
    }
    if (optionId === 'marketing') {
      business.marketingBudget += 120;
      return `Marketing at ${business.name} is now ${money(business.marketingBudget)} a day.`;
    }
    return 'You held your prices. The next few days will show whether that was right.';
  },
  expire() {
    return 'You let the price gap stand.';
  },
};

const PAY_RISE: DecisionDef = {
  id: 'pay-rise',
  weight: 9,
  cooldown: 15,
  create(state) {
    const withStaff = playerBusinesses(state).filter((b) => employeesOf(state, b.id).length >= 2);
    if (withStaff.length === 0) return null;
    const business = gameRng.pick(withStaff);
    const staff = employeesOf(state, business.id);
    const monthly = sum(staff, (e) => e.salary);
    const rise = Math.round(monthly * 0.08);
    return base(
      'pay-rise',
      `The team at ${business.name} is asking for a rise`,
      `${staff.length} people are asking for 8% across the board — about ${money(rise)} a month. Morale there is ${Math.round(
        sum(staff, (e) => e.morale) / staff.length,
      )}/100.`,
      state,
      [
        { id: 'grant', label: 'Grant the full 8%', detail: `${money(rise)}/month more. Morale and loyalty jump.` },
        { id: 'partial', label: 'Offer 4%', detail: `${money(Math.round(rise / 2))}/month. A smaller lift, and they know it.` },
        { id: 'refuse', label: 'Refuse', detail: 'Costs nothing today. Morale falls and some may start looking.' },
      ],
      { businessId: business.id },
      { rise },
    );
  },
  resolve(state, decision, optionId) {
    const business = businessById(state, decision.context.businessId);
    if (!business) return 'That business no longer exists.';
    const staff = employeesOf(state, business.id);
    if (staff.length === 0) return 'Nobody works there any more.';

    const factor = optionId === 'grant' ? 1.08 : optionId === 'partial' ? 1.04 : 1;
    const moraleShift = optionId === 'grant' ? 16 : optionId === 'partial' ? 6 : -15;
    for (const employee of staff) {
      employee.salary = Math.round(employee.salary * factor);
      employee.morale = clamp(employee.morale + moraleShift, 0, 100);
      employee.loyalty = clamp(employee.loyalty + moraleShift * 0.6, 0, 100);
    }
    if (optionId === 'refuse') {
      pushNews(state, 'staff', `Pay request refused at ${business.name}`, 'Morale has dropped across the team.', {
        businessId: business.id,
      });
      return 'You said no. Morale has taken a hit.';
    }
    return `Salaries at ${business.name} are up ${optionId === 'grant' ? '8' : '4'}%.`;
  },
  expire(state, decision) {
    return this.resolve(state, decision, 'refuse');
  },
};

const PRIME_UNIT: DecisionDef = {
  id: 'prime-unit',
  weight: 8,
  cooldown: 18,
  create(state) {
    if (playerBusinesses(state).filter((b) => b.status === 'open').length === 0) return null;
    const available = state.buildings.filter((b) => b.status === 'available' && b.footTraffic > 15000);
    if (available.length === 0) return null;
    const building = available.reduce((best, b) => (b.footTraffic > best.footTraffic ? b : best), available[0]);
    const discounted = Math.round((building.rent * 0.8) / 5) * 5;
    return base(
      'prime-unit',
      `A prime unit has come free at ${building.address}`,
      `${district(building.district).name}, ${building.size} m², ${building.footTraffic.toLocaleString('en-GB')} passers-by a day. The landlord wants it filled quickly and will hold the rent at ${money(
        discounted,
      )} instead of ${money(building.rent)} if you sign now. You still pay the usual deposit.`,
      state,
      [
        { id: 'take', label: `Sign the lease at ${money(discounted)}/month`, detail: `${money(discounted * 3)} due today. The unit is yours to fit out.` },
        { id: 'decline', label: 'Not now', detail: 'It will go to somebody else.' },
      ],
      { buildingId: building.id },
      { discounted },
      3,
    );
  },
  resolve(state, decision, optionId) {
    const building = buildingById(state, decision.context.buildingId);
    if (!building) return 'That unit has gone.';
    if (optionId !== 'take') return 'You let the unit go.';
    if (building.status !== 'available') return 'Somebody else took it first.';
    const discounted = decision.numbers.discounted ?? building.rent;
    const original = building.rent;
    building.rent = discounted;
    const result = rentBuilding(state, building.id);
    if (!result.ok) {
      building.rent = original;
      return result.message;
    }
    pushNews(state, 'property', `Signed a lease at ${building.address}`, `Held at ${money(discounted)} a month.`, {
      importance: 'normal',
    });
    return `${building.address} is yours at ${money(discounted)} a month. Create a business there when you are ready.`;
  },
  expire() {
    return 'The unit was let to somebody else.';
  },
};

const DEFS: DecisionDef[] = [POACH, SUPPLIER_DEAL, RENT_REVIEW, PRESS_FEATURE, BULK_STOCK, PRICE_WAR, PAY_RISE, PRIME_UNIT];

const defById = new Map(DEFS.map((def) => [def.id, def]));

// --------------------------------------------------------------- lifecycle

/** Called once a day. Raises at most one new decision. */
export function decisionsDaily(state: GameState): void {
  // Expire anything the player ignored.
  for (const decision of [...state.decisions]) {
    if (state.day < decision.expiresOnDay) continue;
    const def = defById.get(decision.defId);
    state.decisions = state.decisions.filter((d) => d.id !== decision.id);
    if (!def) continue;
    const outcome = def.expire(state, decision);
    pushNews(state, 'company', decision.title, `No decision was taken. ${outcome}`, { importance: 'normal' });
  }

  // Never stack them up: one open decision at a time keeps each one meaningful.
  if (state.decisions.length > 0) return;
  // Give a new company room to breathe. Nothing interrupts the player until
  // the first shop has been trading for a few days — the opening week is hard
  // enough without a rent review landing on top of it.
  const trading = playerBusinesses(state).filter((b) => b.status === 'open');
  if (trading.length === 0) return;
  const oldest = Math.min(...trading.map((b) => b.openedOnDay));
  if (state.day - oldest < 4) return;
  if (!gameRng.chance(0.3)) return;

  const eligible = DEFS.filter((def) => state.day - (state.decisionHistory[def.id] ?? -999) >= def.cooldown);
  if (eligible.length === 0) return;

  const total = eligible.reduce((acc, def) => acc + def.weight, 0);
  let roll = gameRng.next() * total;
  let chosen = eligible[0];
  for (const def of eligible) {
    roll -= def.weight;
    if (roll <= 0) {
      chosen = def;
      break;
    }
  }

  const decision = chosen.create(state);
  if (!decision) return;
  state.decisions.push(decision);
  state.decisionHistory[chosen.id] = state.day;
  pushAlert(state, 'warning', decision.title, 'A decision is waiting for you.', decision.context.businessId ?? null, 'news');
  pushNews(state, 'company', decision.title, decision.body, {
    businessId: decision.context.businessId ?? null,
    importance: 'high',
  });
}

export function resolveDecision(state: GameState, decisionId: string, optionId: string): { ok: boolean; message: string } {
  const decision = state.decisions.find((d) => d.id === decisionId);
  if (!decision) return { ok: false, message: 'That decision has already been settled.' };
  const def = defById.get(decision.defId);
  if (!def) {
    state.decisions = state.decisions.filter((d) => d.id !== decisionId);
    return { ok: false, message: 'That decision is no longer valid.' };
  }
  const option = decision.options.find((o) => o.id === optionId);
  if (option?.blocked) return { ok: false, message: option.blocked };

  const outcome = def.resolve(state, decision, optionId);
  state.decisions = state.decisions.filter((d) => d.id !== decisionId);
  pushNews(state, 'company', decision.title, outcome, {
    businessId: decision.context.businessId ?? null,
  });
  return { ok: true, message: outcome };
}
