import type { Business, Division, Employee } from './types';
import type { GameState } from './state';
import { businessById, employeeById, employeesOf, playerBusinesses } from './state';
import { GRADES, canRunDivision, gradeOf, performanceOf, titleOf } from './skills';
import { pushNews } from './news';
import { attentionSpan, learn } from './founder';
import { mergerAttentionLoad } from './mergers';
import { clamp, makeId, sum } from './util';
import { executiveReach } from './facilities';
import { operatingReach } from './executives';

/**
 * The holding.
 *
 * One person can run a shop. One person can run four shops badly. Past that
 * something has to change, and what changes is that the company stops being a
 * list of locations and becomes a structure: groups of locations, each with
 * somebody senior enough to be answerable for them.
 *
 * A division is normally what arrives when a rival company is bought whole —
 * you do not buy four shops, you buy a business that had four shops and the way
 * it ran them. Handing one to an executive is the only way a company gets
 * bigger than the attention of the person at the top, and it is a real trade:
 * an executive is expensive, and the alternative is watching every location
 * drift.
 */

/**
 * How many locations one person at the top can genuinely keep an eye on.
 *
 * Four for somebody of no particular management background — and more, or
 * fewer, for somebody whose background says otherwise. This is where the
 * founder's own ability becomes the thing that decides when they have to stop
 * doing it all themselves.
 */
export const OWNER_ATTENTION = 4;

export function attentionOf(state: GameState): number {
  // What the owner can hold themselves, plus whatever an executive floor and
  // the people on it take off them. The floor is the room where delegating
  // happens at all; the chief operating officer is the person doing it.
  return attentionSpan(state) + executiveReach(state) + operatingReach(state);
}

export function divisions(state: GameState): Division[] {
  return state.divisions;
}

export function divisionById(state: GameState, id: string): Division | undefined {
  return state.divisions.find((d) => d.id === id);
}

/** The locations in a division, in the order they were opened. */
export function divisionBusinesses(state: GameState, divisionId: string): Business[] {
  return playerBusinesses(state).filter((business) => business.divisionId === divisionId);
}

/** Locations that answer directly to the owner because nothing else does. */
export function unassignedBusinesses(state: GameState): Business[] {
  return playerBusinesses(state).filter((business) => !business.divisionId);
}

/** The executive running a division, if anybody is. */
export function divisionHead(state: GameState, division: Division): Employee | null {
  if (!division.headEmployeeId) return null;
  return employeeById(state, division.headEmployeeId) ?? null;
}

// ------------------------------------------------------------- attention

/**
 * How thinly the person at the top is spread, 0..1 where one is comfortable.
 *
 * Every location that answers directly to the owner takes a share of the same
 * finite attention. A division with a head on it takes almost none, because
 * somebody else is doing the answering — that is what delegation actually buys,
 * and it is why the number goes back up when you appoint one.
 */
export function ownerAttention(state: GameState): number {
  const direct = unassignedBusinesses(state).filter((b) => b.status !== 'closed').length;
  const delegated = sum(state.divisions, (division) => {
    const head = divisionHead(state, division);
    const locations = divisionBusinesses(state, division.id).filter((b) => b.status !== 'closed').length;
    if (!head) return locations;
    // A good executive takes the whole thing off your desk. A struggling one
    // takes most of it and hands some of it back.
    const topSpan = GRADES[GRADES.length - 1].span;
    const relief = clamp(performanceOf(head) / 80, 0.35, 1) * clamp(gradeOf(head).span / topSpan, 0.4, 1);
    return locations * (1 - relief * 0.9);
  });
  // An integration in progress is work on somebody's desk too, and it is on
  // yours unless the division it belongs to has a head.
  const load = direct + delegated + mergerAttentionLoad(state);
  const span = attentionOf(state);
  if (load <= span) return 1;
  return clamp(span / load, 0.55, 1);
}

/**
 * What being stretched costs a location, as a multiplier on its coordination
 * bill. This is the pressure that makes a holding structure worth building
 * rather than a badge to collect.
 */
export function attentionFactor(state: GameState): number {
  const attention = ownerAttention(state);
  return clamp(2 - attention, 1, 1.45);
}

/**
 * Supervision a division head adds to each location under them.
 *
 * Read by the same span-of-control model that reads the grades inside a shop,
 * so an executive is not a separate kind of management — they are management,
 * standing one level further back.
 */
export function delegatedSupervision(state: GameState, business: Business): number {
  if (!business.divisionId) return 0;
  const division = divisionById(state, business.divisionId);
  if (!division) return 0;
  const head = divisionHead(state, division);
  if (!head) return 0;
  const locations = Math.max(1, divisionBusinesses(state, division.id).filter((b) => b.status !== 'closed').length);
  return (gradeOf(head).span * clamp(performanceOf(head) / 70, 0.4, 1.25)) / locations;
}

// --------------------------------------------------------------- actions

export function createDivision(state: GameState, name: string, acquiredFrom: string): Division {
  const division: Division = {
    id: makeId('div'),
    name: name.trim().slice(0, 40) || 'New division',
    acquiredFrom,
    createdOnDay: state.day,
    headEmployeeId: null,
    mergedOnDay: null,
  };
  state.divisions.push(division);
  return division;
}

export function renameDivision(state: GameState, divisionId: string, name: string): { ok: boolean; message: string } {
  const division = divisionById(state, divisionId);
  if (!division) return { ok: false, message: 'Unknown division.' };
  const next = name.trim().slice(0, 40);
  if (!next) return { ok: false, message: 'A division needs a name.' };
  division.name = next;
  return { ok: true, message: `Renamed to ${next}.` };
}

/** Moves a location into a division, or out of every division when null. */
export function assignToDivision(
  state: GameState,
  businessId: string,
  divisionId: string | null,
): { ok: boolean; message: string } {
  const business = businessById(state, businessId);
  if (!business || business.companyId !== state.playerCompanyId) {
    return { ok: false, message: 'That is not one of your locations.' };
  }
  if (divisionId && !divisionById(state, divisionId)) return { ok: false, message: 'Unknown division.' };
  business.divisionId = divisionId;
  const division = divisionId ? divisionById(state, divisionId) : null;
  return {
    ok: true,
    message: division ? `${business.name} now reports to ${division.name}.` : `${business.name} reports to you directly.`,
  };
}

/** Who could take a division on: anybody senior enough to be answerable for one. */
export function eligibleHeads(state: GameState): Employee[] {
  return state.employees
    .filter((person) => person.companyId === state.playerCompanyId && canRunDivision(gradeOf(person)))
    .sort((a, b) => performanceOf(b) - performanceOf(a));
}

export function appointHead(
  state: GameState,
  divisionId: string,
  employeeId: string | null,
): { ok: boolean; message: string } {
  const division = divisionById(state, divisionId);
  if (!division) return { ok: false, message: 'Unknown division.' };
  if (employeeId === null) {
    const was = divisionHead(state, division);
    division.headEmployeeId = null;
    return {
      ok: true,
      message: was ? `${was.name} no longer runs ${division.name}. It is back on your desk.` : 'Nobody was running it.',
    };
  }
  const person = employeeById(state, employeeId);
  if (!person || person.companyId !== state.playerCompanyId) {
    return { ok: false, message: 'That is not one of your people.' };
  }
  if (!canRunDivision(gradeOf(person))) {
    return {
      ok: false,
      message: `${person.name} is a ${titleOf(person)}. Running a division takes a Senior Manager at least — promote them first, which needs leadership, not more of what they already do well.`,
    };
  }
  // One person cannot run two divisions; taking this one means leaving the other.
  for (const other of state.divisions) {
    if (other.headEmployeeId === employeeId) other.headEmployeeId = null;
  }
  division.headEmployeeId = employeeId;
  // Handing a division over is the single clearest management lesson there is.
  learn(state, 'delegated');
  person.morale = clamp(person.morale + 12, 0, 100);
  person.loyalty = clamp(person.loyalty + 10, 0, 100);
  person.stress = clamp(person.stress + 8, 0, 100);
  pushNews(state, 'company', `${person.name} takes over ${division.name}`, `${divisionBusinesses(state, division.id).length} locations, and they answer for all of them now.`, {
    importance: 'high',
  });
  return { ok: true, message: `${person.name} runs ${division.name}. That is ${divisionBusinesses(state, division.id).length} locations off your desk.` };
}

/** Tidies up after a division loses its last location or its head leaves. */
export function tidyDivisions(state: GameState): void {
  for (const division of state.divisions) {
    if (division.headEmployeeId && !employeeById(state, division.headEmployeeId)) {
      const locations = divisionBusinesses(state, division.id).length;
      division.headEmployeeId = null;
      pushNews(state, 'staff', `${division.name} has nobody running it`, `${locations} locations are back on your desk until you appoint somebody.`, {
        importance: 'high',
      });
    }
  }
  const kept = state.divisions.filter((division) => divisionBusinesses(state, division.id).length > 0);
  if (kept.length !== state.divisions.length) state.divisions = kept;
}

// ---------------------------------------------------------- group figures

export interface GroupRow {
  division: Division | null;
  head: Employee | null;
  businesses: Business[];
  headcount: number;
  /** Yesterday's settled revenue across the group. */
  revenue: number;
  profit: number;
}

/** The company as a structure rather than a list: the holding, top down. */
export function groupStructure(state: GameState): GroupRow[] {
  const rows: GroupRow[] = state.divisions.map((division) => ({
    division,
    head: divisionHead(state, division),
    businesses: divisionBusinesses(state, division.id),
    headcount: 0,
    revenue: 0,
    profit: 0,
  }));
  const direct = unassignedBusinesses(state);
  if (direct.length > 0) {
    rows.push({ division: null, head: null, businesses: direct, headcount: 0, revenue: 0, profit: 0 });
  }
  for (const row of rows) {
    row.headcount = sum(row.businesses, (business) => employeesOf(state, business.id).length);
    row.revenue = sum(row.businesses, (business) => business.yesterday.revenue);
    row.profit = sum(
      row.businesses,
      (business) =>
        business.yesterday.revenue -
        (business.yesterday.cogs +
          business.yesterday.wages +
          business.yesterday.rent +
          business.yesterday.marketing +
          business.yesterday.otherCosts),
    );
  }
  return rows;
}
