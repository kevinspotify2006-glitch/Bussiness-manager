import type { Business, Employee, EmployeeRoleId, SkillId, SkillSet } from './types';
import type { GameState } from './state';
import { businessTypeOrThrow } from '../data/businessTypes';
import { role } from '../data/roles';
import { trait } from '../data/roles';
import { hoursFactor } from './policies';
import { clamp } from './util';

/**
 * What somebody is actually good at.
 *
 * The game already had one number for how good a person was, which meant a
 * brilliant cook was automatically a brilliant accountant. Six skills replace
 * that: every role weighs them differently, so a person is good *at a job*
 * rather than good in the abstract, and moving somebody into the wrong seat
 * costs you.
 *
 * The overall figure the rest of the game has always used — `employee.skill` —
 * is still there and still means the same thing: how far along they are in
 * general. It is the average of the six, kept in step whenever a skill moves,
 * so nothing that reads it needed changing.
 */

export interface SkillDef {
  id: SkillId;
  name: string;
  detail: string;
}

export const SKILLS: SkillDef[] = [
  { id: 'technical', name: 'Technical', detail: 'Doing the actual work: repairs, cooking, installation, making things.' },
  { id: 'sales', name: 'Sales', detail: 'Turning somebody who is looking into somebody who is buying.' },
  { id: 'service', name: 'Service', detail: 'How the customer feels about having been in.' },
  { id: 'logistics', name: 'Logistics', detail: 'Stock, deliveries, and where everything is.' },
  { id: 'admin', name: 'Administration', detail: 'Paperwork, ordering, rotas and keeping the place legal.' },
  { id: 'finance', name: 'Finance', detail: 'The books, the tax, and knowing what a number means.' },
  { id: 'communication', name: 'Communication', detail: 'Being understood — by customers, by colleagues, on paper.' },
  { id: 'leadership', name: 'Leadership', detail: 'Getting more out of everybody else than they would give on their own.' },
];

export const SKILL_IDS: SkillId[] = SKILLS.map((s) => s.id);

/**
 * What each role leans on, as weights that sum to one.
 *
 * This is the whole of "a good cook is not a good technician": the same person
 * scores differently depending on which of these is doing the weighing.
 */
export const ROLE_SKILLS: Record<EmployeeRoleId, Partial<Record<SkillId, number>>> = {
  cashier: { service: 0.42, sales: 0.26, admin: 0.18, communication: 0.14 },
  sales: { sales: 0.5, communication: 0.24, service: 0.18, admin: 0.08 },
  server: { service: 0.48, communication: 0.28, sales: 0.14, logistics: 0.1 },
  cook: { technical: 0.54, logistics: 0.24, service: 0.14, communication: 0.08 },
  technician: { technical: 0.7, service: 0.12, admin: 0.1, communication: 0.08 },
  cleaner: { service: 0.44, technical: 0.34, logistics: 0.22 },
  warehouse: { logistics: 0.7, technical: 0.16, admin: 0.14 },
  driver: { logistics: 0.74, communication: 0.14, service: 0.12 },
  marketer: { communication: 0.38, sales: 0.36, admin: 0.14, service: 0.12 },
  // The three desk jobs that used to be the same job. An accountant lives in
  // the numbers, a solicitor in the wording, a personnel officer in the people.
  accountant: { finance: 0.62, admin: 0.26, technical: 0.06, leadership: 0.06 },
  legal: { admin: 0.5, communication: 0.2, finance: 0.16, leadership: 0.14 },
  hr: { communication: 0.38, leadership: 0.3, admin: 0.22, service: 0.1 },
  manager: { leadership: 0.44, communication: 0.24, admin: 0.16, service: 0.16 },
  it: { technical: 0.62, admin: 0.2, logistics: 0.1, communication: 0.08 },
};

/** A blank profile. */
export function emptySkills(): SkillSet {
  return {
    technical: 0,
    sales: 0,
    service: 0,
    logistics: 0,
    admin: 0,
    finance: 0,
    communication: 0,
    leadership: 0,
  };
}

/** The average of the six: the general level the rest of the game reads. */
export function overallSkill(skills: SkillSet): number {
  let total = 0;
  for (const id of SKILL_IDS) total += skills[id] ?? 0;
  return total / SKILL_IDS.length;
}

/** Keeps the headline figure in step after any skill has moved. */
export function syncOverall(employee: Employee): void {
  employee.skill = clamp(overallSkill(employee.skills), 0, 100);
}

/**
 * How well this person's skills match a job, 0..100.
 *
 * Not the same as how good they are: somebody with 80 across the board is a
 * reasonable fit for everything, and somebody with 95 technical and 20
 * everything else is a superb technician and a poor manager.
 */
export function roleFit(skills: SkillSet, roleId: EmployeeRoleId): number {
  const weights = ROLE_SKILLS[roleId];
  let total = 0;
  let weight = 0;
  for (const [id, w] of Object.entries(weights) as [SkillId, number][]) {
    total += (skills[id] ?? 0) * w;
    weight += w;
  }
  return weight > 0 ? total / weight : 0;
}

/**
 * What fit is worth.
 *
 * A perfect match is worth about a fifth more than an average one, and a bad
 * match costs about a third. Wide enough that putting the right person in the
 * right seat matters; narrow enough that a shop staffed by whoever was
 * available still functions.
 */
export function fitFactor(fit: number): number {
  return clamp(0.62 + (fit / 100) * 0.62, 0.62, 1.24);
}

// --------------------------------------------------------- the career ladder

/**
 * Nine rungs, and a fork most of the way up.
 *
 * The first four are the trade somebody already does, and getting up them is a
 * matter of being good at it — Junior to Specialist, with no leadership asked
 * for anywhere. Everything above is a different job: running other people. That
 * is why the top five rungs are gated on leadership rather than on the skill
 * that got somebody noticed — a technician with 95 technical and 42 leadership
 * is a superb technician and will never be a manager, which is exactly how it
 * works everywhere else.
 *
 * Specialist matters for that reason. Without it the ladder punished anybody
 * without leadership by stopping them at Senior; with it, the trade track has
 * its own proper destination, well paid, that a great many people reach and
 * are right to stay at.
 */
export interface GradeDef {
  n: number;
  name: string;
  /** Leadership needed to reach it. */
  leadership: number;
  /** Overall level needed to reach it. */
  skill: number;
  /** Multiplier on what the role pays at the bottom rung. */
  pay: number;
  /** How many people this rung can keep pointing the same way. */
  span: number;
  /** True once the job is mostly about other people. */
  managerial: boolean;
  detail: string;
}

export const GRADES: GradeDef[] = [
  { n: 0, name: 'Junior', leadership: 0, skill: 0, pay: 1, span: 0, managerial: false, detail: 'Learning the job on somebody else’s time.' },
  { n: 1, name: 'Employee', leadership: 0, skill: 38, pay: 1.16, span: 0, managerial: false, detail: 'Does the job without being watched.' },
  { n: 2, name: 'Senior', leadership: 0, skill: 55, pay: 1.36, span: 0, managerial: false, detail: 'The one the others ask.' },
  { n: 3, name: 'Specialist', leadership: 0, skill: 68, pay: 1.58, span: 0, managerial: false, detail: 'As good at the trade as anybody gets, and paid like it. The top of this track, and a perfectly good place to stop.' },
  { n: 4, name: 'Team Lead', leadership: 45, skill: 68, pay: 1.78, span: 5, managerial: false, detail: 'Still on the floor, and now answerable for a handful of people.' },
  { n: 5, name: 'Manager', leadership: 60, skill: 72, pay: 2.15, span: 11, managerial: true, detail: 'Runs the place. A different job from the one below it.' },
  { n: 6, name: 'Senior Manager', leadership: 72, skill: 76, pay: 2.75, span: 20, managerial: true, detail: 'Runs managers, which is harder than running staff.' },
  { n: 7, name: 'Director', leadership: 80, skill: 80, pay: 3.35, span: 27, managerial: true, detail: 'Answerable for a part of the company rather than a part of a shop.' },
  { n: 8, name: 'Executive', leadership: 88, skill: 84, pay: 4.1, span: 36, managerial: true, detail: 'Takes a division off your hands entirely.' },
];

/**
 * The last rung of the trade itself.
 *
 * Everything above this asks for leadership, and plenty of very good people
 * never get any. Stopping here is not failing: a Specialist is the best there
 * is at the work and is paid more than half again what a junior is.
 */
export const TOP_OF_TRADE = 3;

/** Whether this rung is senior enough to be answerable for a whole division. */
export function canRunDivision(def: GradeDef): boolean {
  return def.span >= 20;
}

export function grade(n: number): GradeDef {
  return GRADES[clamp(Math.round(n), 0, GRADES.length - 1)];
}

export function gradeOf(employee: Employee): GradeDef {
  return grade(employee.grade ?? 0);
}

/** What somebody is called: their rung, and the trade they do it in. */
export function titleOf(employee: Employee): string {
  const def = gradeOf(employee);
  const roleName = role(employee.role).name;
  if (def.n === 0) return `Junior ${roleName}`;
  if (def.n === 1) return roleName;
  if (def.n === 2) return `Senior ${roleName}`;
  if (def.n === 3) return `Specialist ${roleName}`;
  // Above team lead the job is the rung, not the trade they came from.
  if (def.n === 4) return `Team Lead — ${roleName}`;
  return def.name;
}

/**
 * Why somebody cannot go up yet, or null if they can.
 *
 * Every rung asks for the general level; the managerial rungs ask for
 * leadership on top of it, and that is the wall a brilliant specialist hits.
 */
export function gradeBlocker(employee: Employee, target: GradeDef): string | null {
  if (target.n >= GRADES.length) return 'There is nothing above this.';
  const shortOnLevel = employee.skill < target.skill;
  const shortOnLeadership = target.leadership > 0 && employee.skills.leadership < target.leadership;
  if (!shortOnLevel && !shortOnLeadership) return null;

  // Leadership is named first when it is missing, because it is the reason that
  // explains the others: a specialist's overall level is often dragged under
  // the bar by the very skill the rung is asking for, and being told "you need
  // a higher overall level" sends the player off to train the wrong thing.
  if (shortOnLeadership) {
    const also = shortOnLevel
      ? ` They are also at ${Math.round(employee.skill)} overall against the ${target.skill} the rung asks for, and leadership training moves both.`
      : '';
    return `${target.name} needs leadership ${target.leadership}. ${employee.name} is at ${Math.round(
      employee.skills.leadership,
    )} — a fine ${role(employee.role).name.toLowerCase()}, and not yet somebody who runs people. Leadership training would change that.${also}`;
  }
  return `${target.name} needs an overall level of ${target.skill}. They are at ${Math.round(employee.skill)}.`;
}

/**
 * What a rung is worth in output.
 *
 * Deliberately narrow. A senior gets through more than a junior, and that is
 * all — otherwise promoting everybody would be free money, and the wage bill
 * that comes with the rung is supposed to be the point of the decision.
 */
export function gradeFactor(employee: Employee): number {
  return 1 + gradeOf(employee).n * 0.028;
}

/**
 * What a rung pays, for somebody at a given level within it.
 *
 * One formula, read by the applicant pool, by what a promotion quotes and by
 * the market rate the interface shows — so the number a player is asked to beat
 * is the number the simulation judges them against.
 *
 * The rung carries almost all of the price, and the level inside it moves
 * things only a little. That is on purpose and it was a real bug the other way
 * round: pricing on the rung *and* on a full skill premium charged twice for
 * the same thing, and a company's wage bill jumped by a third the moment
 * anybody was worth promoting, for seven per cent more work.
 */
export function rungRate(base: number, gradeN: number, skill: number): number {
  return base * grade(gradeN).pay * (0.86 + clamp(skill, 0, 100) / 700);
}

// ------------------------------------------------------------- workload

/**
 * How hard a business is working the people in it, 0..100.
 *
 * Measured from what the shop actually had to serve yesterday against what the
 * people on the payroll could get through — not from how many role slots the
 * type lists, because a quiet shop with one person on the till is not a
 * pressure cooker. Fifty is comfortable; above eighty they are running.
 */
export function workloadOf(state: GameState, business: Business): number {
  if (business.status !== 'open') return 25;
  const type = businessTypeOrThrow(business.typeId);
  const staff = state.employees.filter((e) => e.businessId === business.id);
  const openHours = Math.max(1, business.openTo - business.openFrom);
  // The owner covers a shop with nobody in it, at half a person's pace.
  const hands = Math.max(0.5, staff.length);
  const capacity = hands * type.customersPerStaffHour * openHours * hoursFactor(state);
  const demanded = business.yesterday.customers + business.yesterday.lostCustomers;
  if (capacity <= 0) return 100;
  return clamp((demanded / capacity) * 70, 0, 100);
}

/** What workload does to a person's output. */
export function workloadFactor(workload: number): number {
  if (workload <= 60) return 1;
  // Past sixty they are cutting corners; past ninety they are drowning.
  return clamp(1 - (workload - 60) * 0.006, 0.76, 1);
}

/** What morale does to it. */
export function moraleFactor(morale: number): number {
  return clamp(0.68 + (morale / 100) * 0.5, 0.68, 1.18);
}

/** What years on the job are worth, flattening off after about a decade. */
export function experienceFactor(years: number): number {
  return 1 + (Math.min(years, 10) / 10) * 0.14;
}

// ----------------------------------------------------------- performance

/**
 * One figure for how much this person is worth to the business today, 0..100.
 *
 * This is the number on their profile page, and it is the same number the
 * simulation multiplies by — there is no second, private calculation behind
 * it. Skill in the job they are actually doing, what their morale and workload
 * are doing to it, what experience has added, and what kind of worker they are.
 */
export function performanceOf(employee: Employee): number {
  const fit = roleFit(employee.skills, employee.role);
  const base = fit * 0.7 + employee.productivity * 0.3;
  const traits = employee.traits.reduce((acc, id) => acc * trait(id).productivity, 1);
  const value =
    base *
    fitFactor(fit) *
    moraleFactor(employee.morale) *
    workloadFactor(employee.workload) *
    experienceFactor(employee.experience) *
    gradeFactor(employee) *
    traits;
  return clamp(value, 0, 100);
}

/** Performance read in plain words, for the interface. */
export function performanceLabel(value: number): string {
  if (value >= 78) return 'Excellent';
  if (value >= 62) return 'Strong';
  if (value >= 45) return 'Steady';
  if (value >= 30) return 'Struggling';
  return 'Not working out';
}

export function fitLabel(fit: number): string {
  if (fit >= 72) return 'Made for this job';
  if (fit >= 56) return 'Well suited';
  if (fit >= 42) return 'Can do the job';
  if (fit >= 28) return 'Out of their depth';
  return 'Wrong job for them';
}

// -------------------------------------------------------------- training

export interface CourseDef {
  id: string;
  name: string;
  skill: SkillId;
  /** Days away from the floor. */
  days: number;
  /** Cost per day. */
  costPerDay: number;
  detail: string;
}

/**
 * Courses.
 *
 * Training is no longer "click for skill": a course puts somebody on a
 * particular skill, takes them off the floor for a week while the rest of the
 * team covers, and costs money. Which course is a management decision, because
 * the skill that helps depends on the seat they are in.
 */
export const COURSES: CourseDef[] = [
  { id: 'technical', name: 'Technical training', skill: 'technical', days: 6, costPerDay: 210, detail: 'The craft itself: faster, cleaner, fewer mistakes.' },
  { id: 'sales', name: 'Sales training', skill: 'sales', days: 5, costPerDay: 190, detail: 'Asking for the sale, and asking for the bigger one.' },
  { id: 'service', name: 'Customer service', skill: 'service', days: 4, costPerDay: 160, detail: 'How people feel on the way out, which is what they write down.' },
  { id: 'logistics', name: 'Stock and logistics', skill: 'logistics', days: 5, costPerDay: 175, detail: 'Where everything is, and how it gets there.' },
  { id: 'admin', name: 'Administration', skill: 'admin', days: 5, costPerDay: 185, detail: 'Ordering, paperwork and the things that go wrong quietly.' },
  { id: 'finance', name: 'Bookkeeping and finance', skill: 'finance', days: 7, costPerDay: 240, detail: 'Reading the numbers rather than filing them. The desk an accountant sits at.' },
  { id: 'communication', name: 'Communication', skill: 'communication', days: 4, costPerDay: 170, detail: 'Saying the difficult thing clearly, to a customer or to a colleague.' },
  { id: 'leadership', name: 'Leadership', skill: 'leadership', days: 8, costPerDay: 290, detail: 'Running a shift, and later a shop. The only way past Senior.' },
];

export const COURSE_BY_ID = new Map(COURSES.map((course) => [course.id, course]));

/** The course that would do this person the most good where they are. */
export function suggestedCourse(employee: Employee): CourseDef {
  const weights = ROLE_SKILLS[employee.role];
  // Somebody who has the level for the next rung and is only held back by
  // leadership has one obvious course, whatever their role leans on.
  const next = GRADES[gradeOf(employee).n + 1];
  if (next && employee.skill >= next.skill && employee.skills.leadership < next.leadership) {
    const leadership = COURSES.find((course) => course.skill === 'leadership');
    if (leadership) return leadership;
  }
  let best = COURSES[0];
  let gap = -1;
  for (const course of COURSES) {
    const weight = weights[course.skill] ?? 0;
    // Worth is how much the role leans on it times how much room there is.
    const worth = weight * (100 - (employee.skills[course.skill] ?? 0));
    if (worth > gap) {
      gap = worth;
      best = course;
    }
  }
  return best;
}

/**
 * Builds a skill profile around an overall level and the job they hold.
 *
 * Used for new applicants and to give people from older saves a profile that
 * matches what they were already good at, so nobody wakes up bad at their job.
 * The spread is drawn from a number the caller supplies, so it is repeatable.
 */
export function profileFor(
  overall: number,
  roleId: EmployeeRoleId,
  roll: (min: number, max: number) => number,
): SkillSet {
  const weights = ROLE_SKILLS[roleId];
  const skills = emptySkills();
  for (const id of SKILL_IDS) {
    const weight = weights[id] ?? 0;
    // What the job needs, they have; what it does not, they may or may not.
    const centre = overall * (0.55 + weight * 0.9);
    skills[id] = clamp(centre + roll(-11, 11), 3, 100);
  }
  // The profile has to average out to the level they were described as, or a
  // person's headline number would drift the moment they got one. Scaling
  // alone is not enough once a skill hits the ceiling, so whatever is left
  // over is spread across the skills that still have room.
  for (let pass = 0; pass < 6; pass += 1) {
    const mean = overallSkill(skills);
    const shortfall = overall - mean;
    if (Math.abs(shortfall) < 0.01) break;
    const room = SKILL_IDS.filter((id) => (shortfall > 0 ? skills[id] < 100 : skills[id] > 3));
    if (room.length === 0) break;
    const share = (shortfall * SKILL_IDS.length) / room.length;
    for (const id of room) skills[id] = clamp(skills[id] + share, 3, 100);
  }
  return skills;
}

/** The role definition, re-exported so views need one import for a person. */
export { role };
