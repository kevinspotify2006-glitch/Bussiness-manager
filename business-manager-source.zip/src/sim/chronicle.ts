import type { GameState } from './state';
import { playerBusinesses, playerCompany } from './state';
import { netWorth } from './finance';
import { calendar, money } from './format';
import { makeId, sum } from './util';

/**
 * What you did, and what the company became.
 *
 * A company that has been running for three game years has a past, and until
 * now the player had no way to see it. The news feed scrolls and is trimmed;
 * the ledger is capped at six hundred rows; the accounts are monthly totals
 * with the decisions taken out. None of them answer the question a person
 * actually asks after a long game, which is "how did I get here".
 *
 * Two things, kept separately because they are different questions:
 *
 *   The log      the decisions you made, in order, with what they cost
 *   The records  the highest the company ever reached, and when
 *
 * Nothing here is generated for the sake of having a timeline. Every entry is
 * written at the moment the thing actually happened, by the system that did it,
 * which is why the log cannot claim a hire that never occurred.
 */

export type ChronicleKind =
  | 'opened' | 'closed' | 'hired' | 'letGo' | 'promoted'
  | 'borrowed' | 'repaid' | 'bought' | 'merged'
  | 'contract' | 'research' | 'levelled' | 'crisis';

export interface ChronicleEntry {
  id: string;
  day: number;
  kind: ChronicleKind;
  /** One line, in the past tense, as a person would say it. */
  text: string;
  /** What it moved, where that is a single figure worth keeping. */
  amount: number | null;
  businessId: string | null;
}

/** How far back the log goes. Long enough for a decade of game time. */
export const CHRONICLE_LIMIT = 400;

/**
 * Records a decision.
 *
 * Called from wherever the decision is actually carried out, never from the
 * interface — the same rule the founder's learning follows, and for the same
 * reason: a log written by the screen would record what was displayed rather
 * than what happened.
 */
export function record(
  state: GameState,
  kind: ChronicleKind,
  text: string,
  options: { amount?: number; businessId?: string | null } = {},
): void {
  if (!state.chronicle) state.chronicle = [];
  state.chronicle.push({
    id: makeId('log'),
    day: state.day,
    kind,
    text,
    amount: options.amount ?? null,
    businessId: options.businessId ?? null,
  });
  if (state.chronicle.length > CHRONICLE_LIMIT) {
    state.chronicle.splice(0, state.chronicle.length - CHRONICLE_LIMIT);
  }
}

/** The log, newest first, optionally narrowed to one kind of decision. */
export function chronicle(state: GameState, kind?: ChronicleKind): ChronicleEntry[] {
  const all = [...(state.chronicle ?? [])].reverse();
  return kind ? all.filter((entry) => entry.kind === kind) : all;
}

/** The log grouped by month, which is how a person reads a history. */
export function chronicleByMonth(state: GameState): { label: string; entries: ChronicleEntry[] }[] {
  const groups = new Map<string, ChronicleEntry[]>();
  for (const entry of chronicle(state)) {
    const cal = calendar(entry.day);
    const label = `${cal.monthName} ${cal.year}`;
    const list = groups.get(label);
    if (list) list.push(entry);
    else groups.set(label, [entry]);
  }
  return [...groups.entries()].map(([label, entries]) => ({ label, entries }));
}

// ------------------------------------------------------------- the records

export interface Records {
  /** The most the company was ever worth, and when. */
  peakNetWorth: { value: number; day: number };
  peakRevenue: { value: number; day: number };
  peakProfit: { value: number; day: number };
  worstDay: { value: number; day: number };
  peakHeadcount: { value: number; day: number };
  peakLocations: { value: number; day: number };
}

export function emptyRecords(): Records {
  const zero = { value: 0, day: 0 };
  return {
    peakNetWorth: { ...zero },
    peakRevenue: { ...zero },
    peakProfit: { ...zero },
    worstDay: { ...zero },
    peakHeadcount: { ...zero },
    peakLocations: { ...zero },
  };
}

/**
 * Updates the high-water marks.
 *
 * Run once at the daily settlement, against figures the simulation has already
 * produced — so a record is a thing that genuinely happened on a day the player
 * can go and look at, not a running maximum of something invented here.
 */
export function recordsDaily(state: GameState): void {
  if (!state.records) state.records = emptyRecords();
  const records = state.records;
  const today = state.dayHistory[state.dayHistory.length - 1];
  if (!today) return;

  const beat = (record: { value: number; day: number }, value: number): void => {
    if (value > record.value) {
      record.value = value;
      record.day = state.day;
    }
  };

  beat(records.peakNetWorth, netWorth(state));
  beat(records.peakRevenue, today.revenue);
  beat(records.peakProfit, today.profit);
  beat(records.peakHeadcount, state.employees.length);
  beat(records.peakLocations, playerBusinesses(state).filter((b) => b.status === 'open').length);
  if (today.profit < records.worstDay.value) {
    records.worstDay.value = today.profit;
    records.worstDay.day = state.day;
  }
}

/** The records as the screen shows them: what, how much, and when. */
export function recordRows(state: GameState): { label: string; value: string; when: string }[] {
  const records = state.records ?? emptyRecords();
  const when = (day: number): string => (day > 0 ? calendar(day).label : 'not yet');
  return [
    { label: 'Most the company has been worth', value: money(records.peakNetWorth.value), when: when(records.peakNetWorth.day) },
    { label: 'Best day of trading', value: money(records.peakRevenue.value), when: when(records.peakRevenue.day) },
    { label: 'Best day of profit', value: money(records.peakProfit.value), when: when(records.peakProfit.day) },
    { label: 'Worst day', value: money(records.worstDay.value), when: when(records.worstDay.day) },
    { label: 'Most people employed', value: String(records.peakHeadcount.value), when: when(records.peakHeadcount.day) },
    { label: 'Most locations open', value: String(records.peakLocations.value), when: when(records.peakLocations.day) },
  ];
}

/**
 * The company in a paragraph.
 *
 * Read from the log and the records rather than written anywhere, so it is
 * always about the company the player actually built.
 */
export function summary(state: GameState): string {
  const company = playerCompany(state);
  const log = state.chronicle ?? [];
  const opened = log.filter((e) => e.kind === 'opened').length;
  const hired = log.filter((e) => e.kind === 'hired').length;
  const borrowed = sum(log.filter((e) => e.kind === 'borrowed'), (e) => e.amount ?? 0);
  const bought = log.filter((e) => e.kind === 'bought' || e.kind === 'merged').length;
  const years = (state.day / 360).toFixed(1);

  const parts = [`${company.name} has been trading for ${years} years.`];
  if (opened > 0) parts.push(`${opened} location${opened === 1 ? '' : 's'} opened.`);
  if (hired > 0) parts.push(`${hired} ${hired === 1 ? 'person' : 'people'} hired.`);
  if (borrowed > 0) parts.push(`${money(borrowed)} borrowed.`);
  if (bought > 0) parts.push(`${bought} ${bought === 1 ? 'company' : 'companies'} bought.`);
  if (log.length === 0) parts.push('Nothing has happened yet worth writing down.');
  return parts.join(' ');
}
