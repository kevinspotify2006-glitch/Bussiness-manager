import type { GameState } from './state';
import { playerBusinesses } from './state';
import { marketRate } from './employees';
import { record } from './chronicle';
import { pushNews } from './news';
import { clamp } from './util';

/**
 * How the company does things, everywhere at once.
 *
 * Until now every one of these decisions was taken a shop at a time, or not at
 * all: what somebody is paid was a number on one person's record, which supplier
 * to buy from was a choice made in one order, how hard people are worked was
 * whatever the rota happened to produce. That is how a company with two shops
 * works. It is not how a company with fifteen works, and a head office that
 * cannot set a rule that applies to all of them is not really a head office.
 *
 * So: four rules, set once, applied everywhere.
 *
 * Every one of them is a genuine trade — there is no setting here that is
 * simply better, and none of them costs money to change. What they cost is the
 * other side of the trade, which lands in systems that already existed:
 *
 *   Pay        salaries, and therefore morale, resignations and the wage bill
 *   Hours      how many customers the same people can serve, and how they feel
 *   Hiring     who applies, how many of them, and what the recruiter charges
 *   Buying     which supplier the shops order from, and what arrives
 *
 * Nothing here holds a number of its own that the rest of the game reads back.
 * A policy is a choice; the consequences are computed where they always were.
 */

export type PolicyId = 'pay' | 'hours' | 'hiring' | 'buying';

export interface PolicyOption {
  id: string;
  name: string;
  /** The trade, said in one line, in the terms it actually works in. */
  detail: string;
}

export interface PolicyDef {
  id: PolicyId;
  name: string;
  question: string;
  options: PolicyOption[];
  /** Which option a company runs on before anybody decides otherwise. */
  fallback: string;
}

export const POLICIES: PolicyDef[] = [
  {
    id: 'pay',
    name: 'What we pay',
    question: 'Where the company sits against what everybody else is paying.',
    fallback: 'market',
    options: [
      {
        id: 'lean',
        name: 'Under the market',
        detail: 'Wages drift to about 88% of the going rate. Cheaper every month, and people leave.',
      },
      {
        id: 'market',
        name: 'At the market',
        detail: 'Wages drift to whatever the job is worth. Nobody is delighted and nobody is insulted.',
      },
      {
        id: 'generous',
        name: 'Over the market',
        detail: 'Wages drift to about 112% of the rate. It costs, and people stay, and better ones apply.',
      },
    ],
  },
  {
    id: 'hours',
    name: 'How hard we work people',
    question: 'What happens when there are more customers than there are hands.',
    fallback: 'standard',
    options: [
      {
        id: 'standard',
        name: 'Standard hours',
        detail: 'People do a day and go home. Busy days lose customers you could have served.',
      },
      {
        id: 'overtime',
        name: 'Overtime when it is busy',
        detail: '15% more out of the same people, paid for in morale and in days off sick.',
      },
    ],
  },
  {
    id: 'hiring',
    name: 'How we hire',
    question: 'Whether to fill a job quickly or fill it well.',
    fallback: 'quick',
    options: [
      {
        id: 'quick',
        name: 'Fill the job',
        detail: 'A full board of applicants, most of them ordinary, and a cheap recruiter.',
      },
      {
        id: 'careful',
        name: 'Hold out for the right person',
        detail: 'Fewer applicants and better ones, and the recruiter charges half again for finding them.',
      },
    ],
  },
  {
    id: 'buying',
    name: 'How we buy',
    question: 'What the shops order when they reorder on their own.',
    fallback: 'cheapest',
    options: [
      {
        id: 'cheapest',
        name: 'Cheapest that will do',
        detail: 'The lowest price on the list. Margin now, and reviews that notice.',
      },
      {
        id: 'balanced',
        name: 'Whatever is worth the money',
        detail: 'Price weighed against what turns up. The middle of the market.',
      },
      {
        id: 'best',
        name: 'The best available',
        detail: 'Quality first whatever it costs. Customers can tell, and so can the margin.',
      },
    ],
  },
];

export function policyDef(id: PolicyId): PolicyDef | undefined {
  return POLICIES.find((p) => p.id === id);
}

export function emptyPolicies(): Record<PolicyId, string> {
  const out = {} as Record<PolicyId, string>;
  for (const def of POLICIES) out[def.id] = def.fallback;
  return out;
}

/** Which option is in force. Falls back rather than throwing on an odd save. */
export function policy(state: GameState, id: PolicyId): string {
  const chosen = state.policies?.[id];
  const def = policyDef(id);
  if (!def) return '';
  return def.options.some((option) => option.id === chosen) ? (chosen as string) : def.fallback;
}

export function policyOption(state: GameState, id: PolicyId): PolicyOption {
  const def = policyDef(id)!;
  return def.options.find((option) => option.id === policy(state, id)) ?? def.options[0];
}

/**
 * Changing a policy.
 *
 * Free, and instant, and that is deliberate — the cost of a policy is what it
 * does, not a fee for setting it. What stops a player flipping between them
 * every week is that pay and morale both take time to move, so the company
 * spends the whole of that time getting the worst of both.
 */
export function setPolicy(state: GameState, id: PolicyId, optionId: string): { ok: boolean; message: string } {
  const def = policyDef(id);
  if (!def) return { ok: false, message: 'Unknown policy.' };
  const option = def.options.find((o) => o.id === optionId);
  if (!option) return { ok: false, message: 'Unknown option.' };
  if (!state.policies) state.policies = emptyPolicies();
  if (state.policies[id] === optionId) return { ok: false, message: `${def.name} is already set that way.` };

  state.policies[id] = optionId;
  record(state, 'levelled', `${def.name}: ${option.name.toLowerCase()}`);
  if (playerBusinesses(state).some((b) => b.status === 'open')) {
    pushNews(state, 'company', `${def.name} — ${option.name}`, option.detail, { importance: 'normal' });
  }
  return { ok: true, message: `${def.name}: ${option.name.toLowerCase()}.` };
}

// ---------------------------------------------------------------- the effects
// Each of these is read by a system that already existed. A policy with no call
// site would be exactly the decorative setting this game is not supposed to have.

/** Where the company aims to sit against the going rate for a job. */
export function payTarget(state: GameState): number {
  const chosen = policy(state, 'pay');
  if (chosen === 'lean') return 0.88;
  if (chosen === 'generous') return 1.12;
  return 1;
}

/**
 * How fast salaries move towards the band the policy aims at.
 *
 * Slow on purpose. A company that cuts its pay policy does not cut anybody's
 * wages tomorrow — it stops giving rises, and the market catches up with it —
 * and a company that raises it does not get a better team the same afternoon.
 */
export const PAY_DRIFT = 0.0025;

/** What overtime does to how many customers the same people can serve. */
export function hoursFactor(state: GameState): number {
  return policy(state, 'hours') === 'overtime' ? 1.15 : 1;
}

/** And what it does to the people doing it, per day, on morale. */
export function hoursMoraleDrag(state: GameState): number {
  return policy(state, 'hours') === 'overtime' ? 0.09 : 0;
}

/** How much more likely somebody is to be off sick under overtime. */
export function sicknessFactor(state: GameState): number {
  return policy(state, 'hours') === 'overtime' ? 1.35 : 1;
}

/** What holding out for the right person does to who applies. */
export function applicantSkillBias(state: GameState): number {
  return policy(state, 'hiring') === 'careful' ? 11 : 0;
}

/** And to how many of them there are. */
export function applicantCountFactor(state: GameState): number {
  return policy(state, 'hiring') === 'careful' ? 0.6 : 1;
}

/** And to what the recruiter charges for doing the looking. */
export function hiringFeeFactor(state: GameState): number {
  return policy(state, 'hiring') === 'careful' ? 1.5 : 1;
}

/**
 * How the shops rank suppliers when they reorder on their own.
 *
 * Returned as a weighting rather than a sort, so the one place that actually
 * orders stock still does the ordering — this only says what it is looking for.
 * Higher is better.
 */
export function supplierScore(
  state: GameState,
  supplier: { priceMultiplier: number; quality: number; reliability: number },
): number {
  const chosen = policy(state, 'buying');
  const cheapness = 2 - clamp(supplier.priceMultiplier, 0.5, 1.6);
  if (chosen === 'best') return supplier.quality * 2 + supplier.reliability - cheapness * 0.2;
  if (chosen === 'balanced') return supplier.quality + supplier.reliability * 0.6 + cheapness * 0.8;
  return cheapness * 2 + supplier.reliability * 0.3;
}

// ------------------------------------------------------------------- the drift

/**
 * Wages moving towards where the policy says they should be.
 *
 * Run once a day against the same market rate everything else reads, so a
 * generous policy shows up as a larger wage bill and a happier team through
 * exactly the machinery that was already deciding both.
 */
export function policiesDaily(state: GameState): void {
  const target = payTarget(state);
  for (const employee of state.employees) {
    if (employee.companyId !== state.playerCompanyId) continue;
    const band = marketRate(state, employee);
    if (band <= 0) continue;
    const wanted = band * target;
    const gap = wanted - employee.salary;
    if (Math.abs(gap) < 1) continue;
    // Rises come faster than cuts, because a cut is a conversation and a rise
    // is an email. A company on a lean policy mostly gets there by standing
    // still while the market moves, which is how it actually happens.
    const speed = gap > 0 ? PAY_DRIFT : PAY_DRIFT * 0.45;
    employee.salary = Math.max(0, Math.round(employee.salary + gap * speed * 30));
  }
}

// ------------------------------------------------------------- for the screen

export interface PolicyRow {
  def: PolicyDef;
  chosen: PolicyOption;
}

export function policyRows(state: GameState): PolicyRow[] {
  return POLICIES.map((def) => ({ def, chosen: policyOption(state, def.id) }));
}
