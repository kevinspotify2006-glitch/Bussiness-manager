import type { GameState } from './state';
import { LEDGER_LIMIT, companyById, playerBusinesses, playerCompany } from './state';
import type { LedgerCategory, Loan } from './types';
import { product } from '../data/products';
import { businessTypeOrThrow } from '../data/businessTypes';
import { clamp, makeId, sum } from './util';
import { DAYS_PER_MONTH, money } from './format';
import { gameRng } from './rng';
import { creditMultiplier } from './progress';
import { taxFactor } from './headOffice';
import { learn, lendingFactor, rateDiscount } from './founder';
import { releaseTaxReserve } from './workingCapital';
import { record } from './chronicle';

export const LEDGER_LABELS: Record<LedgerCategory, string> = {
  sales: 'Product sales',
  service: 'Service revenue',
  stock: 'Stock purchased',
  cogs: 'Cost of goods sold',
  wages: 'Wages',
  rent: 'Rent',
  utilities: 'Utilities',
  marketing: 'Marketing',
  logistics: 'Logistics',
  setup: 'Fit-out',
  equipment: 'Equipment',
  property: 'Property',
  renovation: 'Renovation',
  loan: 'Loan',
  equity: 'Investment',
  dividend: 'Investor distribution',
  interest: 'Interest',
  tax: 'Tax',
  training: 'Training',
  severance: 'Severance',
  invoice: 'Customer payments',
  billpay: 'Supplier payments',
  recruitment: 'Recruitment',
  management: 'Management and coordination',
  outsourcing: 'Outsourced services',
  other: 'Other',
};

/**
 * What counts as revenue in the profit and loss account.
 *
 * `invoice` is deliberately absent: the sale was recognised on the day the work
 * was done, and counting the customer's cheque as a second sale would let a
 * company book the same euro twice.
 */
const REVENUE_CATEGORIES: LedgerCategory[] = ['sales', 'service'];

/**
 * Operating costs belong in the profit and loss account. Capital items —
 * buying a building, fitting out a shop, drawing or repaying a loan — move
 * cash but are not costs of trading, and counting them as such would make
 * every expansion look like a disaster.
 */
const OPERATING_COSTS: LedgerCategory[] = [
  'cogs', 'wages', 'rent', 'utilities', 'marketing', 'logistics', 'tax', 'training', 'severance',
  'recruitment', 'management', 'outsourcing', 'interest',
];

export function isRevenue(category: LedgerCategory): boolean {
  return REVENUE_CATEGORIES.includes(category);
}

export function isOperatingCost(category: LedgerCategory): boolean {
  return OPERATING_COSTS.includes(category);
}

/** Trading revenue and operating costs booked on a given day. */
export function dayTotals(state: GameState, day: number): { revenue: number; costs: number } {
  let revenue = 0;
  let costs = 0;
  for (const entry of state.ledger) {
    if (entry.day !== day) continue;
    if (isRevenue(entry.category)) revenue += entry.amount;
    else if (isOperatingCost(entry.category)) costs += -entry.amount;
  }
  return { revenue, costs: Math.max(0, costs) };
}

/**
 * Adds a movement to the month's running totals.
 *
 * Every euro that reaches the ledger passes through here too, so the management
 * accounts are complete even though the ledger itself is trimmed.
 */
function accrue(state: GameState, category: LedgerCategory, amount: number, businessId: string | null): void {
  const totals = state.period;
  totals.categories[category] = (totals.categories[category] ?? 0) + Math.abs(amount);
  if (!businessId) return;
  if (isRevenue(category)) {
    totals.revenueByBusiness[businessId] = (totals.revenueByBusiness[businessId] ?? 0) + amount;
  } else if (isOperatingCost(category)) {
    totals.costsByBusiness[businessId] = (totals.costsByBusiness[businessId] ?? 0) + Math.abs(amount);
  }
}

/**
 * The only way money moves. Every euro in the game passes through here, which
 * is what makes the finance screen and the "why did profit change" breakdown
 * trustworthy.
 */
export function post(
  state: GameState,
  companyId: string,
  category: LedgerCategory,
  label: string,
  amount: number,
  businessId: string | null = null,
): void {
  if (!Number.isFinite(amount) || amount === 0) return;
  const company = companyById(state, companyId);
  if (!company) return;
  company.cash += amount;

  if (!company.isPlayer) return; // the ledger only tracks the player's books

  if (amount > 0) state.stats.revenueTotal += amount;
  else state.stats.costsTotal += -amount;
  accrue(state, category, amount, businessId);

  const last = state.ledger[state.ledger.length - 1];
  // Collapse identical movements within the same hour so a busy shop does not
  // write one row per customer.
  if (
    last &&
    last.day === state.day &&
    last.hour === state.hour &&
    last.category === category &&
    last.label === label &&
    last.businessId === businessId
  ) {
    last.amount += amount;
    return;
  }

  state.ledger.push({
    day: state.day,
    hour: state.hour,
    category,
    label,
    amount,
    businessId,
  });
  if (state.ledger.length > LEDGER_LIMIT) {
    state.ledger.splice(0, state.ledger.length - LEDGER_LIMIT);
  }
}

/**
 * Records a cost that does not move cash. Cost of goods sold is the important
 * one: the cash left when the stock was bought, so charging it again at the
 * till would count it twice — but leaving it out of the profit figure would
 * make every shop look far more profitable than it is.
 */
export function postNonCash(
  state: GameState,
  companyId: string,
  category: LedgerCategory,
  label: string,
  amount: number,
  businessId: string | null = null,
): void {
  if (!Number.isFinite(amount) || amount === 0) return;
  const company = companyById(state, companyId);
  if (!company || !company.isPlayer) return;
  accrue(state, category, amount, businessId);

  const last = state.ledger[state.ledger.length - 1];
  if (
    last &&
    last.day === state.day &&
    last.hour === state.hour &&
    last.category === category &&
    last.label === label &&
    last.businessId === businessId
  ) {
    last.amount += amount;
    return;
  }
  state.ledger.push({ day: state.day, hour: state.hour, category, label, amount, businessId });
  if (state.ledger.length > LEDGER_LIMIT) {
    state.ledger.splice(0, state.ledger.length - LEDGER_LIMIT);
  }
}

// ------------------------------------------------------------- net worth

export function inventoryValue(state: GameState): number {
  let total = 0;
  for (const business of playerBusinesses(state)) {
    for (const [productId, units] of Object.entries(business.stock)) {
      const def = product(productId);
      if (def) total += def.wholesalePrice * units;
    }
  }
  return total;
}

export function propertyValue(state: GameState): number {
  const player = playerCompany(state);
  return sum(
    state.buildings.filter((b) => b.status === 'owned' && b.occupantCompanyId === player.id),
    (b) => b.value,
  );
}

export function debtTotal(state: GameState): number {
  return sum(state.loans, (loan) => loan.outstanding);
}

/** Businesses are worth a multiple of their recent profit, plus their fit-out. */
export function goodwillValue(state: GameState): number {
  let total = 0;
  for (const business of playerBusinesses(state)) {
    if (business.status !== 'open') continue;
    const recent = business.profitHistory.slice(-30);
    if (recent.length === 0) continue;
    const average = sum(recent, (value) => value) / recent.length;
    total += Math.max(0, average * 120);
  }
  return total;
}

/**
 * What the company is worth: everything it owns, less everything it owes.
 *
 * The sales and purchase ledgers belong here and nowhere else. Money a customer
 * owes you is an asset you happen not to be holding, and a supplier's bill is a
 * liability whether or not the due date has arrived — leaving either off makes
 * a company with customers look poorer than it is and a company with creditors
 * look richer, which is the difference between a balance sheet and a guess.
 */
export function netWorth(state: GameState): number {
  return (
    playerCompany(state).cash +
    receivablesValue(state) +
    inventoryValue(state) +
    propertyValue(state) +
    goodwillValue(state) -
    payablesValue(state) -
    debtTotal(state)
  );
}

/** Owed to the company and not yet collected. */
export function receivablesValue(state: GameState): number {
  return sum(state.invoices, (invoice) => invoice.amount);
}

/** Owed by the company: supplier bills, and the tax already set aside. */
export function payablesValue(state: GameState): number {
  return sum(state.bills, (bill) => bill.amount) + Math.max(0, state.taxReserve);
}

// ------------------------------------------------------------------ loans

export interface LoanTypeDef {
  id: string;
  name: string;
  /** What the borrowing is for, in the player's words. */
  detail: string;
  /** Added to the base rate. */
  spread: number;
  termMonths: number;
  minimumCreditRating: number;
  /** What the loan is secured against, which is what caps it. */
  security: 'assets' | 'equipment' | 'property' | 'nothing';
}

/**
 * The kinds of borrowing, and why anybody would pick one over another.
 *
 * They are not the same loan at three sizes. What a loan is secured against
 * decides how much of it you can have and what it costs: a mortgage on a
 * freehold is cheap because the bank can take the building, and an unsecured
 * overdraft when you are nearly out of money is dear for exactly the same
 * reason. That is the whole decision — borrow cheaply against something you
 * own, or dearly against nothing but a promise.
 */
export const LOAN_TYPES: LoanTypeDef[] = [
  {
    id: 'working',
    name: 'Working capital',
    detail: 'A year of breathing room, to be paid back out of trade rather than growth.',
    spread: 0.052,
    termMonths: 12,
    minimumCreditRating: 30,
    security: 'nothing',
  },
  {
    id: 'business',
    name: 'Business loan',
    detail: 'The ordinary one. Four years, secured on what the company owns.',
    spread: 0.031,
    termMonths: 48,
    minimumCreditRating: 50,
    security: 'assets',
  },
  {
    id: 'equipment',
    name: 'Equipment finance',
    detail: 'Against the ovens, the lifts and the vans. Cheap, and limited to what they are worth.',
    spread: 0.024,
    termMonths: 36,
    minimumCreditRating: 45,
    security: 'equipment',
  },
  {
    id: 'expansion',
    name: 'Expansion loan',
    detail: 'Seven years at the best rate on offer, for a company with a record behind it.',
    spread: 0.019,
    termMonths: 84,
    minimumCreditRating: 70,
    security: 'assets',
  },
  {
    id: 'property',
    name: 'Property loan',
    detail: 'A mortgage on the freeholds you hold. The longest and the cheapest, because the bank can take the building.',
    spread: 0.009,
    termMonths: 180,
    minimumCreditRating: 60,
    security: 'property',
  },
  {
    id: 'emergency',
    name: 'Emergency credit',
    detail: 'Money today, at a price. Only ever worth it against a bill you cannot miss.',
    spread: 0.145,
    termMonths: 18,
    minimumCreditRating: 0,
    security: 'nothing',
  },
];

export function loanType(id: string): LoanTypeDef {
  return LOAN_TYPES.find((t) => t.id === id) ?? LOAN_TYPES[1];
}

export interface LoanOffer {
  id: string;
  lender: string;
  type: LoanTypeDef;
  maxPrincipal: number;
  annualRate: number;
  termMonths: number;
  minimumCreditRating: number;
  /** Why this one is not available, if it is not. */
  blocked: string | null;
}

const LENDERS: Record<string, string> = {
  working: 'Northgate Credit Union',
  business: 'Meridian Business Bank',
  equipment: 'Kestrel Asset Finance',
  expansion: 'Halcyon Capital',
  property: 'Northgate Mutual',
  emergency: 'Vantage Bridging',
};

/**
 * What the company could borrow today, and on what terms.
 *
 * The list is live rather than fixed: equipment finance needs equipment to
 * secure it, a mortgage needs a freehold, and emergency credit only appears
 * when the company is actually in trouble — because offering it to a healthy
 * company would be offering a trap with no reason to take it.
 */
export function loanOffers(state: GameState): LoanOffer[] {
  const company = playerCompany(state);
  const base = state.economy.interestRate;
  const headroom = borrowingHeadroom(state);
  const equipment = equipmentValue(state);
  const freeholds = propertyValue(state);
  const runway = dailyOutgoings(state) > 0 ? company.cash / dailyOutgoings(state) : 99;

  const offers: LoanOffer[] = [];
  for (const type of LOAN_TYPES) {
    let ceiling = headroom;
    let blocked: string | null = null;

    if (type.security === 'equipment') {
      // Against the kit itself, at a haircut, less whatever is already on it.
      ceiling = Math.min(headroom + equipment * 0.6, equipment * 0.6);
      if (equipment < 5_000) blocked = 'You have no equipment worth securing a loan against.';
    } else if (type.security === 'property') {
      ceiling = Math.min(headroom + freeholds * 0.75, freeholds * 0.75);
      if (freeholds < 20_000) blocked = 'A mortgage needs a freehold. You are renting everywhere.';
    } else if (type.id === 'emergency') {
      // Unsecured, so it does not touch headroom — and it is only on the table
      // when the company is genuinely short.
      ceiling = Math.max(15_000, dailyOutgoings(state) * 45);
      if (runway > 30 && company.cash > 0) blocked = 'You are not short of cash. This is not a loan to take for fun.';
    } else if (type.id === 'working') {
      ceiling = Math.min(headroom + 20_000, Math.max(20_000, dailyOutgoings(state) * 60));
    }

    if (!blocked && company.creditRating < type.minimumCreditRating) {
      blocked = `${LENDERS[type.id]} wants a credit rating of ${type.minimumCreditRating}. Yours is ${Math.round(company.creditRating)}.`;
    }
    if (!blocked && ceiling < 1_000) {
      blocked = 'The bank will not lend anything more against what you own.';
    }

    offers.push({
      id: type.id,
      lender: LENDERS[type.id] ?? 'The bank',
      type,
      maxPrincipal: Math.max(0, Math.round(ceiling / 1000) * 1000),
      // A poor credit rating costs real money on top of the spread.
      // Somebody who knows what a lender is looking at is quoted better terms.
      annualRate: Math.max(
        0.005,
        base + type.spread + clamp((60 - company.creditRating) / 100, 0, 0.6) * 0.06 - rateDiscount(state),
      ),
      termMonths: type.termMonths,
      minimumCreditRating: type.minimumCreditRating,
      blocked,
    });
  }
  return offers;
}

/** What the company spends on an average day, used to size short-term credit. */
function dailyOutgoings(state: GameState): number {
  const recent = state.dayHistory.slice(-14);
  if (recent.length === 0) return 0;
  return Math.max(0, sum(recent, (day) => day.costs) / recent.length);
}

/** Depreciated value of the equipment in every trading location. */
export function equipmentValue(state: GameState): number {
  return sum(
    state.businesses.filter((b) => b.companyId === state.playerCompanyId && b.status !== 'closed'),
    (business) => {
      const type = businessTypeOrThrow(business.typeId);
      const age = Math.max(0, state.day - business.openedOnDay);
      return type.equipmentCost * clamp(1 - age / 1800, 0.3, 1);
    },
  );
}

/** Standard annuity payment. */
export function monthlyPayment(principal: number, annualRate: number, months: number): number {
  const monthly = annualRate / 12;
  if (monthly <= 0) return principal / months;
  const factor = Math.pow(1 + monthly, months);
  return (principal * monthly * factor) / (factor - 1);
}

/**
 * How many months it takes to clear a loan from where it stands now.
 *
 * This is the number that makes paying early worth anything. The monthly
 * payment does not change when you put a lump sum in — the term does, and it
 * shortens faster than the lump sum alone suggests, because every month you
 * remove is a month of interest you never pay.
 */
export function monthsRemaining(outstanding: number, annualRate: number, payment: number): number {
  if (outstanding <= 0) return 0;
  const monthly = annualRate / 12;
  if (monthly <= 0) return Math.ceil(outstanding / Math.max(1, payment));
  // If the payment does not cover the interest the debt never clears. The bank
  // would not have written that loan, but arithmetic should not pretend.
  if (payment <= outstanding * monthly) return Infinity;
  return Math.ceil(-Math.log(1 - (monthly * outstanding) / payment) / Math.log(1 + monthly));
}

/** Every euro of interest still to be paid, if nothing is paid early. */
export function interestRemaining(outstanding: number, annualRate: number, payment: number): number {
  const months = monthsRemaining(outstanding, annualRate, payment);
  if (!Number.isFinite(months)) return Infinity;
  return Math.max(0, months * payment - outstanding);
}

export interface RepaymentQuote {
  /** What would actually leave the account. */
  amount: number;
  outstandingAfter: number;
  monthsBefore: number;
  monthsAfter: number;
  interestBefore: number;
  interestAfter: number;
  /** The whole point: what paying this today is worth in interest never paid. */
  interestSaved: number;
  /** Why it cannot be done, if it cannot. */
  blocked: string | null;
}

/**
 * What paying a given amount off today would actually do.
 *
 * Everything the repayment screen shows comes from here, so the figure quoted
 * before the click is the figure that happens after it.
 */
export function quoteRepayment(state: GameState, loanId: string, amount: number): RepaymentQuote | null {
  const loan = state.loans.find((l) => l.id === loanId);
  if (!loan) return null;
  const company = playerCompany(state);
  const wanted = Math.min(Math.max(0, Math.round(amount)), loan.outstanding);
  const monthsBefore = monthsRemaining(loan.outstanding, loan.annualRate, loan.monthlyPayment);
  const interestBefore = interestRemaining(loan.outstanding, loan.annualRate, loan.monthlyPayment);
  const after = Math.max(0, loan.outstanding - wanted);
  const monthsAfter = monthsRemaining(after, loan.annualRate, loan.monthlyPayment);
  const interestAfter = interestRemaining(after, loan.annualRate, loan.monthlyPayment);

  let blocked: string | null = null;
  if (wanted <= 0) blocked = 'Name an amount first.';
  else if (company.cash < wanted) {
    blocked = `That is ${money(wanted - company.cash)} more than you have in the bank.`;
  }

  return {
    amount: wanted,
    outstandingAfter: after,
    monthsBefore,
    monthsAfter,
    interestBefore,
    interestAfter,
    interestSaved: Number.isFinite(interestBefore) && Number.isFinite(interestAfter) ? interestBefore - interestAfter : 0,
    blocked,
  };
}

/** How much the bank is willing to lend on top of existing debt. */
export function borrowingHeadroom(state: GameState): number {
  const company = playerCompany(state);
  const secured = propertyValue(state) * 0.7 + goodwillValue(state) * 0.4;
  const rating = clamp(company.creditRating / 100, 0.1, 1);
  // A bank lends to a track record as well as to a balance sheet.
  const standing = creditMultiplier(state);
  return Math.max(0, (secured + 25000 * rating) * (0.6 + rating) * standing * lendingFactor(state) - debtTotal(state));
}

export function takeLoan(
  state: GameState,
  offerId: string,
  principal: number,
): { ok: boolean; message: string } {
  const offer = loanOffers(state).find((o) => o.id === offerId);
  if (!offer) return { ok: false, message: 'Unknown loan offer.' };
  const company = playerCompany(state);
  // Each kind of borrowing has its own ceiling, because each is secured
  // against something different — the generic headroom is only one of them.
  if (offer.blocked) return { ok: false, message: offer.blocked };
  if (principal > offer.maxPrincipal) {
    return {
      ok: false,
      message: `${offer.lender} will lend up to ${money(offer.maxPrincipal)} on this. Ask for less.`,
    };
  }
  const amount = Math.round(clamp(principal, 1000, offer.maxPrincipal));

  const loan: Loan = {
    id: makeId('loan'),
    lender: offer.lender,
    typeId: offer.type.id,
    principal: amount,
    outstanding: amount,
    annualRate: offer.annualRate,
    termMonths: offer.termMonths,
    monthlyPayment: Math.round(monthlyPayment(amount, offer.annualRate, offer.termMonths)),
    takenOnDay: state.day,
    missedPayments: 0,
    interestPaid: 0,
    earlyRepaid: 0,
  };
  state.loans.push(loan);
  learn(state, 'borrowed');
  record(state, 'borrowed', `Borrowed ${money(amount)} from ${offer.lender}`, { amount });
  post(state, company.id, 'loan', `${offer.lender} loan`, amount);
  return { ok: true, message: `${offer.lender} approved €${amount.toLocaleString('en-GB')}.` };
}

/**
 * Pays a lump sum off a loan.
 *
 * The monthly payment is left alone deliberately. Putting money in shortens the
 * term rather than easing the instalment, which is what makes early repayment
 * worth doing at all — every month removed is a month of interest never paid.
 * The saving is quoted before the click and reported after it.
 */
export function repayLoan(state: GameState, loanId: string, amount: number): { ok: boolean; message: string } {
  const loan = state.loans.find((l) => l.id === loanId);
  if (!loan) return { ok: false, message: 'Loan not found.' };
  const quote = quoteRepayment(state, loanId, amount);
  if (!quote) return { ok: false, message: 'Loan not found.' };
  if (quote.blocked) return { ok: false, message: quote.blocked };

  const company = playerCompany(state);
  loan.outstanding = quote.outstandingAfter;
  loan.earlyRepaid += quote.amount;
  learn(state, 'repaid');
  record(state, 'repaid', `Paid ${money(quote.amount)} off the ${loan.lender} loan`, { amount: -quote.amount });
  post(state, company.id, 'loan', `Early repayment — ${loan.lender}`, -quote.amount);

  if (loan.outstanding < 1) {
    state.loans = state.loans.filter((l) => l.id !== loan.id);
    company.creditRating = clamp(company.creditRating + 4, 0, 100);
    return {
      ok: true,
      message: `${loan.lender} is cleared. ${
        quote.interestSaved > 1 ? `That saved ${money(quote.interestSaved)} in interest you will now never pay. ` : ''
      }Credit rating improved.`,
    };
  }
  const months = Math.max(0, Math.round(quote.monthsBefore - quote.monthsAfter));
  return {
    ok: true,
    message: `Repaid ${money(quote.amount)}.${
      months > 0 ? ` ${months} month${months === 1 ? '' : 's'} off the term` : ''
    }${quote.interestSaved > 1 ? `, ${money(quote.interestSaved)} of interest saved.` : '.'}`,
  };
}

/** Charged on the first day of every month. */
export function settleLoansMonthly(state: GameState): { paid: number; missed: number } {
  const company = playerCompany(state);
  let paid = 0;
  let missed = 0;
  for (const loan of [...state.loans]) {
    const interest = loan.outstanding * (loan.annualRate / 12);
    const payment = Math.min(loan.monthlyPayment, loan.outstanding + interest);
    if (company.cash >= payment) {
      post(state, company.id, 'interest', `Interest — ${loan.lender}`, -interest);
      loan.interestPaid += interest;
      post(state, company.id, 'loan', `Repayment — ${loan.lender}`, -(payment - interest));
      loan.outstanding = Math.max(0, loan.outstanding - (payment - interest));
      paid += payment;
      company.creditRating = clamp(company.creditRating + 0.4, 0, 100);
    } else {
      loan.missedPayments += 1;
      loan.outstanding += interest + payment * 0.05; // interest rolls up plus a penalty
      missed += 1;
      company.creditRating = clamp(company.creditRating - 9, 0, 100);
    }
    if (loan.outstanding < 1) state.loans = state.loans.filter((l) => l.id !== loan.id);
  }
  return { paid, missed };
}

// -------------------------------------------------------------------- tax

/** Corporation tax on the month's profit; losses carry no refund. */
export const TAX_RATE = 0.19;

export function monthlyProfit(state: GameState, days: number): { revenue: number; costs: number; profit: number } {
  const from = state.day - days;
  let revenue = 0;
  let costs = 0;
  for (const record of state.dayHistory) {
    if (record.day <= from) continue;
    revenue += record.revenue;
    costs += record.costs;
  }
  return { revenue, costs, profit: revenue - costs };
}

export function chargeTax(state: GameState): number {
  const { profit } = monthlyProfit(state, 30);
  if (profit <= 0) {
    // A loss-making month owes nothing, and whatever was set aside against a
    // profit that did not arrive is the company's money again.
    releaseTaxReserve(state, state.taxReserve);
    return 0;
  }
  // A finance department knows what is deductible. Nothing dramatic, and over a
  // year it is a salary.
  const tax = profit * TAX_RATE * taxFactor(state);
  post(state, state.playerCompanyId, 'tax', 'Corporation tax', -tax);
  // The bill was being set aside all month; paying it releases the reserve.
  releaseTaxReserve(state, tax);
  return tax;
}

/** What the company should be putting by, as a share of what it earns. */
export function taxRateNow(state: GameState): number {
  return TAX_RATE * taxFactor(state);
}

/**
 * What a lender thinks of this company.
 *
 * The old version asked two questions — did you make a profit, is your balance
 * positive — and drifted toward one of three numbers. That is not a credit
 * assessment, and it meant the rating could not be earned or lost by anything
 * the player actually did.
 *
 * This reads the five things a lender genuinely looks at, each scored against
 * where it stops mattering, and drifts toward the total. Every one of them is
 * something the player controls: pay your bills, keep your borrowing in
 * proportion to what you own, hold a reserve, make money, and do not miss a
 * loan payment.
 */
export function updateCreditRating(state: GameState): void {
  const company = playerCompany(state);
  const target = sum(creditFactors(state), (f) => f.score);
  // A rating moves slowly in both directions, and a little faster downward —
  // trust is easier to lose than to earn, here as anywhere.
  const speed = target < company.creditRating ? 0.09 : 0.05;
  const drift = (target - company.creditRating) * speed + gameRng.range(-0.3, 0.3);
  company.creditRating = clamp(company.creditRating + drift, 0, 100);
}

/**
 * The rating, broken into the five things a lender actually looks at.
 *
 * This is the only place the rating is decided; `updateCreditRating` just drifts
 * toward the total, so the number on the screen and the reasons printed beside
 * it can never disagree.
 *
 * Two rules stop a company scoring well for having nothing. A clean payment
 * record is only worth full marks once there is a record — no suppliers and no
 * loans is unproven, not excellent. And a company that owes more than it owns,
 * or is overdrawn, is capped however tidy the rest of it looks, because no
 * lender reads those numbers and lends anyway.
 */
export function creditFactors(state: GameState): { label: string; score: number; of: number; detail: string }[] {
  const company = playerCompany(state);
  const recent = state.dayHistory.slice(-30);
  const arrears = state.bills.filter((b) => b.lateDays > 0);
  const lateDays = sum(arrears, (b) => b.lateDays);
  const missed = sum(state.loans, (loan) => loan.missedPayments);
  const worth = netWorth(state);
  const debt = debtTotal(state);
  const assets = Math.max(1, worth + debt);
  const leverage = debt / assets;
  const monthlyCost = Math.max(1, (sum(recent, (r) => r.costs) / Math.max(1, recent.length)) * DAYS_PER_MONTH);
  const months = company.cash / monthlyCost;
  const profit = sum(recent, (r) => r.profit);

  // How much of a track record there is to judge. A company that has never
  // bought on account and never borrowed has not earned a clean sheet yet.
  const billsEver = state.bills.length + state.loans.length;
  const proven = clamp(billsEver / 3, 0.6, 1);

  const rows = [
    {
      label: 'Paying suppliers', of: 30,
      score: clamp(30 - lateDays * 2.5 - arrears.length * 2, 0, 30) * proven,
      detail: arrears.length > 0
        ? `${arrears.length} bill${arrears.length === 1 ? '' : 's'} late, ${lateDays} days in total.`
        : billsEver === 0
          ? 'Nothing bought on account yet, so there is no record to go on.'
          : 'Nothing outstanding past its date.',
    },
    {
      label: 'Loan payments', of: 20,
      score: clamp(20 - missed * 6, 0, 20) * proven,
      detail: missed > 0
        ? `${missed} missed payment${missed === 1 ? '' : 's'} on the record.`
        : state.loans.length === 0
          ? 'Never borrowed, so nothing to judge.'
          : 'Every payment made on time.',
    },
    {
      label: 'Borrowing against assets', of: 20,
      // Owing more than you own is the definition of the thing a lender is
      // trying to avoid, so it scores nothing rather than scoring well for a
      // small ratio against a negative denominator.
      score: worth <= 0 ? 0 : clamp(20 - leverage * 26, 0, 20),
      detail: worth <= 0
        ? 'The company owes more than it owns.'
        : `${Math.round(leverage * 100)}% of what the company owns is borrowed.`,
    },
    {
      label: 'Cash reserve', of: 15,
      score: clamp(months * 7, 0, 15),
      detail: company.cash < 0
        ? 'The account is overdrawn.'
        : Number.isFinite(months)
          ? `${months.toFixed(1)} months of outgoings in the bank.`
          : 'No outgoings to measure against yet.',
    },
    {
      label: 'Trading profitably', of: 15,
      score: profit > 0 ? 15 : profit > -monthlyCost * 0.25 ? 7 : 0,
      detail: profit > 0 ? 'The trade makes money.' : 'The trade is losing money.',
    },
  ];

  // The ceiling. An overdrawn or insolvent company does not get a good rating
  // because its paperwork is tidy, and scaling every row keeps the explanation
  // honest about why.
  const ceiling = company.cash < 0 ? 45 : worth <= 0 ? 55 : 100;
  const total = sum(rows, (r) => r.score);
  if (total > ceiling) {
    const scale = ceiling / total;
    for (const row of rows) row.score *= scale;
    const capped = rows.find((r) => r.label === 'Cash reserve');
    if (capped) {
      capped.detail = company.cash < 0
        ? 'The account is overdrawn, which caps the whole rating.'
        : 'The company owes more than it owns, which caps the whole rating.';
    }
  }
  return rows;
}


