import type { GameState } from './state';
import type { Employee, SkillId } from './types';
import { employeeById, playerBusinesses } from './state';
import { FUNCTIONS, type FunctionId } from './headOffice';
import { built } from './facilities';
import { GRADES, gradeOf, performanceOf } from './skills';
import { record } from './chronicle';
import { pushAlert } from './alerts';
import { clamp } from './util';

/**
 * The people at the top of each function, as opposed to the people in it.
 *
 * The head office already had departments, and a department is capacity: enough
 * people doing personnel work that the personnel work gets done. What it never
 * had was anybody running them. That is a different thing and it does something
 * different — a finance department with four competent people in it processes
 * the invoices, and a finance department with four competent people and a chief
 * financial officer over them negotiates the terms those invoices are on.
 *
 * So an officer does not provide cover. Cover comes from headcount and it comes
 * from exactly one place. An officer raises what a given amount of cover is
 * worth, which is why appointing one into an empty department buys almost
 * nothing: there is nobody there to lead.
 *
 * An officer is not a new kind of person either. They are one of the people
 * already working in the head office, promoted into a post — which means they
 * have a name, a salary, a grade and a skill profile that all came from the one
 * employee system, and if they resign the post is simply empty again.
 */

export type OfficerId = 'coo' | 'cfo' | 'cmo' | 'cpo' | 'cto';

export interface OfficerDef {
  id: OfficerId;
  title: string;
  /** What they actually do, in the player's words. */
  brief: string;
  /** The department they are over, or null for the one that is over all of them. */
  functionId: FunctionId | null;
  /** The skill the post is judged on. */
  skill: SkillId;
  /** What the post pays on top of what the person already earns, per month. */
  premium: number;
}

export const OFFICERS: OfficerDef[] = [
  {
    id: 'coo',
    title: 'Chief operating officer',
    brief: 'Runs the estate day to day, so the person who owns it does not have to.',
    functionId: null,
    skill: 'leadership',
    premium: 3_800,
  },
  {
    id: 'cfo',
    title: 'Chief financial officer',
    brief: 'Terms, tax and the relationship with everybody the company owes money to.',
    functionId: 'finance',
    skill: 'finance',
    premium: 3_400,
  },
  {
    id: 'cmo',
    title: 'Chief marketing officer',
    brief: 'Decides what the company is for, and makes the advertising budget mean it.',
    functionId: 'marketing',
    skill: 'sales',
    premium: 3_000,
  },
  {
    id: 'cpo',
    title: 'Chief people officer',
    brief: 'Why people join, and why they stay once they have.',
    functionId: 'hr',
    skill: 'communication',
    premium: 2_800,
  },
  {
    id: 'cto',
    title: 'Chief technology officer',
    brief: 'The systems the company runs on and the work that makes the next ones.',
    functionId: 'it',
    skill: 'technical',
    premium: 3_200,
  },
];

export function officerDef(id: OfficerId): OfficerDef | undefined {
  return OFFICERS.find((o) => o.id === id);
}

export function emptyOfficers(): Record<OfficerId, string | null> {
  return { coo: null, cfo: null, cmo: null, cpo: null, cto: null };
}

/**
 * The person in a post, if they are still employed.
 *
 * Checked against the employee list every time rather than cleaned up on
 * departure, so a post can never point at somebody who has left. The resign
 * path does not need to know that officers exist.
 */
export function officer(state: GameState, id: OfficerId): Employee | null {
  const employeeId = state.officers?.[id];
  if (!employeeId) return null;
  const person = employeeById(state, employeeId);
  if (!person) return null;
  if (person.companyId !== state.playerCompanyId) return null;
  return person;
}

/** Everybody currently holding a post. */
export function officers(state: GameState): { def: OfficerDef; person: Employee }[] {
  return OFFICERS.map((def) => {
    const person = officer(state, def.id);
    return person ? { def, person } : null;
  }).filter((row): row is { def: OfficerDef; person: Employee } => row !== null);
}

/** What the posts cost on top of the salaries, per month. */
export function officerPremiums(state: GameState): number {
  return officers(state).reduce((total, row) => total + row.def.premium, 0);
}

/**
 * How good the person in a post actually is at it, 0..1.
 *
 * Their own skill in what the post is about, weighted by how they are doing and
 * how senior they are. A junior with a talent for figures is worth something as
 * a finance director and is not worth what a seasoned one is.
 */
export function officerStrength(state: GameState, id: OfficerId): number {
  const def = officerDef(id);
  const person = officer(state, id);
  if (!def || !person) return 0;
  const skill = person.skills[def.skill] ?? 0;
  const grade = clamp(gradeOf(person).n / (GRADES.length - 1), 0.35, 1);
  const doing = clamp(performanceOf(person) / 75, 0.4, 1.2);
  return clamp((skill / 100) * grade * doing, 0, 1);
}

/**
 * What having somebody running a department is worth to it, as a multiplier.
 *
 * Deliberately bounded and deliberately multiplicative against cover: at most a
 * fifth more out of a department that is already fully staffed, and next to
 * nothing out of one that is empty. An officer is leverage on work that is
 * being done, not a substitute for doing it.
 */
export const OFFICER_LIFT = 0.2;

export function officerLift(state: GameState, functionId: FunctionId): number {
  const def = OFFICERS.find((o) => o.functionId === functionId);
  if (!def) return 1;
  return 1 + officerStrength(state, def.id) * OFFICER_LIFT;
}

/**
 * Locations a chief operating officer takes off the owner's desk.
 *
 * The executive floor is the room; this is the person in it. The room on its
 * own is worth two locations because it is where the delegating happens at all,
 * and somebody genuinely good running it is worth three more.
 */
export function operatingReach(state: GameState): number {
  return officerStrength(state, 'coo') * 3;
}

// --------------------------------------------------------------- appointing

export interface AppointCheck {
  ok: boolean;
  message: string;
}

/**
 * Whether a post can be filled, and by whom.
 *
 * Three rules, each of which is the reason the post is worth something. There
 * has to be a floor for them to sit on; they have to work in the head office
 * already, because an officer who is also running a shop is running a shop; and
 * they have to be senior enough that the people under them would take it.
 */
export const OFFICER_MIN_RUNG = 3;

export function canAppoint(state: GameState, id: OfficerId, employeeId: string): AppointCheck {
  if (!state.headOffice) return { ok: false, message: 'You need a head office first.' };
  if (!built(state, 'executive')) {
    return { ok: false, message: 'An executive floor is what a board of officers sits on. Build one first.' };
  }
  const def = officerDef(id);
  if (!def) return { ok: false, message: 'Unknown post.' };
  const person = employeeById(state, employeeId);
  if (!person || person.companyId !== state.playerCompanyId) return { ok: false, message: 'Unknown employee.' };
  if (!state.headOffice.employeeIds.includes(employeeId)) {
    return { ok: false, message: `${person.name} works in a location, not the head office.` };
  }
  if (gradeOf(person).n < OFFICER_MIN_RUNG) {
    return { ok: false, message: `${person.name} is too junior for the post — nobody would report to them yet.` };
  }
  const held = OFFICERS.find((other) => other.id !== id && state.officers?.[other.id] === employeeId);
  if (held) return { ok: false, message: `${person.name} is already ${held.title.toLowerCase()}.` };
  return { ok: true, message: `${person.name} can take the post.` };
}

/** Who could take a post, best first, so the screen has something to offer. */
export function candidatesFor(state: GameState, id: OfficerId): Employee[] {
  if (!state.headOffice) return [];
  const def = officerDef(id);
  if (!def) return [];
  return state.headOffice.employeeIds
    .map((employeeId) => employeeById(state, employeeId))
    .filter((person): person is Employee => person !== undefined && canAppoint(state, id, person.id).ok)
    .sort((a, b) => (b.skills[def.skill] ?? 0) - (a.skills[def.skill] ?? 0));
}

export function appoint(state: GameState, id: OfficerId, employeeId: string): { ok: boolean; message: string } {
  const check = canAppoint(state, id, employeeId);
  if (!check.ok) return check;
  const def = officerDef(id)!;
  const person = employeeById(state, employeeId)!;
  if (!state.officers) state.officers = emptyOfficers();

  const previous = officer(state, id);
  state.officers[id] = employeeId;
  // The post pays what the post pays. It goes onto the salary the payroll
  // already charges rather than becoming a second bill nobody can find.
  person.salary += def.premium;

  record(state, 'promoted', `${person.name} appointed ${def.title.toLowerCase()}`, { amount: -def.premium });
  pushAlert(
    state,
    'info',
    `${person.name} is your ${def.title.toLowerCase()}`,
    previous
      ? `${previous.name} is no longer in the post. ${def.brief}`
      : `${def.brief} The post pays ${def.premium.toLocaleString('en-GB')} a month on top of their salary.`,
    null,
    'headOffice',
  );
  return { ok: true, message: `${person.name} is now ${def.title.toLowerCase()}.` };
}

export function vacate(state: GameState, id: OfficerId): { ok: boolean; message: string } {
  const def = officerDef(id);
  const person = officer(state, id);
  if (!def || !person) return { ok: false, message: 'Nobody holds that post.' };
  if (state.officers) state.officers[id] = null;
  person.salary = Math.max(0, person.salary - def.premium);
  return { ok: true, message: `${person.name} is no longer ${def.title.toLowerCase()}.` };
}

// ------------------------------------------------------------- for the screen

export interface OfficerRow {
  def: OfficerDef;
  person: Employee | null;
  strength: number;
  /** What the post is doing for the company right now, in one line. */
  effect: string;
  candidates: Employee[];
  available: boolean;
}

export function officerRows(state: GameState): OfficerRow[] {
  const locations = playerBusinesses(state).filter((b) => b.status === 'open').length;
  return OFFICERS.map((def) => {
    const person = officer(state, def.id);
    const strength = officerStrength(state, def.id);
    const lift = def.functionId ? (officerLift(state, def.functionId) - 1) * 100 : 0;
    const effect = !person
      ? 'Nobody in the post.'
      : def.id === 'coo'
        ? `Holding ${operatingReach(state).toFixed(1)} locations of the ${locations} open for you.`
        : `Getting ${lift.toFixed(0)}% more out of ${FUNCTIONS.find((f) => f.id === def.functionId)?.name.toLowerCase() ?? 'the department'}.`;
    return {
      def,
      person,
      strength,
      effect,
      candidates: candidatesFor(state, def.id),
      available: built(state, 'executive'),
    };
  });
}
