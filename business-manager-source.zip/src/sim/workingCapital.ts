import type { Bill, Business, Invoice } from './types';
import type { GameState } from './state';
import { playerCompany } from './state';
import { businessTypeOrThrow } from '../data/businessTypes';
import { supplier } from '../data/suppliers';
import { post, postNonCash } from './finance';
import { pushAlert } from './alerts';
import { pushNews } from './news';
import { money } from './format';
import { financialStanding } from './standing';
import { gameRng } from './rng';
import { clamp, makeId, sum } from './util';

/**
 * Working capital.
 *
 * Until now every euro this company earned was in the till the moment it was
 * earned, and every euro it spent left on the day it was agreed. That is a
 * shop, and it is why the game could not produce the single most common way a
 * real business dies: being profitable and running out of money anyway.
 *
 * Now the two are separated. Trade sold on account is revenue today and cash in
 * thirty days; stock bought on terms is cost today and cash in fourteen. The
 * profit and loss account is unchanged — it was always accrual — but the bank
 * balance is no longer the same story, and the gap between them is a thing the
 * player has to manage.
 *
 * Which is the whole point. Growing fast now *consumes* cash: every new pound of
 * business funds a customer for a month before it funds you, so the faster you
 * grow the wider the hole, and a company can be winning on every screen except
 * the one that decides whether it is still here next week.
 */

// ------------------------------------------------------------------- terms

/**
 * How much of a trade's takings go on account rather than into the till, and
 * how long the customer takes to pay.
 *
 * A shop is paid at the counter — that is what a shop is. Work done for other
 * businesses is invoiced, and the bigger the client the longer they take, which
 * is a fact of trading that has sunk more businesses than any recession.
 */
export function tradeCreditOf(business: Business): { share: number; days: number } {
  const type = businessTypeOrThrow(business.typeId);
  const share = type.tradeCredit ?? 0;
  return { share: clamp(share, 0, 1), days: type.tradeCreditDays ?? 30 };
}

/** Contracts are always invoiced, and the big ones take the longest. */
export function contractTerms(value: number): number {
  if (value >= 40_000) return 60;
  if (value >= 12_000) return 45;
  return 30;
}

/**
 * What a supplier will let you owe them.
 *
 * Terms are not generosity: a supplier extends them to a company it expects to
 * be paid by, so this reads the credit rating. Pay late and the terms shorten
 * until you are buying for cash, which is exactly when you can least afford to.
 */
/**
 * Set while a scenario is being built.
 *
 * A company handed to the player is a position, not a history of purchasing
 * decisions: it should hold the cash the scenario promised and owe its
 * suppliers nothing. Left on terms, the builder would order stock the cash
 * never funded and the player would inherit the bill for it.
 */
let handingOver = false;

export function setHandoverMode(on: boolean): void {
  handingOver = on;
}

export function supplierTerms(state: GameState, supplierId: string): number {
  if (handingOver) return 0;
  const def = supplier(supplierId);
  if (!def) return 0;
  // A supplier does not read your accounts; it reads your name. Financial
  // standing is the credit rating plus whatever is currently unpaid, and it
  // moves slowly — which is why one missed bill costs terms for months.
  const rating = financialStanding(state);
  if (rating < 35) return 0;
  const base = def.reliability > 0.95 ? 14 : 21;
  if (rating >= 75) return base + 14;
  if (rating >= 55) return base;
  return Math.max(7, base - 7);
}

// --------------------------------------------------------------- raising

/**
 * Books a day's takings, splitting them between the till and the sales ledger.
 *
 * The accrual half is the part that matters: revenue is recognised the day the
 * work is done whatever the customer does about paying for it, so the profit
 * figure never flatters or punishes the company for its customers' habits.
 */
export function bookTakings(state: GameState, business: Business, amount: number, label: string): void {
  if (amount <= 0) return;
  const category = businessTypeOrThrow(business.typeId).productIds.length > 0 ? 'sales' : 'service';
  const { share, days } = tradeCreditOf(business);
  const onAccount = Math.round(amount * share);
  const inTheTill = amount - onAccount;

  if (inTheTill > 0) post(state, business.companyId, category, label, inTheTill, business.id);
  if (onAccount <= 0) return;

  // Revenue today, cash later. The ledger shows it as earned because it was.
  postNonCash(state, business.companyId, category, `${label} — invoiced`, onAccount, business.id);
  if (business.companyId !== state.playerCompanyId) return;
  raiseInvoice(state, {
    from: `${business.name} — trade customers`,
    amount: onAccount,
    days,
    businessId: business.id,
    source: 'trade',
  });
}

/** Adds an invoice to the sales ledger, merging same-day trade for one shop. */
export function raiseInvoice(
  state: GameState,
  options: { from: string; amount: number; days: number; businessId: string | null; source: Invoice['source'] },
): void {
  if (options.amount <= 0) return;
  const dueOnDay = state.day + Math.max(0, Math.round(options.days));
  // A shop invoicing its trade customers every day would fill the ledger with
  // one row per day per shop; the day's invoicing is one invoice.
  const existing = state.invoices.find(
    (i) => i.source === options.source && i.businessId === options.businessId && i.raisedOnDay === state.day,
  );
  if (existing) {
    existing.amount += Math.round(options.amount);
    return;
  }
  state.invoices.push({
    id: makeId('inv'),
    from: options.from,
    amount: Math.round(options.amount),
    raisedOnDay: state.day,
    dueOnDay,
    businessId: options.businessId,
    source: options.source,
    chased: 0,
  });
}

/** Puts a supplier's bill on the purchase ledger instead of paying it today. */
export function raiseBill(
  state: GameState,
  options: { supplierId: string; to: string; amount: number; days: number; businessId: string | null },
): void {
  if (options.amount <= 0) return;
  state.bills.push({
    id: makeId('bill'),
    supplierId: options.supplierId,
    to: options.to,
    amount: Math.round(options.amount),
    raisedOnDay: state.day,
    dueOnDay: state.day + Math.max(1, Math.round(options.days)),
    businessId: options.businessId,
    lateDays: 0,
  });
}

// -------------------------------------------------------------- settling

/**
 * A day of collections and payments.
 *
 * Customers pay roughly when they said they would and some of them do not;
 * suppliers expect to be paid on the day, and being unable to is the thing that
 * quietly costs a company its terms, its rating and eventually its suppliers.
 */
export function workingCapitalDaily(state: GameState): { collected: number; paid: number; missed: number } {
  const company = playerCompany(state);
  let collected = 0;
  let paid = 0;
  let missed = 0;

  // ---- money in
  for (const invoice of [...state.invoices]) {
    if (state.day < invoice.dueOnDay) continue;
    const late = state.day - invoice.dueOnDay;
    // Most customers pay on the day. The rest drift, and a few need chasing —
    // which is what a finance department is for, and why one is worth having.
    const chance = late === 0 ? 0.72 : clamp(0.4 + late * 0.12, 0, 0.95);
    if (!gameRng.chance(chance)) {
      invoice.chased += 1;
      continue;
    }
    post(state, company.id, 'invoice', `Paid — ${invoice.from}`, invoice.amount, invoice.businessId);
    collected += invoice.amount;
    state.invoices = state.invoices.filter((i) => i.id !== invoice.id);
  }

  // ---- money out
  for (const bill of [...state.bills]) {
    if (state.day < bill.dueOnDay) continue;
    if (company.cash < bill.amount) {
      // Not paying is not a decision the player gets to enjoy: it is recorded,
      // it shortens the terms, and the supplier remembers.
      bill.lateDays += 1;
      missed += 1;
      if (bill.lateDays === 1) {
        pushAlert(
          state,
          'critical',
          `You cannot pay ${bill.to}`,
          `${money(bill.amount)} was due today and there is ${money(company.cash)} in the account. Late payment costs you terms and credit rating.`,
          bill.businessId,
          'finance',
        );
      }
      continue;
    }
    post(state, company.id, 'billpay', `Paid — ${bill.to}`, -bill.amount, bill.businessId);
    paid += bill.amount;
    state.bills = state.bills.filter((b) => b.id !== bill.id);
  }
  return { collected, paid, missed };
}

/**
 * What the company can actually commit to right now.
 *
 * Cash, less everything already promised to somebody else. Buying on terms
 * stopped reducing the balance, which meant a company could keep passing the
 * same affordability check with money it had already spent — so the check now
 * asks what is left rather than what is showing.
 */
export function availableToSpend(state: GameState): number {
  return playerCompany(state).cash - sum(state.bills, (b) => b.amount) - Math.max(0, state.taxReserve);
}

/**
 * How much one supplier will let you owe them at once.
 *
 * Terms are a line, not a blank cheque. The ceiling grows with your standing
 * and with how much you have spent with them over time — a supplier extends
 * more rope to a customer who has been good for it — and an order that would
 * go past it is simply a cash order instead.
 */
export function creditCeiling(state: GameState, supplierId: string): number {
  const standing = financialStanding(state);
  if (standing < 35) return 0;
  const history = state.supplierSpend[supplierId] ?? 0;
  return Math.round((2_000 + history * 0.12) * (0.5 + (standing / 100) * 1.2));
}

/** What is currently outstanding with one supplier. */
export function exposureTo(state: GameState, supplierId: string): number {
  return sum(state.bills.filter((b) => b.supplierId === supplierId), (b) => b.amount);
}

// ------------------------------------------------------------- the figures

export interface WorkingCapital {
  /** Owed to you, and not yet late. */
  receivables: number;
  /** Owed to you and past its date. */
  overdue: number;
  /** What you owe suppliers. */
  payables: number;
  /** Bills you have already failed to pay. */
  arrears: number;
  /** Tax set aside against the bill that is coming. */
  taxDue: number;
  /** Cash + what is owed to you − what you owe. */
  net: number;
  /** How many days of outgoings the company could cover from cash alone. */
  runwayDays: number;
  /** Average days a customer actually takes to pay. */
  daysSalesOutstanding: number;
}

export function workingCapital(state: GameState): WorkingCapital {
  const company = playerCompany(state);
  const receivables = sum(state.invoices.filter((i) => i.dueOnDay >= state.day), (i) => i.amount);
  const overdue = sum(state.invoices.filter((i) => i.dueOnDay < state.day), (i) => i.amount);
  const payables = sum(state.bills.filter((b) => b.lateDays === 0), (b) => b.amount);
  const arrears = sum(state.bills.filter((b) => b.lateDays > 0), (b) => b.amount);
  const taxDue = Math.max(0, state.taxReserve);

  const outgoings = dailyOutgoingsEstimate(state);
  const runwayDays = outgoings > 0 ? Math.max(0, company.cash) / outgoings : Infinity;

  const settled = state.invoices.length > 0
    ? sum(state.invoices, (i) => state.day - i.raisedOnDay) / state.invoices.length
    : 0;

  return {
    receivables,
    overdue,
    payables,
    arrears,
    taxDue,
    net: company.cash + receivables + overdue - payables - arrears - taxDue,
    runwayDays,
    daysSalesOutstanding: settled,
  };
}

/** What a day costs, averaged over the last fortnight of actual trading. */
function dailyOutgoingsEstimate(state: GameState): number {
  const recent = state.dayHistory.slice(-14);
  if (recent.length === 0) return 0;
  return Math.max(0, sum(recent, (d) => d.costs) / recent.length);
}

/**
 * The warning the player needs before it is too late to act on it.
 *
 * Said once per crossing rather than every day, because an alert that fires
 * every morning is one the player learns to close without reading.
 */
export function checkLiquidity(state: GameState): void {
  const wc = workingCapital(state);
  const company = playerCompany(state);
  const band = wc.runwayDays < 14 ? 'critical' : wc.runwayDays < 30 ? 'warning' : 'clear';
  if (band === state.liquidityBand) return;
  state.liquidityBand = band;
  if (band === 'clear') return;

  const owed = wc.receivables + wc.overdue;
  pushAlert(
    state,
    band === 'critical' ? 'critical' : 'warning',
    band === 'critical' ? `About ${Math.round(wc.runwayDays)} days of cash left` : 'Cash is getting tight',
    owed > company.cash
      ? `${money(owed)} is owed to you against ${money(company.cash)} in the bank. The money exists; it is just not here yet. Chase it, shorten your terms, or borrow against it.`
      : `${money(company.cash)} in the bank against ${money(dailyOutgoingsEstimate(state))} a day going out.`,
    null,
    'finance',
  );
}

/**
 * Setting money aside for the tax bill.
 *
 * The reserve is not a separate account the player can raid — it is the part of
 * the balance that is already spoken for, shown so that a company does not
 * spend its way into a bill it cannot pay. Profit is not cash, and tax is the
 * clearest case of it.
 *
 * It is a *target*, recomputed each day from the same thirty-day window the tax
 * charge itself uses, and never an accumulator. The first version added a share
 * of every profitable day and subtracted only what the monthly charge actually
 * paid, so a company with good days and bad days ratcheted a reserve upwards
 * for ever — which then ate its spending headroom, blocked its restocking and
 * quietly starved it to death. A figure that can only go one way is not a
 * reserve; it is a leak.
 */
export function reserveTax(state: GameState, monthProfit: number, rate: number): void {
  state.taxReserve = Math.max(0, Math.round(monthProfit * rate));
}

export function releaseTaxReserve(state: GameState, paid: number): void {
  state.taxReserve = Math.max(0, state.taxReserve - Math.round(paid));
}

/**
 * Money against the sales ledger.
 *
 * Invoice financing is the oldest answer to this problem and the most expensive:
 * you get most of what you are owed today and the lender keeps the rest. It is
 * here so that a company with real customers and no cash has a way out that is
 * not a fire sale — at a price that makes it a last resort.
 */
export const FACTORING_FEE = 0.045;

export function factorInvoices(state: GameState, upToAmount: number): { ok: boolean; message: string; raised: number } {
  const due = [...state.invoices].sort((a, b) => a.dueOnDay - b.dueOnDay);
  if (due.length === 0) return { ok: false, message: 'Nobody owes you anything to borrow against.', raised: 0 };

  let face = 0;
  const taken: string[] = [];
  for (const invoice of due) {
    if (face >= upToAmount) break;
    face += invoice.amount;
    taken.push(invoice.id);
  }
  if (face <= 0) return { ok: false, message: 'Nothing on the sales ledger to advance against.', raised: 0 };

  const fee = Math.round(face * FACTORING_FEE);
  const raised = face - fee;
  const company = playerCompany(state);
  post(state, company.id, 'invoice', 'Invoice finance — advance', raised, null);
  postNonCash(state, company.id, 'interest', 'Invoice finance — fee', -fee, null);
  state.invoices = state.invoices.filter((i) => !taken.includes(i.id));
  // Selling the ledger is a thing lenders notice, and it is not a good sign.
  company.creditRating = clamp(company.creditRating - 1.5, 0, 100);

  pushNews(
    state,
    'company',
    'You have sold the sales ledger',
    `${money(face)} of invoices advanced for ${money(raised)}. The ${money(fee)} difference is what it costs to have the money now instead of in ${
      due[0] ? Math.max(0, due[0].dueOnDay - state.day) : 30
    } days.`,
    { importance: 'high' },
  );
  return {
    ok: true,
    message: `${money(raised)} in the account. ${money(fee)} went to the lender, and your rating took a small knock.`,
    raised,
  };
}

/** The sales ledger, oldest first, for the screen that chases it. */
export function ageing(state: GameState): { invoice: Invoice; daysLate: number }[] {
  return state.invoices
    .map((invoice) => ({ invoice, daysLate: state.day - invoice.dueOnDay }))
    .sort((a, b) => b.daysLate - a.daysLate);
}

/** What is owed to suppliers, soonest first. */
export function duesoon(state: GameState): Bill[] {
  return [...state.bills].sort((a, b) => a.dueOnDay - b.dueOnDay);
}
