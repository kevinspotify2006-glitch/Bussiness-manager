import type { GameState } from './state';
import { playerBusinesses, playerCompany } from './state';
import { netWorth } from './finance';
import { pushNews } from './news';
import { learn } from './founder';
import { pushAlert } from './alerts';
import { money, moneyShort } from './format';
import { clamp, sum } from './util';
import { record } from './chronicle';

/**
 * How big the company is, and what that lets it do.
 *
 * Eight levels, each one a real threshold: a company is at a level because of
 * what it is worth, how many places it trades from, how many people it employs
 * and what it clears in a month — not because it ticked something off. And each
 * level opens something the player could not do before, so growing is worth
 * doing for reasons other than the number going up.
 *
 * Nothing here is stored except the high-water mark, which exists only so the
 * game can say "you have been promoted" once. Everything else is read from the
 * company as it is now, which means a company that shrinks really is smaller.
 */

export interface LevelDef {
  n: number;
  name: string;
  blurb: string;
  requires: {
    netWorth: number;
    locations: number;
    headcount: number;
    /** Profit over the last thirty days. */
    monthlyProfit: number;
  };
  /** What reaching this level opens up, in the player's words. */
  unlocks: string[];
}

export const LEVELS: LevelDef[] = [
  {
    n: 1,
    name: 'Starter',
    blurb: 'One shop, your own money, and everything still to prove.',
    requires: { netWorth: 0, locations: 0, headcount: 0, monthlyProfit: 0 },
    unlocks: ['One trading location', 'Hire staff, set prices, buy stock'],
  },
  {
    n: 2,
    name: 'Local business',
    blurb: 'The shop washes its own face. Now make it worth owning.',
    requires: { netWorth: 85_000, locations: 1, headcount: 1, monthlyProfit: 1_500 },
    unlocks: ['A second location', '18% more borrowing against the same assets'],
  },
  {
    n: 3,
    name: 'Growing company',
    blurb: 'Two shops is not twice one shop. It is a different job.',
    requires: { netWorth: 220_000, locations: 2, headcount: 4, monthlyProfit: 6_000 },
    unlocks: ['Up to four locations', 'Supply contracts', '36% more borrowing'],
  },
  {
    n: 4,
    name: 'Regional company',
    blurb: 'Big enough that the things you cannot see start costing you.',
    requires: { netWorth: 650_000, locations: 3, headcount: 9, monthlyProfit: 18_000 },
    unlocks: ['Up to seven locations', 'R&D: operations, logistics and marketing', '54% more borrowing'],
  },
  {
    n: 5,
    name: 'National company',
    blurb: 'A name people recognise in towns you have never been to.',
    requires: { netWorth: 2_000_000, locations: 5, headcount: 20, monthlyProfit: 55_000 },
    unlocks: ['Up to eleven locations', 'R&D: technology', '72% more borrowing'],
  },
  {
    n: 6,
    name: 'Corporation',
    blurb: 'The company runs whether or not you are in the room.',
    requires: { netWorth: 7_000_000, locations: 8, headcount: 45, monthlyProfit: 180_000 },
    unlocks: ['Up to sixteen locations', 'R&D: sustainability — the full tree', '90% more borrowing'],
  },
  {
    n: 7,
    name: 'Industry leader',
    blurb: 'Competitors price against you, not the other way round.',
    requires: { netWorth: 25_000_000, locations: 12, headcount: 80, monthlyProfit: 600_000 },
    unlocks: ['Up to twenty-two locations', 'Contracts sized to a company this big', '108% more borrowing'],
  },
  {
    n: 8,
    name: 'Business empire',
    blurb: 'There is nothing left to be promoted to. Now hold it.',
    requires: { netWorth: 100_000_000, locations: 16, headcount: 120, monthlyProfit: 2_000_000 },
    unlocks: ['No limit on locations', 'Twice the borrowing a starter could raise'],
  },
];

/** How many places the company may trade from at each level. */
const LOCATION_CAP = [1, 2, 4, 7, 11, 16, 22, Infinity];

export interface Measure {
  label: string;
  now: number;
  need: number;
  /** 0..1 */
  progress: number;
  format: (value: number) => string;
}

/** What the company looks like right now, against a level's requirements. */
export function measures(state: GameState, level: LevelDef): Measure[] {
  const open = playerBusinesses(state).filter((b) => b.status === 'open').length;
  const profit = sum(state.dayHistory.slice(-30), (d) => d.profit);
  const rows: Measure[] = [
    {
      label: 'Company value',
      now: netWorth(state),
      need: level.requires.netWorth,
      progress: 0,
      format: moneyShort,
    },
    { label: 'Locations trading', now: open, need: level.requires.locations, progress: 0, format: (v) => `${Math.round(v)}` },
    {
      label: 'People employed',
      now: state.employees.length,
      need: level.requires.headcount,
      progress: 0,
      format: (v) => `${Math.round(v)}`,
    },
    { label: 'Profit, last 30 days', now: profit, need: level.requires.monthlyProfit, progress: 0, format: moneyShort },
  ];
  for (const row of rows) row.progress = row.need <= 0 ? 1 : clamp(row.now / row.need, 0, 1);
  return rows.filter((row) => row.need > 0);
}

/** The level the company is at, from what it actually is. */
export function levelOf(state: GameState): LevelDef {
  let best = LEVELS[0];
  for (const level of LEVELS) {
    if (measures(state, level).every((row) => row.now >= row.need)) best = level;
    else break;
  }
  return best;
}

export function nextLevel(state: GameState): LevelDef | null {
  const now = levelOf(state);
  return LEVELS.find((level) => level.n === now.n + 1) ?? null;
}

/** 0..1 towards the next level: the average of the requirements still short. */
export function levelProgress(state: GameState): number {
  const next = nextLevel(state);
  if (!next) return 1;
  const rows = measures(state, next);
  if (rows.length === 0) return 1;
  return sum(rows, (row) => row.progress) / rows.length;
}

/** The requirement holding the company back most. */
export function bindingMeasure(state: GameState): Measure | null {
  const next = nextLevel(state);
  if (!next) return null;
  const rows = measures(state, next).filter((row) => row.now < row.need);
  if (rows.length === 0) return null;
  return rows.sort((a, b) => a.progress - b.progress)[0];
}

// ------------------------------------------------------------- what it opens

/**
 * What the company has earned the right to do.
 *
 * The level itself is live — a bad month really does show as a step back on the
 * ladder — but nothing is taken away again. You do not lose the right to run
 * four shops because last month was poor, and a research branch does not close
 * behind you. So unlocks read the high-water mark and the ladder reads today.
 */
export function unlockedLevel(state: GameState): number {
  return Math.max(levelOf(state).n, state.levelReached ?? 1);
}

export function locationCap(state: GameState): number {
  return LOCATION_CAP[unlockedLevel(state) - 1] ?? 1;
}

/** The level the unlocks are keyed to, for messages that name it. */
export function unlockedLevelDef(state: GameState): LevelDef {
  return LEVELS[unlockedLevel(state) - 1] ?? LEVELS[0];
}

export function contractsUnlocked(state: GameState): boolean {
  return unlockedLevel(state) >= 3;
}

export function researchUnlocked(state: GameState): boolean {
  return unlockedLevel(state) >= 4;
}

/**
 * How much more than its assets a company can borrow against.
 *
 * A bank lends to a track record as well as to a balance sheet, so a company
 * that has proved it can run eleven shops gets a line a starter never would.
 */
export function creditMultiplier(state: GameState): number {
  return 1 + (unlockedLevel(state) - 1) * 0.18;
}

/** How many research branches are open: the tree widens as the company does. */
export function researchBranches(state: GameState): number {
  const n = unlockedLevel(state);
  if (n >= 6) return 5;
  if (n >= 5) return 4;
  if (n >= 4) return 3;
  return 0;
}

// -------------------------------------------------------------- promotion

/**
 * Called once a day. The level itself is derived, so all this does is notice
 * when it has changed and tell the player — once, and only upwards, so a bad
 * quarter does not read as a demotion every morning.
 */
export function checkPromotion(state: GameState): void {
  const level = levelOf(state);
  if (level.n <= (state.levelReached ?? 1)) return;
  state.levelReached = level.n;
  learn(state, 'levelled');
  record(state, 'levelled', `Became a ${level.name}`);
  pushNews(
    state,
    'company',
    `${playerCompany(state).name} is now a ${level.name.toLowerCase()}`,
    `${level.blurb} ${level.unlocks.join('. ')}.`,
    { importance: 'high' },
  );
  pushAlert(state, 'success', `Level ${level.n}: ${level.name}`, level.unlocks.join(' · '), null, 'progress');
}

// ------------------------------------------------------------- next step

export interface NextStep {
  /** What to do, in the imperative. */
  title: string;
  /** Why it is the thing to do now. */
  why: string;
  /** 0..1 */
  progress: number;
  /** What finishing it gets you. */
  reward: string;
  /** Where the player goes to do it. */
  view: string;
}

/**
 * The one thing worth doing next.
 *
 * A player who opens the game and does not know what to do puts it down. This
 * is always answerable, always specific, and always measured against something
 * real — so the bar moves while you work rather than when you press a button.
 * It reads the company in order of urgency: survive, then trade, then grow.
 */
export function nextStep(state: GameState): NextStep {
  const company = playerCompany(state);
  const mine = playerBusinesses(state);
  const open = mine.filter((b) => b.status === 'open');
  const burn = dailyBurn(state);
  const level = levelOf(state);

  // 1. Do you have a business at all?
  if (mine.length === 0) {
    const held = state.buildings.filter((b) => b.occupantCompanyId === state.playerCompanyId);
    if (held.length === 0) {
      return {
        title: 'Take a lease on your first unit',
        why: `You have ${money(company.cash)} and nowhere to trade from. Rent is the cheapest way in.`,
        progress: 0,
        reward: 'A place to put a business',
        view: 'property',
      };
    }
    return {
      title: 'Open a business in your unit',
      why: 'The lease is running whether or not anything is trading in it.',
      progress: 0.5,
      reward: 'Revenue instead of rent',
      view: 'businesses',
    };
  }

  // 2. Is it actually open?
  const shut = mine.find((b) => b.status !== 'open');
  if (shut && open.length === 0) {
    const stocked = sum(Object.values(shut.stock), (units) => units) > 0;
    return {
      title: stocked ? `Open ${shut.name}` : `Stock ${shut.name} and open the doors`,
      why: stocked
        ? 'Everything is in place. Nothing sells until the doors are open.'
        : 'An empty shop turns customers away and they do not come back soon.',
      progress: stocked ? 0.75 : 0.35,
      reward: 'Your first day of trade',
      view: stocked ? 'businesses' : 'inventory',
    };
  }

  // 3. Are you about to run out of money?
  if (burn > 0 && company.cash / burn < 21) {
    const days = Math.max(0, Math.floor(company.cash / burn));
    return {
      title: 'Fix the cash position',
      why: `At the current rate the company runs out of cash in ${days} days.`,
      progress: clamp(company.cash / (burn * 21), 0, 1),
      reward: 'A company that is still here next month',
      view: 'finance',
    };
  }

  // 4. Is anything losing money?
  const bleeding = open
    .filter((b) => b.totals.revenue > 0)
    .map((b) => ({
      b,
      profit:
        b.yesterday.revenue -
        (b.yesterday.cogs + b.yesterday.wages + b.yesterday.rent + b.yesterday.marketing + b.yesterday.otherCosts),
    }))
    .filter((row) => row.profit < 0)
    .sort((a, b) => a.profit - b.profit)[0];
  if (bleeding) {
    return {
      title: `Turn ${bleeding.b.name} around`,
      why: `It lost ${money(-bleeding.profit)} yesterday. Prices, staffing or the pitch itself.`,
      progress: 0,
      reward: 'One less hole in the accounts',
      view: 'businesses',
    };
  }

  // 5. Otherwise: the next level, and the requirement furthest behind.
  const binding = bindingMeasure(state);
  const next = nextLevel(state);
  if (binding && next) {
    return {
      title: bindingTitle(binding, state),
      why: `${binding.label} is ${binding.format(binding.now)} of the ${binding.format(binding.need)} a ${next.name.toLowerCase()} needs.`,
      progress: binding.progress,
      reward: next.unlocks[0],
      view: bindingView(binding),
    };
  }

  return {
    title: 'Hold the empire together',
    why: `${level.name} is the top of the ladder. What is left is keeping it.`,
    progress: 1,
    reward: 'Nothing but the satisfaction',
    view: 'dashboard',
  };
}

function bindingTitle(measure: Measure, state: GameState): string {
  switch (measure.label) {
    case 'Locations trading': {
      const cap = locationCap(state);
      const open = playerBusinesses(state).filter((b) => b.status === 'open').length;
      return open >= cap ? 'Grow the company to unlock more locations' : 'Open another location';
    }
    case 'People employed':
      return 'Take more people on';
    case 'Profit, last 30 days':
      return 'Get the monthly profit up';
    default:
      return 'Build the company up';
  }
}

function bindingView(measure: Measure): string {
  switch (measure.label) {
    case 'Locations trading':
      return 'property';
    case 'People employed':
      return 'employees';
    case 'Profit, last 30 days':
      return 'reports';
    default:
      return 'dashboard';
  }
}

/** What the company spends on an average day, from the last fortnight. */
export function dailyBurn(state: GameState): number {
  const recent = state.dayHistory.slice(-14);
  if (recent.length === 0) return 0;
  const net = sum(recent, (day) => day.costs - day.revenue) / recent.length;
  return Math.max(0, net);
}
