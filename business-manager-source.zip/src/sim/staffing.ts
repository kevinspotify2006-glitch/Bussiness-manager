import type { Business, BusinessTypeDef, Employee, EmployeeRoleId } from './types';
import type { GameState } from './state';
import { employeesOf } from './state';
import { businessTypeOrThrow } from '../data/businessTypes';
import { role, trait } from '../data/roles';
import { GRADES, grade, gradeBlocker, gradeOf, performanceOf, roleFit, titleOf, workloadOf } from './skills';
import { automationRelief, coordinationFactor } from './headOffice';
import { attentionFactor, delegatedSupervision } from './holding';
import { operationsFactor } from './founder';
import { mergerScaleFactor } from './mergers';
import { clamp, sum } from './util';

/**
 * How many people a business needs, and how many it has.
 *
 * The business types already said which roles they need, in hiring order. That
 * was a list, not a plan: it never said how many, and it never changed as a
 * shop went from twenty customers a day to four hundred. This turns it into a
 * plan that scales with the trade the business is actually doing, and puts a
 * number on the gap — which is the thing a manager needs to see in a second.
 *
 * Nothing here is a second staffing system. It reads the same `type.roles`, the
 * same employees and the same capacity figures the simulation has always used.
 */

// ------------------------------------------------------------ departments

export type DepartmentId = 'operations' | 'sales' | 'logistics' | 'admin' | 'management';

export interface DepartmentDef {
  id: DepartmentId;
  name: string;
  detail: string;
  roles: EmployeeRoleId[];
}

/**
 * Departments are a grouping of the roles that already exist, not a new thing
 * to staff separately. A business "has" a department when somebody in it is
 * doing that kind of work.
 */
export const DEPARTMENTS: DepartmentDef[] = [
  {
    id: 'operations',
    name: 'Operations',
    detail: 'The work itself — making, fixing, cooking, cleaning.',
    roles: ['cook', 'technician', 'cleaner'],
  },
  {
    id: 'sales',
    name: 'Sales and service',
    detail: 'Everybody the customer actually meets.',
    roles: ['cashier', 'sales', 'server', 'marketer'],
  },
  {
    id: 'logistics',
    name: 'Logistics',
    detail: 'Stock in, stock out, and everything between.',
    roles: ['warehouse', 'driver'],
  },
  { id: 'admin', name: 'Administration', detail: 'The books and the paperwork.', roles: ['accountant', 'hr', 'it', 'legal'] },
  { id: 'management', name: 'Management', detail: 'Running the place.', roles: ['manager'] },
];

const DEPARTMENT_OF = new Map<EmployeeRoleId, DepartmentId>();
for (const department of DEPARTMENTS) {
  for (const roleId of department.roles) DEPARTMENT_OF.set(roleId, department.id);
}

export function departmentOf(roleId: EmployeeRoleId): DepartmentId {
  return DEPARTMENT_OF.get(roleId) ?? 'operations';
}

export function department(id: DepartmentId): DepartmentDef {
  const found = DEPARTMENTS.find((d) => d.id === id);
  if (!found) throw new Error(`Unknown department: ${id}`);
  return found;
}

export interface DepartmentRow {
  id: DepartmentId;
  name: string;
  detail: string;
  people: Employee[];
  /** Average performance of the people in it, 0..100. */
  performance: number;
  /** Monthly wage bill for the department. */
  payroll: number;
}

/** The departments a business actually has, in the order they matter. */
export function departmentsOf(state: GameState, business: Business): DepartmentRow[] {
  const staff = employeesOf(state, business.id);
  const rows: DepartmentRow[] = [];
  for (const def of DEPARTMENTS) {
    const people = staff.filter((person) => departmentOf(person.role) === def.id);
    if (people.length === 0) continue;
    rows.push({
      id: def.id,
      name: def.name,
      detail: def.detail,
      people,
      performance: sum(people, (p) => performanceOf(p)) / people.length,
      payroll: sum(people, (p) => p.salary),
    });
  }
  return rows;
}

// ------------------------------------------------------------------ size

export type BusinessSize = 'small' | 'growing' | 'medium' | 'large' | 'enterprise';

export interface SizeDef {
  id: BusinessSize;
  name: string;
  /** Headcount at which a business is this size. */
  from: number;
  /** Managers the place needs to run without friction. */
  managers: number;
  /**
   * Coordination cost per person per day. A big team spends part of its day on
   * each other: rotas, handovers, questions, standing about. It is small per
   * head and it is not small at forty heads.
   */
  adminPerHead: number;
  detail: string;
}

/**
 * Five sizes, and each one is a different job rather than more of the last.
 *
 * The thresholds are where something actually changes: at six you can no longer
 * hold the rota in your head, at ten the team stops eating together, at eighteen
 * there are people in it who have never worked a shift with each other, and at
 * thirty the place has to run without you in it.
 */
export const SIZES: SizeDef[] = [
  { id: 'small', name: 'Small', from: 0, managers: 0, adminPerHead: 0, detail: 'Everybody knows what everybody else is doing.' },
  { id: 'growing', name: 'Growing', from: 6, managers: 1, adminPerHead: 1.2, detail: 'Too many to hold in your head. Somebody has to run the rota.' },
  { id: 'medium', name: 'Medium', from: 10, managers: 1, adminPerHead: 2.2, detail: 'Shifts that never overlap, and a handover that has to be written down.' },
  { id: 'large', name: 'Large', from: 18, managers: 2, adminPerHead: 3.8, detail: 'People who work here and have never met each other.' },
  { id: 'enterprise', name: 'Enterprise', from: 30, managers: 3, adminPerHead: 5.6, detail: 'A business that runs whether or not you are in it.' },
];

export function sizeOf(state: GameState, business: Business): SizeDef {
  const headcount = employeesOf(state, business.id).length;
  let found = SIZES[0];
  for (const size of SIZES) if (headcount >= size.from) found = size;
  return found;
}

/** The size after this one, or null at the top. */
export function nextSize(size: SizeDef): SizeDef | null {
  return SIZES[SIZES.indexOf(size) + 1] ?? null;
}

// -------------------------------------------------------- span of control

/**
 * How much managing this place needs, and how much of it it has.
 *
 * Counting managers was never the real question — one manager can run four
 * people comfortably and cannot run twenty. So the need is measured in people
 * to be managed, weighted by how much attention each of them takes (a difficult
 * or unreliable person takes half as much again; somebody independent takes
 * almost none), and the supply is what the grades present can actually cover.
 * A Team Lead covers five, a Manager eleven, an Executive thirty-four.
 */
export function supervisionLoad(state: GameState, business: Business): number {
  const staff = employeesOf(state, business.id);
  const type = businessTypeOrThrow(business.typeId);
  return sum(
    staff.filter((person) => !gradeOf(person).managerial),
    (person) => sum(person.traits.map(trait), (t) => t.supervision) / Math.max(1, person.traits.length),
  ) * complexityOf(type);
}

/** How many people the grades on this payroll can actually keep pointing one way. */
export function supervisionCapacity(state: GameState, business: Business): number {
  const staff = employeesOf(state, business.id);
  const inside = sum(staff, (person) => {
    const span = gradeOf(person).span;
    if (span <= 0) return 0;
    const knack = person.traits.reduce((acc, id) => acc * trait(id).management, 1);
    // Somebody stretched thin or fed up manages worse than the org chart says.
    return span * knack * clamp(performanceOf(person) / 60, 0.45, 1.2);
  });
  // An executive running a division is management too — standing one level
  // back, with their attention divided between the locations under them.
  return inside + delegatedSupervision(state, business);
}

/**
 * Whether the place has the management it needs, 0..1.25.
 *
 * Below one, the team is being asked to organise itself: everything still
 * happens, but slower and worse. This is the cost of growing that is easy to
 * miss, because it does not appear on an invoice.
 */
export function managementCover(state: GameState, business: Business): number {
  const load = supervisionLoad(state, business);
  // A handful of people need no management structure at all — the owner is the
  // management, and that is exactly what a small business is.
  if (load <= SIZES[1].from - 1) return 1;
  const capacity = supervisionCapacity(state, business);
  return clamp(capacity / load, 0, 1.25);
}

/** What thin management costs in output: nothing at full cover, a fifth at none. */
export function managementFactor(state: GameState, business: Business): number {
  const cover = managementCover(state, business);
  if (cover >= 1) return 1;
  return clamp(0.8 + cover * 0.2, 0.8, 1);
}

/**
 * The daily coordination cost of a team this size, after a head office has
 * taken what it can off it. Central finance and central systems are exactly
 * the things that stop a big team spending its day on itself — and a trade with
 * more moving parts spends more of its day on this than a simple one does.
 */
export function adminCostPerDay(state: GameState, business: Business): number {
  const size = sizeOf(state, business);
  const type = businessTypeOrThrow(business.typeId);
  const headcount = employeesOf(state, business.id).length;
  // And what it costs to be run by somebody with too much on. A company with
  // more locations than one person can hold pays for that in the same place.
  const stretched = business.companyId === state.playerCompanyId ? attentionFactor(state) : 1;
  // And what every company merged in has permanently taken off it: one back
  // office instead of two is the whole reason to buy a company rather than
  // open a shop.
  const scale = business.companyId === state.playerCompanyId ? mergerScaleFactor(state) : 1;
  return (
    size.adminPerHead * headcount * complexityOf(type) * coordinationFactor(state) * stretched *
    operationsFactor(state) * scale
  );
}

/** How much harder this trade is to run than the simplest one, 0.8..1.6. */
export function complexityOf(type: BusinessTypeDef): number {
  return 0.8 + (type.complexity - 1) * 0.2;
}

/**
 * How well this team suits this trade, 0..100.
 *
 * Every business type names the things somebody has to be good at to be worth
 * having there. A restaurant wants people who can cook, look after a room and
 * talk to it; a distribution business wants people who know where everything is
 * and can keep a record of it. The same person is not equally useful in both,
 * and this is the number that says so.
 */
export function tradeFit(state: GameState, business: Business): number {
  const type = businessTypeOrThrow(business.typeId);
  const staff = employeesOf(state, business.id);
  if (staff.length === 0 || type.keySkills.length === 0) return 50;
  return (
    sum(staff, (person) => sum(type.keySkills, (id) => person.skills[id] ?? 0) / type.keySkills.length) /
    staff.length
  );
}

/** How well one person would suit this trade, whatever seat they sit in. */
export function tradeFitOf(person: Employee, type: BusinessTypeDef): number {
  if (type.keySkills.length === 0) return 50;
  return sum(type.keySkills, (id) => person.skills[id] ?? 0) / type.keySkills.length;
}

/**
 * How much of the routine work systems are actually taking off this business.
 *
 * Central IT is only half the answer: what it can take over depends on the
 * trade. A distribution round is mostly a spreadsheet; a restaurant kitchen is
 * not, and no amount of software makes it one.
 */
export function automationAt(state: GameState, business: Business): number {
  const type = businessTypeOrThrow(business.typeId);
  return automationRelief(state) * type.automatable;
}

// -------------------------------------------------------------- org chart

export interface OrgNode {
  person: Employee;
  /** Who reports to them. */
  reports: OrgNode[];
}

/**
 * Who answers to whom.
 *
 * Derived, never stored: everybody reports to the nearest grade above them in
 * their own department, falling back to the most senior person in the building.
 * It means the chart can never disagree with the payroll, and reorganising is
 * a matter of promoting somebody rather than dragging boxes about.
 */
export function orgChart(state: GameState, business: Business): OrgNode[] {
  const staff = [...employeesOf(state, business.id)].sort((a, b) => gradeOf(b).n - gradeOf(a).n);
  const nodes = new Map<string, OrgNode>(staff.map((person) => [person.id, { person, reports: [] }]));
  const roots: OrgNode[] = [];

  for (const person of staff) {
    const node = nodes.get(person.id);
    if (!node) continue;
    const mine = gradeOf(person).n;
    // The nearest person above them, preferring their own department.
    const candidates = staff.filter((other) => other.id !== person.id && gradeOf(other).n > mine && gradeOf(other).span > 0);
    const sameDepartment = candidates.filter((other) => departmentOf(other.role) === departmentOf(person.role));
    const pool = sameDepartment.length > 0 ? sameDepartment : candidates;
    const boss = pool.sort((a, b) => gradeOf(a).n - gradeOf(b).n)[0];
    if (boss) nodes.get(boss.id)?.reports.push(node);
    else roots.push(node);
  }
  return roots;
}

// -------------------------------------------------------- the staffing plan

export interface StaffingRow {
  role: EmployeeRoleId;
  name: string;
  department: DepartmentId;
  /** Below this the business cannot do the trade it is doing. */
  required: number;
  /** Enough to cover peaks, holidays and somebody being off. */
  recommended: number;
  current: number;
  /** Negative is a shortage, positive is a surplus against `required`. */
  gap: number;
  /** How well the people in the seat suit it, 0..100, or null if it is empty. */
  fit: number | null;
}

/**
 * How many people this business needs, per role.
 *
 * The front-line roles scale with the trade: the shop is serving so many people
 * a day, one person gets through so many an hour, the doors are open so long —
 * that is a number of bodies, not an opinion. The supporting roles the type
 * lists are one each, because a shop that needs an accountant needs an
 * accountant whether it is busy or not. Managers come from the size the team
 * has grown to.
 */
export function staffingPlan(state: GameState, business: Business): StaffingRow[] {
  const type = businessTypeOrThrow(business.typeId);
  const staff = employeesOf(state, business.id);
  const openHours = Math.max(1, business.openTo - business.openFrom);

  // What the shop had to deal with yesterday, including the people it could
  // not serve — a queue out of the door is demand, not an absence of it.
  const traded = business.yesterday.customers + business.yesterday.lostCustomers;
  // Before it opens there is no yesterday, so the type's own expectation stands in.
  const demand = business.status === 'open' && traded > 0 ? traded : type.baseCustomers;
  const bodies = Math.max(1, Math.ceil(demand / Math.max(1, type.customersPerStaffHour * openHours)));

  const relief = automationAt(state, business);
  const rows: StaffingRow[] = [];
  for (const [index, roleId] of type.roles.entries()) {
    const inSeat = staff.filter((person) => person.role === roleId);
    let required = 1;
    let recommended = 1;
    if (roleId === 'manager') {
      // How many managers this place needs is a question about how many people
      // there are to manage, not about a table of sizes: one manager covers
      // eleven, and a team of difficult people eats that faster than a team of
      // independent ones.
      const load = supervisionLoad(state, business);
      const perManager = Math.max(1, grade(4).span);
      required = load <= SIZES[1].from - 1 ? 0 : Math.max(1, Math.ceil(load / perManager));
      recommended = required;
    } else if (index === 0) {
      // The first role in the type's list is the one that meets the customers,
      // so it is the one that has to scale with how many there are.
      required = Math.max(1, bodies);
      recommended = Math.max(required + 1, Math.ceil(required * 1.3));
    } else {
      recommended = bodies > 6 ? 2 : 1;
      // Systems doing the routine work is a job that no longer needs doing.
      if (relief >= 0.75) {
        required = 0;
        recommended = Math.max(0, recommended - 1);
      }
    }
    rows.push({
      role: roleId,
      name: role(roleId).name,
      department: departmentOf(roleId),
      required,
      recommended,
      current: inSeat.length,
      gap: inSeat.length - required,
      fit: inSeat.length > 0 ? sum(inSeat, (p) => roleFit(p.skills, roleId)) / inSeat.length : null,
    });
  }
  return rows;
}

export interface StaffingSummary {
  rows: StaffingRow[];
  required: number;
  recommended: number;
  current: number;
  /** How many people short of `required`, never below zero. */
  shortage: number;
  /** How many more than `recommended`. */
  surplus: number;
  workload: number;
  size: SizeDef;
  managementCover: number;
}

export function staffingSummary(state: GameState, business: Business): StaffingSummary {
  const rows = staffingPlan(state, business);
  const required = sum(rows, (row) => row.required);
  const recommended = sum(rows, (row) => row.recommended);
  const current = employeesOf(state, business.id).length;
  return {
    rows,
    required,
    recommended,
    current,
    shortage: Math.max(0, sum(rows, (row) => Math.max(0, row.required - row.current))),
    surplus: Math.max(0, current - recommended),
    workload: workloadOf(state, business),
    size: sizeOf(state, business),
    managementCover: managementCover(state, business),
  };
}

// ------------------------------------------------------------- what is wrong

export interface Finding {
  /** How loudly to say it. */
  level: 'bad' | 'warn' | 'good';
  title: string;
  detail: string;
}

/**
 * What is wrong with this business, and what would help — read from the same
 * figures the rest of the screen shows, so the list can never disagree with it.
 */
export function findings(state: GameState, business: Business): Finding[] {
  const out: Finding[] = [];
  const plan = staffingSummary(state, business);
  const staff = employeesOf(state, business.id);

  if (plan.shortage > 0) {
    const short = plan.rows.filter((row) => row.current < row.required);
    out.push({
      level: 'bad',
      title: `${plan.shortage} short of what this trade needs`,
      detail: short
        .map((row) => `${row.required - row.current} × ${row.name.toLowerCase()}`)
        .join(', '),
    });
  }
  if (plan.workload > 82) {
    out.push({
      level: 'bad',
      title: 'The team is running flat out',
      detail: `Workload is ${Math.round(plan.workload)}/100. People at this pace get ill, get cross, and leave.`,
    });
  } else if (plan.workload > 68) {
    out.push({
      level: 'warn',
      title: 'Busy, and one absence from a problem',
      detail: `Workload is ${Math.round(plan.workload)}/100. Another pair of hands would buy some room.`,
    });
  }
  if (plan.managementCover < 1) {
    const load = Math.round(supervisionLoad(state, business));
    const capacity = Math.round(supervisionCapacity(state, business));
    out.push({
      level: plan.managementCover < 0.55 ? 'bad' : 'warn',
      title: 'Nobody is running this place properly',
      detail: `${load} people need managing and the grades here cover about ${capacity}. ${plan.size.detail} Everything still happens, about ${Math.round(
        (1 - managementFactor(state, business)) * 100,
      )}% slower. Promote somebody with leadership, or hire a manager.`,
    });
  }
  if (plan.surplus > 0 && plan.workload < 45) {
    out.push({
      level: 'warn',
      title: `${plan.surplus} more people than this trade needs`,
      detail: 'Wages are going out for hours nobody is asking for. Either find them work or let somebody go.',
    });
  }

  const mismatched = staff.filter((person) => roleFit(person.skills, person.role) < 38);
  if (mismatched.length > 0) {
    out.push({
      level: 'warn',
      title: `${mismatched.length} ${mismatched.length === 1 ? 'person is' : 'people are'} in the wrong seat`,
      detail: `${mismatched
        .slice(0, 3)
        .map((p) => p.name)
        .join(', ')} — their skills do not suit the job they are doing. Train them, or move them.`,
    });
  }

  const unhappy = staff.filter((person) => person.morale < 40);
  if (unhappy.length > 0) {
    out.push({
      level: 'bad',
      title: `${unhappy.length} unhappy ${unhappy.length === 1 ? 'person' : 'people'}`,
      detail: 'Below forty they start looking. Pay, hours or recognition is usually the cause.',
    });
  }

  if (out.length === 0 && staff.length > 0) {
    out.push({
      level: 'good',
      title: 'Nothing wrong with the team',
      detail: `${staff.length} people, workload ${Math.round(plan.workload)}/100, nobody unhappy.`,
    });
  }
  return out;
}

/** Things worth doing here, whether or not anything is wrong. */
export function opportunities(state: GameState, business: Business): Finding[] {
  const out: Finding[] = [];
  const staff = employeesOf(state, business.id);
  if (staff.length === 0) return out;

  const trainable = staff
    .filter((person) => person.trainingEndsOnDay === null && person.skill < 82)
    .sort((a, b) => roleFit(a.skills, a.role) - roleFit(b.skills, b.role))[0];
  if (trainable) {
    out.push({
      level: 'good',
      title: `Train ${trainable.name}`,
      detail: `They fit the job ${Math.round(roleFit(trainable.skills, trainable.role))}/100. A course would show up in what they get through.`,
    });
  }

  // Somebody who has outgrown the rung they are on. Which way they can go is
  // the interesting part: plenty of very good people cannot go past Senior.
  const ready = staff
    .filter((person) => gradeOf(person).n < 6 && person.skill > 62)
    .sort((a, b) => b.skill - a.skill)[0];
  if (ready) {
    const next = GRADES[gradeOf(ready).n + 1];
    const wall = next ? gradeBlocker(ready, next) : null;
    out.push({
      level: 'good',
      title: wall ? `${ready.name} has gone as far as they can` : `${ready.name} has earned a step up`,
      detail: wall
        ? wall
        : `${titleOf(ready)} now; ${next?.name} next. Recognise them before somebody else does.`,
    });
  }

  const size = sizeOf(state, business);
  const bigger = nextSize(size);
  if (bigger && staff.length >= bigger.from - 2) {
    out.push({
      level: 'good',
      title: `${bigger.from - staff.length} more ${bigger.from - staff.length === 1 ? 'person' : 'people'} and this is a ${bigger.name.toLowerCase()} business`,
      detail: bigger.detail,
    });
  }
  return out;
}
