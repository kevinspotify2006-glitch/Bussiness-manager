import type { Building, BusinessCategory, DistrictDef } from './types';
import { DISTRICTS } from '../data/districts';
import { CITY_SEED, Rng } from './rng';
import { clamp } from './util';
import type { Frontage, Plot } from './cityLayout';
import { cityLayout, plotCount } from './cityLayout';

/**
 * The commercial units of Northgate.
 *
 * The geometry comes from the city layout — every unit is a real frontage on a
 * real street — and this file turns each of those frontages into something the
 * simulation can trade in: a floor area, a rent, an asking price, the passing
 * trade outside the door.
 *
 * Ids are `${district}-${n}` and stable, which is what lets a save from an
 * older layout be re-projected onto the current one.
 */

function pickSuitable(rng: Rng, def: DistrictDef, size: number): BusinessCategory[] {
  const categories: BusinessCategory[] = [];
  const preference = def.preferences;
  const order: BusinessCategory[] = ['retail', 'food', 'services', 'specialized'];
  for (const category of order) {
    const weight = preference[category] ?? 1;
    // Very large units rarely suit food; very small ones rarely suit services.
    const sizeFit =
      category === 'food' ? clamp(1.4 - size / 400, 0.2, 1.2)
      : category === 'services' ? clamp(size / 160, 0.3, 1.3)
      : 1;
    if (rng.chance(clamp(weight * 0.55 * sizeFit, 0.08, 0.95))) categories.push(category);
  }
  if (categories.length === 0) categories.push(order[rng.int(0, order.length - 1)]);
  return categories;
}

/** Passing trade depends on what the unit faces, which is why corners cost more. */
function trafficFactor(frontage: Frontage, corner: boolean): number {
  const base = frontage === 'arterial' ? 1.32 : frontage === 'street' ? 0.95 : 0.62;
  return corner ? base * 1.18 : base;
}

export function generateCity(): Building[] {
  const rng = new Rng(CITY_SEED ^ 0x51de);
  const layout = cityLayout();
  const byDistrict = new Map<string, Plot[]>();
  for (const plot of layout.plots) {
    const list = byDistrict.get(plot.district) ?? [];
    list.push(plot);
    byDistrict.set(plot.district, list);
  }

  const buildings: Building[] = [];

  for (const def of DISTRICTS) {
    const plots = (byDistrict.get(def.id) ?? []).slice(0, plotCount(def));

    for (const plot of plots) {
      // Floor area follows the footprint, so a wide corner unit really is big.
      const size = Math.round(
        clamp(rng.around(70 + def.commercialActivity * 110, 80) * (0.6 + plot.weight * 0.7), 40, 620),
      );
      const floors = size > 280 ? rng.int(1, 2) : rng.int(1, 3);
      const condition = Math.round(clamp(rng.around(72, 22), 25, 100));
      // Poor condition drags both rent and price down.
      const conditionFactor = 0.7 + (condition / 100) * 0.45;
      const position = trafficFactor(plot.frontage, plot.corner);

      const rent = Math.round((size * def.rentPerSqm * conditionFactor * (0.86 + position * 0.22)) / 5) * 5;
      const price = Math.round((size * def.pricePerSqm * conditionFactor * (0.88 + position * 0.2)) / 500) * 500;
      const footTraffic = Math.round(def.footTraffic * position * rng.range(0.78, 1.22));

      buildings.push({
        id: plot.id,
        address: `${plot.number} ${plot.street}`,
        district: def.id,
        x: plot.x,
        y: plot.y,
        w: plot.w,
        h: plot.h,
        size,
        floors,
        rent,
        price,
        value: price,
        customerCapacity: Math.max(4, Math.round(size / 4.5)),
        storageCapacity: Math.max(120, Math.round(size * 3.6)),
        parking:
          def.id === 'suburbs' || def.id === 'warehouse' || def.id === 'industrial'
            ? rng.int(4, 40)
            : rng.int(0, 8),
        condition,
        footTraffic,
        suitableFor: pickSuitable(rng, def, size),
        status: 'available',
        occupantCompanyId: null,
        businessId: null,
        renovationEndsOnDay: null,
      });
    }
  }

  return buildings;
}

/**
 * Moves buildings from an older save onto the current street layout.
 *
 * The city is generated, not stored, so a save made before a layout change
 * carries the old coordinates. Ids are stable, so the fix is to copy the
 * geometry across and leave every bit of state — who rents it, what trades
 * there, what condition it is in — exactly as it was.
 */
export function reprojectBuildings(buildings: Building[]): void {
  const current = new Map(cityLayout().plots.map((plot) => [plot.id, plot]));
  for (const building of buildings) {
    const plot = current.get(building.id);
    if (!plot) continue;
    building.x = plot.x;
    building.y = plot.y;
    building.w = plot.w;
    building.h = plot.h;
  }
}

/** Straight-line distance between two buildings, in kilometres. */