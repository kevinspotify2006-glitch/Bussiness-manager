import type { GameState } from './state';
import { buildingById, businessById, playerBusinesses, playerCompany } from './state';
import type { Business, Company, CompetitorPersonality } from './types';
import { businessTypeOrThrow } from '../data/businessTypes';
import { product } from '../data/products';
import { role } from '../data/roles';
import { post } from './finance';
import { generateApplicant } from './employees';
import { pushNews } from './news';
import { pushAlert } from './alerts';
import { money } from './format';
import { clamp, sum } from './util';
import { gameRng } from './rng';
import { createDivision } from './holding';
import { learn, negotiationFactor } from './founder';
import { record } from './chronicle';

/**
 * Acquisitions.
 *
 * Buying a rival is the only way to grow without waiting for a fit-out, and it
 * is deliberately expensive: you pay for the trade, the lease and the fittings,
 * and you inherit whatever was wrong with the place. Sellers are not pushovers
 * — each personality has its own idea of what its business is worth, and a
 * rejected approach closes the door for a while.
 */

/** Days before the same seller will listen again after saying no. */
export const APPROACH_COOLDOWN = 21;

/** How stubborn each kind of operator is about price. */
const RESERVE: Record<CompetitorPersonality, number> = {
  lowcost: 1.05,
  premium: 1.35,
  aggressive: 1.25,
  conservative: 1.12,
  marketer: 1.18,
  quality: 1.32,
  opportunist: 0.98,
};

export interface Valuation {
  /** What the trade itself is worth: a multiple of annualised profit. */
  goodwill: number;
  /** Fittings and equipment, depreciated. */
  fixtures: number;
  /** Stock on the shelves at cost. */
  stock: number;
  /** Deposit and fit-out value carried by the lease, or the freehold value. */
  premises: number;
  /** The sum, which is what a fair buyer would pay. */
  fair: number;
  /** Annualised profit the valuation is built on. */
  annualProfit: number;
  /** Days of trading history behind the figure — few days, weak figure. */
  history: number;
}

/**
 * What a business is worth.
 *
 * Profit is the bulk of it, capped so a fluke week cannot triple the price, and
 * a business with no history is valued on its assets alone.
 */
export function valueBusiness(state: GameState, business: Business): Valuation {
  const type = businessTypeOrThrow(business.typeId);
  const building = buildingById(state, business.buildingId);
  const history = business.profitHistory.slice(-30);
  const dailyProfit = history.length > 0 ? sum(history, (p) => p) / history.length : 0;
  const annualProfit = dailyProfit * 360;

  // A small business changes hands at roughly two years of profit. Loss-makers
  // are not worth less than nothing — the assets still have value.
  const multiple = 2 + clamp(business.reputation / 100, 0, 1) * 1.2;
  const goodwill = Math.max(0, annualProfit * multiple) * clamp(history.length / 21, 0.25, 1);

  const age = Math.max(0, state.day - business.openedOnDay);
  const fixtures = (type.setupCost + type.equipmentCost) * clamp(1 - age / 1800, 0.35, 1);

  const stock = sum(Object.entries(business.stock), ([productId, units]) => {
    const def = product(productId);
    const cost = business.costBasis[productId] ?? def?.wholesalePrice ?? 0;
    return units * cost;
  });

  const premises = building
    ? building.status === 'owned' && building.occupantCompanyId === business.companyId
      ? building.value
      : building.rent * 2
    : 0;

  const fair = Math.round(goodwill + fixtures + stock + premises);
  return { goodwill, fixtures, stock, premises, fair, annualProfit, history: history.length };
}

export interface ApproachStatus {
  /** Fair value, as both sides see it. */
  valuation: Valuation;
  /** The least the seller would take today. */
  reserve: number;
  /** Whether an offer can be made at all right now, and why not. */
  blocked: string | null;
  /** Day the seller will listen again, if they have just refused. */
  listensAgainOnDay: number | null;
}

/** Everything the player needs to know before making an offer. */
export function approachStatus(state: GameState, businessId: string): ApproachStatus | null {
  const business = businessById(state, businessId);
  if (!business) return null;
  if (business.companyId === state.playerCompanyId) return null;
  const seller = state.companies.find((c) => c.id === business.companyId);
  const valuation = valueBusiness(state, business);
  const personality = seller?.personality ?? 'conservative';
  const reserve = Math.round(valuation.fair * RESERVE[personality]);
  const refusedOn = state.approaches[businessId];
  const listensAgainOnDay = typeof refusedOn === 'number' ? refusedOn + APPROACH_COOLDOWN : null;

  let blocked: string | null = null;
  if (business.status !== 'open') blocked = 'That business is not trading.';
  else if (listensAgainOnDay !== null && state.day < listensAgainOnDay) {
    blocked = `They turned you down on day ${refusedOn}. They will not talk again until day ${listensAgainOnDay}.`;
  }

  return { valuation, reserve, blocked, listensAgainOnDay };
}

export interface OfferResult {
  ok: boolean;
  accepted: boolean;
  message: string;
}

/**
 * Makes an offer for a rival business.
 *
 * The seller compares it against their reserve, with a little noise and a
 * nudge from how the business is actually doing: somebody losing money every
 * day is easier to buy out than somebody printing it.
 */
export function makeOffer(state: GameState, businessId: string, amount: number): OfferResult {
  const business = businessById(state, businessId);
  if (!business) return { ok: false, accepted: false, message: 'That business no longer exists.' };
  const status = approachStatus(state, businessId);
  if (!status) return { ok: false, accepted: false, message: 'You already own that.' };
  if (status.blocked) return { ok: false, accepted: false, message: status.blocked };

  const company = playerCompany(state);
  if (!Number.isFinite(amount) || amount <= 0) {
    return { ok: false, accepted: false, message: 'Name a figure first.' };
  }
  if (company.cash < amount) {
    return { ok: false, accepted: false, message: `You have ${money(company.cash)}. Borrow the difference or offer less.` };
  }

  const seller = state.companies.find((c) => c.id === business.companyId);
  const recent = business.profitHistory.slice(-14);
  const dailyProfit = recent.length > 0 ? sum(recent, (p) => p) / recent.length : 0;
  // A struggling owner will take less; one doing well holds out.
  const distress = dailyProfit < 0 ? clamp(0.88 + dailyProfit / 400, 0.7, 0.95) : 1;
  // A negotiator talks a seller down; a poor one talks them up.
  const threshold = status.reserve * distress * negotiationFactor(state) * gameRng.range(0.97, 1.05);

  if (amount < threshold) {
    state.approaches[businessId] = state.day;
    pushNews(state, 'competitor', `${seller?.name ?? 'The owner'} turned down your offer`, `You offered ${money(amount)} for ${business.name}. They want more, and they will not talk again for ${APPROACH_COOLDOWN} days.`, {
      importance: 'normal',
    });
    return {
      ok: true,
      accepted: false,
      message: `${seller?.name ?? 'They'} rejected ${money(amount)}. They will not listen again until day ${state.day + APPROACH_COOLDOWN}.`,
    };
  }

  learn(state, 'acquired');
  record(state, 'bought', `Bought ${business.name} from ${seller?.name ?? 'its owner'}`, { amount: -amount, businessId: business.id });
  transferBusiness(state, business, seller ?? null, amount);
  return {
    ok: true,
    accepted: true,
    message: `${business.name} is yours for ${money(amount)}. The staff and the stock came with it.`,
  };
}

/** Moves a bought business, its premises and its people over to the player. */
function transferBusiness(state: GameState, business: Business, seller: Company | null, amount: number): void {
  const company = playerCompany(state);
  const type = businessTypeOrThrow(business.typeId);
  const building = buildingById(state, business.buildingId);

  // A group bought whole is paid for once, by the caller, so the handover of
  // each location inside it moves no money of its own.
  if (amount > 0) {
    post(state, company.id, 'property', `Acquisition — ${business.name}`, -amount, business.id);
    if (seller) seller.cash += amount;
  }

  business.companyId = company.id;
  // A change of ownership unsettles customers, and the sign over the door
  // changes: reputation and awareness take a small knock.
  business.reputation = clamp(business.reputation - 6, 0, 100);
  business.awareness = clamp(business.awareness - 8, 0, 100);
  business.autoRestock = true;

  if (building) {
    building.occupantCompanyId = company.id;
    if (building.status === 'competitor') building.status = 'rented';
  }

  // AI outlets have no individual staff, so the team that came with the
  // business is generated as real employees on the day of the handover — the
  // people who were already working there.
  if (business.employeeIds.length === 0) {
    const headcount = Math.max(1, Math.min(type.roles.length, 3));
    for (let i = 0; i < headcount; i += 1) {
      const person = generateApplicant(state, type.roles[i % type.roles.length]);
      person.businessId = business.id;
      person.companyId = company.id;
      person.hiredOnDay = state.day;
      person.lastRecognisedOnDay = state.day;
      // Inherited staff are wary of a new owner.
      person.loyalty = clamp(person.loyalty - 15, 0, 100);
      person.morale = clamp(person.morale - 10, 0, 100);
      state.employees.push(person);
      business.employeeIds.push(person.id);
    }
  }

  // Stock the shelves properly if the previous owner ran the abstracted model.
  if (type.productIds.length > 0 && sum(Object.values(business.stock), (u) => u) <= 0) {
    for (const productId of type.productIds) {
      const def = product(productId);
      if (!def) continue;
      business.stock[productId] = 40;
      business.costBasis[productId] = def.wholesalePrice;
      business.reorderPoints[productId] = 15;
    }
  }

  const team = business.employeeIds
    .map((id) => state.employees.find((e) => e.id === id))
    .filter(Boolean)
    .map((e) => `${e?.name} (${role(e!.role).name})`)
    .join(', ');

  pushNews(state, 'company', `You have bought ${business.name}`, `${money(amount)} to ${seller?.name ?? 'the previous owner'}. The lease, the fittings and the team came with it${team ? `: ${team}` : ''}.`, {
    businessId: business.id,
    importance: 'high',
  });
  pushAlert(
    state,
    'info',
    `${business.name} is yours`,
    'Check the pricing and the staffing — you have inherited whatever the last owner was doing.',
    business.id,
  );
}

// ------------------------------------------------------ buying the whole firm

/**
 * Buying a company rather than a shop.
 *
 * Four separate approaches to four separate owners is four separate
 * negotiations. Buying the company behind them is one — and it costs more,
 * because you are paying for a going concern rather than a lease. What arrives
 * is not four loose locations but a division: a group with a shape, which is
 * the point at which the company stops being a list.
 */
export interface CompanyValuation {
  company: Company;
  businesses: Business[];
  /** The sum of what each location is worth on its own. */
  parts: number;
  /** What the whole is worth: a group trades above the sum of its shops. */
  fair: number;
  /** The least this owner would take today. */
  reserve: number;
  blocked: string | null;
}

/** The premium a working group commands over the same shops sold separately. */
export const GROUP_PREMIUM = 1.18;

export function valueCompany(state: GameState, companyId: string): CompanyValuation | null {
  const company = state.companies.find((c) => c.id === companyId);
  if (!company || company.isPlayer) return null;
  const businesses = state.businesses.filter((b) => b.companyId === companyId && b.status === 'open');
  const parts = sum(businesses, (business) => valueBusiness(state, business).fair);
  const fair = Math.round(parts * (businesses.length > 1 ? GROUP_PREMIUM : 1));
  const reserve = Math.round(fair * RESERVE[company.personality ?? 'conservative']);

  let blocked: string | null = null;
  if (businesses.length === 0) blocked = 'They have nothing trading.';
  else if (businesses.length < 2) blocked = 'One location is not a company. Make an offer for the shop itself.';
  else {
    const refusedOn = state.approaches[companyId];
    if (typeof refusedOn === 'number' && state.day < refusedOn + APPROACH_COOLDOWN) {
      blocked = `They turned you down on day ${refusedOn}. They will not talk again until day ${refusedOn + APPROACH_COOLDOWN}.`;
    }
  }
  return { company, businesses, parts, fair, reserve, blocked };
}

/** Rival companies worth a conversation, cheapest first. */
export function companyTargets(state: GameState): CompanyValuation[] {
  return state.companies
    .filter((company) => !company.isPlayer)
    .map((company) => valueCompany(state, company.id))
    .filter((row): row is CompanyValuation => row !== null && row.businesses.length > 1)
    .sort((a, b) => a.fair - b.fair);
}

/** Makes an offer for an entire rival company. */
export function makeCompanyOffer(state: GameState, companyId: string, amount: number): OfferResult {
  const valuation = valueCompany(state, companyId);
  if (!valuation) return { ok: false, accepted: false, message: 'No such company.' };
  if (valuation.blocked) return { ok: false, accepted: false, message: valuation.blocked };

  const buyer = playerCompany(state);
  if (!Number.isFinite(amount) || amount <= 0) {
    return { ok: false, accepted: false, message: 'Name a figure first.' };
  }
  if (buyer.cash < amount) {
    return { ok: false, accepted: false, message: `You have ${money(buyer.cash)}. Borrow the difference or offer less.` };
  }

  // A group in trouble sells for less, exactly as a single shop does.
  const daily = sum(valuation.businesses, (business) => {
    const recent = business.profitHistory.slice(-14);
    return recent.length > 0 ? sum(recent, (p) => p) / recent.length : 0;
  });
  const distress = daily < 0 ? clamp(0.88 + daily / 1600, 0.68, 0.95) : 1;
  const threshold = valuation.reserve * distress * negotiationFactor(state) * gameRng.range(0.97, 1.05);

  if (amount < threshold) {
    state.approaches[companyId] = state.day;
    pushNews(state, 'competitor', `${valuation.company.name} is not for sale at that price`, `You offered ${money(amount)} for the whole company. They will not talk again for ${APPROACH_COOLDOWN} days.`, {
      importance: 'normal',
    });
    return {
      ok: true,
      accepted: false,
      message: `${valuation.company.name} rejected ${money(amount)}. They will not listen again until day ${state.day + APPROACH_COOLDOWN}.`,
    };
  }

  // One payment, one handover, and the group keeps its shape as a division.
  learn(state, 'acquired', 3);
  record(state, 'bought', `Bought ${valuation.company.name} whole — ${valuation.businesses.length} locations`, { amount: -amount });
  const division = createDivision(state, valuation.company.name, valuation.company.name);
  post(state, buyer.id, 'property', `Acquisition — ${valuation.company.name}`, -amount, null);
  valuation.company.cash += amount;
  for (const business of valuation.businesses) {
    transferBusiness(state, business, null, 0);
    business.divisionId = division.id;
  }

  pushNews(
    state,
    'company',
    `You have bought ${valuation.company.name}`,
    `${money(amount)} for ${valuation.businesses.length} locations, their leases, their stock and their people. They stay together as a division — put somebody senior over it before it drifts.`,
    { importance: 'high' },
  );
  pushAlert(
    state,
    'warning',
    `${division.name} needs somebody running it`,
    `${valuation.businesses.length} locations have just landed on your desk. A Senior Manager or an Executive can take them off it.`,
    null,
    'holding',
  );
  return {
    ok: true,
    accepted: true,
    message: `${valuation.company.name} is yours for ${money(amount)}. ${valuation.businesses.length} locations, kept together as a division.`,
  };
}

/** Rivals the player could realistically buy, best prospects first. */
export function acquisitionTargets(state: GameState, limit = 12): { business: Business; valuation: Valuation }[] {
  const mine = playerBusinesses(state);
  const myDistricts = new Set(
    mine.map((b) => buildingById(state, b.buildingId)?.district).filter(Boolean),
  );

  return state.businesses
    .filter((b) => b.companyId !== state.playerCompanyId && b.status === 'open')
    .map((business) => ({ business, valuation: valueBusiness(state, business) }))
    .sort((a, b) => {
      // Nearby and cheap first: those are the ones worth a conversation.
      const aNear = myDistricts.has(buildingById(state, a.business.buildingId)?.district ?? 'downtown') ? 1 : 0;
      const bNear = myDistricts.has(buildingById(state, b.business.buildingId)?.district ?? 'downtown') ? 1 : 0;
      if (aNear !== bNear) return bNear - aNear;
      return a.valuation.fair - b.valuation.fair;
    })
    .slice(0, limit);
}
