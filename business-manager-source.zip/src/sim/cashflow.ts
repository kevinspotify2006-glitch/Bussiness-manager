import type { GameState } from './state';
import { playerCompany } from './state';
import { DAYS_PER_MONTH } from './format';
import { sum } from './util';

/**
 * Cash is not profit.
 *
 * A company can be profitable and still die, because profit is what it earned
 * and cash is what it has. The accounts already say whether the month made
 * money; this says whether the company will still be able to pay for things in
 * three weeks — which is a different question and the one that kills people.
 *
 * The forecast is built from the trading pattern of the last fortnight plus the
 * payments that are already dated. Rent, wages, utilities and stock are paid as
 * they fall and so are already in the daily rate; the loan book lands in a lump
 * at month end, which is exactly why it catches people out.
 */

export interface Commitment {
  day: number;
  label: string;
  /** Negative for money out. */
  amount: number;
}

export interface Forecast {
  /** Cash at the end of each of the next `days` days. */
  balances: number[];
  /** The day the balance first goes below zero, or null. */
  emptyOnDay: number | null;
  /** Whole days of cash left at the current rate, capped at the horizon. */
  runway: number;
  /** Average daily movement from trading, before the dated commitments. */
  dailyNet: number;
  /** What is already committed inside the horizon, soonest first. */
  commitments: Commitment[];
}

export const HORIZON = 30;
/** Below this the game says something. Two weeks is enough time to act. */
export const WARNING_DAYS = 14;

/** Everything already dated that will move cash inside the horizon. */
export function commitments(state: GameState, days = HORIZON): Commitment[] {
  const out: Commitment[] = [];
  const from = state.day;

  for (const loan of state.loans) {
    if (loan.outstanding <= 0) continue;
    for (let day = from + 1; day <= from + days; day += 1) {
      if (day % DAYS_PER_MONTH !== 0) continue;
      out.push({ day, label: `${loan.lender} repayment`, amount: -loan.monthlyPayment });
    }
  }

  // Rent, wages, utilities and stock are all paid as they fall, so they are
  // already in the daily rate. The loan book is the only thing that lands in a
  // lump, which is exactly why it catches people out.

  return out.sort((a, b) => a.day - b.day);
}

/** What the company has been netting per day, from the last fortnight of trade. */
export function dailyNet(state: GameState): number {
  const recent = state.dayHistory.slice(-14);
  if (recent.length === 0) return 0;
  return sum(recent, (day) => day.revenue - day.costs) / recent.length;
}

export function forecast(state: GameState, days = HORIZON): Forecast {
  const company = playerCompany(state);
  const net = dailyNet(state);
  const dated = commitments(state, days);
  const balances: number[] = [];
  let balance = company.cash;
  let emptyOnDay: number | null = null;

  for (let i = 1; i <= days; i += 1) {
    const day = state.day + i;
    balance += net;
    for (const item of dated) {
      if (item.day === day) balance += item.amount;
    }
    balances.push(balance);
    if (emptyOnDay === null && balance < 0) emptyOnDay = day;
  }

  const runway = emptyOnDay === null ? days : emptyOnDay - state.day;
  return { balances, emptyOnDay, runway, dailyNet: net, commitments: dated };
}

/**
 * The one-line warning, or null when there is nothing to say. It waits for a
 * few days of trading, because a company on its first morning has no pattern to
 * forecast from — but it does not wait for a shop to be open, since a company
 * whose shops have all shut is exactly the one that needs telling.
 */
export function cashWarning(state: GameState): string | null {
  if (state.dayHistory.length < 5) return null;
  const view = forecast(state);
  if (view.emptyOnDay === null) return null;
  const days = view.emptyOnDay - state.day;
  if (days > WARNING_DAYS) return null;
  return `Your company may run out of cash in ${days} day${days === 1 ? '' : 's'}.`;
}
