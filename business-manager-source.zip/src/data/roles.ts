import type { EmployeeRoleDef, EmployeeRoleId, EmployeeTrait } from '../sim/types';

export const ROLES: EmployeeRoleDef[] = [
  { id: 'cashier', name: 'Cashier', baseSalary: 2050, description: 'Handles the queue. Directly limits how many customers you can serve.' },
  { id: 'sales', name: 'Sales Employee', baseSalary: 2250, description: 'Converts browsers into buyers and lifts the average basket.' },
  { id: 'manager', name: 'Store Manager', baseSalary: 3600, description: 'Lifts everyone else and keeps service quality from sliding.' },
  { id: 'warehouse', name: 'Warehouse Worker', baseSalary: 2200, description: 'Keeps the shelves filled from the back room.' },
  { id: 'driver', name: 'Delivery Driver', baseSalary: 2400, description: 'Required for logistics work and own-fleet deliveries.' },
  { id: 'cook', name: 'Cook', baseSalary: 2650, description: 'Sets both the throughput and the food quality of a kitchen.' },
  { id: 'server', name: 'Server', baseSalary: 2000, description: 'Front of house. Drives service quality and review scores.' },
  { id: 'technician', name: 'Technician', baseSalary: 3100, description: 'Skilled work: repairs, installations, treatments.' },
  { id: 'cleaner', name: 'Cleaner', baseSalary: 1850, description: 'Cleanliness feeds directly into reviews.' },
  { id: 'accountant', name: 'Accountant', baseSalary: 3300, description: 'Trims overheads and reduces the tax bill.' },
  { id: 'marketer', name: 'Marketing Employee', baseSalary: 2950, description: 'Makes every euro of marketing spend go further.' },
  // Central functions. They can be hired into a shop, but they only do what
  // they are for from a head office, where they serve every business at once.
  { id: 'hr', name: 'HR Officer', baseSalary: 3150, description: 'Finds people, keeps people, and notices before they go.' },
  { id: 'it', name: 'IT Specialist', baseSalary: 3850, description: 'Systems that do the routine work nobody should be doing by hand.' },
  { id: 'legal', name: 'Legal Counsel', baseSalary: 4250, description: 'Reads the contract before it is signed rather than after.' },
];

const byId = new Map(ROLES.map((role) => [role.id, role]));

export function role(id: EmployeeRoleId): EmployeeRoleDef {
  const found = byId.get(id);
  if (!found) throw new Error(`Unknown role: ${id}`);
  return found;
}

/**
 * Personality.
 *
 * Every field here is read somewhere in the simulation — there is no adjective
 * on this list that only prints. Between them they decide how fast somebody
 * burns out, what they do to the people around them, whether they can be
 * trusted with a team, and how likely they are to hand in their notice.
 */
export interface TraitDef {
  id: EmployeeTrait;
  name: string;
  effect: string;
  /** Multipliers applied to the employee's derived stats. */
  productivity: number;
  reliability: number;
  moraleDrift: number;
  learning: number;
  salaryExpectation: number;
  /** Multiplier on what they add to the customer experience. */
  service: number;
  /** Multiplier on how fast pressure turns into stress. */
  stress: number;
  /** Morale added to every colleague, per day. */
  teamMorale: number;
  /** Multiplier on how much of a manager's attention they take up. */
  supervision: number;
  /** Multiplier on their span of control once they are managing. */
  management: number;
  /** Multiplier on the chance they resign. */
  turnover: number;
}

export const TRAITS: TraitDef[] = [
  { id: 'hardworker', name: 'Hard worker', effect: '+15% productivity, burns out sooner', productivity: 1.15, reliability: 1.04, moraleDrift: 0, learning: 1, salaryExpectation: 1.02, service: 1, stress: 1.15, teamMorale: 0, supervision: 0.9, management: 1, turnover: 1 },
  { id: 'lazy', name: 'Lazy', effect: '−18% productivity, needs watching', productivity: 0.82, reliability: 0.94, moraleDrift: 0.4, learning: 0.8, salaryExpectation: 0.94, service: 0.94, stress: 0.8, teamMorale: -0.04, supervision: 1.45, management: 0.8, turnover: 1 },
  { id: 'ambitious', name: 'Ambitious', effect: 'Learns fast, expects raises, leaves if ignored', productivity: 1.07, reliability: 1, moraleDrift: -0.6, learning: 1.3, salaryExpectation: 1.14, service: 1, stress: 1.05, teamMorale: 0, supervision: 0.85, management: 1.1, turnover: 1.3 },
  { id: 'loyal', name: 'Loyal', effect: 'Rarely resigns', productivity: 1, reliability: 1.06, moraleDrift: 0.5, learning: 1, salaryExpectation: 0.95, service: 1.02, stress: 0.95, teamMorale: 0.02, supervision: 0.9, management: 1, turnover: 0.35 },
  { id: 'unreliable', name: 'Unreliable', effect: 'Often absent, and a handful to manage', productivity: 0.95, reliability: 0.74, moraleDrift: -0.2, learning: 0.95, salaryExpectation: 0.9, service: 0.92, stress: 1, teamMorale: -0.03, supervision: 1.5, management: 0.75, turnover: 1.4 },
  { id: 'fastlearner', name: 'Fast learner', effect: 'Training pays off twice as fast', productivity: 1, reliability: 1, moraleDrift: 0, learning: 1.9, salaryExpectation: 1.05, service: 1, stress: 1, teamMorale: 0, supervision: 0.95, management: 1.05, turnover: 1.1 },
  { id: 'perfectionist', name: 'Perfectionist', effect: '+ service quality, − speed, takes it hard', productivity: 0.92, reliability: 1.05, moraleDrift: -0.3, learning: 1.1, salaryExpectation: 1.06, service: 1.2, stress: 1.3, teamMorale: -0.02, supervision: 1.1, management: 0.95, turnover: 1 },
  { id: 'teamplayer', name: 'Team player', effect: 'Lifts colleagues’ morale every day', productivity: 1.02, reliability: 1.02, moraleDrift: 0.3, learning: 1, salaryExpectation: 1, service: 1.05, stress: 0.95, teamMorale: 0.09, supervision: 0.85, management: 1.15, turnover: 0.85 },
  { id: 'difficult', name: 'Difficult', effect: 'Drags colleagues’ morale down daily', productivity: 1.03, reliability: 0.98, moraleDrift: -0.5, learning: 1, salaryExpectation: 1.03, service: 0.9, stress: 1.1, teamMorale: -0.12, supervision: 1.6, management: 0.7, turnover: 1.2 },
  { id: 'friendly', name: 'Customer-friendly', effect: '+ service quality', productivity: 1.01, reliability: 1.01, moraleDrift: 0.2, learning: 1, salaryExpectation: 1.04, service: 1.18, stress: 0.95, teamMorale: 0.03, supervision: 0.95, management: 1.05, turnover: 0.95 },
  { id: 'independent', name: 'Independent', effect: 'Needs almost no supervision, gives the team little', productivity: 1.04, reliability: 1.02, moraleDrift: 0.1, learning: 1, salaryExpectation: 1.03, service: 0.97, stress: 0.9, teamMorale: -0.01, supervision: 0.45, management: 0.9, turnover: 1.1 },
  { id: 'stressresistant', name: 'Stress resistant', effect: 'Long hours barely touch them', productivity: 1.02, reliability: 1.05, moraleDrift: 0.2, learning: 1, salaryExpectation: 1.04, service: 1.02, stress: 0.5, teamMorale: 0.02, supervision: 0.85, management: 1.1, turnover: 0.8 },
  { id: 'creative', name: 'Creative', effect: 'Finds a way, and customers notice', productivity: 1.03, reliability: 0.97, moraleDrift: -0.1, learning: 1.15, salaryExpectation: 1.07, service: 1.12, stress: 1.05, teamMorale: 0.03, supervision: 1.05, management: 1, turnover: 1.15 },
];

const traitById = new Map(TRAITS.map((trait) => [trait.id, trait]));

export function trait(id: EmployeeTrait): TraitDef {
  const found = traitById.get(id);
  if (!found) throw new Error(`Unknown trait: ${id}`);
  return found;
}

export const FIRST_NAMES = [
  'Aisha', 'Mateo', 'Nora', 'Elias', 'Priya', 'Tomas', 'Lena', 'Youssef', 'Sofia', 'Kenji',
  'Marta', 'Dmitri', 'Chloe', 'Andre', 'Ingrid', 'Hassan', 'Lucia', 'Bram', 'Zoe', 'Otto',
  'Amara', 'Felix', 'Rina', 'Viktor', 'Talia', 'Jonas', 'Mei', 'Rafael', 'Sanne', 'Idris',
  'Clara', 'Nikolai', 'Yara', 'Pieter', 'Esme', 'Omar', 'Freya', 'Diego', 'Hana', 'Lars',
];

export const LAST_NAMES = [
  'Okafor', 'Lindqvist', 'Moreau', 'Hartmann', 'Silva', 'Novak', 'Bergman', 'Halim', 'Costa',
  'Tanaka', 'Kovac', 'Duarte', 'Ferreira', 'Ivanov', 'Nakamura', 'Brandt', 'Rossi', 'Vos',
  'Adeyemi', 'Larsen', 'Mendez', 'Weiss', 'Petrov', 'Dubois', 'Haddad', 'Sorensen', 'Marino',
  'Pereira', 'Farkas', 'Nowak', 'Reyes', 'Aalto', 'Bianchi', 'Steiner', 'Okonkwo', 'Vidal',
];
