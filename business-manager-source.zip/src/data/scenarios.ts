/**
 * How the game starts.
 *
 * A scenario is not a difficulty slider with a name on it. Each one hands the
 * player a genuinely different job: the one-man band is about surviving until
 * somebody else can be paid to help, and the empire is about letting go of
 * things you can no longer personally see. The same city, the same rules, a
 * different problem.
 *
 * Everything a scenario sets up is built by the game's own functions — leases
 * are taken, businesses founded, people hired and doors opened exactly as a
 * player would do it. Nothing here is a pre-baked save with invented numbers in
 * it, which is why a scenario company behaves identically to one you built.
 */
export interface ScenarioDef {
  id: string;
  name: string;
  /** The pitch, in one line. */
  tagline: string;
  /** What you are handed. */
  detail: string;
  /** What the game is about from here. */
  focus: string;
  /** Roughly how hard the first month is. */
  difficulty: 'gentle' | 'ordinary' | 'hard' | 'sandbox';
  cash: number;
  /** Trading locations to set up and open. */
  locations: number;
  /** People hired into each of them. */
  staffPerLocation: number;
  /** Where reputation and awareness start at each location. */
  reputation: number;
  awareness: number;
  creditRating: number;
  /** The rung of the ladder the company counts as having reached. */
  levelReached: number;
  /** Whether a head office is already fitted out. */
  headOffice: boolean;
  /** An inherited business loan, as a fraction of starting cash. */
  debtShare: number;
  /** Extra rival outlets already in the city. */
  extraRivals: number;
  /** Days of trading history to run before handing it over. */
  warmUpDays: number;
}

export const SCENARIOS: ScenarioDef[] = [
  {
    id: 'oneman',
    name: 'One-man band',
    tagline: 'You are the owner, the staff and the manager.',
    detail: 'Barely any money, one small unit, nobody on the payroll but you.',
    focus: 'Survive the first month, then find the money for a second pair of hands.',
    difficulty: 'hard',
    cash: 26_000,
    locations: 0,
    staffPerLocation: 0,
    reputation: 30,
    awareness: 4,
    creditRating: 44,
    levelReached: 1,
    headOffice: false,
    debtShare: 0,
    extraRivals: 0,
    warmUpDays: 0,
  },
  {
    id: 'small',
    name: 'Small business',
    tagline: 'A shop that already trades, and a handful of people in it.',
    detail: 'One location open, staffed, with a few weeks of takings behind it.',
    focus: 'Stop doing everything yourself. Delegate, and make the place worth owning.',
    difficulty: 'ordinary',
    cash: 58_000,
    locations: 1,
    staffPerLocation: 3,
    reputation: 44,
    awareness: 16,
    creditRating: 52,
    levelReached: 1,
    headOffice: false,
    debtShare: 0,
    extraRivals: 0,
    warmUpDays: 20,
  },
  {
    id: 'entrepreneur',
    name: 'Entrepreneur',
    tagline: 'Money in the bank and nothing trading yet.',
    detail: 'A decent stake, a clean record and the whole city to choose from.',
    focus: 'The ordinary game: pick well, open well, and grow at your own pace.',
    difficulty: 'ordinary',
    cash: 60_000,
    locations: 0,
    staffPerLocation: 0,
    reputation: 35,
    awareness: 6,
    creditRating: 52,
    levelReached: 1,
    headOffice: false,
    debtShare: 0,
    extraRivals: 0,
    warmUpDays: 0,
  },
  {
    id: 'startup',
    name: 'Startup',
    tagline: 'Somebody else’s money, and their expectations with it.',
    detail: 'Well funded, badly known, and carrying a loan from day one.',
    focus: 'Spend fast enough to grow and slow enough to still be here in a year.',
    difficulty: 'hard',
    cash: 150_000,
    locations: 1,
    staffPerLocation: 2,
    reputation: 32,
    awareness: 8,
    creditRating: 58,
    levelReached: 2,
    headOffice: false,
    debtShare: 0.42,
    extraRivals: 3,
    warmUpDays: 10,
  },
  {
    id: 'established',
    name: 'Established business',
    tagline: 'You have inherited a going concern, and everything wrong with it.',
    detail: 'Three locations, a real payroll, customers who already have opinions — and a mortgage.',
    focus: 'Optimisation. Find what is quietly losing money and fix it.',
    difficulty: 'ordinary',
    cash: 300_000,
    locations: 3,
    staffPerLocation: 5,
    reputation: 55,
    awareness: 34,
    creditRating: 66,
    levelReached: 3,
    headOffice: false,
    debtShare: 0.3,
    extraRivals: 4,
    warmUpDays: 45,
  },
  {
    id: 'empire',
    name: 'Business empire',
    tagline: 'More locations than one person can see.',
    detail: 'Seven locations, a head office, a large payroll and rivals who have noticed you.',
    focus: 'Letting go. Structure it, delegate it, and keep it from drifting.',
    difficulty: 'sandbox',
    cash: 900_000,
    locations: 7,
    staffPerLocation: 6,
    reputation: 62,
    awareness: 48,
    creditRating: 78,
    levelReached: 5,
    headOffice: true,
    debtShare: 0.5,
    extraRivals: 8,
    warmUpDays: 60,
  },
  {
    id: 'custom',
    name: 'Custom',
    tagline: 'Set it up however you like.',
    detail: 'Every figure below is yours to choose.',
    focus: 'Whatever you decide it is.',
    difficulty: 'sandbox',
    cash: 60_000,
    locations: 1,
    staffPerLocation: 3,
    reputation: 40,
    awareness: 12,
    creditRating: 55,
    levelReached: 1,
    headOffice: false,
    debtShare: 0,
    extraRivals: 0,
    warmUpDays: 14,
  },
];

export function scenario(id: string): ScenarioDef {
  return SCENARIOS.find((s) => s.id === id) ?? SCENARIOS[2];
}

export const DIFFICULTY_LABELS: Record<ScenarioDef['difficulty'], string> = {
  gentle: 'Forgiving',
  ordinary: 'Ordinary',
  hard: 'Unforgiving',
  sandbox: 'Sandbox',
};
