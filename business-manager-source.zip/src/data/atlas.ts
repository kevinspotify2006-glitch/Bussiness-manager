/**
 * The asset pack, measured.
 *
 * `BM_Asset_Atlas_100.png` is a contact sheet: 134 labelled isometric renders on
 * dark panels, with captions. It cannot be blitted onto a top-down city map, and
 * the pack's own notes say to extract or recreate its assets to suit the
 * renderer. So each cell was isolated, its background and drop shadow eroded
 * away, and the building inside it measured: the colour of its roof, its walls,
 * and the one accent that makes it recognisable — a filling station's red
 * canopy, a bank's blue stone, the deep blue of a solar farm. Those measurements
 * are this table, and `src/ui/sprites.ts` draws each asset from them.
 *
 * Generated from the pack; edit the generator, not this file.
 */

export type AssetKind =
  | 'civic'
  | 'energy'
  | 'farm'
  | 'housing'
  | 'industry'
  | 'landmark'
  | 'leisure'
  | 'logistics'
  | 'nature'
  | 'office'
  | 'park'
  | 'retail'
  | 'road'
  | 'street'
  | 'vehicle';

export interface AtlasAsset {
  id: string;
  name: string;
  kind: AssetKind;
  /** Seen from above: the roof. */
  roof: string;
  roofAlt: string;
  /** Seen from the side: the elevation. */
  wall: string;
  wallAlt: string;
  /** The colour that makes it recognisable at a glance. */
  accent: string;
  /** Width over depth as it stands in the pack. */
  ratio: number;
}

export const ATLAS: AtlasAsset[] = [
  { id: 'glass-office', name: 'Glass office', kind: 'office', roof: '#a2a19c', roofAlt: '#ddd8d5', wall: '#5e818f', wallAlt: '#99a8a2', accent: '#618998', ratio: 1.15 },
  { id: 'courtyard-office', name: 'Courtyard office', kind: 'office', roof: '#838380', roofAlt: '#dfdbda', wall: '#5e693c', wallAlt: '#7e8776', accent: '#858f7b', ratio: 1.16 },
  { id: 'business-centre', name: 'Business centre', kind: 'office', roof: '#dfdad7', roofAlt: '#737940', wall: '#828c8f', wallAlt: '#e8e4e1', accent: '#7d8342', ratio: 1.24 },
  { id: 'curtain-wall-tower', name: 'Curtain-wall tower', kind: 'office', roof: '#828995', roofAlt: '#e2ddda', wall: '#7b8889', wallAlt: '#3d5f61', accent: '#4c678e', ratio: 1.06 },
  { id: 'corner-office', name: 'Corner office', kind: 'office', roof: '#7c7d73', roofAlt: '#e8e0d9', wall: '#788285', wallAlt: '#eee5d7', accent: '#f1e7d8', ratio: 1.23 },
  { id: 'head-office', name: 'Head office', kind: 'office', roof: '#e4dbd7', roofAlt: '#627385', wall: '#768686', wallAlt: '#3e5e61', accent: '#42676b', ratio: 1.07 },
  { id: 'rooftop-garden-office', name: 'Rooftop-garden office', kind: 'office', roof: '#868a8b', roofAlt: '#dbd7d5', wall: '#41615f', wallAlt: '#688693', accent: '#435f70', ratio: 1.07 },
  { id: 'office-block', name: 'Office block', kind: 'office', roof: '#7b817d', roofAlt: '#e5ded8', wall: '#eae0d9', wallAlt: '#636e35', accent: '#44606b', ratio: 1.13 },
  { id: 'riverside-office', name: 'Riverside office', kind: 'office', roof: '#536e85', roofAlt: '#7990a2', wall: '#50778a', wallAlt: '#7b969d', accent: '#528094', ratio: 1.17 },
  { id: 'chambers', name: 'Chambers', kind: 'office', roof: '#607380', roofAlt: '#8f9ba3', wall: '#6b8084', wallAlt: '#eee6dc', accent: '#406565', ratio: 1.08 },
  { id: 'supermarket', name: 'Supermarket', kind: 'retail', roof: '#a1a0a9', roofAlt: '#dbc8b7', wall: '#e4d0b1', wallAlt: '#bfb788', accent: '#c6be89', ratio: 1.26 },
  { id: 'electronics-store', name: 'Electronics store', kind: 'retail', roof: '#787276', roofAlt: '#8d888a', wall: '#7e7a7c', wallAlt: '#b6aca8', accent: '#636c43', ratio: 1.55 },
  { id: 'clothing-store', name: 'Clothing store', kind: 'retail', roof: '#6d7d32', roofAlt: '#837f80', wall: '#848084', wallAlt: '#e4d8cd', accent: '#5c6244', ratio: 1.08 },
  { id: 'furniture-store', name: 'Furniture store', kind: 'retail', roof: '#946b6e', roofAlt: '#c3a493', wall: '#7f5b45', wallAlt: '#dcbfb0', accent: '#ed373e', ratio: 1.2 },
  { id: 'builders-merchant', name: 'Builders merchant', kind: 'retail', roof: '#6b7695', roofAlt: '#c7b19e', wall: '#8f5c3a', wallAlt: '#e8ae6d', accent: '#9d633b', ratio: 1.28 },
  { id: 'sports-shop', name: 'Sports shop', kind: 'retail', roof: '#d2b29b', roofAlt: '#e7cab2', wall: '#ddbca2', wallAlt: '#927d6d', accent: '#e4c1a3', ratio: 1.16 },
  { id: 'pharmacy', name: 'Pharmacy', kind: 'retail', roof: '#80828a', roofAlt: '#e3dddb', wall: '#848b8b', wallAlt: '#ece5e2', accent: '#f53b49', ratio: 1.26 },
  { id: 'filling-station', name: 'Filling station', kind: 'retail', roof: '#918a8d', roofAlt: '#dac6c1', wall: '#c1a092', wallAlt: '#5e534b', accent: '#ec4649', ratio: 1.41 },
  { id: 'car-showroom', name: 'Car showroom', kind: 'retail', roof: '#ede2da', roofAlt: '#677187', wall: '#eae2dd', wallAlt: '#dccdc6', accent: '#6c7890', ratio: 1.41 },
  { id: 'shopping-centre', name: 'Shopping centre', kind: 'retail', roof: '#867e7d', roofAlt: '#e9d8c7', wall: '#857d71', wallAlt: '#ede0d3', accent: '#bfa996', ratio: 1.19 },
  { id: 'brick-works', name: 'Brick works', kind: 'industry', roof: '#c3483a', roofAlt: '#e1e1df', wall: '#ede2db', wallAlt: '#847c7b', accent: '#d54a39', ratio: 1.09 },
  { id: 'foundry', name: 'Foundry', kind: 'industry', roof: '#80767d', roofAlt: '#aa9e9f', wall: '#7c7881', wallAlt: '#eee7e6', accent: '#5a6537', ratio: 1.32 },
  { id: 'assembly-plant', name: 'Assembly plant', kind: 'industry', roof: '#7e92a6', roofAlt: '#a5bbc8', wall: '#6d94ae', wallAlt: '#8fafc1', accent: '#6f9bb7', ratio: 1.1 },
  { id: 'chemical-plant', name: 'Chemical plant', kind: 'industry', roof: '#b9a599', roofAlt: '#8d6c65', wall: '#eadcd2', wallAlt: '#787067', accent: '#97726a', ratio: 1.01 },
  { id: 'food-processing', name: 'Food processing', kind: 'industry', roof: '#8c8689', roofAlt: '#dccdc8', wall: '#e2d4ca', wallAlt: '#c5b7af', accent: '#e74c38', ratio: 0.94 },
  { id: 'steelworks', name: 'Steelworks', kind: 'industry', roof: '#e1d7cf', roofAlt: '#85716f', wall: '#e9dfd9', wallAlt: '#747270', accent: '#ad988d', ratio: 1.12 },
  { id: 'textile-mill', name: 'Textile mill', kind: 'industry', roof: '#827979', roofAlt: '#deccc4', wall: '#867f87', wallAlt: '#efe4e0', accent: '#b7625b', ratio: 1.33 },
  { id: 'vehicle-plant', name: 'Vehicle plant', kind: 'industry', roof: '#7e828e', roofAlt: '#c9c8c9', wall: '#7b868b', wallAlt: '#a4b4bb', accent: '#445471', ratio: 1.44 },
  { id: 'machine-shop', name: 'Machine shop', kind: 'industry', roof: '#a99d99', roofAlt: '#7f7879', wall: '#938882', wallAlt: '#c6b6a9', accent: '#ccbaac', ratio: 1.35 },
  { id: 'recycling-centre', name: 'Recycling centre', kind: 'industry', roof: '#77776e', roofAlt: '#a29d8d', wall: '#798881', wallAlt: '#adb1a7', accent: '#a9a491', ratio: 1.06 },
  { id: 'small-warehouse', name: 'Small warehouse', kind: 'logistics', roof: '#afacaf', roofAlt: '#e9ddd8', wall: '#c5b4a8', wallAlt: '#ac9a91', accent: '#b39f95', ratio: 0.94 },
  { id: 'warehouse', name: 'Warehouse', kind: 'logistics', roof: '#4e6181', roofAlt: '#beb4b2', wall: '#beafa8', wallAlt: '#ede2da', accent: '#51688d', ratio: 1.03 },
  { id: 'large-warehouse', name: 'Large warehouse', kind: 'logistics', roof: '#b5b5be', roofAlt: '#565e62', wall: '#b3a298', wallAlt: '#eaded6', accent: '#baa79c', ratio: 1.02 },
  { id: 'distribution-centre', name: 'Distribution centre', kind: 'logistics', roof: '#a69c9d', roofAlt: '#596b8f', wall: '#b2a5a0', wallAlt: '#e9e2de', accent: '#5d729a', ratio: 0.91 },
  { id: 'cold-store', name: 'Cold store', kind: 'logistics', roof: '#c5b8b2', roofAlt: '#868084', wall: '#747981', wallAlt: '#c4b2a2', accent: '#4c6ba0', ratio: 1.24 },
  { id: 'container-terminal', name: 'Container terminal', kind: 'logistics', roof: '#9c4736', roofAlt: '#dc6f3b', wall: '#c87e5a', wallAlt: '#98463d', accent: '#ec7338', ratio: 1.11 },
  { id: 'sorting-office', name: 'Sorting office', kind: 'logistics', roof: '#b6a9a7', roofAlt: '#848081', wall: '#b0a3a0', wallAlt: '#d1c2ba', accent: '#d85a52', ratio: 1.08 },
  { id: 'transhipment-yard', name: 'Transhipment yard', kind: 'logistics', roof: '#76798c', roofAlt: '#4a618f', wall: '#7a7a85', wallAlt: '#af9d95', accent: '#4c679b', ratio: 1.17 },
  { id: 'bank', name: 'Bank', kind: 'civic', roof: '#847c77', roofAlt: '#e4d9cb', wall: '#376b97', wallAlt: '#a8a595', accent: '#3673a5', ratio: 1.01 },
  { id: 'hospital', name: 'Hospital', kind: 'civic', roof: '#837b7b', roofAlt: '#e7e0d9', wall: '#8f8b80', wallAlt: '#ece1d8', accent: '#6c733b', ratio: 0.93 },
  { id: 'fire-station', name: 'Fire station', kind: 'civic', roof: '#e27b5d', roofAlt: '#7a473d', wall: '#734938', wallAlt: '#d36752', accent: '#e26a52', ratio: 0.95 },
  { id: 'police-station', name: 'Police station', kind: 'civic', roof: '#e0dad0', roofAlt: '#72787f', wall: '#77848a', wallAlt: '#a9aba0', accent: '#7d8b91', ratio: 0.9 },
  { id: 'school', name: 'School', kind: 'civic', roof: '#8a7d79', roofAlt: '#76813a', wall: '#8f8170', wallAlt: '#cdab83', accent: '#7c7932', ratio: 1.28 },
  { id: 'university', name: 'University', kind: 'civic', roof: '#847f79', roofAlt: '#dac9b9', wall: '#a09286', wallAlt: '#e9d8c5', accent: '#4a5362', ratio: 1.06 },
  { id: 'town-hall', name: 'Town hall', kind: 'civic', roof: '#9a9a9e', roofAlt: '#d7d3cf', wall: '#e8ded3', wallAlt: '#5f673f', accent: '#677043', ratio: 1.31 },
  { id: 'courthouse', name: 'Courthouse', kind: 'civic', roof: '#857f78', roofAlt: '#dac6b4', wall: '#8a8171', wallAlt: '#e7d4c2', accent: '#757e2c', ratio: 1.06 },
  { id: 'restaurant', name: 'Restaurant', kind: 'leisure', roof: '#8d7567', roofAlt: '#6b7531', wall: '#8b725d', wallAlt: '#c69a72', accent: '#8c5b3e', ratio: 0.95 },
  { id: 'cafe', name: 'Café', kind: 'leisure', roof: '#697731', roofAlt: '#8e7465', wall: '#b87a69', wallAlt: '#956857', accent: '#c47e6c', ratio: 0.95 },
  { id: 'small-hotel', name: 'Small hotel', kind: 'leisure', roof: '#a6846e', roofAlt: '#e2ae7e', wall: '#cfa079', wallAlt: '#a07d5e', accent: '#ecb37d', ratio: 0.9 },
  { id: 'hotel', name: 'Hotel', kind: 'leisure', roof: '#ecdbc8', roofAlt: '#7d7a73', wall: '#e7d5c2', wallAlt: '#8c8371', accent: '#6f7735', ratio: 0.98 },
  { id: 'cinema', name: 'Cinema', kind: 'leisure', roof: '#7a7176', roofAlt: '#898284', wall: '#7d7579', wallAlt: '#805c44', accent: '#8c6347', ratio: 1.25 },
  { id: 'gym', name: 'Gym', kind: 'leisure', roof: '#687632', roofAlt: '#8f8a79', wall: '#7d7877', wallAlt: '#a09690', accent: '#dacbb4', ratio: 1.07 },
  { id: 'swimming-pool', name: 'Swimming pool', kind: 'leisure', roof: '#5f908d', roofAlt: '#667136', wall: '#2295b6', wallAlt: '#dcc09b', accent: '#1aa0c5', ratio: 1.3 },
  { id: 'funfair-ride', name: 'Funfair ride', kind: 'leisure', roof: '#9a6f7a', roofAlt: '#686058', wall: '#8d836d', wallAlt: '#6d6a3c', accent: '#ce7968', ratio: 1.12 },
  { id: 'terrace', name: 'Terrace', kind: 'housing', roof: '#7d767b', roofAlt: '#d49f80', wall: '#817a57', wallAlt: '#c29271', accent: '#717929', ratio: 1.16 },
  { id: 'semi-detached', name: 'Semi-detached', kind: 'housing', roof: '#7b757a', roofAlt: '#d8a486', wall: '#87814c', wallAlt: '#ba9572', accent: '#72752c', ratio: 1.17 },
  { id: 'detached-house', name: 'Detached house', kind: 'housing', roof: '#49534c', roofAlt: '#85856e', wall: '#636e2d', wallAlt: '#918f55', accent: '#9b9957', ratio: 0.9 },
  { id: 'apartment-block', name: 'Apartment block', kind: 'housing', roof: '#e7d4c4', roofAlt: '#847b75', wall: '#867f71', wallAlt: '#e8d3c3', accent: '#798034', ratio: 1.01 },
  { id: 'villa', name: 'Villa', kind: 'housing', roof: '#8e5d4a', roofAlt: '#b98671', wall: '#aa8a70', wallAlt: '#826f45', accent: '#9a624c', ratio: 1.33 },
  { id: 'tiny-house', name: 'Tiny house', kind: 'housing', roof: '#667626', roofAlt: '#898948', wall: '#d19872', wallAlt: '#8d8046', accent: '#716e2d', ratio: 1.7 },
  { id: 'student-house', name: 'Student house', kind: 'housing', roof: '#908580', roofAlt: '#e3cebd', wall: '#e4cebc', wallAlt: '#cab7a6', accent: '#777c36', ratio: 1.39 },
  { id: 'social-housing', name: 'Social housing', kind: 'housing', roof: '#7a716e', roofAlt: '#d39471', wall: '#e8a377', wallAlt: '#c88b68', accent: '#8d513d', ratio: 1.4 },
  { id: 'solar-farm', name: 'Solar farm', kind: 'energy', roof: '#476ba6', roofAlt: '#385592', wall: '#4362a2', wallAlt: '#707336', accent: '#385ba0', ratio: 1.54 },
  { id: 'wind-turbine', name: 'Wind turbine', kind: 'energy', roof: '#e7e2df', roofAlt: '#afa9aa', wall: '#898c41', wallAlt: '#676e2d', accent: '#717a2d', ratio: 1.06 },
  { id: 'gas-plant', name: 'Gas plant', kind: 'energy', roof: '#af3832', roofAlt: '#c08d7e', wall: '#9e8f7e', wallAlt: '#b6a99a', accent: '#c13931', ratio: 1.31 },
  { id: 'nuclear-plant', name: 'Nuclear plant', kind: 'energy', roof: '#807b73', roofAlt: '#bfaa9b', wall: '#817a72', wallAlt: '#c9b8ab', accent: '#b1a089', ratio: 0.96 },
  { id: 'storage-silos', name: 'Storage silos', kind: 'energy', roof: '#8f8886', roofAlt: '#cec1ae', wall: '#a29864', wallAlt: '#837d41', accent: '#8d8741', ratio: 1.85 },
  { id: 'substation', name: 'Substation', kind: 'energy', roof: '#8e8c83', roofAlt: '#bdb7b2', wall: '#c5b3a3', wallAlt: '#9f9081', accent: '#686953', ratio: 1.48 },
  { id: 'charging-hub', name: 'Charging hub', kind: 'energy', roof: '#dfdbd7', roofAlt: '#6f8489', wall: '#beafa5', wallAlt: '#eae5e2', accent: '#748b91', ratio: 2.3 },
  { id: 'biogas-plant', name: 'Biogas plant', kind: 'energy', roof: '#698891', roofAlt: '#a4b7b3', wall: '#a19961', wallAlt: '#557d7e', accent: '#aba262', ratio: 1.73 },
  { id: 'farmhouse', name: 'Farmhouse', kind: 'farm', roof: '#935043', roofAlt: '#86443c', wall: '#835c40', wallAlt: '#ca9563', accent: '#94483e', ratio: 1.26 },
  { id: 'glasshouse', name: 'Glasshouse', kind: 'farm', roof: '#8d9493', roofAlt: '#73797a', wall: '#8b928e', wallAlt: '#74766b', accent: '#af9a4c', ratio: 1.13 },
  { id: 'poultry-shed', name: 'Poultry shed', kind: 'farm', roof: '#8d8f8d', roofAlt: '#c8bdb7', wall: '#929292', wallAlt: '#8d7b52', accent: '#988454', ratio: 1.21 },
  { id: 'livestock-shed', name: 'Livestock shed', kind: 'farm', roof: '#9a8882', roofAlt: '#7b726b', wall: '#897657', wallAlt: '#b49567', accent: '#7f7034', ratio: 1.3 },
  { id: 'arable-field', name: 'Arable field', kind: 'farm', roof: '#90794d', roofAlt: '#be904b', wall: '#d99e59', wallAlt: '#ebb36a', accent: '#ce9445', ratio: 1.55 },
  { id: 'orchard', name: 'Orchard', kind: 'farm', roof: '#878734', roofAlt: '#5e6e20', wall: '#9a8d3f', wallAlt: '#837f33', accent: '#929232', ratio: 1.51 },
  { id: 'pasture', name: 'Pasture', kind: 'farm', roof: '#9a9145', roofAlt: '#b1aa54', wall: '#929440', wallAlt: '#848438', accent: '#8f8f37', ratio: 1.9 },
  { id: 'fruit-plantation', name: 'Fruit plantation', kind: 'farm', roof: '#9e7f42', roofAlt: '#796b34', wall: '#817837', wallAlt: '#9c8b43', accent: '#7d6a29', ratio: 1.8 },
  { id: 'research-centre', name: 'Research centre', kind: 'landmark', roof: '#7b8084', roofAlt: '#e3dcdd', wall: '#81846d', wallAlt: '#69722d', accent: '#737d2d', ratio: 1.16 },
  { id: 'data-centre', name: 'Data centre', kind: 'landmark', roof: '#798a95', roofAlt: '#d8d5d6', wall: '#7f8f95', wallAlt: '#b8bab8', accent: '#3e5762', ratio: 1.15 },
  { id: 'airport', name: 'Airport', kind: 'landmark', roof: '#545b5d', roofAlt: '#4c5659', wall: '#c0aea2', wallAlt: '#968a80', accent: '#c7b2a5', ratio: 1.22 },
  { id: 'station', name: 'Station', kind: 'landmark', roof: '#867c7a', roofAlt: '#a99f98', wall: '#7f766f', wallAlt: '#b59f8a', accent: '#856045', ratio: 1.07 },
  { id: 'harbour', name: 'Harbour', kind: 'landmark', roof: '#816c68', roofAlt: '#c1603d', wall: '#996757', wallAlt: '#b49b8b', accent: '#d1643c', ratio: 1.46 },
  { id: 'stadium', name: 'Stadium', kind: 'landmark', roof: '#cec1c0', roofAlt: '#ac9c98', wall: '#c7b7b0', wallAlt: '#52754c', accent: '#a39a8a', ratio: 1.6 },
  { id: 'events-hall', name: 'Events hall', kind: 'landmark', roof: '#a39292', roofAlt: '#e0d4c8', wall: '#dc6552', wallAlt: '#764747', accent: '#ec6851', ratio: 1.38 },
  { id: 'telecom-mast', name: 'Telecom mast', kind: 'landmark', roof: '#716c6d', roofAlt: '#854349', wall: '#81464d', wallAlt: '#a7595b', accent: '#92464d', ratio: 0.85 },
  { id: 'city-park', name: 'City park', kind: 'park', roof: '#768529', roofAlt: '#5f6f22', wall: '#7e7a46', wallAlt: '#a39859', accent: '#6d7724', ratio: 1.08 },
  { id: 'fountain', name: 'Fountain', kind: 'park', roof: '#4a5549', roofAlt: '#768334', wall: '#cec3bb', wallAlt: '#89875f', accent: '#4e7775', ratio: 1.19 },
  { id: 'playground', name: 'Playground', kind: 'park', roof: '#4e543e', roofAlt: '#736029', wall: '#d7ac70', wallAlt: '#a88747', accent: '#7f6929', ratio: 1.22 },
  { id: 'petting-farm', name: 'Petting farm', kind: 'park', roof: '#c9a67c', roofAlt: '#737c2e', wall: '#867f4a', wallAlt: '#cdac79', accent: '#7d872c', ratio: 1.01 },
  { id: 'cemetery', name: 'Cemetery', kind: 'park', roof: '#968e5a', roofAlt: '#737241', wall: '#90894e', wallAlt: '#a69c69', accent: '#7f7c36', ratio: 1.84 },
  { id: 'statue', name: 'Statue', kind: 'park', roof: '#dac7b7', roofAlt: '#8f7a76', wall: '#d6c3b4', wallAlt: '#bfa99b', accent: '#c6ae9f', ratio: 1.42 },
  { id: 'market-square', name: 'Market square', kind: 'park', roof: '#c5ad9c', roofAlt: '#e4d4c9', wall: '#c6b09d', wallAlt: '#ac957c', accent: '#726549', ratio: 1.74 },
  { id: 'terrace-seating', name: 'Terrace seating', kind: 'park', roof: '#948d7f', roofAlt: '#ecd9ca', wall: '#efddd0', wallAlt: '#d1b6a4', accent: '#a58f7c', ratio: 1.58 },
  { id: 'straight-road', name: 'Straight road', kind: 'road', roof: '#696768', roofAlt: '#6e6d6d', wall: '#6b6a6b', wallAlt: '#6e6e6f', accent: '#cab3a0', ratio: 1.68 },
  { id: 'curved-road', name: 'Curved road', kind: 'road', roof: '#777373', roofAlt: '#cac0ba', wall: '#726e6e', wallAlt: '#aa9f98', accent: '#b0a49c', ratio: 1.44 },
  { id: 'crossroads', name: 'Crossroads', kind: 'road', roof: '#878077', roofAlt: '#cac5ba', wall: '#837c78', wallAlt: '#b3aca5', accent: '#8e877c', ratio: 1.18 },
  { id: 't-junction', name: 'T-junction', kind: 'road', roof: '#807977', roofAlt: '#cdc3bc', wall: '#7c7773', wallAlt: '#b4aaa2', accent: '#4c413e', ratio: 1.26 },
  { id: 'roundabout', name: 'Roundabout', kind: 'road', roof: '#716f6f', roofAlt: '#908787', wall: '#6e6c67', wallAlt: '#797768', accent: '#817f6d', ratio: 1.26 },
  { id: 'motorway', name: 'Motorway', kind: 'road', roof: '#767372', roofAlt: '#b6b0ab', wall: '#757372', wallAlt: '#9d9894', accent: '#3a3d40', ratio: 1.45 },
  { id: 'bridge', name: 'Bridge', kind: 'road', roof: '#928c8f', roofAlt: '#888186', wall: '#948d8f', wallAlt: '#a7a2a3', accent: '#8f878d', ratio: 1.76 },
  { id: 'tunnel', name: 'Tunnel', kind: 'road', roof: '#747173', roofAlt: '#817a7c', wall: '#777073', wallAlt: '#9d8b7f', accent: '#a59283', ratio: 1.68 },
  { id: 'cycle-path', name: 'Cycle path', kind: 'road', roof: '#c4685f', roofAlt: '#856a65', wall: '#c96d62', wallAlt: '#bc6258', accent: '#ca6559', ratio: 1.77 },
  { id: 'footpath', name: 'Footpath', kind: 'road', roof: '#996a64', roofAlt: '#a99891', wall: '#b6a79e', wallAlt: '#a89791', accent: '#a57068', ratio: 1.67 },
  { id: 'saloon-car', name: 'Saloon car', kind: 'vehicle', roof: '#222427', roofAlt: '#686e7a', wall: '#17171b', wallAlt: '#292e32', accent: '#2e3439', ratio: 1.06 },
  { id: 'suv', name: 'SUV', kind: 'vehicle', roof: '#83838d', roofAlt: '#ebe8e9', wall: '#f1eded', wallAlt: '#797983', accent: '#898995', ratio: 1.5 },
  { id: 'hatchback', name: 'Hatchback', kind: 'vehicle', roof: '#6989af', roofAlt: '#41668d', wall: '#6a8db5', wallAlt: '#86a8cc', accent: '#426d99', ratio: 1.43 },
  { id: 'sports-car', name: 'Sports car', kind: 'vehicle', roof: '#ca272b', roofAlt: '#9c2a2f', wall: '#eb3238', wallAlt: '#ae282d', accent: '#df2429', ratio: 1.61 },
  { id: 'electric-car', name: 'Electric car', kind: 'vehicle', roof: '#9ba27e', roofAlt: '#80866d', wall: '#9ba475', wallAlt: '#adb587', accent: '#7a8058', ratio: 1.35 },
  { id: 'van', name: 'Van', kind: 'vehicle', roof: '#83868d', roofAlt: '#eee7e8', wall: '#868790', wallAlt: '#f6f5f4', accent: '#7c7c88', ratio: 1.2 },
  { id: 'lorry', name: 'Lorry', kind: 'vehicle', roof: '#e4dddc', roofAlt: '#b1acae', wall: '#b5b1b3', wallAlt: '#aca6a9', accent: '#8a807d', ratio: 1.9 },
  { id: 'articulated-lorry', name: 'Articulated lorry', kind: 'vehicle', roof: '#d9d2d1', roofAlt: '#a6a2a6', wall: '#9b9598', wallAlt: '#d5cac6', accent: '#605351', ratio: 1.74 },
  { id: 'scooter', name: 'Scooter', kind: 'vehicle', roof: '#5e6364', roofAlt: '#7d7d83', wall: '#7b7b7f', wallAlt: '#76747b', accent: '#bfc2a0', ratio: 1.44 },
  { id: 'bicycle', name: 'Bicycle', kind: 'vehicle', roof: '#25262b', roofAlt: '#696766', wall: '#292c2e', wallAlt: '#1c1c20', accent: '#202026', ratio: 1.0 },
  { id: 'street-light', name: 'Street light', kind: 'street', roof: '#7d7266', roofAlt: '#272c30', wall: '#8e887d', wallAlt: '#1f252a', accent: '#e2c89f', ratio: 0.57 },
  { id: 'traffic-light', name: 'Traffic light', kind: 'street', roof: '#2b252b', roofAlt: '#a9a39e', wall: '#303334', wallAlt: '#1a171c', accent: '#9a5d55', ratio: 1.27 },
  { id: 'bus-stop', name: 'Bus stop', kind: 'street', roof: '#8b8d9a', roofAlt: '#787c89', wall: '#baa496', wallAlt: '#ac9589', accent: '#b59b8d', ratio: 0.84 },
  { id: 'litter-bin', name: 'Litter bin', kind: 'street', roof: '#828d96', roofAlt: '#74808b', wall: '#b9a598', wallAlt: '#978d89', accent: '#e8ceb4', ratio: 0.84 },
  { id: 'bench', name: 'Bench', kind: 'street', roof: '#7e767a', roofAlt: '#a39ea0', wall: '#756e6e', wallAlt: '#7d7574', accent: '#b6a396', ratio: 0.53 },
  { id: 'railings', name: 'Railings', kind: 'street', roof: '#6f6d6b', roofAlt: '#999591', wall: '#696866', wallAlt: '#908984', accent: '#bcb2ab', ratio: 1.26 },
  { id: 'hedge', name: 'Hedge', kind: 'street', roof: '#819131', roofAlt: '#91a33c', wall: '#6c7d27', wallAlt: '#7a8c2d', accent: '#748623', ratio: 1.59 },
  { id: 'bench-2', name: 'Bench', kind: 'street', roof: '#8e5e43', roofAlt: '#ae7c57', wall: '#eec399', wallAlt: '#8c5a3f', accent: '#9a6041', ratio: 1.45 },
  { id: 'planter', name: 'Planter', kind: 'street', roof: '#746b22', roofAlt: '#9a8c37', wall: '#b5977e', wallAlt: '#ceb29c', accent: '#807620', ratio: 1.7 },
  { id: 'solar-panel', name: 'Solar panel', kind: 'street', roof: '#384d78', roofAlt: '#4a5f87', wall: '#3a5179', wallAlt: '#4e6389', accent: '#3a5384', ratio: 1.14 },
  { id: 'oak', name: 'Oak', kind: 'nature', roof: '#7d8a2b', roofAlt: '#65711e', wall: '#5f6c1f', wallAlt: '#828e31', accent: '#6f7e1c', ratio: 1.37 },
  { id: 'beech', name: 'Beech', kind: 'nature', roof: '#808d2e', roofAlt: '#657221', wall: '#5f6f1f', wallAlt: '#748328', accent: '#6f7f1f', ratio: 0.88 },
  { id: 'pine', name: 'Pine', kind: 'nature', roof: '#2e3e17', roofAlt: '#66732e', wall: '#1c2c0e', wallAlt: '#344519', accent: '#354818', ratio: 1.32 },
  { id: 'birch', name: 'Birch', kind: 'nature', roof: '#8a8d3a', roofAlt: '#9ea145', wall: '#818339', wallAlt: '#8f9244', accent: '#7e822e', ratio: 1.78 },
  { id: 'palm', name: 'Palm', kind: 'nature', roof: '#93992d', roofAlt: '#6f7722', wall: '#8f733c', wallAlt: '#a78552', accent: '#7a831f', ratio: 0.82 },
  { id: 'rocks', name: 'Rocks', kind: 'nature', roof: '#a08c7e', roofAlt: '#c0ae9c', wall: '#78695b', wallAlt: '#978771', accent: '#94983a', ratio: 1.27 },
  { id: 'shrubs', name: 'Shrubs', kind: 'nature', roof: '#696f20', roofAlt: '#86872b', wall: '#7d8224', wallAlt: '#9c9a30', accent: '#ffa92c', ratio: 2.48 },
  { id: 'flowers', name: 'Flowers', kind: 'nature', roof: '#aa8423', roofAlt: '#876214', wall: '#756717', wallAlt: '#858b24', accent: '#bd8a07', ratio: 2.5 },
  { id: 'grass', name: 'Grass', kind: 'nature', roof: '#859628', roofAlt: '#92a531', wall: '#7a8b24', wallAlt: '#86982a', accent: '#80911d', ratio: 1.47 },
  { id: 'pond', name: 'Pond', kind: 'nature', roof: '#235e78', roofAlt: '#2d6e8a', wall: '#1f5b74', wallAlt: '#266780', accent: '#1c6481', ratio: 1.44 },
];

const BY_ID = new Map(ATLAS.map((a) => [a.id, a]));
const BY_KIND = new Map<AssetKind, AtlasAsset[]>();
for (const a of ATLAS) {
  const list = BY_KIND.get(a.kind);
  if (list) list.push(a);
  else BY_KIND.set(a.kind, [a]);
}

export function asset(id: string): AtlasAsset {
  const found = BY_ID.get(id);
  if (!found) throw new Error('Unknown asset: ' + id);
  return found;
}

