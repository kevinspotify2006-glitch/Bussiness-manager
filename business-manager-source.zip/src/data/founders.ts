import type { FounderSkillId, FounderSkills } from '../sim/types';

/**
 * The person running the company.
 *
 * The player was an invisible pair of hands: every decision cost the same and
 * landed the same whoever was making it. These seven skills are the difference
 * between one owner and another — what they are good at when they start, and
 * what they get better at by doing it.
 *
 * Every one of them is read somewhere in the simulation. There is no skill here
 * that only prints on a profile page.
 */

export interface FounderSkillDef {
  id: FounderSkillId;
  name: string;
  /** What it is, in the player's words. */
  detail: string;
  /** What it does, in the same words the effect works in. */
  says: string;
}

export const FOUNDER_SKILLS: FounderSkillDef[] = [
  {
    id: 'management',
    name: 'Management',
    detail: 'Holding more than one thing in your head at once.',
    says: 'You can keep an eye on more locations before any of them starts drifting',
  },
  {
    id: 'finance',
    name: 'Finance',
    detail: 'Reading a balance sheet, and knowing what a bank will say before you ask.',
    says: 'Lenders quote you a better rate and lend you more against the same assets',
  },
  {
    id: 'sales',
    name: 'Sales',
    detail: 'Knowing why people buy, and what makes them come back.',
    says: 'Every euro of marketing spend buys more awareness',
  },
  {
    id: 'operations',
    name: 'Operations',
    detail: 'Making the same work take less doing.',
    says: 'Coordination costs less at every location you run',
  },
  {
    id: 'strategy',
    name: 'Strategy',
    detail: 'Seeing the move after this one.',
    says: 'Research finishes sooner',
  },
  {
    id: 'leadership',
    name: 'Leadership',
    detail: 'People work harder for some owners than others.',
    says: 'Everybody on the payroll settles at a higher morale',
  },
  {
    id: 'negotiation',
    name: 'Negotiation',
    detail: 'Asking for a better price without souring the room.',
    says: 'Suppliers charge you less and sellers accept less for their business',
  },
];

export const FOUNDER_SKILL_IDS: FounderSkillId[] = FOUNDER_SKILLS.map((s) => s.id);

export function founderSkill(id: FounderSkillId): FounderSkillDef {
  const found = FOUNDER_SKILLS.find((s) => s.id === id);
  if (!found) throw new Error(`Unknown founder skill: ${id}`);
  return found;
}

/**
 * What you did before this.
 *
 * A starting specialisation is not a bonus bolted onto the side — it is where
 * your seven skills begin. Somebody who came out of a bank starts a long way
 * ahead on finance and a long way behind on the shop floor, and will play a
 * different game because of it: cheaper money, and a harder first year of
 * actually running the place.
 */
export interface FounderTraitDef {
  id: string;
  name: string;
  /** What they did before, in one line. */
  detail: string;
  /** How the game plays differently. */
  plays: string;
  /** Where each skill starts, 0..100. Anything unlisted starts at the base. */
  skills: Partial<Record<FounderSkillId, number>>;
}

/** What every founder starts at in a skill their background does not cover. */
export const FOUNDER_BASE = 30;

export const FOUNDER_TRAITS: FounderTraitDef[] = [
  {
    id: 'financier',
    name: 'Financial expert',
    detail: 'Fifteen years on the other side of the lending desk.',
    plays: 'Money is cheap and plentiful. Running the place is the part you have to learn.',
    skills: { finance: 72, strategy: 46, negotiation: 44, operations: 20, sales: 18 },
  },
  {
    id: 'seller',
    name: 'Sales expert',
    detail: 'You have sold everything from windows to advertising, and enjoyed it.',
    plays: 'Customers come. Keeping the books straight and the team steady is where it gets hard.',
    skills: { sales: 72, negotiation: 52, leadership: 40, finance: 18, operations: 22 },
  },
  {
    id: 'operator',
    name: 'Operations expert',
    detail: 'You ran somebody else’s floor for a decade and knew where every minute went.',
    plays: 'The place runs beautifully and cheaply. Getting anybody through the door is the problem.',
    skills: { operations: 72, management: 50, leadership: 44, sales: 18, finance: 22 },
  },
  {
    id: 'strategist',
    name: 'Strategist',
    detail: 'Consulting. You are very good at knowing what a business should do.',
    plays: 'You see further than anybody. Doing it is a different skill from seeing it.',
    skills: { strategy: 72, management: 52, finance: 44, operations: 22, leadership: 22 },
  },
  {
    id: 'shopfloor',
    name: 'Up from the floor',
    detail: 'You did the job itself for years, and everybody knows it.',
    plays: 'Your people would follow you anywhere. The bank has never heard of you.',
    skills: { leadership: 70, operations: 52, management: 42, finance: 16, strategy: 22 },
  },
  {
    id: 'allrounder',
    name: 'All-rounder',
    detail: 'A bit of everything, nothing in particular.',
    plays: 'No advantage anywhere, and no hole anywhere either.',
    skills: { management: 42, finance: 42, sales: 42, operations: 42, strategy: 42, leadership: 42, negotiation: 42 },
  },
];

export function founderTrait(id: string): FounderTraitDef {
  return FOUNDER_TRAITS.find((t) => t.id === id) ?? FOUNDER_TRAITS[FOUNDER_TRAITS.length - 1];
}

/** The skill profile a background starts you on. */
export function startingSkills(traitId: string): FounderSkills {
  const trait = founderTrait(traitId);
  const skills = {} as FounderSkills;
  for (const id of FOUNDER_SKILL_IDS) skills[id] = trait.skills[id] ?? FOUNDER_BASE;
  return skills;
}
