# Business Manager

A browser-based business empire simulator set in Northgate, a fictional city of
about 640,000 people. You are the owner, not a character on a map: everything
happens through the management interface.

Start with limited capital, find premises, open a business, stock it, staff it,
price it, and try to still be trading next month. Competitors are already in the
city and react to what you do.

## Running it

```bash
npm install
npm run dev        # development server
npm run typecheck  # TypeScript, strict
npm run build      # type check + production build
```

## What is implemented

**City.** Northgate is generated from a fixed seed, so every player walks the
same streets. Fifteen economically distinct districts with population, density,
income, age mix, foot traffic, tourism, rent and property levels — and a real
street network underneath them: arterial roads along the district boundaries,
two diagonal avenues, local streets and back lanes, blocks subdivided into
frontages, and a railway that comes in from the north into the transport hub
before running east–west across the city. There is a harbour on the waterfront,
a runway with taxiways and hangars at the airport, parks with pitches and trees,
plazas with fountains, car parks, and farmland beyond the ring road.

Districts are built the way they would really be built: towers downtown,
brick terraces in midtown, detached houses and gardens in the suburbs, sheds
and yards in the industrial districts, tight lanes in the tourist quarter. Every
unit the game trades in is a frontage on one of those streets, and what it faces
— a main road, a side street, or the service road behind the shops — is most of
what its rent and its passing trade are made of.

The map is drawn in code at device pixel density, so it stays sharp at any zoom,
and it adds detail as you come in: roads and blocks, then pavements, roof lines
and lane markings, then trees, crossings, bus stops and street names. It carries
seven overlays: commercial, demand, income, competition, property value and foot
traffic.

**Demand.** Nothing is rolled at random. Each hour, every district produces a
pool of customers per business type, shaped by population, demographics, the
hour of the day, the day of the week, the season, consumer confidence and any
city event running. The businesses competing for that pool split it according to
how attractive each one is: location, price against local incomes, product
quality, service, reputation, awareness, premises and size. Outlets the game
does not simulate individually compete as a background market, which is what
stops one corner shop from being handed a whole district's trade.

Because share is computed rather than assigned, a competitor cutting prices
shows up directly as a fall in your sales — and the business panel breaks your
pull apart factor by factor so you can see exactly where you are losing.

**Customers.** That pool is not one undifferentiated crowd. It is split into
students, families, professionals, retirees and visitors, in proportions read
from each district's own age mix, income and tourism. They are out at different
hours, they weigh price, quality and service differently, and they spend
differently: a student basket is worth a fraction of a professional's. So each
group chooses between the shops on its own terms, and a business's takings
depend on which of them it actually attracted.

The weights are normalised against the city, so segments move demand around
rather than adding or removing any: the average Northgate customer is exactly
the neutral customer the economy was balanced against. What changes is that the
average is no longer evenly spread. The University District really is "huge
crowds, tiny budgets" now, and the Financial District really is the opposite.
Each business shows who came through its door against who lives in the
district, so under-trading with a group you should be winning is visible.

**Businesses.** Twenty types across retail, food, services and specialised
trades, all data-driven. Each has its own space requirement, fit-out cost,
product range, staffing profile, throughput per employee, opening hours and
price sensitivity. Adding a new type needs no code.

**Employees.** Skill, experience, productivity, reliability, morale, stress,
loyalty and ten personality traits that change how people perform. Pay below the
market rate and morale falls; work a team too hard and stress climbs; let it run
and people resign. Training raises skill with diminishing returns. Staff decide
how many customers you can serve in an hour and how good the experience is —
which feeds reviews, which feed demand.

They also have a working life. Stress and low morale make people call in sick
for a few days, still on the payroll and not on the floor. There are two rungs
of promotion — senior in their own trade, then store manager — gated on skill,
service and how recently they were recognised. A bonus buys morale now and
changes nothing structurally. Ambitious people who go two months without a
promotion or a rise lose heart, and the game says so before they walk. A
difficult colleague on a bad day takes the whole shift's morale down with them.

**Inventory and procurement.** Six suppliers differing in price, lead time,
reliability, quality, minimum order and volume discounts. The cheapest is never
the best. Stock has weight and volume, storage is finite, perishables spoil, and
anything that will not fit on arrival is credited back. Automatic reordering
plans an order against storage, cash and the supplier's minimum order together.

**Distribution.** Take on a unit with real storage, rack it out, and it becomes
a distribution centre: you buy in bulk at one delivery charge instead of six,
and your own van restocks the shops overnight with no lead time and no minimum
order per shop. What it costs is rent, wages, drivers — each one adds four runs
a night — and the cash tied up in stock on a rack rather than on a shelf. Its
cold store slows spoilage down but does not stop it, so fresh goods are still
the wrong thing to hold in volume. Shops stop ordering from suppliers whatever
their own warehouse is holding. With one shop it is a waste of money; at about
three locations it stops being one, and the advisor says so either way.

**Competitors.** Ten AI companies with seven strategic personalities occupy real
buildings, pay real rent and take real share out of the same demand pools. They
watch their own results and the going rate in their district — not your books —
and adjust prices, marketing and expansion accordingly. They open outlets where
money is being made and close ones that keep losing it.

**Money.** Every euro passes through one posting function, so the ledger is
complete and the finance screen is trustworthy. Buying stock is a balance-sheet
movement; cost of goods sold is booked as a non-cash expense when the goods are
sold. Loans have credit requirements, interest and monthly payments; missing one
damages your rating. Corporation tax is charged monthly on profit. Bankruptcy is
possible, and the game tells you which businesses caused it.

**Marketing.** Seven channels that differ in who they reach, not just what they
cost. Awareness saturates as it rises and decays when you stop spending, so an
influencer campaign in a student district is money well spent and the same
campaign in a retirement suburb is not.

**Management accounts.** The books are closed at the end of every month from
running totals accumulated as the money moves, not from the ledger — the ledger
is trimmed to keep the finance screen quick, and a set of accounts that quietly
lost the first week of the month would be worse than none. Each month files a
profit and loss account down to net profit, a balance sheet at the close, the
figures that actually moved against last month largest first, and what each
location contributed. A lease deposit is booked as money held rather than money
spent, so signing a lease no longer looks like a loss.

**Reports.** What happened, why it moved, and what you could do about it —
category-by-category comparison against the previous day, cost structure as a
share of revenue, and specific advice drawn from the same numbers the simulation
used.

**The advisor.** The dashboard's "What to do next" panel reads the same figures
the demand model uses and names the single biggest thing holding each business
back, with the number that proves it and a link to the screen that fixes it:
cash runway, loss streaks with the largest cost named, dead pitches, shops
nobody has heard of, stock-outs, turn-aways, pricing against local rivals, thin
margins, unaffordable rent, unhappy or absent staff, and whatever customers are
complaining about most.

**Newsroom.** The city reports itself. Economy shifts, competitor moves,
supplier failures, staff events, weekly trading summaries and monthly accounts,
filtered by category, each item linked to the business it concerns.

**Decisions.** Eight recurring situations that stop the clock and ask: a rival
poaching your best employee, a supplier offering preferred terms, a rent review,
a press feature, clearance stock, a price war, a pay demand, a prime unit coming
free. Every option changes real state and the cost is spelled out before you
choose. Ignoring one still resolves it, usually not in your favour.

**Reviews.** Customers write reviews with text, and what they complain about is
whichever of price, service, availability, product quality or the state of the
premises was actually worst that day.

**Goals.** Time-limited targets generated from what your company looks like
today — lift a shop's reviews, serve more customers, take share in a district,
clear a week in profit, open a second site, build a cash reserve, get a team
back on side. Progress is measured from where the figure stood when the goal was
set, and finishing one pays: a trade association grant, a supplier signing you
as their flagship stockist, a bank refunding fees, a better credit rating.

**Market.** How big your market really is, what share of it you hold, which
rivals hold the rest, and every competitor company's strategy, cash, reach and
price level.

**Acquisitions.** Buy a rival outright. The valuation is built from goodwill
(a multiple of the last thirty days of profit), the fittings depreciated by age,
the stock at cost and the lease or freehold, and it is shown to you before you
name a figure. Sellers have a reserve that follows their personality and their
own trading: an owner losing money will take less, one doing well holds out, and
a refusal closes the conversation for three weeks. What transfers is everything
— lease, fittings, stock and the team, who arrive wary of a new owner.

Plus real estate (rent, buy, renovate, sell), thirteen achievements, seven
progression tiers, an optional tutorial that reads live state rather than
scripting you, and save/load/rename/delete with autosave.

## Not yet built

Deliberately absent rather than faked: holding-company structures above the
single company, contracts, research and technology, automatic pricing and
scheduling, and a sandbox mode. No button in the interface leads to a system
that does not exist.

## Architecture

```
src/
  sim/     simulation — no file here imports any UI module
  data/    static content: districts, business types, products, suppliers,
           roles, marketing channels, city events
  ui/      application shell, city map renderer, views
tools/     simulate.ts — headless balance harness
           sanity.ts   — economic invariants, run in CI
```

The simulation runs on a fixed hourly tick. Crossing midnight settles the day
(wages, rent, reviews, reputation, spoilage, economy); day 1 of a week runs
competitor strategy; day 1 of a month runs loans and tax. The same code path
runs at every speed, so 8× produces exactly the same result as 1×.

## Sanity checks

```bash
npx tsx tools/sanity.ts
```

Sixty-three assertions about the economy, run from fixed seeds so they cannot
flake, and wired into CI. No NaN or Infinity anywhere in the state after 200
days; a well-run shop trades profitably and a badly placed, overpriced one does
not; cutting prices brings more customers and raising them does not; a fuller
team can serve more people per hour; competitors trade, earn and price
differently from each other; bankruptcy is reachable; an empty shop earns
nothing and still pays rent; a team held at breaking point falls ill and
recovers; goals ask for more than they started with; and a lowball offer for a
rival is refused, costs nothing, and closes the conversation, while a generous
one transfers the business, its premises, its stock and its staff.

## Browser tests

```bash
npm run build && npm run preview
npx playwright install chromium
node tools/browser-qa.mjs      # every screen, desktop and phone
node tools/playthrough.mjs     # a full game, played through the interface
```

Both drive the real interface in a real browser and fail on console errors,
NaN or Infinity on screen, horizontal overflow, screens that render nearly
blank, and dialogs that stack. They found the decision dialogs that piled up on
top of each other, the toast that widened the mobile layout viewport, the
double-tap that zoomed the whole interface on a phone, and the property list
that opened on the forty deadest pitches in the city.

## Balance harness

```bash
npx tsx tools/simulate.ts [days] [businessType] [cheap|best] [staff] [marketing]
```

Runs the simulation without a browser, playing an average opening and printing
the daily profit and loss, a ledger breakdown and the alerts raised. It is how
the economy is checked: it found the double-counted cost of goods, the daily
profit figure that subtracted revenue twice, the automatic reordering that could
never meet a supplier's minimum, and the demand model that offered one shop a
whole district.

A full playthrough is also driven through the interface — rent a unit, open,
advertise, borrow, open a second site, staff it, run five months and try to buy
a rival — sweeping every screen for console errors, broken numbers and layout
overflow along the way. Played sensibly, that game ends around day 160 with two
sites trading, four goals met and cash up from €30k to €87k.

Current results over 90 days, opening on a busy pitch with two staff and modest
marketing, changing nothing afterwards:

| Business          | Profit per day, last 14 days |
| ----------------- | ---------------------------- |
| Convenience store | €197                         |
| Coffee shop       | €508                         |
| Clothing store    | €663                         |
| Repair company    | €417                         |
| Pet store         | €97                          |
| Cleaning company  | €78                          |

The same openings on the cheapest available premises lose money, which is the
point: location is a decision, not a formality.
