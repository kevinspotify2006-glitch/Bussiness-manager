"""Turns the measured atlas into the game's asset table."""
import json, re

P = json.load(open('tools/palettes.json'))

KIND = {
    '01_kantoorgebouwen': 'office',
    '02_winkels_retail': 'retail',
    '03_industrie_productie': 'industry',
    '04_logistiek_opslag': 'logistics',
    '05_diensten': 'civic',
    '06_horeca_vrije_tijd': 'leisure',
    '07_woningen': 'housing',
    '08_energie_infra': 'energy',
    '09_landbouw_natuur': 'farm',
    '10_speciale_gebouwen': 'landmark',
    '11_parken_decoratie': 'park',
    '12_wegen': 'road',
    '13_voertuigen': 'vehicle',
    '14_overig': 'street',
    '15_bos_bomen_omgeving': 'nature',
}

EN = {
    'Kantoor 1': 'Glass office', 'Kantoor 2': 'Courtyard office', 'Kantoor 3': 'Business centre',
    'Kantoor 4': 'Curtain-wall tower', 'Kantoor 5': 'Corner office', 'Kantoor 6': 'Head office',
    'Kantoor 7': 'Rooftop-garden office', 'Kantoor 8': 'Office block', 'Kantoor 9': 'Riverside office',
    'Kantoor 10': 'Chambers',
    'Supermarkt': 'Supermarket', 'Elektronica': 'Electronics store', 'Kledingwinkel': 'Clothing store',
    'Meubels': 'Furniture store', 'Bouwmarkt': 'Builders merchant', 'Sportwinkel': 'Sports shop',
    'Apotheek': 'Pharmacy', 'Tankstation': 'Filling station', 'Showroom': 'Car showroom',
    'Winkelcentrum': 'Shopping centre',
    'Fabriek 1': 'Brick works', 'Fabriek 2': 'Foundry', 'Fabriek 3': 'Assembly plant',
    'Chemie': 'Chemical plant', 'Voedsel': 'Food processing', 'Metaal': 'Steelworks',
    'Textiel': 'Textile mill', 'Automotive': 'Vehicle plant', 'Machinebouw': 'Machine shop',
    'Recycling': 'Recycling centre',
    'Magazijn S': 'Small warehouse', 'Magazijn M': 'Warehouse', 'Magazijn L': 'Large warehouse',
    'Distributiecentrum': 'Distribution centre', 'Koelhuis': 'Cold store',
    'Containerterminal': 'Container terminal', 'Postcentrum': 'Sorting office', 'Overslag': 'Transhipment yard',
    'Bank': 'Bank', 'Ziekenhuis': 'Hospital', 'Brandweer': 'Fire station', 'Politie': 'Police station',
    'School': 'School', 'Universiteit': 'University', 'Gemeentehuis': 'Town hall', 'Rechtbank': 'Courthouse',
    'Restaurant': 'Restaurant', 'Restauarnt': 'Restaurant', 'Café': 'Café', 'Hotel (klein)': 'Small hotel',
    'Hotel (groot)': 'Hotel', 'Bioscoop': 'Cinema', 'Sportschool': 'Gym', 'Zwembad': 'Swimming pool',
    'Pretpark attractie': 'Funfair ride',
    'Rijwoning': 'Terrace', 'Rijwoning ': 'Terrace', '2-onder-1-kap': 'Semi-detached', 'Vrijstaand': 'Detached house',
    'Appartement': 'Apartment block', 'Luxe villa': 'Villa', 'Tiny house': 'Tiny house',
    'Studentenhuis': 'Student house', 'Sociale huur': 'Social housing',
    'Zonnepark': 'Solar farm', 'Windmolen': 'Wind turbine', 'Windmoiens': 'Wind turbine',
    'Gascentrale': 'Gas plant', 'Kerncentrale': 'Nuclear plant', 'Kerocentrale': 'Nuclear plant',
    'Bergsilo/vergisting': 'Storage silos', 'Begrauivering': 'Storage silos', 'Transformator': 'Substation',
    'Laadstation': 'Charging hub', 'Biogasinstallatie': 'Biogas plant',
    'Boerderij': 'Farmhouse', 'Boarderji': 'Farmhouse', 'Kas': 'Glasshouse', 'Kippenstal': 'Poultry shed',
    'Varkensstal': 'Livestock shed', 'Akker': 'Arable field', 'Boomgaard': 'Orchard',
    'Koeienweide': 'Pasture', 'Fruitplantage': 'Fruit plantation',
    'Onderzoekscentrum': 'Research centre', 'Datacenter': 'Data centre', 'Luchthaven': 'Airport',
    'Luchtlvaen': 'Airport', 'Treinstation': 'Station', 'Haven': 'Harbour', 'Stadion': 'Stadium',
    'Evenementenhal': 'Events hall', 'Telecommast': 'Telecom mast', 'Telecomtoren': 'Telecom mast',
    'Stadspark': 'City park', 'Fontein': 'Fountain', 'Speeltuin': 'Playground', 'Dierenweide': 'Petting farm',
    'Begraafplaats': 'Cemetery', 'Standbeeld': 'Statue', 'Marktplein': 'Market square', 'Terras': 'Terrace seating',
    'Weg (recht)': 'Straight road', 'Weg (bocht)': 'Curved road',
    'Weg recht': 'Straight road', 'Weg bocht': 'Curved road', 'Auto sedan': 'Saloon car', 'Kruispunt': 'Crossroads',
    'T-splitsing': 'T-junction', 'Rotonde': 'Roundabout', 'Snelweg': 'Motorway', 'Brug': 'Bridge',
    'Tunnel': 'Tunnel', 'Fietspad': 'Cycle path', 'Voetpad': 'Footpath',
    'Auto (sedan)': 'Saloon car', 'SUV': 'SUV', 'Hatchback': 'Hatchback', 'Sportwagen': 'Sports car',
    'Elektrisch': 'Electric car', 'Bestelbus': 'Van', 'Vrachtwagen': 'Lorry', 'Trailer': 'Articulated lorry',
    'Brommer': 'Scooter', 'Fiets': 'Bicycle',
    'Straatlantaarn': 'Street light', 'Verkeerslicht': 'Traffic light', 'Bushalte': 'Bus stop',
    'Abri': 'Shelter', 'Prullenbak': 'Litter bin', 'Afvalbak': 'Litter bin', 'Proppenbank': 'Bench',
    'Hekwerk': 'Railings', 'Heg': 'Hedge', 'Bankje': 'Bench', 'Bloembak': 'Planter', 'Zonnepaneel': 'Solar panel',
    'Eik': 'Oak', 'Beuk': 'Beech', 'Dennenboom': 'Pine', 'Berk': 'Birch', 'Palmboom': 'Palm',
    'Rotsen': 'Rocks', 'Struiken': 'Shrubs', 'Bloemen': 'Flowers', 'Grasveld': 'Grass', 'Water (vijver)': 'Pond',
}


ACCENTS = str.maketrans('áàâäéèêëíìîïóòôöúùûüç', 'aaaaeeeeiiiioooouuuuc')


def slug(name):
    return re.sub(r'[^a-z0-9]+', '-', name.lower().translate(ACCENTS)).strip('-')


def lift(hx, amount=0.80, sat=1.12):
    r, g, b = (int(hx[i:i + 2], 16) for i in (1, 3, 5))
    out = []
    m = (r + g + b) / 3
    for v in (r, g, b):
        v = 255 * (v / 255) ** amount           # the atlas is lit at dusk; the map is not
        v = m + (v - m) * sat if False else v
        out.append(v)
    m = sum(out) / 3
    out = [max(0, min(255, m + (v - m) * sat)) for v in out]
    return '#%02x%02x%02x' % tuple(int(round(v)) for v in out)


rows = []
seen = set()
for r in P:
    kind = KIND[r['category']]
    label = EN.get(r['name'].strip(), r['name'])
    sid = slug(label)
    if sid in seen:
        n = 2
        while f'{sid}-{n}' in seen:
            n += 1
        sid = f'{sid}-{n}'
    seen.add(sid)
    rows.append({
        'id': sid, 'name': label, 'kind': kind,
        'roof': lift(r['roof']), 'roofAlt': lift(r['roofAlt']),
        'wall': lift(r['wall']), 'wallAlt': lift(r['wallAlt']),
        'accent': lift(r['accent'], 0.74, 1.3),
        'ratio': r['ratio'],
    })

body = ',\n'.join(
    "  { id: '%s', name: '%s', kind: '%s', roof: '%s', roofAlt: '%s', wall: '%s', wallAlt: '%s', accent: '%s', ratio: %s }"
    % (r['id'], r['name'].replace("'", "\\'"), r['kind'], r['roof'], r['roofAlt'], r['wall'], r['wallAlt'], r['accent'], r['ratio'])
    for r in rows
)

kinds = sorted({r['kind'] for r in rows})
ts = '''/**
 * The asset pack, measured.
 *
 * `BM_Asset_Atlas_100.png` is a contact sheet: 134 labelled isometric renders on
 * dark panels, with captions. It cannot be blitted onto a top-down city map, and
 * the pack's own notes say to extract or recreate its assets to suit the
 * renderer. So each cell was isolated, its background and drop shadow eroded
 * away, and the building inside it measured: the colour of its roof, its walls,
 * and the one accent that makes it recognisable — a filling station's red
 * canopy, a bank's blue stone, the deep blue of a solar farm. Those measurements
 * are this table, and `src/ui/sprites.ts` draws each asset from them.
 *
 * Generated from the pack; edit the generator, not this file.
 */

export type AssetKind =
%s;

export interface AtlasAsset {
  id: string;
  name: string;
  kind: AssetKind;
  /** Seen from above: the roof. */
  roof: string;
  roofAlt: string;
  /** Seen from the side: the elevation. */
  wall: string;
  wallAlt: string;
  /** The colour that makes it recognisable at a glance. */
  accent: string;
  /** Width over depth as it stands in the pack. */
  ratio: number;
}

export const ATLAS: AtlasAsset[] = [
%s,
];

const BY_ID = new Map(ATLAS.map((a) => [a.id, a]));
const BY_KIND = new Map<AssetKind, AtlasAsset[]>();
for (const a of ATLAS) {
  const list = BY_KIND.get(a.kind);
  if (list) list.push(a);
  else BY_KIND.set(a.kind, [a]);
}

export function asset(id: string): AtlasAsset {
  const found = BY_ID.get(id);
  if (!found) throw new Error('Unknown asset: ' + id);
  return found;
}

export function assetsOf(kind: AssetKind): AtlasAsset[] {
  return BY_KIND.get(kind) ?? [];
}
''' % ('\n'.join("  | '%s'" % k for k in kinds), body)

open('src/data/atlas.ts', 'w').write(ts)
print(len(rows), 'assets written')
print(sorted({r['kind'] for r in rows}))
