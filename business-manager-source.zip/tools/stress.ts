/**
 * A thousand ticks, and nothing allowed to drift.
 *
 * The systems added in 3.0 all keep running state — a sales ledger, a purchase
 * ledger, a tax reserve, five standing facets, a relationship graph — and every
 * one of those is a place where a slow leak can hide for a hundred days before
 * it matters. This runs the simulation for roughly three game years and asserts,
 * every hundred days, that none of it has come loose.
 *
 * Run with:  npx tsx tools/stress.ts
 */
import { startGame } from '../src/sim/scenario';
import { Engine } from '../src/sim/engine';
import { playerBusinesses, playerCompany } from '../src/sim/state';
import { netWorth, receivablesValue, payablesValue } from '../src/sim/finance';
import { workingCapital } from '../src/sim/workingCapital';
import { STANDING_FACETS, standingOf } from '../src/sim/standing';
import { MAX_BONDS, bondsOf } from '../src/sim/relationships';
import { sum } from '../src/sim/util';
import type { GameState } from '../src/sim/state';

const problems: string[] = [];
const fail = (message: string): void => { problems.push(message); };

function audit(state: GameState, day: number): void {
  const where = `day ${day}`;

  // Nothing anywhere may become NaN or Infinity.
  const walk = (value: unknown, path: string, depth = 0): void => {
    if (depth > 6 || value === null || value === undefined) return;
    if (typeof value === 'number') {
      if (!Number.isFinite(value)) fail(`${where}: ${path} is ${value}`);
      return;
    }
    if (Array.isArray(value)) {
      value.slice(0, 40).forEach((item, i) => walk(item, `${path}[${i}]`, depth + 1));
      return;
    }
    if (typeof value === 'object') {
      for (const [key, item] of Object.entries(value as Record<string, unknown>)) {
        if (key === 'buildings' || key === 'ledger' || key === 'news' || key === 'reviews') continue;
        walk(item, `${path}.${key}`, depth + 1);
      }
    }
  };
  walk(state.companies, 'companies');
  walk(state.employees.slice(0, 30), 'employees');
  walk(state.invoices, 'invoices');
  walk(state.bills, 'bills');
  walk(state.standing, 'standing');
  walk(state.loans, 'loans');

  // The balance sheet must still add up out of its own parts.
  const wc = workingCapital(state);
  if (Math.abs(receivablesValue(state) - (wc.receivables + wc.overdue)) > 1) {
    fail(`${where}: receivables disagree — ${receivablesValue(state)} vs ${wc.receivables + wc.overdue}`);
  }
  if (Math.abs(payablesValue(state) - (wc.payables + wc.arrears + wc.taxDue)) > 1) {
    fail(`${where}: payables disagree — ${payablesValue(state)} vs ${wc.payables + wc.arrears + wc.taxDue}`);
  }

  // The ledgers must not grow without bound — a leak here is invisible until
  // it is a hundred thousand rows.
  if (state.invoices.length > 400) fail(`${where}: the sales ledger has ${state.invoices.length} rows`);
  if (state.bills.length > 400) fail(`${where}: the purchase ledger has ${state.bills.length} rows`);
  if (state.ledger.length > 600) fail(`${where}: the ledger is over its cap at ${state.ledger.length}`);
  if (state.dayHistory.length > 365) fail(`${where}: day history is over its cap at ${state.dayHistory.length}`);

  // No invoice or bill may sit unresolved for ever.
  const ancient = state.invoices.filter((i) => day - i.raisedOnDay > 400);
  if (ancient.length > 0) fail(`${where}: ${ancient.length} invoices older than 400 days`);

  // Standing stays inside its bounds.
  for (const facet of STANDING_FACETS) {
    const value = standingOf(state)[facet.id];
    if (value < 0 || value > 100) fail(`${where}: standing.${facet.id} is ${value}`);
  }

  // Relationships stay bounded, mutual and pointed at people who exist.
  const ids = new Set(state.employees.map((e) => e.id));
  for (const person of state.employees) {
    const bonds = bondsOf(person);
    if (bonds.length > MAX_BONDS) fail(`${where}: ${person.name} has ${bonds.length} relationships`);
    for (const bond of bonds) {
      if (!ids.has(bond.withId)) fail(`${where}: ${person.name} has a relationship with somebody who has left`);
      if (bond.withId === person.id) fail(`${where}: ${person.name} has a relationship with themselves`);
      if (bond.strength < -100 || bond.strength > 100) fail(`${where}: bond strength ${bond.strength}`);
    }
  }

  // Stock and cash must remain real numbers a human could believe.
  for (const business of playerBusinesses(state)) {
    for (const [productId, units] of Object.entries(business.stock)) {
      if (units < 0) fail(`${where}: ${business.name} has ${units} of ${productId}`);
    }
  }
  if (!Number.isFinite(netWorth(state))) fail(`${where}: net worth is not a number`);
}

const state = startGame({
  companyName: 'Meridian Group', founderName: 'K', traitId: 'allrounder', scenarioId: 'established', seed: 90210,
});
const engine = new Engine(state);
const started = Date.now();
let peakEmployees = 0;

for (let day = 0; day < 1000; day += 1) {
  for (let hour = 0; hour < 24; hour += 1) engine.stepHour();
  peakEmployees = Math.max(peakEmployees, state.employees.length);
  if (state.day % 100 === 0) audit(state, state.day);
}
audit(state, state.day);

const elapsed = Date.now() - started;
const company = playerCompany(state);
const wc = workingCapital(state);
console.log(`1000 days simulated in ${(elapsed / 1000).toFixed(1)}s (${(elapsed / 1000).toFixed(2)}ms a day)`);
console.log(`  cash ${Math.round(company.cash)} · net worth ${Math.round(netWorth(state))} · rating ${Math.round(company.creditRating)}`);
console.log(`  sales ledger ${state.invoices.length} rows (${Math.round(wc.receivables + wc.overdue)}) · purchase ledger ${state.bills.length} rows`);
console.log(`  ledger ${state.ledger.length} rows · day history ${state.dayHistory.length} · news ${state.news.length}`);
console.log(`  people ${state.employees.length} (peak ${peakEmployees}) · relationships ${sum(state.employees, (e) => bondsOf(e).length)}`);
console.log(`  standing ${STANDING_FACETS.map((f) => `${f.id[0]}${Math.round(standingOf(state)[f.id])}`).join(' ')}`);

console.log('');
if (problems.length === 0) {
  console.log('STRESS TEST CLEAN — nothing drifted over 1000 days');
} else {
  for (const problem of problems.slice(0, 20)) console.log(`  FAIL  ${problem}`);
  console.log(`${problems.length} problems`);
  process.exit(1);
}
