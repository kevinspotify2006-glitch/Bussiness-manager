"""
Reads the asset pack atlas, isolates each labelled cell, and measures the asset
inside it: the colour of its roof, its walls and its strongest accent, plus how
tall and wide it stands. The atlas itself never reaches the game — these
measurements do, so the city is drawn in the pack's own colours.
"""
from PIL import Image
import numpy as np
import json

ATLAS = 'assets/BM_Asset_Atlas_100.png'
im = Image.open(ATLAS).convert('RGB')
A = np.asarray(im).astype(float)

MANIFEST = json.load(open('assets/asset_manifest.json'))
CATS = MANIFEST['categories']

PANELS = [
    ('01_kantoorgebouwen', 8, 492, [(36, 130), (152, 254)], 5),
    ('02_winkels_retail', 502, 1020, [(36, 130), (152, 254)], 5),
    ('03_industrie_productie', 1030, 1526, [(36, 130), (152, 254)], 5),
    ('04_logistiek_opslag', 8, 386, [(322, 432), (438, 532)], 4),
    ('05_diensten', 392, 770, [(322, 432), (438, 532)], 4),
    ('06_horeca_vrije_tijd', 776, 1150, [(322, 432), (438, 532)], 4),
    ('07_woningen', 1156, 1528, [(322, 432), (438, 532)], 4),
    ('08_energie_infra', 8, 386, [(598, 692), (700, 772)], 4),
    ('09_landbouw_natuur', 392, 770, [(598, 692), (700, 772)], 4),
    ('10_speciale_gebouwen', 776, 1150, [(598, 692), (700, 772)], 4),
    ('11_parken_decoratie', 1156, 1528, [(598, 692), (700, 772)], 4),
    ('12_wegen', 8, 386, [(828, 896), (906, 962)], 5),
    ('13_voertuigen', 392, 770, [(828, 896), (906, 962)], 5),
    ('14_overig', 776, 1150, [(828, 896), (906, 962)], 5),
    ('15_bos_bomen_omgeving', 1156, 1528, [(828, 896), (906, 962)], 5),
]


def kmeans(points, k, iters=14):
    """Small deterministic k-means; the pack has few colours per asset."""
    if len(points) <= k:
        return points, np.ones(len(points))
    order = np.argsort(points.sum(1))
    seeds = points[order[np.linspace(0, len(points) - 1, k).astype(int)]].copy()
    for _ in range(iters):
        d = ((points[:, None, :] - seeds[None, :, :]) ** 2).sum(2)
        who = d.argmin(1)
        for i in range(k):
            hit = points[who == i]
            if len(hit):
                seeds[i] = hit.mean(0)
    counts = np.array([(who == i).sum() for i in range(k)], dtype=float)
    return seeds, counts


def hexof(c):
    return '#%02x%02x%02x' % tuple(int(max(0, min(255, round(v)))) for v in c)


out = []
for cat, x0, x1, bands, cols in PANELS:
    names = CATS[cat]
    w = (x1 - x0) / cols
    for r, (y0, y1) in enumerate(bands):
        for c in range(cols):
            index = r * cols + c
            if index >= len(names):
                continue
            a, b = int(x0 + c * w), int(x0 + (c + 1) * w)
            cell = A[y0:y1, a:b]
            h, wd = cell.shape[:2]
            # The panel background is whatever fills the cell's outer border.
            border = np.concatenate([
                cell[:3].reshape(-1, 3), cell[-3:].reshape(-1, 3),
                cell[:, :3].reshape(-1, 3), cell[:, -3:].reshape(-1, 3),
            ])
            bg = np.median(border, 0)
            dist = np.sqrt(((cell - bg) ** 2).sum(2))
            mask = dist > 30
            # Drop the label strip at the bottom: light text on the panel.
            mask[int(h * 0.88):] = False
            if mask.sum() < 80:
                mask = dist > 18
                mask[int(h * 0.88):] = False
            # Pull the mask in by two pixels so half-background edge pixels and
            # the drop shadow underneath the asset never colour the result.
            inner = mask.copy()
            for dy in (-2, -1, 1, 2):
                inner &= np.roll(mask, dy, 0)
            for dx in (-2, -1, 1, 2):
                inner &= np.roll(mask, dx, 1)
            lum = cell.mean(2)
            inner &= lum > 52
            if inner.sum() > 120:
                mask = inner
            ys, xs = np.nonzero(mask)
            if len(ys) < 40:
                continue
            top, bot = ys.min(), ys.max()
            left, right = xs.min(), xs.max()
            span = max(1, bot - top)
            # Isometric assets: the upper third reads as roof, the lower half as
            # the elevation you see from the side.
            roofband = mask.copy()
            roofband[top + int(span * 0.45):] = False
            wallband = mask.copy()
            wallband[:top + int(span * 0.45)] = False
            wallband[top + int(span * 0.9):] = False

            def pick(sel, k=3):
                pts = cell[sel]
                if len(pts) < 12:
                    return None
                seeds, counts = kmeans(pts, min(k, len(pts)))
                order = np.argsort(-counts)
                return [hexof(seeds[i]) for i in order]

            roof = pick(roofband) or ['#8d9299']
            wall = pick(wallband, 4) or roof
            # The accent is the most saturated colour the building itself uses.
            # Foliage is excluded: every cell in the pack is landscaped, and a
            # tree is not a fact about the building.
            def rgb(hx):
                return [int(hx[i:i + 2], 16) for i in (1, 3, 5)]
            def sat(hx):
                v = rgb(hx)
                return (max(v) - min(v)) / (max(v) + 1)
            def foliage(hx):
                r, g, b = rgb(hx)
                return g > r + 8 and g > b + 8
            field = [c for c in roof + wall if not foliage(c)] or roof
            accent = max(field, key=sat)
            out.append({
                'category': cat,
                'name': names[index],
                'roof': roof[0],
                'roofAlt': roof[1] if len(roof) > 1 else roof[0],
                'wall': wall[0],
                'wallAlt': wall[1] if len(wall) > 1 else wall[0],
                'accent': accent,
                'ratio': round((right - left + 1) / max(1, bot - top + 1), 2),
                'coverage': round(float(mask.sum()) / (h * wd), 3),
            })

json.dump(out, open('tools/palettes.json', 'w'), indent=1)
print(len(out), 'assets measured')
for row in out[:6]:
    print(row)
