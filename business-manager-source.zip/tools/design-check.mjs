/**
 * Does the product still match the design system?
 *
 * Three questions, all of which used to be answered by somebody remembering:
 *
 *   1. Does every colour, radius and layout value in design/tokens.json appear
 *      in the :root block of styles.css with the same value? A design system
 *      whose token file and stylesheet disagree is two design systems.
 *   2. Does every screen register an icon the icon set actually draws? A missing
 *      name silently falls back, so a typo is invisible until somebody notices
 *      a nav item wearing the wrong picture.
 *   3. Is anybody still building a card, a badge or a KPI by hand? Those are the
 *      sixteen parallel card styles growing back.
 *
 * Run with:  node tools/design-check.mjs
 * Exits non-zero on any disagreement, so CI can gate on it.
 */
import { readFileSync } from 'node:fs';

const root = new URL('..', import.meta.url);
const read = (p) => readFileSync(new URL(p, root), 'utf8');

const tokens = JSON.parse(read('design/tokens.json'));
const css = read('src/ui/styles.css');
const problems = [];
let checks = 0;

const check = (ok, message) => {
  checks += 1;
  if (!ok) problems.push(message);
};

// ---------------------------------------------------------------- 1. tokens

const rootBlock = css.slice(css.indexOf(':root {'), css.indexOf('\n}', css.indexOf(':root {')));
const declared = new Map();
for (const match of rootBlock.matchAll(/--([\w-]+):\s*([^;]+);/g)) {
  declared.set(match[1], match[2].trim());
}

/** tokens.json name -> the CSS custom property that must carry it. */
const COLOR_VARS = {
  'bg/base': 'bg', 'bg/raised': 'bg-2',
  'surface/panel': 'panel', 'surface/panel-2': 'panel-2', 'surface/panel-3': 'panel-3',
  'line/strong': 'line', 'line/soft': 'line-soft',
  'text/primary': 'text', 'text/secondary': 'text-2', 'text/tertiary': 'text-3',
  'accent/base': 'accent', 'accent/hot': 'accent-hot', 'accent/deep': 'accent-deep',
  'status/good': 'good', 'status/bad': 'bad', 'status/warn': 'warn',
  'status/tech': 'tech', 'status/info': 'info',
};
for (const [token, cssVar] of Object.entries(COLOR_VARS)) {
  const want = tokens.color[token].hex.toLowerCase();
  const got = (declared.get(cssVar) ?? '').toLowerCase();
  check(got === want, `colour ${token}: tokens.json says ${want}, --${cssVar} says ${got || '(missing)'}`);
}

for (const [name, px] of Object.entries(tokens.radius)) {
  const cssVar = `r-${name}`;
  const want = name === 'pill' ? '999px' : `${px}px`;
  check(declared.get(cssVar) === want, `radius ${name}: tokens.json says ${want}, --${cssVar} says ${declared.get(cssVar) ?? '(missing)'}`);
}

for (const [name, cssVar] of [['nav', 'nav-w'], ['header', 'header-h'], ['gutter', 'gutter']]) {
  const want = `${tokens.layout[name]}px`;
  check(declared.get(cssVar) === want, `layout ${name}: tokens.json says ${want}, --${cssVar} says ${declared.get(cssVar) ?? '(missing)'}`);
}

check(
  css.includes(`font: ${tokens.type.body.size}px/1.5 "${tokens.type.family}"`),
  `body type: tokens.json says ${tokens.type.body.size}px ${tokens.type.family}`,
);

// -------------------------------------------------------------- 2. the icons

const icons = read('src/ui/icons.ts');
const known = new Set([...icons.matchAll(/^\s{2}([a-zA-Z]+):\s*'/gm)].map((m) => m[1]));
check(known.size > 20, `the icon set looks empty — parsed ${known.size} names`);

const main = read('src/main.ts');
for (const match of main.matchAll(/icon:\s*'([^']+)'/g)) {
  check(known.has(match[1]), `main.ts registers icon '${match[1]}', which the icon set does not draw`);
}
for (const file of ['src/ui/views/dashboard.ts', 'src/ui/views/reports.ts', 'src/ui/views/employees.ts']) {
  for (const match of read(file).matchAll(/icon:\s*'([^']+)'/g)) {
    check(known.has(match[1]), `${file} asks for icon '${match[1]}', which the icon set does not draw`);
  }
}
check(!main.includes("icon: '\\u"), 'main.ts is registering an emoji as a nav icon again');

// -------------------------------------------------- 3. nobody rolling their own

const VIEWS = [
  'dashboard', 'businesses', 'employees', 'finance', 'reports', 'market', 'property',
  'research', 'marketing', 'headOffice', 'holding', 'contracts', 'logistics', 'inventory',
  'news', 'progress', 'settings', 'founder', 'mapView', 'newBusiness',
];
for (const view of VIEWS) {
  const body = read(`src/ui/views/${view}.ts`);
  // A hand-built KPI card is the one that actually broke: reports.ts built the
  // markup itself and every number on the screen was clipped the day the shared
  // card grew an icon tile.
  check(
    !/class:\s*'kpi'/.test(body),
    `${view}.ts builds a KPI card by hand — use kpi() from ../dom`,
  );
  check(
    !/class:\s*'panel'[^)]*border-radius/.test(body),
    `${view}.ts is restyling the card inline — put it in styles.css`,
  );
  check(
    !/background:\s*#|color:\s*#[0-9a-f]{3,6}/i.test(body),
    `${view}.ts hardcodes a colour — every colour comes from a token`,
  );
}

// ------------------------------------------------------------------- report

console.log(`design-check: ${checks - problems.length}/${checks} checks passed`);
if (problems.length > 0) {
  console.log('');
  for (const problem of problems) console.log(`  FAIL  ${problem}`);
  process.exit(1);
}
