/**
 * Screen-by-screen browser check: desktop and phone.
 *
 * Drives the real interface in a real browser. Start a server first, then run
 * it:
 *
 *   npm run build && npm run preview      # serves the built game
 *   npx playwright install chromium       # once
 *   node tools/browser-qa.mjs
 *
 * The base URL can be overridden with BM_URL, and the Playwright package with
 * PLAYWRIGHT_MODULE if it lives somewhere unusual.
 */
const pwModule = await import(process.env.PLAYWRIGHT_MODULE ?? 'playwright');
// A CJS build imported from ESM arrives under `default`; a real ESM one does not.
const { chromium } = pwModule.chromium ? pwModule : pwModule.default;
const BASE = process.env.BM_URL ?? 'http://127.0.0.1:4173/';
const SP = process.env.SP ?? '.';
const launchOptions = process.env.CHROMIUM_PATH ? { executablePath: process.env.CHROMIUM_PATH } : {};

const errors = [];
const browser = await chromium.launch(launchOptions);

const nav = async (page, label) => {
  await dismissModal(page);
  await page.locator(`.nav-item:visible:has-text("${label}")`).first().click();
};

// Runs whole in-game days through the real engine instead of waiting in real time.
const fastForward = (page, days) =>
  page.evaluate((d) => {
    const bm = window.__BM__;
    for (let i = 0; i < d * 24; i += 1) bm.engine.stepHour();
    bm.app.refresh?.();
  }, days);

// A decision can pop by itself while the clock runs; that is by design, so the
// test closes it the way a player would before carrying on.

/**
 * Walks the start screen the way a player does: title, scenario, founder,
 * names, go. Defaults to the entrepreneur start, which is the one with nothing
 * trading yet — the same blank slate these harnesses have always assumed.
 */
async function newGame(page, companyName, scenarioName = null) {
  await page.waitForSelector('.welcome-menu');
  await page.locator('.menu-item:has-text("New game")').click();
  await page.waitForSelector('.scenario-grid');
  if (scenarioName) {
    await page.locator(`.scenario-card:has-text("${scenarioName}")`).first().click();
    await page.waitForTimeout(150);
  }
  await page.locator('button:has-text("Next")').click();
  await page.waitForSelector('input[placeholder="Company name"]');
  await page.fill('input[placeholder="Company name"]', companyName);
  await page.locator('button:has-text("Start the company")').click();
  await page.waitForSelector('.shell', { timeout: 45000 });
  await page.locator('.tutorial button:has-text("Skip tutorial")').click().catch(() => {});
}

async function dismissModal(page) {
  let guard = 0;
  while ((await page.locator('.modal-overlay').count()) > 0 && guard < 24) {
    guard += 1;
    if ((await page.locator('.modal-overlay').count()) > 1) errors.push('modal dialogs are stacking on top of each other');
    const later = page.locator('.modal-footer .btn:has-text("Decide later")').last();
    if (await later.count()) await later.click().catch(() => {});
    else await page.locator('.modal-head button').last().click().catch(() => {});
    await page.waitForTimeout(200);
  }
}

async function play(page) {
  page.setDefaultTimeout(10000);
  await page.goto(BASE, { waitUntil: 'load' });
  await newGame(page, 'Northgate Retail');
  await nav(page, 'Real estate');
  await page.waitForSelector('table');
  await page.locator('button:has-text("Rent")').first().click();
  await page.waitForSelector('.modal-card');
  await page.click('.modal-footer .btn.primary');
  await page.waitForSelector('.modal-overlay', { state: 'detached' });
  await page.waitForTimeout(300);
  await nav(page, 'Real estate');
  await page.waitForTimeout(300);
  await page.locator('table').first().locator('button:has-text("Map")').first().click();
  await page.waitForTimeout(600);
  await page.locator('button:has-text("Create a business here")').click();
  await page.waitForSelector('.modal-card');
  await page.waitForTimeout(200);
  await page.click('.modal-footer .btn.primary');
  await page.waitForSelector('.modal-overlay', { state: 'detached' });
  await page.waitForTimeout(400);
  // Service businesses hold no stock, so the inventory step only applies to
  // the ones that sell things.
  const sellsStock = await page.evaluate(() => {
    const s = window.__BM__.state;
    const mine = s.businesses.filter((b) => b.companyId === s.playerCompanyId)[0];
    return mine ? Object.keys(mine.prices).filter((k) => k !== 'service').length > 0 : false;
  });
  if (sellsStock) {
    await nav(page, 'Inventory');
    await page.waitForSelector('table');
    await page.locator('button:has-text("Suggest quantities")').click();
    await page.waitForTimeout(250);
    const place = page.locator('button:has-text("Place order")').first();
    if (await place.isEnabled()) await place.click();
    await page.waitForTimeout(250);
    await page.locator('.switch input[type=checkbox]').first().check().catch(() => {});
  }
  await nav(page, 'Employees');
  await page.waitForSelector('table');
  for (let i = 0; i < 2; i += 1) {
    await page.locator('button:has-text("Hire")').first().click().catch(() => {});
    await page.waitForTimeout(200);
  }
  console.log('  stocked and staffed');
  await fastForward(page, 3); // wait for the delivery
  await nav(page, 'Businesses');
  await page.waitForTimeout(300);
  const openBtn = page.locator('button:has-text("Open for business")');
  if (await openBtn.count()) {
    await openBtn.click();
    await page.waitForTimeout(300);
  }
  console.log('  opened');
  await fastForward(page, 45); // trade long enough for news, reviews and decisions
  await page.waitForTimeout(600);
  await dismissModal(page);
}

async function assertLive(page, tag) {
  await dismissModal(page);
  // Newsroom must actually carry news after 45 traded days.
  await nav(page, 'Newsroom');
  await page.waitForTimeout(400);
  const newsCount = await page.locator('.news-item').count();
  if (newsCount === 0) errors.push(`${tag}: newsroom is empty after 45 days`);
  const filters = await page.locator('.filter-row .map-mode').count();
  if (filters < 5) errors.push(`${tag}: news filters missing (${filters})`);
  // Filtering must not blank the screen with an unhandled error.
  await page.locator('.filter-row .map-mode:has-text("Economy")').click();
  await page.waitForTimeout(250);
  await page.locator('.filter-row .map-mode:has-text("Everything")').click();
  await page.waitForTimeout(250);

  // The screen is called Competition; `has-text` is a substring match, so
  // asking for "Market" here silently lands on Marketing instead.
  await nav(page, 'Competition');
  await page.waitForTimeout(400);
  const marketText = await page.textContent('.view');
  if (!/share/i.test(marketText)) errors.push(`${tag}: market view shows no share figures`);
  if (/NaN|Infinity|undefined/.test(marketText)) errors.push(`${tag}: market view shows a broken number`);

  await nav(page, 'Businesses');
  await page.waitForTimeout(500);
  const bizText = await page.textContent('.view');
  if (!/Customer reviews/.test(bizText)) errors.push(`${tag}: review panel missing`);
  if (/NaN|Infinity/.test(bizText)) errors.push(`${tag}: business view shows a broken number`);

  // The career ladder has to say where somebody stops, not only what is next.
  await nav(page, 'Employees');
  await page.waitForTimeout(400);
  const manage = page.locator('button:has-text("Manage")').first();
  if (await manage.count()) {
    await manage.click();
    await page.waitForTimeout(400);
    const profile = await page.textContent('.modal-card');
    // Nine rungs: Junior, Employee, Senior, Specialist, Team Lead, Manager,
    // Senior Manager, Director, Executive. Read from the ladder itself rather
    // than pinned to a number here, so adding a rung never fails this on its
    // own — what must stay true is that every rung the game defines is shown.
    const rungs = await page.locator('.ladder-row').count();
    const defined = await page.evaluate(() => window.__BM__?.grades ?? 9);
    if (rungs !== defined) errors.push(`${tag}: career ladder shows ${rungs} rungs, the game defines ${defined}`);
    if (!/Specialist/.test(profile)) errors.push(`${tag}: the ladder never offers the trade track's top rung`);
    if (!/leadership/i.test(profile)) errors.push(`${tag}: the ladder never mentions what the next rung asks for`);
    if (!/Communication/.test(profile)) errors.push(`${tag}: profile is missing the communication skill`);
    if (!/Finance/.test(profile)) errors.push(`${tag}: profile is missing the finance skill`);
    if (/NaN|Infinity|undefined/.test(profile)) errors.push(`${tag}: employee profile shows a broken number`);
    await dismissModal(page);
  }

  // The business screen has to show the shape of the place, not just its people.
  await nav(page, 'Businesses');
  await page.waitForTimeout(400);
  const shape = await page.textContent('.view');
  if (!/Where this business has got to/i.test(shape)) errors.push(`${tag}: business screen is missing the scale strip`);
  if (!/Management cover/i.test(shape)) errors.push(`${tag}: business screen is missing management cover`);

  // The holding is the screen the whole structure hangs off, and it has to be
  // legible from the first day, when there is one location and no divisions.
  await nav(page, 'Holding');
  await page.waitForTimeout(400);
  const holdingText = await page.textContent('.view');
  if (!/keep an eye on/i.test(holdingText)) errors.push(`${tag}: holding view is missing the attention panel`);
  if (!/structure/i.test(holdingText)) errors.push(`${tag}: holding view is missing the structure`);
  if (/NaN|Infinity|undefined/.test(holdingText)) errors.push(`${tag}: holding view shows a broken number`);

  // The head office screen answers for itself before there is one.
  await nav(page, 'Head office');
  await page.waitForTimeout(400);
  const hqText = await page.textContent('.view');
  if (/NaN|Infinity|undefined/.test(hqText)) errors.push(`${tag}: head office view shows a broken number`);

  // The founder screen has to say what each of their skills is worth in the
  // units the effect works in, not just print a number.
  await nav(page, 'You');
  await page.waitForTimeout(400);
  const youText = await page.textContent('.view');
  if (!/Right now/.test(youText)) errors.push(`${tag}: the founder screen never says what a skill is worth`);
  if (!/Management/.test(youText) || !/Negotiation/.test(youText)) {
    errors.push(`${tag}: the founder screen is missing skills`);
  }
  if (/NaN|Infinity|undefined/.test(youText)) errors.push(`${tag}: founder screen shows a broken number`);

  // Borrowing, and the four ways to pay it back.
  await nav(page, 'Finance');
  await page.waitForTimeout(500);
  const borrow = page.locator('button:has-text("Borrow")').first();
  if (await borrow.count()) {
    await borrow.click();
    await page.waitForTimeout(600);
    const loanText = await page.textContent('.view');
    for (const label of ['25%', '50%', '100%']) {
      if (!loanText.includes(label)) errors.push(`${tag}: the loan card is missing the ${label} button`);
    }
    if (!/interest/i.test(loanText)) errors.push(`${tag}: the loan card never mentions interest`);
    if (!/Months left/i.test(loanText)) errors.push(`${tag}: the loan card never says how long is left`);
    if ((await page.locator('.loan-card').count()) === 0) errors.push(`${tag}: borrowing produced no loan card`);
    if (/NaN|Infinity/.test(loanText)) errors.push(`${tag}: the loan card shows a broken number`);
  }

  await nav(page, 'Dashboard');
  await page.waitForTimeout(400);
  const dashText = await page.textContent('.view');
  if (!/Latest news/.test(dashText)) errors.push(`${tag}: dashboard news panel missing`);
  // Four grouped blocks, not a wall of tiles.
  const blocks = await page.locator('.kpi-block').count();
  if (blocks !== 4) errors.push(`${tag}: dashboard should show four blocks, found ${blocks}`);
  for (const label of ['Financial', 'Business', 'People', 'Market']) {
    if (!new RegExp(label).test(dashText)) errors.push(`${tag}: dashboard is missing the ${label} block`);
  }
  if (/NaN|Infinity/.test(dashText)) errors.push(`${tag}: dashboard shows a broken number`);
  if (/NaN|Infinity/.test(dashText)) errors.push(`${tag}: dashboard shows a broken number`);
  // Alert rows are shortcuts; clicking one must navigate, not throw.
  const alertRow = page.locator('.clickable-row').first();
  if (await alertRow.count()) {
    await alertRow.click();
    await page.waitForTimeout(400);
  }
}

async function exerciseDecision(page, tag) {
  // Keep running days until the decision system offers something, then answer it.
  for (let attempt = 0; attempt < 12; attempt += 1) {
    const open = await page.evaluate(() => window.__BM__.state.decisions.length);
    if (open > 0) break;
    await fastForward(page, 10);
    await page.waitForTimeout(200);
    await dismissModal(page);
  }
  const open = await page.evaluate(() => window.__BM__.state.decisions.length);
  if (open === 0) {
    errors.push(`${tag}: no decision was offered in 120 days`);
    return;
  }
  await dismissModal(page);
  await nav(page, 'Newsroom');
  await page.waitForTimeout(400);
  await page.locator('.decision-card .btn.primary').first().click();
  await page.waitForSelector('.modal-card');
  await page.waitForTimeout(200);
  const optionCount = await page.locator('.decision-option').count();
  if (optionCount < 2) errors.push(`${tag}: decision dialog offered ${optionCount} options`);
  const speedWhileDeciding = await page.evaluate(() => window.__BM__.state.speed);
  if (speedWhileDeciding !== 0) errors.push(`${tag}: clock kept running during a decision`);
  await page.screenshot({ path: `${SP}/${tag}-decision.png` });
  const before = await page.evaluate(() => window.__BM__.state.decisions.length);
  await page.locator('.decision-option:not(.disabled)').first().click();
  await page.waitForTimeout(500);
  const after = await page.evaluate(() => window.__BM__.state.decisions.length);
  if (after >= before) errors.push(`${tag}: choosing an option did not resolve the decision`);
  const resolved = await page.evaluate(() => Object.keys(window.__BM__.state.decisionHistory).length);
  if (resolved === 0) errors.push(`${tag}: decision history was not recorded`);
}

const ONLY = process.env.ONLY ?? 'both';

// ------------------------------------------------------------------ desktop
if (ONLY !== 'mobile') {
  const page = await (await browser.newContext({ viewport: { width: 1440, height: 900 } })).newPage();
  page.on('pageerror', (e) => errors.push('DESKTOP PAGEERROR: ' + e.message));
  page.on('console', (m) => {
    if (m.type() === 'error' && !m.text().includes('404')) errors.push('DESKTOP CONSOLE: ' + m.text());
  });
  await play(page);
  await assertLive(page, 'desktop');
  await exerciseDecision(page, 'desktop');
  await dismissModal(page);
  for (const view of ['Dashboard', 'Map', 'Newsroom', 'Market', 'Businesses', 'Employees', 'Inventory', 'Distribution', 'Marketing', 'Finance', 'Real estate', 'Reports', 'Settings']) {
    // A decision can open between two clicks, so this goes through the same
    // dismissal every other navigation in this file uses.
    await dismissModal(page);
    await page.click(`.nav .nav-item:has-text("${view}")`);
    await page.waitForTimeout(450);
    const overflow = await page.evaluate(() => document.documentElement.scrollWidth > window.innerWidth + 1);
    if (overflow) errors.push(`DESKTOP OVERFLOW on ${view}`);
    const text = await page.textContent('.view').catch(() => '');
    if (/NaN|Infinity/.test(text)) errors.push(`DESKTOP broken number on ${view}`);
    await page.screenshot({ path: `${SP}/d4-${view.replace(/\s/g, '')}.png` });
  }
  console.log('desktop pass done');
}

// -------------------------------------------------------------------- phone
if (ONLY !== 'desktop') {
  const page = await (
    await browser.newContext({ viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true, deviceScaleFactor: 3 })
  ).newPage();
  page.on('pageerror', (e) => errors.push('MOBILE PAGEERROR: ' + e.message));
  page.on('console', (m) => {
    if (m.type() === 'error' && !m.text().includes('404')) errors.push('MOBILE CONSOLE: ' + m.text());
  });
  await play(page);
  await assertLive(page, 'mobile');
  await dismissModal(page);
  for (const view of ['Dashboard', 'Newsroom', 'Market', 'Businesses', 'Inventory', 'Distribution', 'Finance', 'Reports']) {
    await dismissModal(page);
    await page.click(`.mobile-nav .nav-item:has-text("${view}")`);
    await page.waitForTimeout(450);
    const overflow = await page.evaluate(() => document.body.scrollWidth > window.innerWidth + 1);
    if (overflow) errors.push(`MOBILE OVERFLOW on ${view} (${await page.evaluate(() => document.body.scrollWidth)}px)`);
    await page.screenshot({ path: `${SP}/m4-${view.replace(/\s/g, '')}.png` });
  }
  console.log('mobile pass done');
}

console.log('\n--- issues ---');
console.log(errors.length ? [...new Set(errors)].join('\n') : 'none');
await browser.close();
