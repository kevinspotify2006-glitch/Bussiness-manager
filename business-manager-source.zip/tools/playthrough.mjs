/**
 * A full playthrough, driven through the interface.
 *
 * Drives the real interface in a real browser. Start a server first, then run
 * it:
 *
 *   npm run build && npm run preview      # serves the built game
 *   npx playwright install chromium       # once
 *   node tools/playthrough.mjs
 *
 * The base URL can be overridden with BM_URL, and the Playwright package with
 * PLAYWRIGHT_MODULE if it lives somewhere unusual.
 */
const pwModule = await import(process.env.PLAYWRIGHT_MODULE ?? 'playwright');
// A CJS build imported from ESM arrives under `default`; a real ESM one does not.
const { chromium } = pwModule.chromium ? pwModule : pwModule.default;
const BASE = process.env.BM_URL ?? 'http://127.0.0.1:4173/';
const SP = process.env.SP ?? '.';
const launchOptions = process.env.CHROMIUM_PATH ? { executablePath: process.env.CHROMIUM_PATH } : {};

const problems = [];
const browser = await chromium.launch(launchOptions);
const page = await (await browser.newContext({ viewport: { width: 1440, height: 900 } })).newPage();
page.setDefaultTimeout(12000);
page.on('pageerror', (e) => problems.push('PAGEERROR: ' + e.message));
page.on('console', (m) => {
  if (m.type() === 'error' && !m.text().includes('404')) problems.push('CONSOLE: ' + m.text());
});

const VIEWS = [
  'Dashboard', 'Newsroom', 'Businesses', 'Employees', 'Inventory', 'Distribution',
  'Head office', 'Finance', 'Reports', 'Marketing', 'Real estate', 'Progress', 'Contracts',
  'Research', 'Map', 'Competition', 'Settings',
];

async function dismissModal() {
  let guard = 0;
  // A long fast-forward queues several decisions, and the app offers them one
  // at a time — so draining them takes more than a couple of goes.
  while ((await page.locator('.modal-overlay').count()) > 0 && guard < 24) {
    guard += 1;
    const later = page.locator('.modal-footer .btn:has-text("Decide later")').last();
    if (await later.count()) await later.click().catch(() => {});
    else await page.locator('.modal-head button').last().click().catch(() => {});
    await page.waitForTimeout(150);
  }
}

const nav = async (label) => {
  await dismissModal();
  await page.locator(`.nav-item:visible:has-text("${label}")`).first().click();
  await page.waitForTimeout(300);
};

const ff = async (days) => {
  await page.evaluate((d) => {
    for (let i = 0; i < d * 24; i += 1) window.__BM__.engine.stepHour();
    window.__BM__.app.refresh?.();
  }, days);
  await page.waitForTimeout(300);
  await dismissModal();
};

const snapshot = () =>
  page.evaluate(() => {
    const s = window.__BM__.state;
    const mine = s.businesses.filter((b) => b.companyId === s.playerCompanyId);
    return {
      day: s.day,
      cash: Math.round(s.companies.find((c) => c.isPlayer).cash),
      businesses: mine.length,
      open: mine.filter((b) => b.status === 'open').length,
      staff: s.employees.length,
      news: s.news.length,
      goals: s.goals.length,
      goalsCompleted: s.goalsCompleted,
      decisions: s.decisions.length,
      reviews: s.reviews.length,
      bankrupt: s.stats.bankrupt,
      lastProfit: Math.round(s.dayHistory.at(-1)?.profit ?? 0),
    };
  });

async function sweep(tag) {
  for (const view of VIEWS) {
    await nav(view);
    const text = await page.textContent('.view').catch(() => '');
    if (/NaN|Infinity|undefined/.test(text)) problems.push(`${tag}: broken number on ${view}`);
    const overflow = await page.evaluate(() => document.documentElement.scrollWidth > window.innerWidth + 1);
    if (overflow) problems.push(`${tag}: horizontal overflow on ${view}`);
    const blank = await page.evaluate(() => (document.querySelector('.view')?.textContent ?? '').trim().length < 60);
    if (blank) problems.push(`${tag}: ${view} is nearly blank`);
  }
}

// -------------------------------------------------------------- the opening
await page.goto(BASE, { waitUntil: 'load' });
// The start screen, walked the way a player walks it. The entrepreneur start
// is the blank slate: money in the bank and nothing trading, which is what the
// rest of this playthrough is written against.
await page.waitForSelector('.welcome-menu');
await page.locator('.menu-item:has-text("New game")').click();
await page.waitForSelector('.scenario-grid');
await page.locator('.scenario-card:has-text("Entrepreneur")').first().click();
await page.locator('button:has-text("Next")').click();
await page.waitForSelector('input[placeholder="Company name"]');
await page.fill('input[placeholder="Company name"]', 'Halstead Group');
await page.locator('button:has-text("Start the company")').click();
await page.waitForSelector('.shell', { timeout: 45000 });
await page.locator('.tutorial button:has-text("Skip tutorial")').click().catch(() => {});

// Play it properly: take the busiest unit the company can actually carry,
// the way somebody who read the map would.
const pick = await page.evaluate(() => {
  const s = window.__BM__.state;
  const cash = s.companies.find((c) => c.isPlayer).cash;
  const affordable = s.buildings
    .filter((b) => b.status === 'available' && b.rent * 3 < cash * 0.35)
    .sort((a, b) => b.footTraffic - a.footTraffic);
  return affordable[0] ? { address: affordable[0].address, foot: affordable[0].footTraffic, rent: affordable[0].rent } : null;
});
if (!pick) throw new Error('no affordable unit at all on a fresh game');
console.log('renting:', JSON.stringify(pick));

await nav('Real estate');
await page.waitForSelector('table');
const row = page.locator('table tr', { hasText: pick.address }).first();
await row.locator('button:has-text("Rent")').first().click();
await page.waitForSelector('.modal-card');
await page.click('.modal-footer .btn.primary');
await page.waitForSelector('.modal-overlay', { state: 'detached' });

await nav('Real estate');
await page.waitForTimeout(300);
await page
  .locator('table tr', { hasText: pick.address })
  .first()
  .locator('button:has-text("Map")')
  .first()
  .click();
await page.waitForTimeout(700);
await page.locator('button:has-text("Create a business here")').click();
await page.waitForSelector('.modal-card');
await page.waitForTimeout(300);
// Choose the type the way somebody who read the dialog would: footfall is only
// half of it, so this reads the fit, the basket and how price-driven the crowd
// is for every type that is affordable, and takes the best of them.
const cards = page.locator('.modal-body .card.clickable');
const cardCount = await cards.count();
const candidates = [];
for (let i = 0; i < cardCount; i += 1) {
  const badge = cards.nth(i).locator('.tag');
  if ((await badge.getAttribute('class'))?.includes('bad')) continue;
  await cards.nth(i).click();
  await page.waitForTimeout(120);
  const detail = (await page.locator('.modal-body').textContent()) ?? '';
  const name = ((await cards.nth(i).locator('.card-title').textContent()) ?? '').trim();
  const fit = /Strong fit/.test(detail) ? 1.3 : /Reasonable fit/.test(detail) ? 1 : 0.7;
  const basket = Number((detail.match(/([0-9.]+)× the city norm/) ?? [])[1] ?? 1);
  const pricey = /Shopping on price\s*Yes, heavily/.test(detail) ? 0.85 : /Barely/.test(detail) ? 1.12 : 1;
  if (!Number.isFinite(basket)) continue;
  candidates.push({ i, name, score: fit * basket * pricey, fit, basket, pricey });
}
candidates.sort((a, b) => b.score - a.score);
if (candidates.length === 0) problems.push('opening: nothing at all was affordable in the new-business dialog');
else {
  console.log('picking:', JSON.stringify(candidates.slice(0, 3).map((c) => `${c.name} ${c.score.toFixed(2)}`)));
  await cards.nth(candidates[0].i).click();
}
await page.waitForTimeout(200);
await page.click('.modal-footer .btn.primary');
await page.waitForTimeout(600);
if (await page.locator('.modal-overlay').count()) {
  const why = await page.locator('.toast').textContent().catch(() => '');
  problems.push(`opening: the business could not be created — ${why || 'no reason given'}`);
  await dismissModal();
}

const opening = await page.evaluate(() => {
  const s = window.__BM__.state;
  const mine = s.businesses.filter((b) => b.companyId === s.playerCompanyId);
  const b = mine[0];
  if (!b) return null;
  const stockKeys = Object.keys(b.prices).filter((k) => k !== 'service');
  return { id: b.id, name: b.name, sellsStock: stockKeys.length > 0 };
});
if (!opening) throw new Error('no business was created');
console.log('created:', JSON.stringify(opening));

if (opening.sellsStock) {
  await nav('Inventory');
  await page.waitForSelector('table');
  await page.locator('button:has-text("Suggest quantities")').click();
  await page.waitForTimeout(300);
  const place = page.locator('button:has-text("Place order")').first();
  if (await place.isEnabled()) await place.click();
  else problems.push('opening: the suggested order could not be placed');
  await page.waitForTimeout(300);
  await page.locator('.switch input[type=checkbox]').first().check().catch(() => {});
}

await nav('Employees');
await page.waitForSelector('table');
for (let i = 0; i < 3; i += 1) {
  await page.locator('button:has-text("Hire")').first().click().catch(() => {});
  await page.waitForTimeout(200);
}
await ff(3);
await nav('Businesses');
const openBtn = page.locator('button:has-text("Open for business")');
if (await openBtn.count()) await openBtn.click();
else problems.push('opening: the business could not be opened');
await page.waitForTimeout(300);
console.log('opened:', JSON.stringify(await snapshot()));

// What the game told the player to do first, so the end of the run can check
// that the advice actually moved on.
await nav('Dashboard');
await page.waitForTimeout(300);
const openingStep = await page.evaluate(
  () => document.querySelector('.next-step-title')?.textContent ?? '',
);
console.log('first next step:', openingStep);

// ------------------------------------------------------------ advertise it
await nav('Marketing');
const budget = page.locator('input[type=number]').first();
if (await budget.count()) {
  await budget.fill('70');
  await budget.blur();
  await page.waitForTimeout(300);
} else {
  problems.push('marketing: no budget field on the marketing screen');
}
const spendBefore = await page.evaluate(() => window.__BM__.state.businesses.find((b) => b.companyId === window.__BM__.state.playerCompanyId)?.marketingBudget ?? 0);
if (spendBefore <= 0) problems.push('marketing: setting a budget did not stick');

await ff(30);
await sweep('after a month');
console.log('month 1:', JSON.stringify(await snapshot()));

// ------------------------------------------------------------- borrow money
await nav('Finance');
const borrow = page.locator('button:has-text("Borrow")').first();
if (await borrow.count()) {
  const cashBefore = await page.evaluate(() => Math.round(window.__BM__.state.companies.find((c) => c.isPlayer).cash));
  await borrow.click();
  await page.waitForTimeout(400);
  await dismissModal();
  const cashAfter = await page.evaluate(() => Math.round(window.__BM__.state.companies.find((c) => c.isPlayer).cash));
  if (cashAfter <= cashBefore) {
    const why = await page.locator('.toast').textContent().catch(() => '');
    if (!why || !why.trim()) problems.push('finance: borrowing did nothing and said nothing');
    else console.log('finance: loan refused —', why.trim());
  } else {
    console.log(`borrowed: cash ${cashBefore} -> ${cashAfter}`);
  }
} else {
  console.log('finance: no loan was on offer, which is legitimate');
}

// --------------------------------------------------------- a second location
/**
 * Takes another lease and opens a business in it, the way the interface does.
 * Returns how many businesses the company has afterwards.
 */
async function openAnotherSite() {
  await nav('Real estate');
  await page.waitForTimeout(300);
  const rentAgain = page.locator('button:has-text("Rent")').first();
  if (await rentAgain.count()) {
    await rentAgain.click();
    await page.waitForSelector('.modal-card');
    const confirm = page.locator('.modal-footer .btn.primary');
    if (await confirm.count()) await confirm.click();
    await page.waitForTimeout(500);
    await dismissModal();
    await nav('Real estate');
    // The empty lease is the one to build in, not the row with a shop in it.
    const emptyRow = page.locator('table tr', { hasText: 'Empty' }).first();
    const mapBtns = (await emptyRow.count())
      ? emptyRow.locator('button:has-text("Map")')
      : page.locator('table').first().locator('button:has-text("Map")');
    if (await mapBtns.count()) {
      await mapBtns.first().click();
      await page.waitForTimeout(700);
      const create = page.locator('button:has-text("Create a business here")');
      if (await create.count()) {
        await create.click();
        await page.waitForSelector('.modal-card');
        await page.waitForTimeout(200);
        await page.click('.modal-footer .btn.primary');
        await page.waitForTimeout(500);
        const refusal = await page.locator('.toast').textContent().catch(() => '');
        if (refusal && refusal.trim()) console.log('  refused:', refusal.trim());
        await dismissModal();
      }
    }
  }
  return page.evaluate(() => {
    const s = window.__BM__.state;
    return s.businesses.filter((b) => b.companyId === s.playerCompanyId).length;
  });
}

const firstTry = await openAnotherSite();
const levelNow = await page.evaluate(() => window.__BM__.state.levelReached);
if (firstTry < 2 && levelNow > 1) {
  problems.push('expansion: a second business could not be created at a level that allows one');
} else if (firstTry < 2) {
  console.log(`  held to one site at level ${levelNow} — that is the location cap, and it is the design`);
}

const afterSecond = await snapshot();
console.log('second site:', JSON.stringify(afterSecond));

// Stock and staff the new one, using the same navigation the interface uses.
const second = await page.evaluate(() => {
  const s = window.__BM__.state;
  const mine = s.businesses.filter((b) => b.companyId === s.playerCompanyId);
  const setup = mine.find((b) => b.status === 'setup');
  if (!setup) return null;
  const stockKeys = Object.keys(setup.prices).filter((k) => k !== 'service');
  window.__BM__.app.go('inventory', { business: setup.id });
  return { id: setup.id, name: setup.name, sellsStock: stockKeys.length > 0 };
});
if (second) {
  console.log('second business:', JSON.stringify(second));
  await page.waitForTimeout(500);
  if (second.sellsStock) {
    const suggest = page.locator('button:has-text("Suggest quantities")').first();
    if (await suggest.count()) {
      await suggest.click();
      await page.waitForTimeout(300);
      const place = page.locator('button:has-text("Place order")').first();
      if (await place.isEnabled()) await place.click();
      else {
        const why = await page.locator('.tiny.bad').first().textContent().catch(() => '');
        console.log('second site: no order placed —', (why || 'no reason given').trim());
      }
      await page.waitForTimeout(300);
      await page.locator('.switch input[type=checkbox]').first().check().catch(() => {});
    }
  }
  await page.evaluate((id) => window.__BM__.app.go('employees', { business: id }), second.id);
  await page.waitForTimeout(500);
  for (let i = 0; i < 2; i += 1) {
    await page.locator('button:has-text("Hire")').first().click().catch(() => {});
    await page.waitForTimeout(250);
  }
  await ff(4);
  await page.evaluate((id) => window.__BM__.app.go('businesses', { business: id }), second.id);
  await page.waitForTimeout(400);
  const openSecond = page.locator('button:has-text("Open for business")').first();
  if (await openSecond.count()) {
    await openSecond.click();
    await page.waitForTimeout(400);
  }
  const nowOpen = await page.evaluate((id) => window.__BM__.state.businesses.find((b) => b.id === id)?.status, second.id);
  if (nowOpen !== 'open') problems.push(`expansion: the second business is still "${nowOpen}" after stocking and staffing it`);
  else console.log('second business is trading');
} else {
  // Not being able to afford a second site is a legitimate outcome, not a bug —
  // but the game has to say why rather than silently doing nothing.
  const cash = await page.evaluate(() => Math.round(window.__BM__.state.companies.find((c) => c.isPlayer).cash));
  const capped = await page.evaluate(() => {
    const bm = window.__BM__;
    const open = bm.state.businesses.filter((b) => b.companyId === bm.state.playerCompanyId && b.status !== 'closed');
    return { running: open.length, level: bm.state.levelReached };
  });
  console.log(`  no second business: ${cash} in the bank, ${capped.running} running at level ${capped.level}`);
  // Being held back by the level is the game working, not a fault — but it has
  // to be the reason, and the player has to have been told it.
  if (capped.level === 1 && capped.running >= 1) {
    console.log('  (the location cap is holding it to one site, which is the design)');
  } else if (cash > 60000) {
    problems.push('expansion: a second business could not be created despite the cash and the level for it');
  }
}

// -------------------------------------------------------------- the long run
for (let block = 0; block < 4; block += 1) {
  await ff(30);
  const snap = await snapshot();
  console.log(`month ${block + 2}:`, JSON.stringify(snap));
  if (snap.bankrupt) console.log(`  (insolvent on day ${snap.day} — watching whether it trades out)`);
}
await sweep('after five months');

// By now the company should have earned the right to a second site. If the
// level allows it, it has to be possible — that is what the unlock is for.
const grownLevel = await page.evaluate(() => window.__BM__.state.levelReached);
const sites = await page.evaluate(() => {
  const s = window.__BM__.state;
  return s.businesses.filter((b) => b.companyId === s.playerCompanyId).length;
});
if (grownLevel > 1 && sites < 2) {
  const retry = await openAnotherSite();
  console.log(`expansion retried at level ${grownLevel}: ${retry} businesses`);
  if (retry < 2) problems.push(`expansion: still could not open a second site at level ${grownLevel}`);
} else {
  console.log(`expansion: ${sites} site(s) at level ${grownLevel}`);
}

// ----------------------------------------------------------- buy a rival
await nav('Competition');
await page.waitForTimeout(500);
// A refusal only means something if the offer could have been met, so the test
// funds the approach before making it.
await page.evaluate(() => {
  window.__BM__.state.companies.find((c) => c.isPlayer).cash += 500000;
});
await dismissModal();
const offerBtn = page.locator('button:has-text("Make an offer")').first();
if (await offerBtn.count()) {
  await offerBtn.click();
  await page.waitForSelector('.modal-card');
  await page.waitForTimeout(200);
  const dialog = await page.textContent('.modal-body');
  if (/NaN|Infinity/.test(dialog)) problems.push('acquisition: the valuation shows a broken number');
  // Offer far too little on purpose: the refusal path must be clean.
  const field = page.locator('.modal-body input[type=number]').first();
  await field.fill('1000');
  await page.locator('.modal-footer .btn.primary').click();
  await page.waitForTimeout(500);
  await dismissModal();
  const refused = await page.evaluate(() => Object.keys(window.__BM__.state.approaches).length);
  if (refused === 0) problems.push('acquisition: a lowball offer was not recorded as a refusal');
  else console.log('acquisition: lowball correctly refused');
} else {
  problems.push('acquisition: no rival could be approached');
}

// ------------------------------------------------ the progression spine
// The single most important question the prompt asks: is the player ever told
// what to do next, does it change as the company changes, and does it lead
// somewhere real?
await nav('Dashboard');
await page.waitForTimeout(400);
const step = await page.evaluate(() => {
  const panel = document.querySelector('.next-step');
  if (!panel) return null;
  return {
    title: panel.querySelector('.next-step-title')?.textContent ?? '',
    why: panel.querySelector('.next-step-why')?.textContent ?? '',
    reward: panel.querySelector('.next-step-reward')?.textContent ?? '',
    bar: panel.querySelector('.bar') !== null,
  };
});
if (!step) problems.push('there is no "your next step" panel on the dashboard');
else {
  console.log('next step:', JSON.stringify(step));
  if (!step.title || !step.why) problems.push('the next step has no title or no reason');
  if (!step.bar) problems.push('the next step has no progress bar');
  if (!/Reward/.test(step.reward)) problems.push('the next step names no reward');
  if (step.title === openingStep) problems.push('the next step never changed across the whole run');
}

await nav('Progress');
await page.waitForTimeout(400);
const ladder = await page.evaluate(() => ({
  rows: document.querySelectorAll('.ladder-row').length,
  reached: document.querySelectorAll('.ladder-row.reached').length,
  level: window.__BM__.state.levelReached,
}));
console.log('progression:', JSON.stringify(ladder));
if (ladder.rows !== 8) problems.push(`the ladder shows ${ladder.rows} levels, not 8`);
if (ladder.reached < 1) problems.push('no level is marked as reached');

// The cash forecast has to be a forecast, not a restatement of the balance.
await nav('Finance');
await page.waitForTimeout(400);
const forecast = await page.evaluate(() => {
  const text = document.querySelector('.view')?.textContent ?? '';
  return { hasPanel: /Cash forecast/.test(text), broken: /NaN|Infinity/.test(text) };
});
if (!forecast.hasPanel) problems.push('the finance screen has no cash forecast');
if (forecast.broken) problems.push('the cash forecast shows a broken number');

// ------------------------------------------------------------ the map
// Zoomed out, the whole city and the country around it. Zoomed in, individual
// buildings, street furniture and moving traffic.
await nav('Map');
await page.waitForTimeout(700);
const mapCheck = await page.evaluate(async () => {
  const map = window.__BM__.map();
  const report = map.checkMap();
  window.__BM__.state.speed = 2;
  map.setCamera(0.5, 0.46, 0.85);
  await new Promise((r) => setTimeout(r, 400));
  const far = map.canvas.toDataURL().length;
  map.setCamera(0.45, 0.35, 9);
  await new Promise((r) => setTimeout(r, 900));
  const near = map.canvas.toDataURL().length;
  const before = map.traffic.vehicles.map((v) => [v.x, v.y]);
  await new Promise((r) => setTimeout(r, 1200));
  const after = map.traffic.vehicles.map((v) => [v.x, v.y]);
  const moved = before.filter((p, i) => Math.hypot(after[i][0] - p[0], after[i][1] - p[1]) > 1e-5).length;
  return {
    problems: report.problems.length,
    counts: report.counts,
    farBytes: far,
    nearBytes: near,
    vehicles: before.length,
    moved,
  };
});
console.log('map:', JSON.stringify(mapCheck));
if (mapCheck.problems > 0) problems.push(`the map reports ${mapCheck.problems} problems`);
if (mapCheck.counts.plots !== 390) problems.push(`the city has ${mapCheck.counts.plots} units, not 390`);
if (mapCheck.moved < mapCheck.vehicles * 0.5) {
  problems.push(`only ${mapCheck.moved} of ${mapCheck.vehicles} vehicles moved while the clock ran`);
}
if (mapCheck.nearBytes < 20000 || mapCheck.farBytes < 20000) problems.push('the map drew almost nothing at one of the zoom levels');
await page.screenshot({ path: `${SP}/playthrough-map-near.png` });

// ------------------------------------------------------------------- verdict
const final = await snapshot();
console.log('final:', JSON.stringify(final));
await nav('Dashboard');
await page.screenshot({ path: `${SP}/playthrough-final.png` });

if (final.news < 10) problems.push(`only ${final.news} news items after ${final.day} days`);
if (final.reviews < 5) problems.push(`only ${final.reviews} reviews after ${final.day} days`);
if (final.goalsCompleted === 0 && final.goals === 0) problems.push('no goals were ever set or met');
if (final.bankrupt) problems.push(`still insolvent at the end of the run, on day ${final.day}`);

console.log('\n--- problems ---');
console.log(problems.length ? [...new Set(problems)].join('\n') : 'none');
await browser.close();
