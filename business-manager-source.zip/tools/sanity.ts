/**
 * Economic sanity checks.
 *
 * The balance harness (tools/simulate.ts) is for reading; this one is for
 * failing. It runs the simulation headlessly a dozen times under different
 * conditions and asserts the things that must always be true of the economy:
 *
 *   - no NaN or Infinity ever reaches the state
 *   - a sensible shop can make money, a badly run one loses it
 *   - price changes move demand in the right direction
 *   - staff change throughput
 *   - competitors take share and it moves over time
 *   - bankruptcy is reachable
 *   - nothing prints money out of nothing
 *   - the news, review and decision systems produce bounded, sane output
 *
 * Run with:  npx tsx tools/sanity.ts
 * Exits non-zero on the first broken invariant, so CI can gate on it.
 */
import { createNewGame } from '../src/sim/setup';
import { Engine } from '../src/sim/engine';
import { foundBusiness, openBusiness, rentBuilding } from '../src/sim/business';
import { placeOrder, rankedSuppliers, suggestOrder } from '../src/sim/procurement';
import { applicantsFor, hire, isOffSick, marketRate, refreshApplicants, setSalary, sickDaysLeft, startTraining } from '../src/sim/employees';
import {
  GRADES,
  ROLE_SKILLS,
  TOP_OF_TRADE,
  canRunDivision,
  SKILL_IDS,
  emptySkills,
  gradeOf,
  overallSkill,
  performanceOf,
  profileFor,
  roleFit,
  rungRate,
  syncOverall,
  titleOf,
  workloadOf,
} from '../src/sim/skills';
import { migrate } from '../src/sim/save';
import {
  PAY_DRIFT,
  POLICIES,
  applicantSkillBias,
  hoursFactor,
  hoursMoraleDrag,
  policiesDaily,
  policy,
  setPolicy,
  sicknessFactor,
} from '../src/sim/policies';
import {
  OFFICERS,
  OFFICER_LIFT,
  appoint,
  canAppoint,
  officer,
  officerLift,
  officerStrength,
  officers,
  operatingReach,
  vacate,
} from '../src/sim/executives';
import {
  MAX_OUTSIDE_STAKE,
  RAISE_FLOOR,
  boardConfidence,
  boardDaily,
  buyBack,
  buybackCost,
  canRaise,
  outsideStake,
  ownersStake,
  raiseEquity,
  stakeFor,
  valuation,
} from '../src/sim/board';
import { DEVELOPMENTS, cityChangeDaily, drift, pending, pendingIn } from '../src/sim/cityChange';
import { SAVE_VERSION } from '../src/sim/state';
import {
  OWNER_ATTENTION,
  appointHead,
  assignToDivision,
  attentionOf,
  attentionFactor,
  createDivision,
  delegatedSupervision,
  divisionBusinesses,
  ownerAttention,
} from '../src/sim/holding';
import { promote, quotePromotion } from '../src/sim/employees';
import { BUSINESS_TYPES } from '../src/data/businessTypes';
import {
  adminCostPerDay,
  complexityOf,
  departmentsOf,
  findings,
  managementCover,
  managementFactor,
  sizeOf,
  staffingPlan,
  staffingSummary,
  supervisionCapacity,
  supervisionLoad,
  tradeFitOf,
} from '../src/sim/staffing';
import { employeesOf } from '../src/sim/state';
import {
  FUNCTION_BY_ID,
  automationRelief,
  closeHeadOffice,
  coordinationFactor,
  cover,
  coverNeeded,
  hireToHeadOffice,
  marketingFactor,
  openHeadOffice,
  outsourcingBill,
  penaltyFactor,
  recruitmentFee,
  retentionFactor,
  setOutsourced,
  taxFactor,
  FUNCTIONS,
  HQ_LEVELS,
  automationCover,
  centralStaff,
  hqLevel,
  investInAutomation,
  localResponsiveness,
  overheadBill,
  setStance,
  upgradeHeadOffice,
  canRelocate,
  hqArea,
  nextHqLevel,
  relocateHeadOffice,
  relocationOptions,
} from '../src/sim/headOffice';
import { RECRUITMENT_FEE, generateApplicant } from '../src/sim/employees';
import { businessTypeOrThrow } from '../src/data/businessTypes';
import { hourlyCapacity } from '../src/sim/business';
import { acquisitionTargets, approachStatus, makeOffer } from '../src/sim/acquisitions';
import {
  capacityOf,
  closeWarehouse,
  dispatchDaily,
  openWarehouse,
  placeBulkOrder,
  stockValue,
  stockableProducts,
  warehouseCanSupply,
  warehousesOf,
} from '../src/sim/warehouse';
import { SUPPLIERS } from '../src/data/suppliers';
import { product as productFor } from '../src/data/products';
import { DISTRICTS } from '../src/data/districts';
import { SEGMENTS, basketFactor, districtMix, emptyMix, leadingSegment } from '../src/sim/segments';
import { NEWS_LIMIT } from '../src/sim/news';
import { REVIEW_LIMIT } from '../src/sim/reviews';
import { playerBusinesses, playerCompany } from '../src/sim/state';
import type { GameState } from '../src/sim/state';
import type { Business } from '../src/sim/types';
import { routeAcrossCity, validateMap } from '../src/sim/validateMap';
import { RESEARCH, canStart } from '../src/sim/research';
import { creditMultiplier } from '../src/sim/progress';
import { startGame } from '../src/sim/scenario';
import { SCENARIOS } from '../src/data/scenarios';
import { FOUNDER_SKILL_IDS, FOUNDER_TRAITS, startingSkills } from '../src/data/founders';
import {
  attentionSpan,
  lendingFactor,
  marketingSkillFactor,
  moraleFromOwner,
  negotiationFactor,
  operationsFactor,
  rateDiscount,
  researchSpeed,
  skillOf,
} from '../src/sim/founder';
import {
  FACTORING_FEE,
  ageing,
  bookTakings,
  factorInvoices,
  raiseBill,
  raiseInvoice,
  supplierTerms,
  tradeCreditOf,
  workingCapital,
  workingCapitalDaily,
} from '../src/sim/workingCapital';
import { creditFactors, isOperatingCost, isRevenue } from '../src/sim/finance';
import {
  FACILITIES,
  activeProject,
  automationCeiling,
  built,
  canBuild,
  desksLeft,
  desksTotal,
  desksUsed,
  executiveReach,
  exposure,
  facilitiesBill,
  facilityOrThrow,
  hasBoard,
  labFactor,
  projectsDaily,
  startProject,
  trainingFactor,
  utilisation,
  utilisationPenalty,
} from '../src/sim/facilities';
import { CHRONICLE_LIMIT, chronicle, recordRows, record, summary } from '../src/sim/chronicle';
import {
  MAX_BONDS,
  bondMorale,
  bondsOf,
  mentorBoost,
  relationshipsDaily,
  relationshipsOf,
  teamFriction,
} from '../src/sim/relationships';
import {
  STANDING_FACETS,
  brandFactor,
  employerPull,
  emptyStanding,
  qualityBias,
  retentionFactorOf,
  standingDaily,
  standingOf,
  standingTargets,
} from '../src/sim/standing';
import {
  GROUPED_BY_HAND,
  MERGER_STYLES,
  SCALE_FLOOR,
  abandonMerger,
  cultureGapOf,
  duplicatesIn,
  divisionPeople,
  mergerAttentionLoad,
  mergerFor,
  mergerMoraleDrag,
  mergerPlan,
  mergerScaleFactor,
  mergersDaily,
  startMerger,
} from '../src/sim/mergers';
import {
  LOAN_TYPES,
  interestRemaining,
  loanOffers,
  monthlyPayment,
  monthsRemaining,
  quoteRepayment,
  repayLoan,
  takeLoan,
} from '../src/sim/finance';
import { unitPrice } from '../src/sim/procurement';
import {
  accept as acceptContract,
  contractsOf,
  contractsWeekly,
  makeOffer as makeContractOffer,
} from '../src/sim/contracts';
import { cashWarning, forecast as forecastCash } from '../src/sim/cashflow';
import { sum } from '../src/sim/util';

// --------------------------------------------------------------- assertions

let failures = 0;
let checks = 0;

function check(label: string, ok: boolean, detail = ''): void {
  checks += 1;
  if (ok) {
    console.log(`  ok    ${label}`);
  } else {
    failures += 1;
    console.log(`  FAIL  ${label}${detail ? ` — ${detail}` : ''}`);
  }
}

function heading(text: string): void {
  console.log(`\n${text}`);
}

// ------------------------------------------------------------- scenario rig

interface ScenarioOptions {
  typeId?: string;
  days?: number;
  /** "best" rents the busiest affordable unit, "cheap" the cheapest. */
  strategy?: 'cheap' | 'best';
  /** Multiplies every shelf price after the shop is stocked. */
  priceFactor?: number;
  /** How many of the type's roles to fill. 0 means the owner works alone. */
  staff?: number;
  marketing?: number;
  /** Skip stocking the shop — the fastest way to run a business into the ground. */
  noStock?: boolean;
  /** Fixed seed, so every run of this file asserts the same simulation. */
  seed?: number;
}

interface ScenarioResult {
  state: GameState;
  business: Business;
  profit: number;
  customers: number;
  revenue: number;
  costs: number;
  bankrupt: boolean;
}

function runScenario(options: ScenarioOptions = {}): ScenarioResult {
  const {
    typeId = 'convenience',
    days = 60,
    strategy = 'best',
    priceFactor = 1,
    staff = -1,
    marketing = 0,
    noStock = false,
    seed = 20260601,
  } = options;

  const state = createNewGame('Sanity Ltd', seed);
  const engine = new Engine(state);
  const type = businessTypeOrThrow(typeId);

  const affordable = state.buildings.filter(
    (b) =>
      b.status === 'available' &&
      b.size >= type.minSize &&
      b.suitableFor.includes(type.category) &&
      b.rent * 3 + type.setupCost + type.equipmentCost < playerCompany(state).cash * 0.6,
  );
  const sorted =
    strategy === 'best'
      ? affordable.slice().sort((a, b) => b.footTraffic - a.footTraffic)
      : affordable.slice().sort((a, b) => a.rent - b.rent);
  const target = sorted[0];
  if (!target) throw new Error(`No affordable unit for ${type.name}`);

  rentBuilding(state, target.id);
  foundBusiness(state, typeId, target.id, 'Sanity Shop');
  const business = playerBusinesses(state)[0];

  if (!noStock && type.productIds.length > 0) {
    for (const supplierId of rankedSuppliers(state, business)) {
      const lines = suggestOrder(state, business, supplierId);
      if (lines.length === 0) continue;
      if (placeOrder(state, supplierId, business.id, lines).ok) break;
    }
    business.autoRestock = true;
  }

  const roles = staff < 0 ? type.roles : type.roles.slice(0, staff);
  for (const roleId of roles) {
    const applicant = applicantsFor(state, business).find((a) => a.role === roleId);
    if (applicant) hire(state, applicant.id, business.id);
  }

  // Let the first delivery land, then open the doors.
  for (let hour = 0; hour < 72; hour += 1) {
    engine.stepHour();
    if (sum(Object.values(business.stock), (units) => units) > 0) break;
  }
  if (priceFactor !== 1) {
    for (const productId of Object.keys(business.prices)) {
      business.prices[productId] = Math.round(business.prices[productId] * priceFactor * 100) / 100;
    }
  }
  business.marketingBudget = marketing;
  openBusiness(state, business.id);

  for (let day = 0; day < days; day += 1) {
    for (let hour = 0; hour < 24; hour += 1) engine.stepHour();
  }

  // Only count the days the shop was actually trading.
  const trading = state.dayHistory.filter((record) => record.day >= business.openedOnDay);
  return {
    state,
    business,
    profit: sum(trading, (d) => d.profit),
    customers: business.totals.customers,
    revenue: business.totals.revenue,
    costs: business.totals.costs,
    bankrupt: state.stats.bankrupt,
  };
}

/** Every effect the research tree declares must have a call site in the sim. */
const EFFECTS = new Set([
  'throughput', 'wages', 'purchasing', 'logistics', 'trips', 'capacity', 'awareness', 'utilities',
]);

/** A product the company actually sells, for the buying-price check. */
function productIdFor(state: GameState): string {
  const shop = playerBusinesses(state)[0];
  return Object.keys(shop.prices).find((id) => id !== 'service') ?? '';
}

// --------------------------------------------------------- numeric scanning

/** Walks the whole state looking for a number that should never exist. */
function findBadNumber(value: unknown, path = 'state', seen = new Set<unknown>()): string | null {
  if (typeof value === 'number') {
    return Number.isFinite(value) ? null : `${path} = ${value}`;
  }
  if (value === null || typeof value !== 'object') return null;
  if (seen.has(value)) return null;
  seen.add(value);
  if (Array.isArray(value)) {
    for (let i = 0; i < value.length; i += 1) {
      const bad = findBadNumber(value[i], `${path}[${i}]`, seen);
      if (bad) return bad;
    }
    return null;
  }
  for (const [key, child] of Object.entries(value as Record<string, unknown>)) {
    const bad = findBadNumber(child, `${path}.${key}`, seen);
    if (bad) return bad;
  }
  return null;
}

// ------------------------------------------------------------------- checks

console.log('BUSINESS MANAGER — economic sanity checks\n' + '='.repeat(42));

heading('1. Numbers stay real');
const long = runScenario({ typeId: 'convenience', days: 200, strategy: 'best', marketing: 120 });
check('no NaN or Infinity anywhere in the state after 200 days', findBadNumber(long.state) === null, findBadNumber(long.state) ?? '');
check('cash is a finite number', Number.isFinite(playerCompany(long.state).cash));
check('reputation stays inside 0..100', long.business.reputation >= 0 && long.business.reputation <= 100, `${long.business.reputation}`);
check('review score stays inside 1..5', long.business.reviewScore >= 1 && long.business.reviewScore <= 5, `${long.business.reviewScore}`);
check('awareness stays inside 0..100', long.business.awareness >= 0 && long.business.awareness <= 100, `${long.business.awareness}`);

heading('2. Money can be made and lost');
const wellRun = runScenario({ typeId: 'coffeeshop', days: 90, strategy: 'best', marketing: 90 });
const badlyRun = runScenario({ typeId: 'coffeeshop', days: 90, strategy: 'cheap', priceFactor: 1.9, staff: -1 });
check('a well-placed, well-run shop trades profitably', wellRun.revenue > wellRun.costs * 0.8, `revenue ${Math.round(wellRun.revenue)} vs costs ${Math.round(wellRun.costs)}`);
check('a badly placed, overpriced shop loses money', badlyRun.profit < 0, `profit ${Math.round(badlyRun.profit)}`);
check('the two outcomes are meaningfully different', wellRun.profit - badlyRun.profit > 1000, `${Math.round(wellRun.profit)} vs ${Math.round(badlyRun.profit)}`);

heading('3. Price moves demand');
const cheapPrices = runScenario({ typeId: 'convenience', days: 45, priceFactor: 0.8 });
const dearPrices = runScenario({ typeId: 'convenience', days: 45, priceFactor: 1.6 });
check('cutting prices brings more customers', cheapPrices.customers > dearPrices.customers, `${Math.round(cheapPrices.customers)} vs ${Math.round(dearPrices.customers)}`);
check('raising prices does not increase customers', dearPrices.customers <= cheapPrices.customers);
check('the effect is a curve, not a cliff', dearPrices.customers > 0, 'a 60% price rise emptied the shop entirely');

heading('4. Staff change throughput');
// Staffing only shows up where there is demand to serve, so this runs in a busy
// unit with marketing behind it — otherwise the shop is demand-limited and the
// extra hands would correctly make no difference.
const skeleton = runScenario({ typeId: 'coffeeshop', days: 45, staff: 1, marketing: 200 });
const fullStaff = runScenario({ typeId: 'coffeeshop', days: 45, staff: -1, marketing: 200 });
// Attendance has a random element, so this is measured over many shifts
// rather than one.
const averageCapacity = (result: ScenarioResult): number => {
  let total = 0;
  for (let i = 0; i < 40; i += 1) total += hourlyCapacity(result.state, result.business);
  return total / 40;
};
const fullCapacity = averageCapacity(fullStaff);
const thinCapacity = averageCapacity(skeleton);
check(
  'a fuller team can serve more people per hour',
  fullCapacity > thinCapacity,
  `${fullCapacity.toFixed(1)} vs ${thinCapacity.toFixed(1)}`,
);
check('a one-person shop still trades', skeleton.customers > 0);
check('staff cost real money', fullStaff.costs > skeleton.costs, `${Math.round(fullStaff.costs)} vs ${Math.round(skeleton.costs)}`);
const unstaffed = runScenario({ typeId: 'coffeeshop', days: 2, staff: 0 });
check('a shop cannot open with nobody working in it', unstaffed.business.status !== 'open', unstaffed.business.status);

heading('5. Competitors are alive');
const market = long.state;
const rivals = market.businesses.filter((b) => b.companyId !== market.playerCompanyId);
const rivalPrices = new Set(rivals.map((b) => Math.round(sum(Object.values(b.prices), (p) => p) * 100)));
const rivalRevenue = sum(rivals, (b) => b.totals.revenue);
check('competitors are trading', rivals.length > 5, `${rivals.length} outlets`);
check('competitors earn revenue of their own', rivalRevenue > 0, `${Math.round(rivalRevenue)}`);
check('competitors do not all price identically', rivalPrices.size > 3, `${rivalPrices.size} distinct price sets`);
check('competitor companies hold cash positions', market.companies.filter((c) => c.id !== market.playerCompanyId).every((c) => Number.isFinite(c.cash)));

heading('6. Failure is reachable');
const doomed = runScenario({ typeId: 'coffeeshop', days: 150, strategy: 'cheap', priceFactor: 2.2, marketing: 900 });
const startingCash = 60000;
check('reckless pricing and spending destroys the company', playerCompany(doomed.state).cash < startingCash * 0.5, `cash ${Math.round(playerCompany(doomed.state).cash)}`);
check('the losses are reported to the player', doomed.state.alerts.length > 0);
check('the daily record shows losing days', doomed.state.dayHistory.some((d) => d.profit < 0));

heading('7. No money from nothing');
const idle = runScenario({ typeId: 'convenience', days: 30, noStock: true, staff: 0 });
check('a business that never opens earns nothing', idle.revenue === 0, `${Math.round(idle.revenue)}`);
check('an idle leased unit still costs money', playerCompany(idle.state).cash < startingCash, `cash ${Math.round(playerCompany(idle.state).cash)}`);
check('revenue never exceeds what was sold', long.business.totals.revenue >= 0 && long.business.totals.units >= 0);
check(
  'profit is bounded by revenue',
  long.business.profitHistory.every((p) => Math.abs(p) < Math.max(5000, long.business.yesterday.revenue * 20)),
);

heading('8. The world reports itself');
check('news is being written', long.state.news.length > 0, `${long.state.news.length} items`);
check('the news feed is capped', long.state.news.length <= NEWS_LIMIT, `${long.state.news.length} > ${NEWS_LIMIT}`);
check('reviews are being written', long.state.reviews.length > 0, `${long.state.reviews.length} reviews`);
check('the review list is capped', long.state.reviews.length <= REVIEW_LIMIT, `${long.state.reviews.length} > ${REVIEW_LIMIT}`);
check('every review has text', long.state.reviews.every((r) => r.text.trim().length > 0));
check('review stars are 1..5 integers', long.state.reviews.every((r) => Number.isInteger(r.stars) && r.stars >= 1 && r.stars <= 5));
check('at most one decision is open at a time', long.state.decisions.length <= 1, `${long.state.decisions.length}`);
check('decisions have been offered over 200 days', Object.keys(long.state.decisionHistory).length > 0);
check('open decisions always offer a choice', long.state.decisions.every((d) => d.options.length >= 2));

heading('9. People are people');
const peopleState = long.state;
const everyone = peopleState.employees;
check('the payroll survived 200 days', everyone.length >= 0);
check('nobody is permanently ill', everyone.every((e) => e.sickUntilDay === null || e.sickUntilDay <= peopleState.day + 5), 'someone is off sick for more than five days');
// Illness is driven by stress, so this pins a team at breaking point and checks
// that the simulation reacts. A relaxed team is rarely off, which is correct.
const sickRun = runScenario({ typeId: 'coffeeshop', days: 40, strategy: 'best', marketing: 250 });
const sickEngine = new Engine(sickRun.state);
// Long enough that the assertion is about the model rather than about which
// side of the dice this particular seed happened to land on.
for (let day = 0; day < 120; day += 1) {
  // Stressed but not mutinous: morale is held up so they stay in the job and
  // the thing being tested is illness, not resignation.
  for (const person of sickRun.state.employees) {
    person.stress = 100;
    person.morale = 80;
  }
  for (let hour = 0; hour < 24; hour += 1) sickEngine.stepHour();
}
check('the team was still employed while the test ran', sickRun.state.employees.length > 0);
check(
  'a team run at breaking point falls ill',
  sickRun.state.news.some((n) => n.headline.includes('called in sick')),
  'nobody was ever off sick despite 120 days at maximum stress',
);
check(
  'sick leave ends by itself',
  // A spell that ends today is over: `isOffSick` is the predicate the rest of
  // the game uses, so it is the one the check uses too.
  sickRun.state.employees.every((e) => !isOffSick(sickRun.state, e) || sickDaysLeft(sickRun.state, e) <= 4),
  'somebody is stuck on sick leave',
);
check('promotion counters are whole numbers', everyone.every((e) => Number.isInteger(e.promotions) && e.promotions >= 0));
check('morale and stress stay inside 0..100', everyone.every((e) => e.morale >= 0 && e.morale <= 100 && e.stress >= 0 && e.stress <= 100));
check('salaries stay positive', everyone.every((e) => e.salary > 0 && Number.isFinite(e.salary)));
check('the applicant pool never empties', peopleState.applicants.length > 0, `${peopleState.applicants.length}`);

heading('10. Goals are real targets');
const goalState = long.state;
check('goals are offered over 200 days', goalState.goalsCompleted > 0 || goalState.goals.length > 0 || goalState.news.some((n) => n.headline.startsWith('New goal')), 'no goal was ever set');
check('no more than three run at once', goalState.goals.length <= 3, `${goalState.goals.length}`);
check('every goal has a deadline in the future or is gone', goalState.goals.every((g) => g.expiresOnDay > goalState.day - 1));
check('goal targets are finite numbers', goalState.goals.every((g) => Number.isFinite(g.target) && Number.isFinite(g.startValue)));
check('a goal always asks for more than it started with', goalState.goals.every((g) => g.target > g.startValue || g.metric === 'reviewScore'));
check('completed goals were counted', Number.isInteger(goalState.goalsCompleted) && goalState.goalsCompleted >= 0);

heading('11. Buying a rival is a real transaction');
{
  const buyState = runScenario({ typeId: 'convenience', days: 90, strategy: 'best', marketing: 150 }).state;
  const company = playerCompany(buyState);
  company.cash += 5_000_000; // fund the purchase so the test is about the mechanism
  const targets = acquisitionTargets(buyState, 5);
  check('there are rivals worth valuing', targets.length > 0);
  const target = targets[0];
  check('a valuation is a finite, positive figure', Number.isFinite(target.valuation.fair) && target.valuation.fair > 0, `${target.valuation.fair}`);

  const before = playerBusinesses(buyState).length;
  const cashBefore = company.cash;
  const lowball = makeOffer(buyState, target.business.id, Math.round(target.valuation.fair * 0.2));
  check('a lowball offer is refused', lowball.ok && !lowball.accepted, lowball.message);
  check('a refusal costs you the conversation', approachStatus(buyState, target.business.id)?.blocked !== null);
  check('a refused offer costs no money', playerCompany(buyState).cash === cashBefore);

  const second = acquisitionTargets(buyState, 5).find((t) => t.business.id !== target.business.id);
  if (second) {
    const generous = makeOffer(buyState, second.business.id, Math.round(second.valuation.fair * 1.6));
    check('a generous offer is accepted', generous.accepted, generous.message);
    check('the business changed hands', playerBusinesses(buyState).length === before + 1, `${playerBusinesses(buyState).length} vs ${before + 1}`);
    check('the money left the account', playerCompany(buyState).cash < cashBefore);
    const bought = buyState.businesses.find((b) => b.id === second.business.id);
    check('it came with staff', (bought?.employeeIds.length ?? 0) > 0);
    check('it came with stock or sells nothing', (bought ? sum(Object.values(bought.stock), (u) => u) > 0 : false) || (bought ? businessTypeOrThrow(bought.typeId).productIds.length === 0 : false));
    check('the premises followed the business', buyState.buildings.find((b) => b.id === bought?.buildingId)?.occupantCompanyId === buyState.playerCompanyId);
  } else {
    check('a second acquisition target exists', false, 'only one rival was available');
  }
}

heading('12. Distribution moves stock, it does not invent it');
{
  const chain = runScenario({ typeId: 'convenience', days: 60, strategy: 'best', marketing: 120 }).state;
  const company = playerCompany(chain);
  company.cash += 250_000;

  // Take on a second unit with plenty of storage and rack it out.
  const shed = chain.buildings
    .filter((b) => b.status === 'available' && b.storageCapacity >= 400)
    .sort((a, b) => b.storageCapacity - a.storageCapacity)[0];
  check('the city has premises big enough to rack out', Boolean(shed));
  rentBuilding(chain, shed.id);

  const cashBefore = playerCompany(chain).cash;
  const opened = openWarehouse(chain, shed.id, 'Sanity Distribution');
  check('a held unit can become a distribution centre', opened.ok, opened.message);
  check('the fit-out is paid for', playerCompany(chain).cash < cashBefore, `${playerCompany(chain).cash} vs ${cashBefore}`);

  const warehouse = warehousesOf(chain)[0];
  check('the racks hold more than a shop back room', capacityOf(chain, warehouse) > shed.storageCapacity);

  // Buy in bulk.
  // Order a proper bulk load: enough that a night's run leaves a buffer, which
  // is the whole point of holding stock centrally.
  const lines = stockableProducts(chain).map((productId) => ({ productId, quantity: 400 }));
  let placed = { ok: false, message: 'no supplier tried' };
  for (const def of SUPPLIERS) {
    const attempt = placeBulkOrder(chain, def.id, warehouse.id, lines.filter((line) => {
      const p = productFor(line.productId);
      return p ? def.categories.includes(p.category) : false;
    }));
    if (attempt.ok) {
      placed = attempt;
      break;
    }
  }
  check('a bulk order can be placed', placed.ok, placed.message);

  const engine = new Engine(chain);
  // Run only as far as the delivery, so what is tested next is the dispatch and
  // not three nights of the shop drawing on it.
  for (let hour = 0; hour < 48; hour += 1) {
    engine.stepHour();
    if (sum(Object.values(warehouse.stock), (units) => units) > 0) break;
  }
  const onRacks = sum(Object.values(warehouse.stock), (units) => units);
  check('the bulk delivery reaches the racks', onRacks > 100, `${Math.round(onRacks)} units`);

  // Empty the shop's shelves so tonight's run has something to do.
  const shop = playerBusinesses(chain)[0];
  for (const productId of Object.keys(shop.stock)) shop.stock[productId] = 0;
  shop.autoRestock = true;

  const beforeRacks = sum(Object.values(warehouse.stock), (u) => u);
  const beforeShelves = sum(Object.values(shop.stock), (u) => u);
  dispatchDaily(chain);
  const afterRacks = sum(Object.values(warehouse.stock), (u) => u);
  const afterShelves = sum(Object.values(shop.stock), (u) => u);

  check('stock leaves the racks', afterRacks < beforeRacks, `${Math.round(beforeRacks)} -> ${Math.round(afterRacks)}`);
  check('the same stock arrives on the shelves', afterShelves > beforeShelves, `${Math.round(beforeShelves)} -> ${Math.round(afterShelves)}`);
  check(
    'nothing is created or destroyed in transit',
    Math.abs((beforeRacks + beforeShelves) - (afterRacks + afterShelves)) < 0.001,
    `${(beforeRacks + beforeShelves).toFixed(2)} vs ${(afterRacks + afterShelves).toFixed(2)}`,
  );
  check('the van run is charged for', chain.ledger.some((entry) => entry.category === 'logistics' && entry.label.startsWith('Delivery run')));
  const stillHeld = Object.entries(warehouse.stock).find(([, units]) => units > 5)?.[0] ?? '';
  check(
    'a shop will not buy from a supplier what its own warehouse holds',
    stillHeld !== '' && warehouseCanSupply(chain, stillHeld, 1),
    stillHeld === '' ? 'the racks were emptied by the run' : stillHeld,
  );

  const valueOnRacks = stockValue(warehouse);
  const cashBeforeClose = playerCompany(chain).cash;
  const closed = closeWarehouse(chain, warehouse.id);
  check('closing a centre clears the stock', closed.ok, closed.message);
  check(
    'clearance raises about half what the stock cost',
    playerCompany(chain).cash > cashBeforeClose && playerCompany(chain).cash <= cashBeforeClose + valueOnRacks,
    `raised ${Math.round(playerCompany(chain).cash - cashBeforeClose)} of ${Math.round(valueOnRacks)}`,
  );
}

heading('13. An empty lease is a liability');
{
  const holder = runScenario({ typeId: 'convenience', days: 20, strategy: 'best' }).state;
  const spare = holder.buildings.filter((b) => b.status === 'available')[0];
  rentBuilding(holder, spare.id);
  const engine = new Engine(holder);
  for (let day = 0; day < 10; day += 1) for (let hour = 0; hour < 24; hour += 1) engine.stepHour();
  const onTheEmptyUnit = holder.ledger.filter((entry) => entry.label.includes('(empty)'));
  check('rent is charged on a unit with nothing in it', onTheEmptyUnit.length > 0, 'an empty lease was free');
  // What the empty unit costs, not what the company did overall: a shop that
  // trades well enough to cover it does not make the lease free.
  const cost = sum(onTheEmptyUnit, (entry) => entry.amount);
  check('holding it costs money', cost < 0, `the empty unit moved ${Math.round(cost)} over ten days`);
}

heading('14. The books close honestly');
{
  const booked = long.state;
  check('accounts are filed every month', booked.accounts.length >= 5, `${booked.accounts.length} months`);
  const account = booked.accounts[booked.accounts.length - 1];
  check('every figure in the accounts is finite', Object.values(account).every((value) => typeof value !== 'number' || Number.isFinite(value)));
  check(
    'gross profit is turnover less cost of sales',
    Math.abs(account.grossProfit - (account.revenue - account.costOfSales)) < 0.5,
  );
  check(
    'net profit is gross profit less everything else',
    Math.abs(account.netProfit - (account.grossProfit - account.overheads - account.interest - account.tax)) < 0.5,
    `${account.netProfit} vs ${account.grossProfit - account.overheads - account.interest - account.tax}`,
  );
  const daily = sum(
    booked.dayHistory.filter((d) => d.day >= account.fromDay && d.day <= account.toDay),
    (d) => d.revenue,
  );
  check(
    'the accounts agree with the daily record',
    Math.abs(account.revenue - daily) < Math.max(50, account.revenue * 0.02),
    `${Math.round(account.revenue)} in the accounts vs ${Math.round(daily)} in the daily figures`,
  );
  check(
    'the balance sheet adds up',
    Math.abs(
      account.netWorth -
        (account.cash + account.receivables + account.stock + account.property + account.goodwill -
          account.payables - account.debt),
    ) < 1,
    `${Math.round(account.netWorth)} vs ${Math.round(
      account.cash + account.receivables + account.stock + account.property + account.goodwill -
        account.payables - account.debt,
    )}`,
  );
  check('months do not overlap', booked.accounts.every((a, i) => i === 0 || a.fromDay > booked.accounts[i - 1].toDay));
  check('the month in progress starts after the last close', booked.period.fromDay > booked.accounts[booked.accounts.length - 1].toDay);
  check('running totals survive the ledger being trimmed', booked.ledger.length <= 600 && account.revenue > 0);
}

heading('15. Customers are people, not a number');
{
  const cityMix = DISTRICTS.map((def) => districtMix(def, 'retail'));
  check('every district mix sums to one', cityMix.every((mix) => Math.abs(SEGMENTS.reduce((a, s) => a + mix[s.id], 0) - 1) < 0.001));
  check('no district is made of a single group', cityMix.every((mix) => SEGMENTS.filter((s) => mix[s.id] > 0.02).length >= 3));
  const uni = districtMix(DISTRICTS.find((d) => d.id === 'university')!, 'retail');
  const fin = districtMix(DISTRICTS.find((d) => d.id === 'financial')!, 'retail');
  check('the university district is full of students', leadingSegment(uni).id === 'students', leadingSegment(uni).id);
  check('the financial district is not', fin.students < uni.students / 3, `${fin.students.toFixed(2)} vs ${uni.students.toFixed(2)}`);
  check('a student basket is worth less than a professional one', basketFactor({ ...emptyMix(), students: 1 }) < basketFactor({ ...emptyMix(), professionals: 1 }));
  check(
    'segments redistribute demand rather than inflating it',
    Math.abs(
      DISTRICTS.reduce((acc, def) => acc + basketFactor(districtMix(def, 'retail')) * def.population, 0) /
        DISTRICTS.reduce((acc, def) => acc + def.population, 0) -
        1,
    ) < 0.05,
    'the city-wide average basket has drifted away from neutral',
  );
  const crowd = long.business.yesterdayMix;
  check('a trading shop records who came in', SEGMENTS.reduce((a, s) => a + (crowd[s.id] ?? 0), 0) > 0);
  check('the recorded crowd has no impossible shares', SEGMENTS.every((s) => (crowd[s.id] ?? 0) >= 0 && Number.isFinite(crowd[s.id] ?? 0)));
}

heading('16. Insolvency is a state, not a life sentence');
{
  const rescued = runScenario({ typeId: 'convenience', days: 30, strategy: 'best', marketing: 100 }).state;
  const company = playerCompany(rescued);
  const engine = new Engine(rescued);
  // Drive it under, then put the money back and let a day settle.
  company.cash = -50_000;
  for (let hour = 0; hour < 24; hour += 1) engine.stepHour();
  check('going under is recorded', rescued.stats.bankrupt, 'the company was not marked insolvent');
  company.cash = 120_000;
  for (let hour = 0; hour < 24; hour += 1) engine.stepHour();
  check('trading out of it clears the record', !rescued.stats.bankrupt, 'the company is still marked bankrupt with money in the bank');
  check('the player is told', rescued.news.some((n) => n.headline.includes('traded out of insolvency')));
}

heading('17. The ledger balances');
const ledgerSum = sum(long.state.ledger, (entry) => entry.amount);
check('every ledger entry is finite', long.state.ledger.every((e) => Number.isFinite(e.amount)));
check('the ledger has entries in every day it traded', long.state.ledger.length > 100, `${long.state.ledger.length}`);
check('the ledger total is a real number', Number.isFinite(ledgerSum));

heading('18. The map holds together');
{
  const report = validateMap();
  const counts: Record<string, number> = {};
  for (const problem of report.problems) counts[problem.kind] = (counts[problem.kind] ?? 0) + 1;
  const summary = Object.entries(counts).map(([kind, n]) => `${n} ${kind}`).join(', ');
  check('the city has the units the economy is balanced against', report.counts.plots === 390, `${report.counts.plots}`);
  check('the road network is one connected network', (counts.unreachable ?? 0) === 0, `${counts.unreachable ?? 0} junctions cut off`);
  check('no building stands on another', (counts.overlap ?? 0) === 0, `${counts.overlap ?? 0} overlaps`);
  check('every trading unit fronts onto a road', (counts['no-road-access'] ?? 0) === 0, `${counts['no-road-access'] ?? 0} with none`);
  check('no vehicle is sent through a building to park', (counts['blocked-approach'] ?? 0) === 0, `${counts['blocked-approach'] ?? 0} blocked`);
  check('every asset the map asks for exists in the pack', (counts['missing-asset'] ?? 0) === 0, `${counts['missing-asset'] ?? 0} missing`);
  check('nothing is off the map', (counts['out-of-bounds'] ?? 0) === 0, `${counts['out-of-bounds'] ?? 0} outside`);
  check('the map reports no problems at all', report.problems.length === 0, summary);
  check('there are car parks a vehicle can get into', report.counts.parking >= 20, `${report.counts.parking}`);
  check('traffic can cross the city corner to corner', routeAcrossCity() > 10, `${routeAcrossCity()} legs`);
}

heading('19. Growth systems do what they say');
{
  const grown = runScenario({ typeId: 'convenience', days: 60, strategy: 'best' }).state;
  const shop = playerBusinesses(grown)[0];

  // ---------------------------------------------------------- research
  // Attendance is a dice roll per person per call, so this is averaged.
  const sample = (): number => {
    let total = 0;
    for (let i = 0; i < 400; i += 1) total += hourlyCapacity(grown, shop);
    return total / 400;
  };
  const before = sample();
  grown.research.done.push('efficiency');
  const after = sample();
  check(
    'an efficiency review really does raise throughput',
    after > before * 1.05 && after < before * 1.11,
    `${before.toFixed(2)} to ${after.toFixed(2)}`,
  );

  const cheapBefore = unitPrice(grown, SUPPLIERS[0].id, productIdFor(grown), 1);
  grown.research.done.push('lean');
  const cheapAfter = unitPrice(grown, SUPPLIERS[0].id, productIdFor(grown), 1);
  check('lean production really does cut the buying price', cheapAfter < cheapBefore, `${cheapBefore} to ${cheapAfter}`);

  check('every research project changes something the simulation uses', RESEARCH.every((node) => EFFECTS.has(node.effect)));
  check(
    'a bigger company can borrow more against the same assets',
    creditMultiplier({ ...grown, levelReached: 5 }) > creditMultiplier({ ...grown, levelReached: 1 }),
  );
  check(
    'research is closed to a company too small to carry it',
    !canStart(grown, 'branding').ok,
    canStart(grown, 'branding').reason,
  );

  // --------------------------------------------------------- contracts
  const client = runScenario({ typeId: 'convenience', days: 90, strategy: 'best' }).state;
  const offer = makeContractOffer(client);
  check('a contract offer can be generated once there is stock to supply', offer !== null);
  if (offer) {
    check('the offer is worth more than the goods cost', offer.unitPrice > (productFor(offer.productId)?.wholesalePrice ?? 0));
    check('the offer states what it needs', offer.requiresHeadcount >= 1);
    client.contractOffers.push(offer);
    // Force the company to meet the terms so the accept path is exercised.
    offer.requiresHeadcount = 0;
    offer.requiresWarehouse = false;
    const signed = acceptContract(client, offer.id);
    check('a contract can be signed', signed.ok, signed.message);
    check('signing puts it on the books', contractsOf(client).length === 1);

    // A week with the stock in hand pays; a week without costs.
    const contract = contractsOf(client)[0];
    const shopWithStock = playerBusinesses(client)[0];
    shopWithStock.stock[contract.productId] = contract.unitsPerWeek * 4;
    // A business client does not pay across a counter. The week is earned now
    // and invoiced on terms, which is the whole of the working-capital change:
    // the profit is real today and the money is real in a month or two.
    const cashBefore = playerCompany(client).cash;
    const owedBefore = sum(client.invoices, (i) => i.amount);
    contractsWeekly(client);
    const owedAfter = sum(client.invoices, (i) => i.amount);
    check('a delivered week is invoiced, not paid at the till',
      owedAfter > owedBefore && playerCompany(client).cash === cashBefore,
      `owed +${Math.round(owedAfter - owedBefore)}, cash ${Math.round(playerCompany(client).cash - cashBefore)}`);
    check('and the sale is revenue on the day it was earned',
      sum(client.dayHistory.slice(-1), (d) => d.revenue) >= 0);
    check('the week is counted', contractsOf(client)[0]?.weeksDone === 1);


    for (const business of playerBusinesses(client)) business.stock[contract.productId] = 0;
    for (const warehouse of client.warehouses) warehouse.stock[contract.productId] = 0;
    const cashShort = playerCompany(client).cash;
    contractsWeekly(client);
    check('a short week is charged a penalty', playerCompany(client).cash < cashShort);
    check('a short week is a strike', (client.contracts[0]?.missed ?? 0) === 1);

    contractsWeekly(client);
    contractsWeekly(client);
    check('three short weeks lose the contract', client.contracts[0]?.status === 'failed', client.contracts[0]?.status ?? 'gone');
  }

  // ---------------------------------------------------------- cashflow
  const sinking = runScenario({ typeId: 'convenience', days: 40, strategy: 'best', noStock: true, staff: 3 }).state;
  const first = forecastCash(sinking);
  check('the forecast produces a balance for every day of the horizon', first.balances.length === 30);
  check('every projected balance is a real number', first.balances.every((v) => Number.isFinite(v)));
  check('a shop with nothing to sell is losing money every day', first.dailyNet < 0, `${Math.round(first.dailyNet)}/day`);

  // Eight days of cover, so the warning is being asserted rather than the luck
  // of how much cash this particular run happened to have left.
  playerCompany(sinking).cash = Math.abs(first.dailyNet) * 8;
  const view = forecastCash(sinking);
  check('the forecast sees the account empty', view.emptyOnDay !== null);
  check('the runway is about the cover that is left', view.runway >= 7 && view.runway <= 10, `${view.runway} days`);
  check('a company burning cash is told it will run out', cashWarning(sinking) !== null);

  // And a company with plenty of cover is not nagged.
  playerCompany(sinking).cash = Math.abs(first.dailyNet) * 200;
  check('a company with cover is left alone', cashWarning(sinking) === null);
}

heading('20. People are good at particular jobs');
{
  const team = runScenario({ typeId: 'convenience', days: 40, strategy: 'best' }).state;

  // Every role has to ask for something, and ask for a whole person's worth.
  const badWeights = (Object.keys(ROLE_SKILLS) as (keyof typeof ROLE_SKILLS)[]).filter((roleId) => {
    const weight = Object.values(ROLE_SKILLS[roleId]).reduce((a, b) => a + (b ?? 0), 0);
    return Math.abs(weight - 1) > 0.001;
  });
  check('every role asks for a whole person', badWeights.length === 0, badWeights.join(', '));

  const flat = (min: number, max: number): number => (min + max) / 2;
  const cook = profileFor(70, 'cook', flat);
  const accountant = profileFor(70, 'accountant', flat);
  check(
    'a cook fits a kitchen better than an accountant does',
    roleFit(cook, 'cook') > roleFit(accountant, 'cook'),
    `${roleFit(cook, 'cook').toFixed(1)} vs ${roleFit(accountant, 'cook').toFixed(1)}`,
  );
  check(
    'and worse at the books than the accountant',
    roleFit(cook, 'accountant') < roleFit(accountant, 'accountant'),
    `${roleFit(cook, 'accountant').toFixed(1)} vs ${roleFit(accountant, 'accountant').toFixed(1)}`,
  );
  check(
    'two people of the same overall level are not the same hire',
    Math.abs(overallSkill(cook) - overallSkill(accountant)) < 0.5 &&
      Math.abs(roleFit(cook, 'cook') - roleFit(accountant, 'cook')) > 8,
  );
  check('a profile averages out to the level it was built from', Math.abs(overallSkill(cook) - 70) < 0.5, `${overallSkill(cook).toFixed(2)}`);

  // Performance has to move with the things the screen says it moves with.
  const person = team.employees[0];
  if (person) {
    person.workload = 40;
    person.morale = 80;
    const happy = performanceOf(person);
    person.morale = 25;
    const unhappy = performanceOf(person);
    check('unhappy people are worth less', unhappy < happy, `${happy.toFixed(1)} → ${unhappy.toFixed(1)}`);
    person.morale = 80;
    person.workload = 95;
    const swamped = performanceOf(person);
    check('swamped people are worth less', swamped < happy, `${happy.toFixed(1)} → ${swamped.toFixed(1)}`);
    person.workload = 40;

    const before = performanceOf(person);
    const wrongSeat = { ...person, role: person.role === 'accountant' ? 'cook' : 'accountant' } as typeof person;
    check('the wrong seat costs output', performanceOf(wrongSeat) < before, `${before.toFixed(1)} → ${performanceOf(wrongSeat).toFixed(1)}`);
  }

  // Training moves the skill the course was about, and only that one.
  const learner = team.employees.find((e) => e.trainingEndsOnDay === null);
  if (learner) {
    const engine = new Engine(team);
    const beforeSkills = { ...learner.skills };
    const started = startTraining(team, learner.id, 'leadership');
    check('somebody can be put on a named course', started.ok, started.message);
    for (let day = 0; day < 12; day += 1) for (let hour = 0; hour < 24; hour += 1) engine.stepHour();
    check(
      'the course moves the skill it was about',
      learner.skills.leadership > beforeSkills.leadership,
      `${beforeSkills.leadership.toFixed(1)} → ${learner.skills.leadership.toFixed(1)}`,
    );
    check(
      'and leaves the others alone',
      Math.abs(learner.skills.technical - beforeSkills.technical) < 0.001,
      `technical moved ${(learner.skills.technical - beforeSkills.technical).toFixed(2)}`,
    );
    check(
      'the headline figure stays the average of the six',
      Math.abs(learner.skill - overallSkill(learner.skills)) < 0.01,
    );
  }

  // Workload is read from what the shop actually had to serve.
  const busy = playerBusinesses(team)[0];
  if (busy) {
    const quiet = { ...busy, yesterday: { ...busy.yesterday, customers: 1, lostCustomers: 0 } };
    const rushed = { ...busy, yesterday: { ...busy.yesterday, customers: 4000, lostCustomers: 500 } };
    check('a quiet day is a light workload', workloadOf(team, quiet) < 30, `${workloadOf(team, quiet).toFixed(0)}`);
    check('a day that turned people away is a heavy one', workloadOf(team, rushed) > 80, `${workloadOf(team, rushed).toFixed(0)}`);
  }

  // An old save has no skill profile, and must not lose its people's ability.
  const old = JSON.parse(JSON.stringify(team)) as Record<string, unknown>;
  const oldPeople = (old.employees as Record<string, unknown>[]).map((e) => {
    const copy = { ...e };
    delete copy.skills;
    delete copy.workload;
    delete copy.trainingCourseId;
    return copy;
  });
  old.employees = oldPeople;
  const migrated = migrate(old);
  check('a save without skill profiles still loads', migrated !== null);
  if (migrated) {
    const restored = migrated.employees[0];
    const original = team.employees[0];
    check('everybody comes back with a profile', SKILL_IDS.every((id) => Number.isFinite(restored.skills[id])));
    check(
      'and at the level they were at before',
      Math.abs(restored.skill - original.skill) < 2,
      `${original.skill.toFixed(1)} → ${restored.skill.toFixed(1)}`,
    );
    check(
      'still suited to the job they hold',
      roleFit(restored.skills, restored.role) > overallSkill(restored.skills) * 0.9,
      `fit ${roleFit(restored.skills, restored.role).toFixed(1)} against overall ${overallSkill(restored.skills).toFixed(1)}`,
    );
    check('loading twice gives the same people', (() => {
      const again = migrate(JSON.parse(JSON.stringify(old)));
      return again !== null && Math.abs(again.employees[0].skills.technical - restored.skills.technical) < 0.001;
    })());
  }
}

heading('21. A business knows what it needs');
{
  const shop = runScenario({ typeId: 'convenience', days: 45, strategy: 'best' }).state;
  const business = playerBusinesses(shop)[0];
  const plan = staffingSummary(shop, business);

  check('every role the type needs is in the plan', plan.rows.length === businessTypeOrThrow(business.typeId).roles.length);
  // Every job the trade needs asks for somebody — except management, which a
  // small shop genuinely does not need, and the plan should say so rather than
  // inventing a manager for four people.
  check(
    'the plan asks for at least one of each, management aside',
    plan.rows.every((row) => row.required >= 1 || row.role === 'manager'),
  );
  check('recommended is never below required', plan.rows.every((row) => row.recommended >= row.required));
  check('the totals add up', plan.required === plan.rows.reduce((a, r) => a + r.required, 0));
  check('shortage and current agree', plan.shortage === plan.rows.reduce((a, r) => a + Math.max(0, r.required - r.current), 0));
  check('every figure in the plan is a real number', plan.rows.every((r) =>
    [r.required, r.recommended, r.current, r.gap].every((v) => Number.isFinite(v))));

  // The front-line requirement has to follow the trade, not sit still.
  const quiet = { ...business, yesterday: { ...business.yesterday, customers: 20, lostCustomers: 0 } };
  const heaving = { ...business, yesterday: { ...business.yesterday, customers: 900, lostCustomers: 200 } };
  const quietPlan = staffingPlan(shop, quiet);
  const busyPlan = staffingPlan(shop, heaving);
  check(
    'a busier shop needs more people',
    busyPlan[0].required > quietPlan[0].required,
    `${quietPlan[0].required} → ${busyPlan[0].required}`,
  );

  // Size, management cover and what thin management costs.
  check('a shop with a handful of staff is small', sizeOf(shop, business).id === 'small' || shop.employees.length >= 6);
  check('a small business needs no managers to run smoothly', managementFactor(shop, { ...business } as typeof business) <= 1);
  const big = { ...business, id: 'big-test' } as typeof business;
  for (let i = 0; i < 8; i += 1) {
    shop.employees.push({ ...shop.employees[0], id: `filler-${i}`, role: 'cashier', grade: 1, businessId: 'big-test' });
  }
  check('eight people is a growing business', sizeOf(shop, big).id === 'growing', sizeOf(shop, big).id);
  for (let i = 8; i < 20; i += 1) {
    shop.employees.push({ ...shop.employees[0], id: `filler-${i}`, role: 'cashier', grade: 1, businessId: 'big-test' });
  }
  check('twenty is a large one', sizeOf(shop, big).id === 'large', sizeOf(shop, big).id);
  check('with no managers it runs slower', managementFactor(shop, big) < 1, `${managementFactor(shop, big).toFixed(2)}`);
  check('and it costs money to coordinate', adminCostPerDay(shop, big) > 0, `${adminCostPerDay(shop, big).toFixed(2)}/day`);

  // Span of control, not a headcount of job titles: somebody called a manager
  // who has never been promoted covers nobody, and the plan should not pretend
  // otherwise. Two real managers cover twenty people; two juniors do not.
  shop.employees.push({ ...shop.employees[0], id: 'name-only', role: 'manager', grade: 0, businessId: 'big-test' });
  check(
    'a manager in name only fixes nothing',
    managementFactor(shop, big) < 1,
    `${managementFactor(shop, big).toFixed(2)}`,
  );
  const thin = managementCover(shop, big);
  shop.employees.push({ ...shop.employees[0], id: 'boss-1', role: 'manager', grade: 5, businessId: 'big-test' });
  shop.employees.push({ ...shop.employees[0], id: 'boss-2', role: 'manager', grade: 5, businessId: 'big-test' });
  check(
    'real managers move it a long way',
    managementCover(shop, big) > thin + 0.25,
    `${thin.toFixed(2)} -> ${managementCover(shop, big).toFixed(2)}`,
  );

  // Enough of them, and the penalty goes entirely. How many "enough" is depends
  // on who the team are — a difficult team takes more managing than an easy
  // one — so the test hires until it is covered and then checks it did not take
  // an absurd number to get there, which is the property that actually matters.
  let added = 0;
  while (managementCover(shop, big) < 1 && added < 8) {
    added += 1;
    shop.employees.push({ ...shop.employees[0], id: `boss-extra-${added}`, role: 'manager', grade: 6, businessId: 'big-test' });
  }
  check('enough of them put it right', managementFactor(shop, big) === 1, `${managementFactor(shop, big).toFixed(2)}`);
  check('and it does not take an absurd number of them', added <= 5, `${2 + added} managers for ${23} people`);
  check(
    'past full cover it stops paying',
    managementCover(shop, big) <= 1.25,
    `cover ${managementCover(shop, big).toFixed(2)}`,
  );

  // Departments are a grouping of the roles that exist, not a second payroll.
  const rows = departmentsOf(shop, business);
  check('departments only appear when somebody works in them', rows.every((row) => row.people.length > 0));
  check(
    'everybody on the payroll is in exactly one department',
    employeesOf(shop, business.id).length === rows.reduce((a, r) => a + r.people.length, 0),
  );
  check('the departmental payroll is the real payroll', Math.abs(
    rows.reduce((a, r) => a + r.payroll, 0) - employeesOf(shop, business.id).reduce((a, p) => a + p.salary, 0),
  ) < 0.01);

  // Findings have to read the same figures the screen does.
  const problems = findings(shop, business);
  check('a business always has something to say about itself', problems.length > 0);
  check('every finding has a title and a reason', problems.every((f) => f.title.length > 0 && f.detail.length > 0));

  // Coordination really is charged, and shows up under its own name.
  const costed = runScenario({ typeId: 'coffeeshop', days: 30, strategy: 'best' }).state;
  const bigShop = playerBusinesses(costed)[0];
  for (let i = 0; i < 12; i += 1) {
    const clone = { ...costed.employees[0], id: `growth-${i}`, businessId: bigShop.id };
    costed.employees.push(clone);
    bigShop.employeeIds.push(clone.id);
  }
  const engine = new Engine(costed);
  const before = costed.ledger.filter((e) => e.category === 'management').length;
  for (let hour = 0; hour < 48; hour += 1) engine.stepHour();
  const after = costed.ledger.filter((e) => e.category === 'management').length;
  check('a team that has outgrown itself is charged for it', after > before, `${before} → ${after} entries`);
}

heading('22. A head office serves the shops');
{
  const group = runScenario({ typeId: 'coffeeshop', days: 40, strategy: 'best' }).state;
  playerCompany(group).cash += 400_000;

  check('a company starts without one', group.headOffice === null);
  // Recruiting has two inputs now — a personnel department, and whether anybody
  // wants to work here — so employer standing is pinned at its neutral middle
  // to isolate what this section is actually about, which is the head office.
  group.standing.employer = 50;
  check('and every central effect is neutral until it has one', (
    recruitmentFee(group) === RECRUITMENT_FEE &&
    retentionFactor(group) === 1 &&
    coordinationFactor(group) === 1 &&
    taxFactor(group) === 1 &&
    marketingFactor(group) === 1 &&
    penaltyFactor(group) === 1
  ));

  const spare = group.buildings.find((b) => b.status === 'available');
  if (spare) {
    rentBuilding(group, spare.id);
    const opened = openHeadOffice(group, spare.id, 'Halstead House');
    check('a head office can be opened in a unit the company holds', opened.ok, opened.message);
    check('opening it twice is refused', !openHeadOffice(group, spare.id, 'Again').ok);

    // Staffing a function, and what that is worth.
    const feeBefore = recruitmentFee(group);
    for (let i = 0; i < 3; i += 1) {
      const applicant = generateApplicant(group, 'hr');
      group.applicants.push(applicant);
      const hired = hireToHeadOffice(group, applicant.id);
      if (i === 0) check('somebody can be taken on centrally', hired.ok, hired.message);
    }
    check('a shop worker cannot be hired into the head office', (() => {
      const wrong = generateApplicant(group, 'cashier');
      group.applicants.push(wrong);
      return !hireToHeadOffice(group, wrong.id).ok;
    })());
    check('HR cover is now above nothing', cover(group, 'hr') > 0, `${cover(group, 'hr').toFixed(2)}`);
    check('and recruitment costs less than it did', recruitmentFee(group) < feeBefore, `${feeBefore} → ${recruitmentFee(group)}`);
    check('people are less likely to walk', retentionFactor(group) < 1, `${retentionFactor(group).toFixed(2)}`);

    // Outsourcing: cheaper to start, never as good.
    const staffedHr = cover(group, 'hr');
    setOutsourced(group, 'legal', true);
    check('a function can be bought in instead', cover(group, 'legal') > 0 && cover(group, 'legal') < 1);
    check('and it costs a monthly fee', outsourcingBill(group) > 0, `${outsourcingBill(group)}`);
    check('bought-in cover is worse than staffing it properly', cover(group, 'legal') < staffedHr || staffedHr < 0.55);
    check('contract penalties fall once legal is covered', penaltyFactor(group) < 1, `${penaltyFactor(group).toFixed(2)}`);
    setOutsourced(group, 'legal', false);
    check('and stopping puts it back', cover(group, 'legal') === 0 && outsourcingBill(group) === 0);

    // Every function has to actually reach the simulation.
    setOutsourced(group, 'finance', true);
    check('finance reaches the tax bill', taxFactor(group) < 1, `${taxFactor(group).toFixed(3)}`);
    check('and the coordination bill', coordinationFactor(group) < 1, `${coordinationFactor(group).toFixed(3)}`);
    setOutsourced(group, 'marketing', true);
    check('marketing reaches campaign spend', marketingFactor(group) > 1, `${marketingFactor(group).toFixed(3)}`);
    setOutsourced(group, 'it', true);
    check('IT reaches the staffing plan', automationRelief(group) > 0, `${automationRelief(group).toFixed(2)}`);

    // The scale advantage: more shops need more central staff, but not in proportion.
    const forOne = coverNeeded(group, FUNCTION_BY_ID.get('hr'));
    const many = { ...group, businesses: group.businesses } as typeof group;
    const extra = playerBusinesses(group)[0];
    for (let i = 0; i < 5; i += 1) many.businesses.push({ ...extra, id: `clone-${i}`, status: 'open' });
    const forSix = coverNeeded(many, FUNCTION_BY_ID.get('hr'));
    check('six shops need more central staff than one', forSix > forOne, `${forOne} → ${forSix}`);
    check('but not six times as many', forSix < forOne * 6, `${forOne} → ${forSix}`);

    // The bill is charged, and under its own name.
    const engine = new Engine(group);
    const before = group.ledger.filter((e) => e.category === 'outsourcing').length;
    for (let hour = 0; hour < 48; hour += 1) engine.stepHour();
    check('the outsourcing bill is actually charged', group.ledger.filter((e) => e.category === 'outsourcing').length > before);

    check('it cannot be closed with people still in it', !closeHeadOffice(group).ok);
  }
}

heading('23. The new depth costs money rather than printing it');
{
  // Everything added in this update has to be visible in the books, and none of
  // it may quietly make the company richer.
  const run = runScenario({ typeId: 'coffeeshop', days: 120, strategy: 'best' }).state;
  const account = run.accounts[run.accounts.length - 1];
  if (account) {
    check('the month has a people-cost total', Number.isFinite(account.people));
    check(
      'and it is at least the wage bill',
      account.people >= account.wages - 0.01,
      `${Math.round(account.people)} against wages of ${Math.round(account.wages)}`,
    );
    check('recruitment, management and outsourcing are all finite', (
      Number.isFinite(account.recruitment) && Number.isFinite(account.management) && Number.isFinite(account.outsourcing)
    ));
    check(
      'net profit still equals gross less everything else',
      Math.abs(account.netProfit - (account.grossProfit - account.overheads - account.interest - account.tax)) < 0.5,
    );
    check('every new cost is inside overheads', account.overheads >= account.management + account.recruitment + account.outsourcing - 0.01);
  }

  // A head office is a cost centre. Opening one and buying everything in must
  // make the company poorer, not richer, all else being equal.
  const withHq = runScenario({ typeId: 'coffeeshop', days: 60, strategy: 'best' }).state;
  playerCompany(withHq).cash += 300_000;
  const spare2 = withHq.buildings.find((b) => b.status === 'available');
  if (spare2) {
    rentBuilding(withHq, spare2.id);
    const opened = openHeadOffice(withHq, spare2.id, 'HQ');
    check('the head office opened for the cost test', opened.ok, opened.message);
    for (const def of FUNCTIONS) setOutsourced(withHq, def.id, true);
    check('every function is bought in', outsourcingBill(withHq) > 0, `${outsourcingBill(withHq)}`);
    const engine = new Engine(withHq);
    const before = playerCompany(withHq).cash;
    const spend = outsourcingBill(withHq);
    for (let day = 0; day < 30; day += 1) for (let hour = 0; hour < 24; hour += 1) engine.stepHour();
    const charged = withHq.ledger
      .filter((e) => e.category === 'outsourcing')
      .reduce((a, e) => a + -e.amount, 0);
    check('a month of bought-in services costs about a month of the fee', Math.abs(charged - spend) < spend * 0.15,
      `${Math.round(charged)} against ${Math.round(spend)}`);
    check('and the company is poorer for it than the fee alone', before - playerCompany(withHq).cash > 0 || charged > 0);
  }

  // Nothing anywhere may produce money from nothing.
  check('no ledger entry is an infinity', run.ledger.every((e) => Number.isFinite(e.amount)));
  check('the state has no broken numbers after 120 days of the new systems', findBadNumber(run) === null, findBadNumber(run) ?? '');
}

// ---------------------------------------------------------------------------

heading('24. A career is a ladder, and most people do not reach the top of it');
{
  const state = createNewGame('Ladder Ltd', 4242);
  state.day = 200;

  // The example from the brief, made literal: a superb technician who cannot
  // run people. This is the whole point of splitting the ladder at Team Lead.
  const specialist = generateApplicant(state, 'technician');
  specialist.skills = { ...emptySkills(), technical: 98, service: 82, admin: 76, logistics: 78, sales: 62, finance: 58, communication: 70, leadership: 42 };
  syncOverall(specialist);
  specialist.grade = TOP_OF_TRADE;
  specialist.companyId = state.playerCompanyId;
  specialist.hiredOnDay = 1;
  specialist.lastRecognisedOnDay = 1;
  state.employees.push(specialist);

  check('the ladder has nine rungs', GRADES.length === 9, `${GRADES.length}`);
  // The trade track goes all the way to Specialist without ever asking for
  // leadership. That is the whole reason Specialist exists.
  check('the trade track never asks for leadership',
    GRADES.slice(0, TOP_OF_TRADE + 1).every((g) => g.leadership === 0));
  check('and its top rung is worth reaching', GRADES[TOP_OF_TRADE].pay > GRADES[1].pay * 1.3,
    `×${GRADES[TOP_OF_TRADE].pay}`);
  check('the rung above it does ask for leadership', GRADES[TOP_OF_TRADE + 1].leadership > 0);
  const wall = quotePromotion(state, specialist);
  check('a 98-technical, 42-leadership specialist is stuck at the top of the trade',
    wall.blocked !== null, wall.blocked ?? 'not blocked');
  check('and their title says so, rather than calling them junior anything',
    titleOf(specialist).startsWith('Specialist'), titleOf(specialist));
  // The message has to send the player to train the right thing. A specialist's
  // overall level is often under the bar *because* their leadership is, so the
  // reason must name leadership rather than the number it drags down.
  check('and the reason names leadership, not their trade', (wall.blocked ?? '').toLowerCase().includes('leadership'), wall.blocked ?? '');


  // The only thing that moves them is the skill the rung actually asks for.
  specialist.skills.leadership = 70;
  syncOverall(specialist);
  const open = quotePromotion(state, specialist);
  check('leadership training opens the rung', open.blocked === null, open.blocked ?? '');
  check('a team lead is still on the floor, and a manager is not',
    !GRADES[TOP_OF_TRADE + 1].managerial && GRADES[TOP_OF_TRADE + 2].managerial);

  const before = titleOf(specialist);
  promote(state, specialist.id);
  check('promotion moves them up exactly one rung', gradeOf(specialist).n === TOP_OF_TRADE + 1,
    `${before} -> ${titleOf(specialist)}`);

  // Rungs must not be free money: the pay rises faster than the output does.
  const junior = generateApplicant(state, 'cook');
  junior.skills = { ...emptySkills(), technical: 70, service: 60, logistics: 60, admin: 50, sales: 40, finance: 40, communication: 50, leadership: 50 };
  syncOverall(junior);
  junior.grade = 0;
  junior.morale = 70;
  junior.workload = 45;
  const senior = { ...junior, id: 'senior-copy', grade: 2 };
  const payStep = rungRate(2650, 2, junior.skill) / rungRate(2650, 0, junior.skill);
  check('only the most senior rungs can be handed a division',
    GRADES.filter(canRunDivision).length >= 3 && !canRunDivision(GRADES[TOP_OF_TRADE + 1]));
  const workStep = performanceOf(senior) / performanceOf(junior);
  check('a rung costs more than it produces', payStep > workStep, `pay ×${payStep.toFixed(2)} against work ×${workStep.toFixed(2)}`);
  check('and not absurdly more', payStep < 1.7, `×${payStep.toFixed(2)}`);
  check('pay rises with the rung, every rung', GRADES.every((g, i) => i === 0 || g.pay > GRADES[i - 1].pay));
  check('so does what one person can supervise', GRADES.filter((g) => g.span > 0).every((g, i, list) => i === 0 || g.span > list[i - 1].span));
}

heading('25. Management is measured in people, not job titles');
{
  const shop = runScenario({ typeId: 'convenience', days: 30, strategy: 'best' }).state;
  const business = playerBusinesses(shop)[0];
  const staff = employeesOf(shop, business.id);
  check('there is somebody to manage', staff.length > 0);

  // Who somebody is changes how much managing they take.
  const awkward = { ...staff[0], id: 'awkward', traits: ['difficult'] as typeof staff[0]['traits'], businessId: business.id };
  const easy = { ...staff[0], id: 'easy', traits: ['independent'] as typeof staff[0]['traits'], businessId: business.id };
  shop.employees.push(awkward);
  const withAwkward = supervisionLoad(shop, business);
  shop.employees = shop.employees.filter((e) => e.id !== 'awkward');
  shop.employees.push(easy);
  const withEasy = supervisionLoad(shop, business);
  shop.employees = shop.employees.filter((e) => e.id !== 'easy');
  check('a difficult person takes more managing than an independent one', withAwkward > withEasy,
    `${withAwkward.toFixed(2)} against ${withEasy.toFixed(2)}`);

  // A rung with a span adds capacity; one without adds none.
  const base = supervisionCapacity(shop, business);
  shop.employees.push({ ...staff[0], id: 'lead', grade: 4, businessId: business.id });
  const withLead = supervisionCapacity(shop, business);
  check('a team lead adds supervision capacity', withLead > base, `${base.toFixed(1)} -> ${withLead.toFixed(1)}`);
  shop.employees = shop.employees.filter((e) => e.id !== 'lead');
  shop.employees.push({ ...staff[0], id: 'nominal', grade: 0, role: 'manager' as const, businessId: business.id });
  check('a manager who has never been promoted adds none',
    Math.abs(supervisionCapacity(shop, business) - base) < 0.001);
  shop.employees = shop.employees.filter((e) => e.id !== 'nominal');
  check('cover is never worth more than a little over full', managementCover(shop, business) <= 1.25);
  check('and never negative', managementCover(shop, business) >= 0);
}

heading('26. A trade is a trade, and they are not the same trade');
{
  const restaurant = businessTypeOrThrow('restaurant');
  const convenience = businessTypeOrThrow('convenience');
  check('a restaurant is harder to run than a corner shop', restaurant.complexity > convenience.complexity,
    `${restaurant.complexity} against ${convenience.complexity}`);
  check('which costs more to coordinate', complexityOf(restaurant) > complexityOf(convenience));
  check('a restaurant lives or dies on its reputation more', restaurant.reputationSensitivity > convenience.reputationSensitivity);
  check('and less of its work can be automated', restaurant.automatable < convenience.automatable);
  check('every type says what it needs people to be good at', BUSINESS_TYPES.every((t) => t.keySkills.length > 0));
  check('and every one of those is a real skill', BUSINESS_TYPES.every((t) => t.keySkills.every((id) => SKILL_IDS.includes(id))));
  check('every type services its equipment', BUSINESS_TYPES.every((t) => t.equipmentUpkeep > 0));

  // The same person is not equally useful everywhere.
  const cook = generateApplicant(createNewGame('Fit Ltd', 7), 'cook');
  cook.skills = { ...emptySkills(), technical: 90, logistics: 70, service: 60, communication: 55, admin: 30, finance: 20, sales: 25, leadership: 30 };
  const clerk = { ...cook, skills: { ...emptySkills(), admin: 90, finance: 85, logistics: 70, technical: 20, service: 40, communication: 60, sales: 30, leadership: 35 } };
  check('a cook suits a restaurant better than a bookkeeper does',
    tradeFitOf(cook, restaurant) > tradeFitOf(clerk, restaurant),
    `${Math.round(tradeFitOf(cook, restaurant))} against ${Math.round(tradeFitOf(clerk, restaurant))}`);
  check('and a bookkeeper suits a distribution business better than the cook',
    tradeFitOf(clerk, businessTypeOrThrow('logistics')) > tradeFitOf(cook, businessTypeOrThrow('logistics')));

  // Eight skills, and the desk jobs no longer share a brain.
  check('there are eight skills', SKILL_IDS.length === 8, SKILL_IDS.join(', '));
  check('finance and communication are among them', SKILL_IDS.includes('finance') && SKILL_IDS.includes('communication'));
  check('an accountant leans on finance more than a solicitor does',
    (ROLE_SKILLS.accountant.finance ?? 0) > (ROLE_SKILLS.legal.finance ?? 0));
  check('a solicitor leans on paperwork more than an accountant does',
    (ROLE_SKILLS.legal.admin ?? 0) > (ROLE_SKILLS.accountant.admin ?? 0));
  check('a personnel officer leans on people, not paperwork',
    (ROLE_SKILLS.hr.communication ?? 0) + (ROLE_SKILLS.hr.leadership ?? 0) > (ROLE_SKILLS.hr.admin ?? 0));
  check('every role still weighs to one', (Object.values(ROLE_SKILLS) as Record<string, number>[]).every(
    (weights) => Math.abs(Object.values(weights).reduce((a, b) => a + b, 0) - 1) < 0.0001));
}

heading('27. A head office has floors, a stance and systems, and all three cost');
{
  const state = createNewGame('Central Ltd', 9090);
  const company = playerCompany(state);
  company.cash = 4_000_000;
  const unit = state.buildings.find((b) => b.status === 'available' && b.size > 80);
  if (!unit) throw new Error('no unit for the head office test');
  rentBuilding(state, unit.id);
  check('a head office opens', openHeadOffice(state, unit.id, 'Central').ok);
  check('it starts as a back office', hqLevel(state).n === 1, hqLevel(state).name);

  const desks = hqLevel(state).desks;
  const beforeCash = playerCompany(state).cash;
  check('upgrading it costs real money', upgradeHeadOffice(state).ok && playerCompany(state).cash < beforeCash);
  check('and buys desks', hqLevel(state).desks > desks, `${desks} -> ${hqLevel(state).desks}`);
  check('a bigger floor gets more out of the same people', hqLevel(state).reach > HQ_LEVELS[0].reach);
  check('and costs more every month', overheadBill(state) > 0, `${overheadBill(state)}`);

  // Desks are a real limit on hiring, not a decoration.
  const room = hqLevel(state).desks;
  for (let i = 0; i < room + 3; i += 1) {
    const person = generateApplicant(state, 'hr');
    state.applicants.push(person);
    hireToHeadOffice(state, person.id);
  }
  check('desks cap how many people the centre can hold', centralStaff(state).length === room,
    `${centralStaff(state).length} of ${room}`);
  const overflow = generateApplicant(state, 'hr');
  state.applicants.push(overflow);
  const refused = hireToHeadOffice(state, overflow.id);
  check('and the refusal says why', !refused.ok && /desk/i.test(refused.message), refused.message);

  // Centralising is a trade, not an upgrade.
  setStance(state, 'central');
  const centralCoordination = coordinationFactor(state);
  const centralLocal = localResponsiveness(state);
  setStance(state, 'local');
  check('running it from the centre costs less to coordinate', centralCoordination < coordinationFactor(state),
    `${centralCoordination.toFixed(2)} against ${coordinationFactor(state).toFixed(2)}`);
  check('and the shops read their own street worse for it', centralLocal < localResponsiveness(state),
    `${centralLocal.toFixed(2)} against ${localResponsiveness(state).toFixed(2)}`);
  setStance(state, 'hybrid');
  check('the middle is in the middle on both counts',
    coordinationFactor(state) > centralCoordination && localResponsiveness(state) < 1.12);

  // Systems are the third way to cover a function.
  const coverBefore = cover(state, 'legal');
  const cashBefore = playerCompany(state).cash;
  const invested = investInAutomation(state, 'legal');
  check('systems can be installed', invested.ok, invested.message);
  check('they cost capital', playerCompany(state).cash < cashBefore);
  check('they cover a function with nobody in the seat', cover(state, 'legal') > coverBefore,
    `${coverBefore.toFixed(2)} -> ${cover(state, 'legal').toFixed(2)}`);
  check('and they never cover it entirely', automationCover(state, 'legal') < 0.6);
  check('a bigger head office is needed for the deepest systems',
    HQ_LEVELS[0].automationCap < HQ_LEVELS[4].automationCap);
}

heading('28. A company gets bigger than one person, and has to be delegated');
{
  const state = createNewGame('Empire Ltd', 5150);
  playerCompany(state).cash = 20_000_000;
  state.levelReached = 8;
  check('one person is comfortable to start with', ownerAttention(state) === 1);
  check('and being comfortable costs nothing', attentionFactor(state) === 1);

  let made = 0;
  for (const building of state.buildings) {
    if (made >= OWNER_ATTENTION + 3) break;
    if (building.status !== 'available') continue;
    const type = BUSINESS_TYPES.find((t) => building.size >= t.minSize && building.suitableFor.includes(t.category));
    if (!type) continue;
    if (!rentBuilding(state, building.id).ok) continue;
    if (!foundBusiness(state, type.id, building.id, `Site ${made + 1}`).ok) continue;
    made += 1;
  }
  check('a company can be built past what one person carries', made > OWNER_ATTENTION, `${made} locations`);
  check('and attention falls when it is', ownerAttention(state) < 1, ownerAttention(state).toFixed(2));
  check('which costs every location money', attentionFactor(state) > 1, `×${attentionFactor(state).toFixed(2)}`);

  const division = createDivision(state, 'Bought Group', 'somebody else');
  for (const business of playerBusinesses(state).slice(0, 3)) business.divisionId = division.id;
  check('a division holds the locations put in it', divisionBusinesses(state, division.id).length === 3);

  // Only somebody senior enough can be handed one, and the refusal says why.
  const junior = generateApplicant(state, 'manager');
  junior.grade = 2;
  junior.companyId = state.playerCompanyId;
  state.employees.push(junior);
  const tooJunior = appointHead(state, division.id, junior.id);
  check('a junior cannot be handed a division', !tooJunior.ok);
  check('and the refusal explains the ladder', /leadership|senior manager/i.test(tooJunior.message), tooJunior.message);

  const exec = generateApplicant(state, 'manager');
  exec.grade = 6;
  exec.morale = 80;
  exec.workload = 40;
  exec.companyId = state.playerCompanyId;
  state.employees.push(exec);
  const stretched = ownerAttention(state);
  check('an executive can', appointHead(state, division.id, exec.id).ok);
  check('and it hands the owner their attention back', ownerAttention(state) > stretched,
    `${stretched.toFixed(2)} -> ${ownerAttention(state).toFixed(2)}`);
  const inside = divisionBusinesses(state, division.id)[0];
  check('a division head is management at the locations under them', delegatedSupervision(state, inside) > 0,
    `${delegatedSupervision(state, inside).toFixed(1)}`);
  check('spread across all of them rather than counted once each',
    delegatedSupervision(state, inside) < GRADES[6].span);
  check('nobody runs two divisions at once', (() => {
    const second = createDivision(state, 'Second', 'nobody');
    playerBusinesses(state)[4].divisionId = second.id;
    appointHead(state, second.id, exec.id);
    return state.divisions.filter((d) => d.headEmployeeId === exec.id).length === 1;
  })());
}

heading('29. A version 1 save still loads, and nobody loses standing');
{
  // Exactly what an older build wrote: six skills, a promotion count, no grade,
  // no divisions, and a head office with no floors.
  const old = {
    version: 1,
    seed: 12345,
    day: 140,
    hour: 9,
    speed: 2,
    playerCompanyId: 'co-1',
    companies: [{ id: 'co-1', name: 'Old Save Ltd', isPlayer: true, cash: 120000, creditRating: 60, brandAwareness: 20, foundedOnDay: 1, personality: null }],
    buildings: [],
    businesses: [],
    employees: [
      {
        id: 'emp-books', name: 'Vera Books', age: 41, role: 'accountant', salary: 3400, skill: 78,
        skills: { technical: 40, sales: 30, service: 45, logistics: 35, admin: 88, leadership: 55 },
        experience: 12, productivity: 70, reliability: 85, morale: 66, stress: 20, loyalty: 70,
        traits: ['loyal'], businessId: null, companyId: 'co-1', hiredOnDay: 3, trainingDays: 2,
        trainingEndsOnDay: null, sickUntilDay: null, promotions: 2, lastRecognisedOnDay: 40,
      },
      {
        id: 'emp-boss', name: 'Ida Roth', age: 50, role: 'manager', salary: 4200, skill: 72,
        skills: { technical: 40, sales: 50, service: 60, logistics: 40, admin: 70, leadership: 80 },
        experience: 20, productivity: 75, reliability: 90, morale: 70, stress: 25, loyalty: 80,
        traits: [], businessId: null, companyId: 'co-1', hiredOnDay: 3, trainingDays: 4,
        trainingEndsOnDay: null, sickUntilDay: null, promotions: 3, lastRecognisedOnDay: 60,
      },
    ],
    applicants: [],
    headOffice: { id: 'hq-1', companyId: 'co-1', buildingId: 'b-1', name: 'Old HQ', openedOnDay: 50, employeeIds: [], outsourced: { hr: true } },
  };
  const loaded = migrate(old);
  check('a version 1 save loads at all', loaded !== null);
  if (loaded) {
    check('and is stamped with the current version', loaded.version === SAVE_VERSION, `${loaded.version}`);
    const books = loaded.employees.find((e) => e.id === 'emp-books');
    const boss = loaded.employees.find((e) => e.id === 'emp-boss');
    check('everybody has all eight skills', loaded.employees.every((e) => SKILL_IDS.every((id) => Number.isFinite(e.skills[id]))));
    check('the six that were saved are kept exactly', books?.skills.admin === 88 && books?.skills.leadership === 55);
    check('the two new ones are inferred, not zeroed', (books?.skills.finance ?? 0) > 20, `${Math.round(books?.skills.finance ?? 0)}`);
    check('an accountant is still good at the job they were good at',
      roleFit(books!.skills, 'accountant') > 55, `${Math.round(roleFit(books!.skills, 'accountant'))}`);
    check('everybody has a rung', loaded.employees.every((e) => Number.isFinite(e.grade)));
    check('two promotions in the old game still reads as Senior', gradeOf(books!).n === 2, titleOf(books!));
    check('a manager is still a manager', gradeOf(boss!).managerial, titleOf(boss!));
    check('nobody has a rung off the ladder', loaded.employees.every((e) => e.grade >= 0 && e.grade < GRADES.length));
    check('the head office opens as a back office', loaded.headOffice?.level === 1);
    check('run the middle way', loaded.headOffice?.stance === 'hybrid');
    check('with nothing automated', FUNCTIONS.every((f) => (loaded.headOffice?.automation[f.id] ?? 0) === 0));
    check('and what it had bought in is remembered', loaded.headOffice?.outsourced.hr === true);
    check('a save with no divisions loads with none', Array.isArray(loaded.divisions) && loaded.divisions.length === 0);
    check('nothing in the migrated save is a broken number', findBadNumber(loaded) === null, findBadNumber(loaded) ?? '');
  }
}

heading('30. Morale is a reading, not a ratchet');
{
  // A number that climbs to a hundred in a month and stays there is a number
  // the player learns to ignore. It has to settle where the conditions put it,
  // move when they move, and come back down when a rise wears off.
  const calm = runScenario({ typeId: 'convenience', days: 150, strategy: 'best' }).state;
  const team = calm.employees.filter((e) => e.companyId === calm.playerCompanyId);
  check('a well-run shop still has its people after five months', team.length > 0, `${team.length} left`);
  if (team.length > 0) {
    const morale = sum(team, (e) => e.morale) / team.length;
    check('who are content rather than euphoric', morale > 45 && morale < 92, `${Math.round(morale)}`);
    check('and none of them is pinned at the ceiling', team.every((e) => e.morale < 99.5),
      `highest ${Math.round(Math.max(...team.map((e) => e.morale)))}`);
  }

  // Pay moves it, in the direction you would expect.
  const shop = runScenario({ typeId: 'convenience', days: 20, strategy: 'best' }).state;
  const person = shop.employees.filter((e) => e.companyId === shop.playerCompanyId)[0];
  if (person) {
    const rate = marketRate(shop, person);
    const shopEngine = new Engine(shop);
    setSalary(shop, person.id, Math.round(rate * 0.6));
    for (let day = 0; day < 60; day += 1) for (let hour = 0; hour < 24; hour += 1) shopEngine.stepHour();
    const underpaid = shop.employees.find((e) => e.id === person.id);
    check('somebody on well under the rate ends up unhappy', !underpaid || underpaid.morale < 55,
      underpaid ? `${Math.round(underpaid.morale)}` : 'they left, which is the same answer');
    if (underpaid) {
      setSalary(shop, person.id, Math.round(rate * 1.35));
      for (let day = 0; day < 60; day += 1) for (let hour = 0; hour < 24; hour += 1) shopEngine.stepHour();
      const after = shop.employees.find((e) => e.id === person.id);
      check('and paying them properly brings it back', !after || after.morale > underpaid.morale,
        after ? `${Math.round(underpaid.morale)} -> ${Math.round(after.morale)}` : 'they had already gone');
    }
  }
}

heading('31. Borrowing, and what paying it off early is actually worth');
{
  const state = createNewGame('Debt Ltd', 606);
  const company = playerCompany(state);
  company.creditRating = 80;
  company.cash = 400_000;

  // The schedule arithmetic has to agree with itself before anything else can.
  const payment = monthlyPayment(100_000, 0.06, 48);
  check('an annuity payment clears the loan in its term',
    Math.abs(monthsRemaining(100_000, 0.06, payment) - 48) <= 1, `${monthsRemaining(100_000, 0.06, payment)}`);
  check('and the interest is the payments less the principal',
    Math.abs(interestRemaining(100_000, 0.06, payment) - (48 * payment - 100_000)) < 1);
  check('a payment that does not cover the interest never clears it',
    !Number.isFinite(monthsRemaining(100_000, 0.12, 500)));
  check('an interest-free loan still ends', Number.isFinite(monthsRemaining(1_000, 0, 100)));

  // Several kinds of borrowing, each secured against something different.
  const offers = loanOffers(state);
  check('there is more than one kind of borrowing', offers.length >= 5, `${offers.length}`);
  check('every kind has its own term', new Set(offers.map((o) => o.termMonths)).size >= 4);
  check('and its own rate', new Set(offers.map((o) => Math.round(o.annualRate * 10000))).size >= 4);
  check('a mortgage needs a freehold', offers.find((o) => o.id === 'property')?.blocked !== null);
  check('equipment finance needs equipment', offers.find((o) => o.id === 'equipment')?.blocked !== null);
  check('emergency credit is not offered to a company that is fine',
    offers.find((o) => o.id === 'emergency')?.blocked !== null);
  check('the cheapest borrowing is the one secured on a building',
    LOAN_TYPES.find((t) => t.id === 'property')!.spread < LOAN_TYPES.find((t) => t.id === 'working')!.spread);
  check('and the dearest is the one secured on nothing in a hurry',
    LOAN_TYPES.find((t) => t.id === 'emergency')!.spread > Math.max(...LOAN_TYPES.filter((t) => t.id !== 'emergency').map((t) => t.spread)));

  const working = loanOffers(state).find((o) => o.id === 'working')!;
  const taken = takeLoan(state, 'working', working.maxPrincipal);
  check('a loan can be taken', taken.ok, taken.message);
  check('asking for more than the ceiling is refused, and says the ceiling',
    /will lend up to/i.test(takeLoan(state, 'working', working.maxPrincipal * 4).message));
  const loan = state.loans[0];
  check('and it remembers what kind it was', loan.typeId === 'working', loan.typeId);
  check('the cash arrives', playerCompany(state).cash > 400_000);

  // The quote before the click must be what happens after it.
  const before = monthsRemaining(loan.outstanding, loan.annualRate, loan.monthlyPayment);
  const quarter = quoteRepayment(state, loan.id, loan.outstanding * 0.25)!;
  check('a quarter is quoted as a quarter', Math.abs(quarter.amount - loan.outstanding * 0.25) < 1);
  check('paying it shortens the term', quarter.monthsAfter < quarter.monthsBefore,
    `${quarter.monthsBefore} -> ${quarter.monthsAfter}`);
  check('and saves interest', quarter.interestSaved > 0, `${Math.round(quarter.interestSaved)}`);
  check('the saving is never negative', quarter.interestSaved >= 0);

  const owedBefore = loan.outstanding;
  const cashBefore = playerCompany(state).cash;
  const done = repayLoan(state, loan.id, owedBefore * 0.25);
  check('the repayment goes through', done.ok, done.message);
  check('the outstanding balance matches the quote',
    Math.abs(loan.outstanding - quarter.outstandingAfter) < 1,
    `${Math.round(loan.outstanding)} against ${Math.round(quarter.outstandingAfter)}`);
  check('exactly that much left the bank account',
    Math.abs(cashBefore - playerCompany(state).cash - quarter.amount) < 1);
  check('the term really did shorten',
    monthsRemaining(loan.outstanding, loan.annualRate, loan.monthlyPayment) < before,
    `${before} -> ${monthsRemaining(loan.outstanding, loan.annualRate, loan.monthlyPayment)}`);
  check('the monthly payment is untouched — that is what shortens it',
    loan.monthlyPayment === Math.round(monthlyPayment(loan.principal, loan.annualRate, loan.termMonths)));
  check('and what was paid early is on the record', loan.earlyRepaid > 0);

  // Paying more must always save more. Checked on a large, long loan rather
  // than the small one above, because at eight months left the month counter
  // rounds and two different lump sums can land on the same answer — which is
  // honest arithmetic, not a broken rule.
  const big = 250_000;
  const bigPayment = monthlyPayment(big, 0.07, 120);
  const owedAt = (left: number): number => interestRemaining(left, 0.07, bigPayment);
  check('paying more always saves more',
    owedAt(big * 0.75) > owedAt(big * 0.5) && owedAt(big * 0.5) > owedAt(big * 0.25),
    `${Math.round(owedAt(big * 0.75))} > ${Math.round(owedAt(big * 0.5))} > ${Math.round(owedAt(big * 0.25))}`);
  check('and clearing it outright costs no more interest at all', owedAt(0) === 0);

  // A half, then the lot.
  const all = quoteRepayment(state, loan.id, loan.outstanding)!;
  check('paying the lot leaves nothing owing', all.outstandingAfter === 0);
  check('and takes every remaining month off', all.monthsAfter === 0);
  repayLoan(state, loan.id, loan.outstanding);
  check('the loan is gone', state.loans.length === 0);
  check('and clearing it helped the credit rating', playerCompany(state).creditRating > 80);

  // You cannot pay with money you do not have, and you cannot overpay.
  company.creditRating = 80;
  const again = loanOffers(state).find((o) => o.id === 'working')!;
  takeLoan(state, 'working', Math.max(1000, again.maxPrincipal));
  const second = state.loans[0];
  playerCompany(state).cash = 100;
  const broke = repayLoan(state, second.id, second.outstanding);
  check('you cannot repay with money you do not have', !broke.ok, broke.message);
  check('and the refusal says how short you are', /more than you have/i.test(broke.message), broke.message);
  playerCompany(state).cash = 500_000;
  const over = quoteRepayment(state, second.id, 999_999)!;
  check('an overpayment is capped at what is owed', over.amount <= second.outstanding + 0.5);
  check('so it can never go into credit', over.outstandingAfter >= 0);
  check('no loan figure is ever broken', findBadNumber(state) === null, findBadNumber(state) ?? '');
}

heading('32. Seven ways to start, and a person doing the starting');
{
  // Every scenario has to produce a company that behaves like one a player
  // built: real leases, real people, real trading history, nothing invented.
  for (const def of SCENARIOS) {
    const state = startGame({
      companyName: 'Scenario Co',
      founderName: 'Kevin',
      traitId: 'allrounder',
      scenarioId: def.id,
      seed: 424242,
    });
    const open = playerBusinesses(state).filter((b) => b.status === 'open');
    check(`${def.name} builds a company`, state.companies.length > 1 && playerCompany(state).cash > 0);
    check(`  and opens what it promised`, def.locations === 0 || open.length === def.locations,
      `${open.length} of ${def.locations}`);
    check(`  with people in it`, def.staffPerLocation === 0 || state.employees.length > 0, `${state.employees.length}`);
    check(`  and a trading history if it claims one`,
      def.warmUpDays === 0 || state.dayHistory.length > 0, `${state.dayHistory.length} days`);
    check(`  nothing broken anywhere in it`, findBadNumber(state) === null, findBadNumber(state) ?? '');
    check(`  and it is not insolvent before the player has done anything`, !state.stats.bankrupt);
  }

  // Every figure a scenario claims is the figure the company actually has.
  const empire = startGame({ companyName: 'Big Co', founderName: 'K', traitId: 'allrounder', scenarioId: 'empire', seed: 7 });
  check('the empire has a head office', empire.headOffice !== null);
  check('and carries the debt it says it does', empire.loans.length > 0);
  check('and the revenue it claims is real revenue from the ledger',
    sum(empire.dayHistory.slice(-30), (d) => d.revenue) > 0);
  const oneman = startGame({ companyName: 'Solo', founderName: 'K', traitId: 'allrounder', scenarioId: 'oneman', seed: 7 });
  check('the one-man band really does start alone', oneman.employees.length === 0);
  check('with less money than anybody else', oneman.companies.find((c) => c.isPlayer)!.cash < 40_000);

  // A custom start honours every figure it is given.
  const custom = startGame({
    companyName: 'Made Up Ltd',
    founderName: 'K',
    traitId: 'allrounder',
    scenarioId: 'custom',
    seed: 11,
    overrides: { cash: 500_000, locations: 2, staffPerLocation: 4, warmUpDays: 10, creditRating: 71, levelReached: 4 },
  });
  // A scenario hands over exactly the capital printed on its card. The warm-up
  // gives the company a past; it does not spend the player's stake first.
  check('a custom start honours the cash it was given', playerCompany(custom).cash === 500_000,
    `${Math.round(playerCompany(custom).cash)}`);
  check('and the credit rating', Math.abs(playerCompany(custom).creditRating - 71) < 25, `${Math.round(playerCompany(custom).creditRating)}`);
  check('and the level', custom.levelReached === 4);
  check('and opens the locations it was asked for',
    playerBusinesses(custom).filter((b) => b.status === 'open').length === 2,
    `${playerBusinesses(custom).filter((b) => b.status === 'open').length}`);
}

heading('33. The founder is a person, and every skill of theirs does something');
{
  // A background is where the seven skills start, not a bonus bolted on.
  const banker = startGame({ companyName: 'A', founderName: 'K', traitId: 'financier', scenarioId: 'entrepreneur', seed: 3 });
  const seller = startGame({ companyName: 'B', founderName: 'K', traitId: 'seller', scenarioId: 'entrepreneur', seed: 3 });
  check('a banker starts ahead on finance', skillOf(banker, 'finance') > skillOf(seller, 'finance'));
  check('and behind on selling', skillOf(banker, 'sales') < skillOf(seller, 'sales'));
  check('every background fills in all seven skills',
    FOUNDER_TRAITS.every((t) => FOUNDER_SKILL_IDS.every((id) => Number.isFinite(startingSkills(t.id)[id]))));
  check('and none of them starts anybody at nothing',
    FOUNDER_TRAITS.every((t) => FOUNDER_SKILL_IDS.every((id) => startingSkills(t.id)[id] > 0)));

  // Each skill has to reach the simulation. A skill that only prints would be
  // exactly the decoration this game is not supposed to have.
  check('finance reaches the rate a lender quotes', rateDiscount(banker) > rateDiscount(seller));
  check('and how much they will lend', lendingFactor(banker) > lendingFactor(seller));
  check('sales reaches what marketing buys', marketingSkillFactor(seller) > marketingSkillFactor(banker));

  const operator = startGame({ companyName: 'C', founderName: 'K', traitId: 'operator', scenarioId: 'entrepreneur', seed: 3 });
  check('operations reaches the coordination bill', operationsFactor(operator) < operationsFactor(banker));
  check('management reaches how much one person can hold', attentionSpan(operator) > attentionSpan(banker),
    `${attentionSpan(operator).toFixed(2)} against ${attentionSpan(banker).toFixed(2)}`);

  const strategist = startGame({ companyName: 'D', founderName: 'K', traitId: 'strategist', scenarioId: 'entrepreneur', seed: 3 });
  check('strategy reaches how long research takes', researchSpeed(strategist) > researchSpeed(operator));

  const floor = startGame({ companyName: 'E', founderName: 'K', traitId: 'shopfloor', scenarioId: 'entrepreneur', seed: 3 });
  check('leadership reaches everybody’s morale', moraleFromOwner(floor) > moraleFromOwner(strategist));
  check('negotiation reaches what suppliers charge', negotiationFactor(seller) < negotiationFactor(floor));

  // And the founder gets better by doing, rather than by spending points.
  const learner = startGame({ companyName: 'F', founderName: 'K', traitId: 'allrounder', scenarioId: 'small', seed: 5 });
  const before = { ...learner.founder!.skills };
  const engine = new Engine(learner);
  for (let day = 0; day < 120; day += 1) for (let hour = 0; hour < 24; hour += 1) engine.stepHour();
  const after = learner.founder!.skills;
  check('four months of trading teaches operations', after.operations > before.operations,
    `${Math.round(before.operations)} -> ${Math.round(after.operations)}`);
  check('and nobody learns anything they never did',
    after.negotiation >= before.negotiation && after.finance >= before.finance);
  check('no skill ever passes a hundred', FOUNDER_SKILL_IDS.every((id) => after[id] <= 100));
  check('and none of them goes backwards', FOUNDER_SKILL_IDS.every((id) => after[id] >= before[id]));
  check('learning leaves no broken numbers', findBadNumber(learner) === null, findBadNumber(learner) ?? '');

  // A save from before any of this opens with an ordinary founder rather than
  // nothing, so every effect keeps working on an old game.
  const old = migrate({
    version: 2,
    seed: 1,
    day: 40,
    hour: 9,
    speed: 0,
    playerCompanyId: 'co-1',
    companies: [{ id: 'co-1', name: 'Old Ltd', isPlayer: true, cash: 50000, creditRating: 55, brandAwareness: 10, foundedOnDay: 1, personality: null }],
    buildings: [],
    businesses: [],
    employees: [],
    applicants: [],
  });
  check('a save with no founder gets one', old?.founder != null);
  check('of no particular background', old?.founder?.traitId === 'allrounder');
  check('so nothing it multiplies by is broken', old ? Number.isFinite(attentionSpan(old)) && attentionSpan(old) > 0 : false);
}

heading('34. Two companies become one, and it costs what that costs');
{
  /** An empire, with three of its locations reorganised into a bought group. */
  const bought = (seed: number): GameState => {
    const state = startGame({ companyName: 'Meridian', founderName: 'K', traitId: 'allrounder', scenarioId: 'empire', seed });
    const group = createDivision(state, 'Northfield Group', 'Northfield Retail Ltd');
    for (const business of playerBusinesses(state).filter((b) => b.status === 'open').slice(0, 3)) {
      assignToDivision(state, business.id, group.id);
    }
    return state;
  };

  const state = bought(21);
  const group = state.divisions.find((d) => d.acquiredFrom === 'Northfield Retail Ltd')!;
  check('a bought group can be merged in', mergerPlan(state, group.id, 'blend')?.blocked === null);

  // A group you drew on a whiteboard was never another company, so there is
  // nothing to merge with and the game says so rather than offering it.
  const mine = createDivision(state, 'South', GROUPED_BY_HAND);
  check('a group you made yourself cannot be',
    (mergerPlan(state, mine.id, 'blend')?.blocked ?? '').includes('already one'));

  // The three styles are three genuinely different decisions.
  const absorb = mergerPlan(state, group.id, 'absorb')!;
  const blend = mergerPlan(state, group.id, 'blend')!;
  const federate = mergerPlan(state, group.id, 'federate')!;
  check('absorbing is the fast way', absorb.days < blend.days, `${absorb.days} against ${blend.days}`);
  check('and blending costs more in total', blend.integrationCost > absorb.integrationCost,
    `${blend.integrationCost} against ${absorb.integrationCost}`);
  check('leaving them alone lets nobody go', federate.cuts === 0);
  check('and absorbing lets everybody spare go', absorb.cuts === absorb.duplicates.length);
  check('every style has a real bill', MERGER_STYLES.every((style) => {
    const plan = mergerPlan(state, group.id, style.id);
    return plan !== null && plan.integrationCost > 0 && plan.days > 0;
  }));

  // The line that stops a merger wrecking the thing it just bought.
  // A shop can already be short-staffed when you buy it. The invariant is not
  // that every shop ends up above its line — it is that a merger never pushes
  // one below it, and takes nobody at all from a place that is already short.
  check('nobody is spare if their shop cannot trade without them',
    divisionBusinesses(state, group.id).every((business) => {
      const staff = employeesOf(state, business.id).length;
      const spare = duplicatesIn(state, group.id).filter((p) => p.businessId === business.id).length;
      return staff - spare >= Math.min(staff, staffingSummary(state, business).required);
    }));
  check('and a shop that is already short loses nobody at all',
    divisionBusinesses(state, group.id).every((business) => {
      const staff = employeesOf(state, business.id).length;
      if (staff >= staffingSummary(state, business).required) return true;
      return duplicatesIn(state, group.id).every((p) => p.businessId !== business.id);
    }));

  // Culture is four things the player can already look up, not a die roll.
  const culture = cultureGapOf(state, group.id);
  check('a culture gap is a number between nought and a hundred', culture.gap >= 0 && culture.gap <= 100, `${culture.gap}`);
  check('and it always says why', culture.reasons.length > 0);

  // Who is carrying it is what decides how long it takes.
  const undelegated = mergerPlan(state, group.id, 'blend')!;
  const heads = state.employees.filter((p) => p.companyId === state.playerCompanyId && gradeOf(p).span >= 20);
  if (heads.length > 0) {
    appointHead(state, group.id, heads[0].id);
    const delegatedPlan = mergerPlan(state, group.id, 'blend')!;
    check('putting somebody over it makes the integration shorter',
      delegatedPlan.days < undelegated.days, `${delegatedPlan.days} against ${undelegated.days}`);
    appointHead(state, group.id, null);
  }

  // Running one.
  const run = bought(22);
  const runGroup = run.divisions.find((d) => d.acquiredFrom === 'Northfield Retail Ltd')!;
  const before = playerCompany(run).cash;
  const plan = mergerPlan(run, runGroup.id, 'absorb')!;
  const started = startMerger(run, runGroup.id, 'absorb');
  check('an integration can be started', started.ok, started.message);
  check('and nothing is charged for it on the day it starts', playerCompany(run).cash === before);
  check('only one at a time',
    (mergerPlan(run, mine.id, 'blend') ?? { blocked: null }).blocked === null ||
      startMerger(run, runGroup.id, 'blend').ok === false);

  const merger = mergerFor(run, runGroup.id)!;
  const insider = divisionPeople(run, runGroup.id)[0];
  const outsider = run.employees.find((e) => e.companyId === run.playerCompanyId && !divisionPeople(run, runGroup.id).includes(e))!;
  check('the side being merged in feels it hardest',
    mergerMoraleDrag(run, insider) < mergerMoraleDrag(run, outsider),
    `${mergerMoraleDrag(run, insider).toFixed(1)} against ${mergerMoraleDrag(run, outsider).toFixed(1)}`);
  check('and nobody feels it by more than the cap', mergerMoraleDrag(run, insider) >= -24);
  check('an integration takes attention', mergerAttentionLoad(run) > 0);

  const headcountAtStart = divisionPeople(run, runGroup.id).length;
  const engine2 = new Engine(run);
  for (let day = 0; day < merger.days + 5; day += 1) for (let hour = 0; hour < 24; hour += 1) engine2.stepHour();

  check('it finishes', merger.completedOnDay !== null, `progress ${merger.progress.toFixed(2)}`);
  check('and it was paid for day by day rather than in a lump', merger.spent > 0);
  check('the culture gap closes as the two sides get used to each other',
    merger.cultureGap < plan.culture.gap || plan.culture.gap === 0,
    `${Math.round(merger.cultureGap)} from ${plan.culture.gap}`);
  if (plan.cuts > 0) {
    check('the duplicated jobs actually went', merger.letGo > 0, `${merger.letGo} of ${plan.cuts}`);
    check('with severance actually paid', merger.severanceSpent > 0);
    check('and the division is smaller for it',
      divisionPeople(run, runGroup.id).length < headcountAtStart + plan.cuts);
  }
  check('and nobody carries a morale drag once it is done',
    run.employees.every((person) => mergerMoraleDrag(run, person) === 0));
  check('the saving is permanent', mergerScaleFactor(run) < 1, `${mergerScaleFactor(run).toFixed(3)}`);
  check('and it never goes below the floor', mergerScaleFactor(run) >= SCALE_FLOOR);
  check('a merged division cannot be merged again',
    (mergerPlan(run, runGroup.id, 'blend')?.blocked ?? '').length > 0);
  check('merging leaves no broken numbers', findBadNumber(run) === null, findBadNumber(run) ?? '');

  // The saving is not a badge: it is off the coordination bill every day.
  const quiet = bought(23);
  const quietGroup = quiet.divisions.find((d) => d.acquiredFrom === 'Northfield Retail Ltd')!;
  const shop = divisionBusinesses(quiet, quietGroup.id)[0];
  const costBefore = adminCostPerDay(quiet, shop);
  quiet.mergers.push({
    id: 'merge-test', divisionId: quietGroup.id, fromCompany: 'Northfield Retail Ltd', style: 'absorb',
    startedOnDay: 1, days: 30, progress: 1, cultureGap: 0, duplicateIds: [], headcountAtStart: 0,
    spent: 0, severanceSpent: 0, letGo: 0, completedOnDay: quiet.day, savingLockedIn: 0.06,
  });
  check('a completed merger is cheaper coordination for every location',
    adminCostPerDay(quiet, shop) < costBefore,
    `${adminCostPerDay(quiet, shop).toFixed(2)} against ${costBefore.toFixed(2)}`);

  // Calling it off keeps what was earned and stops the rest.
  const quit = bought(24);
  const quitGroup = quit.divisions.find((d) => d.acquiredFrom === 'Northfield Retail Ltd')!;
  startMerger(quit, quitGroup.id, 'blend');
  const quitting = mergerFor(quit, quitGroup.id)!;
  for (let day = 0; day < 12; day += 1) mergersDaily(quit);
  const spentByThen = quitting.spent;
  const stopped = abandonMerger(quit, quitting.id);
  check('an integration can be called off', stopped.ok, stopped.message);
  check('and you keep the share you earned', quitting.savingLockedIn > 0 && quitting.savingLockedIn < 0.09);
  for (let day = 0; day < 10; day += 1) mergersDaily(quit);
  check('and it stops costing anything', quitting.spent === spentByThen);

  // A save from before any of this loads with nothing merged, not with nothing.
  const old = migrate({
    version: 2, seed: 1, day: 40, hour: 9, speed: 0, playerCompanyId: 'co-1',
    companies: [{ id: 'co-1', name: 'Old Ltd', isPlayer: true, cash: 50000, creditRating: 55, brandAwareness: 10, foundedOnDay: 1, personality: null }],
    buildings: [], businesses: [], employees: [], applicants: [],
    divisions: [{ id: 'div-1', name: 'Bought', acquiredFrom: 'Someone Ltd', createdOnDay: 10, headEmployeeId: null }],
  });
  check('an old save has no mergers rather than no list', Array.isArray(old?.mergers) && old?.mergers.length === 0);
  check('and its bought divisions are simply not merged yet', old?.divisions[0]?.mergedOnDay === null);
  check('so the scale factor on an old save is exactly one', old ? mergerScaleFactor(old) === 1 : false);
}


heading('35. Revenue and cash are no longer the same thing');
{
  const state = startGame({ companyName: 'Meridian', founderName: 'K', traitId: 'allrounder', scenarioId: 'small', seed: 31 });
  // The scenario picks its own trade, and this section is about the difference
  // between two kinds of trade — so both are named rather than assumed.
  const tillType = BUSINESS_TYPES.find((t) => (t.tradeCredit ?? 0) === 0)!;
  const shop = { ...playerBusinesses(state)[0], id: 'biz-till', typeId: tillType.id };

  // A till trade is unchanged: money at the counter is money in the bank, and
  // the whole of this system stays out of the way of a shop.
  const cashBefore = playerCompany(state).cash;
  const owedAtStart = sum(state.invoices, (i) => i.amount);
  bookTakings(state, shop, 1000, 'Takings — test');
  check('a till trade still banks its takings on the day',
    Math.round(playerCompany(state).cash - cashBefore) === 1000 &&
      Math.round(sum(state.invoices, (i) => i.amount)) === Math.round(owedAtStart),
    `${Math.round(playerCompany(state).cash - cashBefore)} banked, ledger moved ${Math.round(sum(state.invoices, (i) => i.amount) - owedAtStart)}`);

  // A trade that invoices does not.
  const type = BUSINESS_TYPES.find((t) => (t.tradeCredit ?? 0) > 0);
  check('some trades invoice rather than take cash at a counter', type !== undefined);
  if (type) {
    const invoicing = { ...shop, id: 'biz-invoicing', typeId: type.id };
    const terms = tradeCreditOf(invoicing);
    check('and those trades have terms', terms.share > 0 && terms.days > 0, `${terms.share} over ${terms.days}d`);

    const cashBefore2 = playerCompany(state).cash;
    const owedBefore2 = sum(state.invoices, (i) => i.amount);
    bookTakings(state, invoicing, 1000, 'Work done — test');
    const banked = playerCompany(state).cash - cashBefore2;
    const invoiced = sum(state.invoices, (i) => i.amount) - owedBefore2;
    check('an invoiced trade banks only the counter share today',
      banked < 1000 && banked >= 0, `${Math.round(banked)} of 1000`);
    // Not a penny may fall between the two ledgers.
    check('and every penny of the rest is on the sales ledger',
      Math.round(invoiced + banked) === 1000,
      `${Math.round(invoiced)} invoiced + ${Math.round(banked)} banked`);
  }

  // The money genuinely arrives. Nothing is allowed to fall between the two
  // ledgers: what is owed either turns into cash or is still owed.
  const owed = sum(state.invoices, (i) => i.amount);
  const before = playerCompany(state).cash;
  let collected = 0;
  for (let day = 0; day < 120; day += 1) {
    state.day += 1;
    collected += workingCapitalDaily(state).collected;
  }
  check('invoices are collected rather than lost',
    collected > 0 && Math.round(collected + sum(state.invoices, (i) => i.amount)) === Math.round(owed),
    `collected ${Math.round(collected)}, still owed ${Math.round(sum(state.invoices, (i) => i.amount))}, of ${Math.round(owed)}`);
  check('and the cash actually landed', Math.round(playerCompany(state).cash - before) === Math.round(collected));

  // Supplier terms are a function of the rating, not a gift.
  // Terms read financial standing rather than the raw rating: a supplier does
  // not see your accounts, it sees your name, and a name takes weeks to move.
  const fresh = startGame({ companyName: 'B', founderName: 'K', traitId: 'allrounder', scenarioId: 'small', seed: 32 });
  const supplierId = SUPPLIERS[0].id;
  fresh.standing.financial = 90;
  const good = supplierTerms(fresh, supplierId);
  fresh.standing.financial = 45;
  const poor = supplierTerms(fresh, supplierId);
  fresh.standing.financial = 20;
  const none = supplierTerms(fresh, supplierId);
  check('a good rating buys longer terms', good > poor, `${good}d against ${poor}d`);
  check('and a poor one buys cash on delivery', none === 0);

  // Being unable to pay is recorded rather than silently forgiven.
  const broke = startGame({ companyName: 'C', founderName: 'K', traitId: 'allrounder', scenarioId: 'small', seed: 33 });
  playerCompany(broke).cash = 100;
  raiseBill(broke, { supplierId, to: 'Northgate Wholesale', amount: 5000, days: 1, businessId: null });
  broke.day += 2;
  const missed = workingCapitalDaily(broke).missed;
  check('a bill you cannot pay is missed, not ignored', missed === 1 && broke.bills[0].lateDays === 1);
  check('and it shows up as arrears', workingCapital(broke).arrears === 5000);

  // The rating reads the arrears, and an overdrawn company cannot score well
  // just because the rest of its paperwork is tidy.
  const factors = creditFactors(broke);
  check('the rating is explained in five parts', factors.length === 5);
  check('every part scores within its band', factors.every((f) => f.score >= 0 && f.score <= f.of));
  playerCompany(broke).cash = -5000;
  check('an overdrawn company is capped', sum(creditFactors(broke), (f) => f.score) <= 45,
    `${Math.round(sum(creditFactors(broke), (f) => f.score))}`);
  const empty = startGame({ companyName: 'D', founderName: 'K', traitId: 'allrounder', scenarioId: 'entrepreneur', seed: 34 });
  check('and a company with no record does not score full marks for it',
    creditFactors(empty)[0].score < 30, `${creditFactors(empty)[0].score.toFixed(1)}/30`);

  // Invoice finance: real money today at a real price.
  const factored = startGame({ companyName: 'E', founderName: 'K', traitId: 'allrounder', scenarioId: 'entrepreneur', seed: 35 });
  // Nothing trades in this start, so the ledger holds exactly what is put on it.
  check('the ledger starts empty on a company that has not traded', factored.invoices.length === 0);
  raiseInvoice(factored, { from: 'A client', amount: 10_000, days: 45, businessId: null, source: 'contract' });
  const cashAt = playerCompany(factored).cash;
  const result = factorInvoices(factored, 10_000);
  check('the sales ledger can be sold', result.ok, result.message);
  check('and it raises less than face value',
    result.raised === 10_000 - Math.round(10_000 * FACTORING_FEE), `${result.raised}`);
  check('the cash is real', Math.round(playerCompany(factored).cash - cashAt) === result.raised);
  check('and the invoice is gone', factored.invoices.length === 0);

  // Ageing is ordered worst-first, which is the order you chase in.
  const aged = startGame({ companyName: 'F', founderName: 'K', traitId: 'allrounder', scenarioId: 'small', seed: 36 });
  aged.day = 100;
  raiseInvoice(aged, { from: 'Late', amount: 100, days: -40, businessId: null, source: 'trade' });
  raiseInvoice(aged, { from: 'Newer', amount: 100, days: 10, businessId: null, source: 'contract' });
  check('the ageing list puts the worst first', ageing(aged)[0].daysLate > ageing(aged)[1].daysLate);

  check('working capital leaves no broken numbers', findBadNumber(state) === null, findBadNumber(state) ?? '');
}


heading('36. What the company is known for, in five parts that each do something');
{
  const state = startGame({ companyName: 'Meridian', founderName: 'K', traitId: 'allrounder', scenarioId: 'established', seed: 41 });
  check('a company starts with a standing in all five', STANDING_FACETS.every((f) => Number.isFinite(standingOf(state)[f.id])));
  check('and every facet is inside its bounds',
    STANDING_FACETS.every((f) => standingOf(state)[f.id] >= 0 && standingOf(state)[f.id] <= 100));

  // The targets are read from the company, never stored, so a facet cannot
  // drift away from the thing it is supposed to describe.
  const targets = standingTargets(state);
  check('the targets are computed from the company', STANDING_FACETS.every((f) => Number.isFinite(targets[f.id])));

  // Standing is slow. That lag is what makes it standing rather than a readout
  // of today, and it is why a bad month still costs you something later.
  const before = { ...standingOf(state) };
  standingDaily(state);
  const moved = STANDING_FACETS.map((f) => Math.abs(standingOf(state)[f.id] - before[f.id]));
  check('and it moves slowly', moved.every((m) => m < 2), `largest move ${Math.max(...moved).toFixed(2)}`);

  // ---- every facet must reach the simulation. A facet that only prints is
  // exactly the decoration this game is not supposed to have.
  const high = startGame({ companyName: 'H', founderName: 'K', traitId: 'allrounder', scenarioId: 'small', seed: 42 });
  const low = startGame({ companyName: 'L', founderName: 'K', traitId: 'allrounder', scenarioId: 'small', seed: 42 });
  high.standing = { ...emptyStanding(), brand: 95, quality: 95, service: 95, employer: 95, financial: 95 };
  low.standing = { ...emptyStanding(), brand: 5, quality: 5, service: 5, employer: 5, financial: 5 };

  // Fifty is the middle: a company with no reputation either way plays the
  // game exactly as it played before standing existed.
  const neutral = startGame({ companyName: 'N0', founderName: 'K', traitId: 'allrounder', scenarioId: 'small', seed: 45 });
  neutral.standing = emptyStanding();
  neutral.standing.brand = 50;
  check('a facet at fifty changes nothing', Math.abs(brandFactor(neutral) - 1) < 0.001, `${brandFactor(neutral)}`);
  check('and so does the employer one', Math.abs(employerPull(neutral).fee - 1) < 0.001 && employerPull(neutral).skill === 0);
  check('and retention', Math.abs(retentionFactorOf(neutral) - 1) < 0.001);
  check('and quality', qualityBias(neutral) === 0);

  check('brand reaches what marketing buys', brandFactor(high) > brandFactor(low),
    `${brandFactor(high).toFixed(2)} against ${brandFactor(low).toFixed(2)}`);
  check('quality reaches what customers write', qualityBias(high) > qualityBias(low));
  check('service reaches whether they come back', retentionFactorOf(high) > retentionFactorOf(low),
    `${retentionFactorOf(high).toFixed(3)} against ${retentionFactorOf(low).toFixed(3)}`);
  check('being a good employer brings better applicants', employerPull(high).skill > employerPull(low).skill);
  check('and costs less to recruit', employerPull(high).fee < employerPull(low).fee,
    `${employerPull(high).fee.toFixed(2)} against ${employerPull(low).fee.toFixed(2)}`);
  check('financial standing reaches what suppliers allow',
    supplierTerms(high, SUPPLIERS[0].id) > supplierTerms(low, SUPPLIERS[0].id),
    `${supplierTerms(high, SUPPLIERS[0].id)}d against ${supplierTerms(low, SUPPLIERS[0].id)}d`);

  // The applicant field really is better, not just the multiplier.
  let strong = 0;
  let weak = 0;
  for (let i = 0; i < 60; i += 1) {
    strong += generateApplicant(high).skill;
    weak += generateApplicant(low).skill;
  }
  check('and the people who actually apply are better', strong / 60 > weak / 60,
    `${(strong / 60).toFixed(1)} against ${(weak / 60).toFixed(1)}`);

  // Paying people properly is what an employer reputation is made of.
  const generous = startGame({ companyName: 'G', founderName: 'K', traitId: 'allrounder', scenarioId: 'small', seed: 43 });
  const mean = startGame({ companyName: 'M', founderName: 'K', traitId: 'allrounder', scenarioId: 'small', seed: 43 });
  for (const person of generous.employees) person.salary = Math.round(marketRate(generous, person) * 1.3);
  for (const person of mean.employees) person.salary = Math.round(marketRate(mean, person) * 0.72);
  check('paying over the odds builds a name as an employer',
    standingTargets(generous).employer > standingTargets(mean).employer,
    `${standingTargets(generous).employer.toFixed(0)} against ${standingTargets(mean).employer.toFixed(0)}`);

  // And failing to pay suppliers destroys the financial one.
  const late = startGame({ companyName: 'N', founderName: 'K', traitId: 'allrounder', scenarioId: 'small', seed: 44 });
  const clean = standingTargets(late).financial;
  late.bills.push({ id: 'b1', supplierId: SUPPLIERS[0].id, to: 'X', amount: 900, raisedOnDay: 1, dueOnDay: 2, businessId: null, lateDays: 9 });
  check('and a bill left unpaid costs you it', standingTargets(late).financial < clean,
    `${standingTargets(late).financial.toFixed(0)} against ${clean.toFixed(0)}`);

  check('standing leaves no broken numbers', findBadNumber(state) === null, findBadNumber(state) ?? '');
}


heading('37. People work with people, not with an average');
{
  // A start with no trading history has nobody who has worked with anybody.
  const fresh37 = startGame({ companyName: 'F', founderName: 'K', traitId: 'allrounder', scenarioId: 'entrepreneur', seed: 51 });
  check('nobody knows anybody before the company has traded', fresh37.employees.every((e) => bondsOf(e).length === 0));

  // An inherited company is different, and rightly so: it comes with people who
  // already have a history with each other.
  const state = startGame({ companyName: 'Meridian', founderName: 'K', traitId: 'allrounder', scenarioId: 'established', seed: 51 });
  check('but a company you inherit comes with relationships already formed',
    state.employees.some((e) => bondsOf(e).length > 0));

  // Relationships form from working alongside each other, not from a die roll
  // on hiring. A couple of months is enough for a shop to have a shape.
  for (let day = 0; day < 90; day += 1) {
    state.day += 1;
    relationshipsDaily(state);
  }
  const withBonds = state.employees.filter((e) => bondsOf(e).length > 0);
  check('working alongside people forms relationships', withBonds.length > 0, `${withBonds.length} of ${state.employees.length}`);
  check('and nobody keeps up with more than they could',
    state.employees.every((e) => bondsOf(e).length <= MAX_BONDS));
  check('every relationship names somebody who exists',
    state.employees.every((e) => bondsOf(e).every((b) => state.employees.some((o) => o.id === b.withId))));
  check('and nobody is their own colleague',
    state.employees.every((e) => bondsOf(e).every((b) => b.withId !== e.id)));
  check('strength stays inside its bounds',
    state.employees.every((e) => bondsOf(e).every((b) => b.strength >= -100 && b.strength <= 100)));

  // ---- the three effects, each of which must reach something real.
  const sample = withBonds[0];
  if (sample) {
    check('relationships reach the morale figure the player already watches',
      Number.isFinite(bondMorale(state, sample)) && bondMorale(state, sample) >= -14 && bondMorale(state, sample) <= 8);
    check('and they are listed against real people',
      relationshipsOf(state, sample).every((row) => row.other.id !== sample.id));
  }

  // Friction reaches the customers rather than sitting on an HR screen.
  const shop = playerBusinesses(state).find((b) => b.status === 'open' && employeesOf(state, b.id).length >= 2);
  if (shop) {
    const staff = employeesOf(state, shop.id);
    // Cleared on every one of them, so the measurement is of this feud and not
    // of whatever else that shop happens to have going on.
    const saved = staff.map((person) => person.bonds);
    for (const person of staff) person.bonds = [];
    const clean = teamFriction(state, shop);
    staff[0].bonds = [{ withId: staff[1].id, strength: -90, kind: 'rival' }];
    staff[1].bonds = [{ withId: staff[0].id, strength: -90, kind: 'rival' }];
    check('a feud costs the shop service', teamFriction(state, shop) < clean,
      `${teamFriction(state, shop).toFixed(3)} against ${clean.toFixed(3)}`);
    check('and it is bounded rather than ruinous', teamFriction(state, shop) >= 0.82);
    // And goodwill is worth something, or this is a tax on having colleagues.
    staff[0].bonds = [{ withId: staff[1].id, strength: 90, kind: 'friend' }];
    staff[1].bonds = [{ withId: staff[0].id, strength: 90, kind: 'friend' }];
    check('a team that gets on serves people better', teamFriction(state, shop) > clean,
      `${teamFriction(state, shop).toFixed(3)} against ${clean.toFixed(3)}`);
    for (const person of staff) person.bonds = [];
    check('and it goes away when they do', teamFriction(state, shop) === clean);
    staff.forEach((person, index) => { person.bonds = saved[index]; });

    // A mentor makes training count for more, and only from somebody senior.
    const junior = staff.reduce((a, b) => (gradeOf(a).n <= gradeOf(b).n ? a : b));
    const senior = staff.reduce((a, b) => (gradeOf(a).n >= gradeOf(b).n ? a : b));
    junior.bonds = [];
    check('without a mentor, training is worth what it is worth', mentorBoost(state, junior) === 1);
    if (gradeOf(senior).n > gradeOf(junior).n) {
      senior.skills.leadership = 90;
      junior.bonds = [{ withId: senior.id, strength: 80, kind: 'mentor' }];
      check('somebody senior taking an interest makes training count for more',
        mentorBoost(state, junior) > 1, `${mentorBoost(state, junior).toFixed(3)}`);
      // And not from somebody who is not senior to them.
      junior.bonds = [{ withId: staff.find((p) => gradeOf(p).n <= gradeOf(junior).n && p.id !== junior.id)?.id ?? senior.id, strength: 80, kind: 'mentor' }];
      const peerBoost = mentorBoost(state, junior);
      check('but not from a peer', peerBoost === 1 || junior.bonds[0].withId === senior.id);
      junior.bonds = [];
    }
  }

  // Management is what decides whether friction becomes a feud. Two shops, the
  // same difficult people, one of them run by somebody who can lead.
  const feuds = (leadership: number): number => {
    const test = startGame({ companyName: 'T', founderName: 'K', traitId: 'allrounder', scenarioId: 'established', seed: 52 });
    for (const person of test.employees) {
      if (gradeOf(person).managerial) person.skills.leadership = leadership;
    }
    for (let day = 0; day < 120; day += 1) {
      test.day += 1;
      relationshipsDaily(test);
    }
    return sum(test.employees, (e) => bondsOf(e).filter((b) => b.strength < 0).length);
  };
  const badlyRun = feuds(10);
  const wellRun = feuds(95);
  check('a place nobody can manage ends up with more friction in it',
    badlyRun >= wellRun, `${badlyRun} against ${wellRun}`);

  check('relationships leave no broken numbers', findBadNumber(state) === null, findBadNumber(state) ?? '');
}


heading('38. The company has a past, and it is one that actually happened');
{
  const state = startGame({ companyName: 'Meridian', founderName: 'K', traitId: 'allrounder', scenarioId: 'entrepreneur', seed: 61 });
  check('a company that has done nothing has an empty log', chronicle(state).length === 0);
  check('and says so rather than inventing something', summary(state).includes('Nothing has happened'));

  // Every entry is written where the thing happens, so the log cannot claim a
  // decision that was never carried out.
  const building = state.buildings.find((b) => b.status === 'available' && b.size > 60);
  if (building) {
    rentBuilding(state, building.id);
    const type = BUSINESS_TYPES.find((t) => t.minSize <= building.size)!;
    foundBusiness(state, type.id, building.id, 'Test Shop');
    const shop = playerBusinesses(state)[0];
    check('founding a business is not itself an entry', chronicle(state).length === 0);
    // Give it what it needs, then open it for real.
    for (const productId of type.productIds) shop.stock[productId] = 50;
    const applicant = applicantsFor(state, shop)[0];
    if (applicant) hire(state, applicant.id, shop.id);
    const opened = openBusiness(state, shop.id);
    if (opened.ok) {
      check('opening one is', chronicle(state, 'opened').length === 1);
      check('and it names the place', chronicle(state, 'opened')[0].text.includes('Test Shop'));
    }
    check('hiring somebody is recorded', chronicle(state, 'hired').length >= 1);
    if (applicant) {
      check('with what they cost, as a cost', (chronicle(state, 'hired')[0].amount ?? 0) < 0);
    }
  }

  // Borrowing and repaying, which is the loop the player feels most.
  const offers = loanOffers(state);
  const working = offers.find((o) => !o.blocked);
  if (working) {
    const borrowed = takeLoan(state, working.id, working.maxPrincipal);
    check('the loan was actually taken', borrowed.ok, borrowed.message);
    check('borrowing is recorded', chronicle(state, 'borrowed').length === 1);
    check('as money in', (chronicle(state, 'borrowed')[0].amount ?? 0) > 0);
  }

  // The log is capped, and the cap drops the oldest rather than the newest.
  for (let i = 0; i < CHRONICLE_LIMIT + 40; i += 1) record(state, 'crisis', `filler ${i}`);
  check('the log is capped', (state.chronicle ?? []).length === CHRONICLE_LIMIT);
  check('and it keeps the most recent', chronicle(state)[0].text === `filler ${CHRONICLE_LIMIT + 39}`);

  // The record books read from figures the simulation actually settled.
  const played = startGame({ companyName: 'R', founderName: 'K', traitId: 'allrounder', scenarioId: 'small', seed: 62 });
  const engine38 = new Engine(played);
  for (let day = 0; day < 60; day += 1) for (let hour = 0; hour < 24; hour += 1) engine38.stepHour();
  const rows = recordRows(played);
  check('the record books are filled in from real days', rows.length === 6);
  check('and every record points at a day that happened',
    rows.every((row) => row.when === 'not yet' || row.when.length > 4));
  check('the best day of trading is a day that was traded',
    played.records.peakRevenue.day > 0 && played.records.peakRevenue.day <= played.day);
  check('and the peak is at least as good as the last day',
    played.records.peakRevenue.value >= (played.dayHistory[played.dayHistory.length - 1]?.revenue ?? 0));
  check('the summary describes the company that was built',
    summary(played).includes(String((played.day / 360).toFixed(1))));

  check('the chronicle leaves no broken numbers', findBadNumber(played) === null, findBadNumber(played) ?? '');
}


heading('39. Every save ever written still opens');
{
  // A version 1 save: before skills were split, before the ladder, before
  // divisions, head offices, founders, mergers, working capital or standing.
  const v1 = migrate({
    version: 1, seed: 5, day: 120, hour: 10, speed: 0, playerCompanyId: 'co-1',
    companies: [{ id: 'co-1', name: 'Ancient Ltd', isPlayer: true, cash: 40_000, creditRating: 61, brandAwareness: 22, foundedOnDay: 1, personality: null }],
    buildings: [], businesses: [],
    employees: [
      { id: 'e1', name: 'Old Hand', age: 44, role: 'manager', salary: 3400, skill: 71, workload: 50, experience: 3, productivity: 1, reliability: 1, morale: 62, stress: 20, loyalty: 70, traits: ['loyal'], businessId: null, companyId: 'co-1', hiredOnDay: 2, trainingDays: 0, trainingEndsOnDay: null, promotions: 2, manager: true },
    ],
    applicants: [],
  });
  check('a version 1 save opens', v1 !== null);
  if (v1) {
    check('  and its people keep their standing', v1.employees[0].grade >= 2, `grade ${v1.employees[0].grade}`);
    check('  with all eight skills filled in', SKILL_IDS.every((id) => Number.isFinite(v1.employees[0].skills[id])));
    check('  nobody knows anybody, because nobody ever did', v1.employees[0].bonds.length === 0);
    check('  the sales ledger is empty, which is what it always was', v1.invoices.length === 0 && v1.bills.length === 0);
    check('  standing starts unproven rather than flattering', v1.standing.employer === 50);
    check('  and the history is empty rather than invented', v1.chronicle.length === 0);
    check('  nothing in it is broken', findBadNumber(v1) === null, findBadNumber(v1) ?? '');
  }

  // A version 3 save: everything up to the interface overhaul, which is the
  // last build anybody actually played.
  const v3 = migrate({
    version: 3, seed: 9, day: 400, hour: 14, speed: 0, playerCompanyId: 'co-1',
    companies: [{ id: 'co-1', name: 'Recent Ltd', isPlayer: true, cash: 120_000, creditRating: 70, brandAwareness: 40, foundedOnDay: 1, personality: null }],
    buildings: [], businesses: [], applicants: [],
    employees: [
      { id: 'e1', name: 'Manager', age: 39, role: 'manager', salary: 4100, skill: 68, skills: emptySkills(), workload: 55, experience: 5, productivity: 1, reliability: 1, morale: 70, stress: 25, loyalty: 75, traits: [], businessId: null, companyId: 'co-1', hiredOnDay: 10, trainingDays: 4, trainingEndsOnDay: null, trainingCourseId: null, sickUntilDay: null, promotions: 3, grade: 5, lastRecognisedOnDay: 200 },
    ],
    divisions: [{ id: 'd1', name: 'North', acquiredFrom: 'Somebody Ltd', createdOnDay: 50, headEmployeeId: null, mergedOnDay: null }],
    mergers: [],
    founder: { name: 'K', traitId: 'operator', skills: {}, progress: {}, scenarioId: 'small' },
  });
  check('a version 3 save opens', v3 !== null);
  if (v3) {
    check('  its ladder position is untouched', v3.employees[0].grade === 5);
    check('  its divisions survive', v3.divisions.length === 1 && v3.divisions[0].mergedOnDay === null);
    check('  its founder survives', v3.founder?.traitId === 'operator');
    check('  and it gains the 3.0 systems empty rather than guessed',
      v3.invoices.length === 0 && v3.bills.length === 0 && v3.chronicle.length === 0 && v3.taxReserve === 0);
    check('  with records that claim nothing', v3.records.peakNetWorth.value === 0);
    check('  nothing in it is broken', findBadNumber(v3) === null, findBadNumber(v3) ?? '');
  }

  // And a save from this version round-trips through JSON without losing a
  // thing, which is what the autosave does every day.
  const live = startGame({ companyName: 'Round Trip', founderName: 'K', traitId: 'allrounder', scenarioId: 'small', seed: 71 });
  const engine39 = new Engine(live);
  for (let day = 0; day < 40; day += 1) for (let hour = 0; hour < 24; hour += 1) engine39.stepHour();
  const reopened = migrate(JSON.parse(JSON.stringify(live)));
  check('a current save round-trips', reopened !== null);
  if (reopened) {
    check('  the money is the same', Math.round(reopened.companies[0].cash) === Math.round(live.companies[0].cash));
    check('  the sales ledger is the same', reopened.invoices.length === live.invoices.length);
    check('  the people are the same', reopened.employees.length === live.employees.length);
    check('  their relationships survive',
      sum(reopened.employees, (e) => e.bonds.length) === sum(live.employees, (e) => e.bonds.length));
    check('  standing survives', Math.round(reopened.standing.brand) === Math.round(live.standing.brand));
    check('  the history survives', reopened.chronicle.length === live.chronicle.length);
    check('  and the version is stamped', reopened.version === SAVE_VERSION);
  }
}


heading('40. The head office is rooms as well as people');
{
  const state = startGame({ companyName: 'Meridian', founderName: 'K', traitId: 'allrounder', scenarioId: 'empire', seed: 81 });
  playerCompany(state).cash += 2_000_000;

  check('a company with no head office cannot build rooms in it',
    FACILITIES.every((def) => state.headOffice !== null || !canBuild(state, def.id).ok));

  if (state.headOffice) {
    // Room in the building is finite, and both people and rooms take it up.
    check('the building has a fixed number of desks', desksTotal(state) > 0);
    check('and they are accounted for', desksUsed(state) + desksLeft(state) === desksTotal(state));
    check('utilisation is a share', utilisation(state) >= 0 && utilisation(state) <= 2);

    // Building is a project: months of money before anything works.
    const training = facilityOrThrow('training');
    state.headOffice.level = 5;
    const started = startProject(state, 'training');
    check('a room can be started', started.ok, started.message);
    check('and it is a project rather than a purchase', activeProject(state)?.facilityId === 'training');
    check('nothing is finished on day one', !built(state, 'training'));
    check('and only one thing is built at a time', !canBuild(state, 'lab').ok);

    // The money goes out as the work is done.
    const cashAt = playerCompany(state).cash;
    for (let day = 0; day < 10; day += 1) { state.day += 1; projectsDaily(state); }
    check('the money goes out as it is built', playerCompany(state).cash < cashAt);
    check('and only a share of it so far',
      playerCompany(state).cash > cashAt - training.cost, `${Math.round(cashAt - playerCompany(state).cash)} of ${training.cost}`);

    // Run it to completion.
    for (let day = 0; day < training.days + 5; day += 1) { state.day += 1; projectsDaily(state); }
    check('and eventually the room opens', built(state, 'training'));
    check('the project is done with', activeProject(state) === null);
    check('it takes desks for ever after', desksUsed(state) >= training.desks);
    check('and costs something to run', facilitiesBill(state) >= training.running);
  }

  // ---- every room must reach the simulation. A room that only appears on its
  // own screen is scenery, and this game does not have scenery.
  const withRoom = (id: string) => {
    const test = startGame({ companyName: 'W', founderName: 'K', traitId: 'allrounder', scenarioId: 'empire', seed: 82 });
    if (test.headOffice) {
      test.headOffice.level = 5;
      test.headOffice.facilities = [id];
    }
    return test;
  };
  const bare = startGame({ companyName: 'B', founderName: 'K', traitId: 'allrounder', scenarioId: 'empire', seed: 82 });
  if (bare.headOffice) bare.headOffice.level = 5;

  check('a training centre makes training cheaper and quicker',
    trainingFactor(withRoom('training')) < trainingFactor(bare),
    `${trainingFactor(withRoom('training'))} against ${trainingFactor(bare)}`);
  check('a lab makes research finish sooner', labFactor(withRoom('lab')) < labFactor(bare));
  check('a data centre raises how far systems can be pushed',
    automationCeiling(withRoom('datacentre')) > automationCeiling(bare),
    `${automationCeiling(withRoom('datacentre'))} against ${automationCeiling(bare)}`);
  check('an executive floor is worth real locations',
    executiveReach(withRoom('executive')) > 0 && executiveReach(bare) === 0);
  check('and it reaches what one person can actually hold',
    attentionOf(withRoom('executive')) > attentionOf(bare),
    `${attentionOf(withRoom('executive')).toFixed(1)} against ${attentionOf(bare).toFixed(1)}`);
  check('a board room unlocks what needs other people to agree',
    hasBoard(withRoom('board')) && !hasBoard(bare));

  // A data centre is worth having and is also the thing worth attacking.
  check('a company with no data centre has nothing exposed', exposure(bare) === 0);
  check('building one exposes it', exposure(withRoom('datacentre')) > 0);
  const guarded = withRoom('datacentre');
  if (guarded.headOffice) guarded.headOffice.facilities = ['datacentre', 'security'];
  check('and a security team is what takes that back',
    exposure(guarded) < exposure(withRoom('datacentre')),
    `${exposure(guarded)} against ${exposure(withRoom('datacentre'))}`);

  // An office that is mostly empty is rent for nothing, and that has to cost
  // something or upgrading early would be free.
  const roomy = startGame({ companyName: 'R', founderName: 'K', traitId: 'allrounder', scenarioId: 'empire', seed: 83 });
  if (roomy.headOffice) {
    roomy.headOffice.level = 5;
    roomy.headOffice.employeeIds = [];
    roomy.headOffice.facilities = [];
    check('a half-empty office costs more to coordinate, not less', utilisationPenalty(roomy) > 1,
      `${utilisationPenalty(roomy)}`);
    roomy.headOffice.level = 1;
    check('and one that fits does not', utilisationPenalty(roomy) <= 1.12);
  }

  check('rooms leave no broken numbers', findBadNumber(state) === null, findBadNumber(state) ?? '');
}


heading('41. The city changes, and it stays changed');
{
  const state = startGame({ companyName: 'Northgate Co', founderName: 'K', traitId: 'allrounder', scenarioId: 'empire', seed: 91 });

  check('nothing is announced before anything is announced', state.announcements.length === 0);

  // Every development has to be able to happen somewhere real, or it is a
  // definition that can never fire.
  check('every development names districts that exist',
    DEVELOPMENTS.every((def) => def.where.every((id) => DISTRICTS.some((d) => d.id === id))));
  check('every development actually moves something',
    DEVELOPMENTS.every((def) => def.demand !== 1 || def.rent !== 1 || def.property !== 1));
  check('and every one gives notice before it lands',
    DEVELOPMENTS.every((def) => def.notice[0] > 0 && def.notice[1] >= def.notice[0]));

  // Announced, then waited for, then landed — and the district is different.
  const metro = DEVELOPMENTS.find((d) => d.id === 'metro');
  if (metro) {
    const target = metro.where[0];
    const before = { ...state.districts[target] };
    state.announcements.push({
      id: 'test-dev',
      defId: 'metro',
      districtId: target,
      announcedOnDay: state.day,
      landsOnDay: state.day + 30,
    });

    check('an announcement is visible before it lands', pending(state).length === 1);
    check('  and it is dated', pending(state)[0].daysAway === 30);
    check('  and it shows on the district it is about', pendingIn(state, target).length === 1);

    // Twenty-nine days of nothing: notice means notice.
    for (let i = 0; i < 29; i += 1) { state.day += 1; cityChangeDaily(state); }
    check('nothing changes during the notice period',
      Math.abs(state.districts[target].demandIndex - before.demandIndex) < 0.0001,
      `${state.districts[target].demandIndex} against ${before.demandIndex}`);
    check('  and it is still pending', state.announcements.some((a) => a.id === 'test-dev'));

    state.day += 1;
    cityChangeDaily(state);
    check('it lands on its day', !state.announcements.some((a) => a.id === 'test-dev'));
    check('  and the district is permanently busier',
      state.districts[target].demandIndex > before.demandIndex,
      `${state.districts[target].demandIndex.toFixed(3)} against ${before.demandIndex.toFixed(3)}`);
    check('  and dearer to rent', state.districts[target].rentIndex > before.rentIndex);
    check('  and worth more to own', state.districts[target].propertyIndex > before.propertyIndex);

    // Sixty more days with nothing else allowed to land: if the change were a
    // modifier it would expire somewhere in here, and it does not.
    const landed = state.districts[target].demandIndex;
    for (let i = 0; i < 60; i += 1) {
      state.day += 1;
      cityChangeDaily(state);
      state.announcements = [];
    }
    check('and it stays changed — there is no modifier to expire',
      Math.abs(state.districts[target].demandIndex - landed) < 0.0001,
      `${state.districts[target].demandIndex.toFixed(3)} against ${landed.toFixed(3)}`);
    check('the drift is readable from the indices themselves',
      Math.abs(drift(state, target).demand - (state.districts[target].demandIndex - 1) * 100) < 0.0001);
  }

  // A long run: the city has to actually do things, stay inside its bounds,
  // and never announce the same development twice at once.
  const long = startGame({ companyName: 'Long Co', founderName: 'K', traitId: 'allrounder', scenarioId: 'empire', seed: 92 });
  const opening = DISTRICTS.map((d) => long.districts[d.id].demandIndex);
  let everAnnounced = 0;
  let worstConcurrent = 0;
  for (let i = 0; i < 1200; i += 1) {
    long.day += 1;
    const was = long.announcements.length;
    cityChangeDaily(long);
    if (long.announcements.length > was) everAnnounced += long.announcements.length - was;
    worstConcurrent = Math.max(worstConcurrent, long.announcements.length);
    const ids = long.announcements.map((a) => a.defId);
    if (new Set(ids).size !== ids.length) { worstConcurrent = -1; break; }
  }
  check('over three years the city does a number of things', everAnnounced >= 3, `${everAnnounced} announced`);
  check('and never announces the same thing twice at once', worstConcurrent > 0);
  check('the city is a different place by the end',
    DISTRICTS.some((d, i) => Math.abs(long.districts[d.id].demandIndex - opening[i]) > 0.01));
  check('every district stays inside its bounds',
    DISTRICTS.every((d) => {
      const it = long.districts[d.id];
      return it.demandIndex >= 0.4 && it.demandIndex <= 2.2
        && it.rentIndex >= 0.5 && it.rentIndex <= 2.4
        && it.propertyIndex >= 0.5 && it.propertyIndex <= 2.6;
    }));
  check('and the city leaves no broken numbers', findBadNumber(long) === null, findBadNumber(long) ?? '');

  // Announcements survive a save, or the player would lose the warning they
  // were given and the change would arrive out of nowhere.
  const reopened = migrate(JSON.parse(JSON.stringify(long)) as Record<string, unknown>);
  check('announcements survive a save', reopened.announcements.length === long.announcements.length);
  const older = JSON.parse(JSON.stringify(long)) as Record<string, unknown>;
  delete older.announcements;
  check('and a save from before the city could change opens with none',
    migrate(older).announcements.length === 0);
}


heading('42. The head office has people at the top of it, and they do the job');
{
  const state = startGame({ companyName: 'Officer Co', founderName: 'K', traitId: 'allrounder', scenarioId: 'empire', seed: 84 });
  playerCompany(state).cash += 3_000_000;

  check('every post is judged on a skill that exists',
    OFFICERS.every((def) => SKILL_IDS.includes(def.skill)));
  check('every post costs something to fill', OFFICERS.every((def) => def.premium > 0));
  check('no two posts lead the same department',
    new Set(OFFICERS.map((o) => o.functionId).filter((f) => f !== null)).size ===
      OFFICERS.filter((o) => o.functionId !== null).length);
  check('nobody holds a post at the start', officers(state).length === 0);

  if (state.headOffice) {
    // Somebody senior, in the head office, to appoint.
    const person = state.employees.find((e) => state.headOffice?.employeeIds.includes(e.id));
    if (!person) {
      check('there is somebody in the head office to promote', false);
    } else {
      check('a post cannot be filled without a floor to sit them on',
        !canAppoint(state, 'cfo', person.id).ok);

      state.headOffice.facilities = [...state.headOffice.facilities, 'executive'];
      person.grade = GRADES.length - 1;
      person.skills.finance = 90;
      syncOverall(person);

      check('with an executive floor the post can be filled', canAppoint(state, 'cfo', person.id).ok,
        canAppoint(state, 'cfo', person.id).message);

      const paidBefore = person.salary;
      const taxBefore = taxFactor(state);
      const appointed = appoint(state, 'cfo', person.id);
      check('appointing works', appointed.ok, appointed.message);
      check('  and the post is paid for out of the payroll everybody else uses',
        person.salary > paidBefore, `${person.salary} against ${paidBefore}`);
      check('  and they are the officer', officer(state, 'cfo')?.id === person.id);
      check('  and a good one is worth something', officerStrength(state, 'cfo') > 0.4,
        `${officerStrength(state, 'cfo').toFixed(2)}`);
      check('  and what they lead gets more out of the same people',
        taxFactor(state) < taxBefore, `${taxFactor(state).toFixed(4)} against ${taxBefore.toFixed(4)}`);
      check('  and the lift is bounded — an officer is leverage, not a department',
        officerLift(state, 'finance') <= 1 + OFFICER_LIFT + 0.0001);

      // Leading a department nobody works in is worth nothing, which is the
      // rule that stops an officer being a way to skip staffing the place.
      const hollow = startGame({ companyName: 'Hollow', founderName: 'K', traitId: 'allrounder', scenarioId: 'empire', seed: 85 });
      if (hollow.headOffice) {
        hollow.headOffice.facilities = ['executive'];
        const solo = hollow.employees.find((e) => hollow.headOffice?.employeeIds.includes(e.id));
        if (solo) {
          solo.grade = GRADES.length - 1;
          solo.skills.sales = 95;
          syncOverall(solo);
          hollow.headOffice.employeeIds = [solo.id];
          const before = marketingFactor(hollow);
          appoint(hollow, 'cmo', solo.id);
          check('an officer over an empty department buys almost nothing',
            marketingFactor(hollow) - before < 0.05,
            `${(marketingFactor(hollow) - before).toFixed(4)}`);
        }
      }

      check('nobody can hold two posts at once', !canAppoint(state, 'cmo', person.id).ok,
        canAppoint(state, 'cmo', person.id).message);

      // The operating officer is the one that shows up as capacity rather than
      // as a multiplier — the only post that changes how many locations one
      // person can actually hold.
      const reachBefore = attentionOf(state);
      vacate(state, 'cfo');
      person.skills.leadership = 92;
      syncOverall(person);
      appoint(state, 'coo', person.id);
      check('a chief operating officer is management capacity, in locations',
        attentionOf(state) > reachBefore,
        `${attentionOf(state).toFixed(1)} against ${reachBefore.toFixed(1)}`);
      check('  and it is bounded by how good they are', operatingReach(state) <= 3.0001);
      vacate(state, 'coo');
      check('  and it goes when they do',
        Math.abs(attentionOf(state) - reachBefore) < 0.0001);

      // Vacating gives the money back and empties the post.
      appoint(state, 'cfo', person.id);
      const held = person.salary;
      vacate(state, 'cfo');
      check('vacating a post empties it', officer(state, 'cfo') === null);
      check('  and stops paying for it', person.salary < held);

      // And a post cannot point at somebody who has left.
      appoint(state, 'cfo', person.id);
      state.employees = state.employees.filter((e) => e.id !== person.id);
      check('a post held by somebody who has left is simply empty', officer(state, 'cfo') === null);
      check('  and the lift goes with them', Math.abs(officerLift(state, 'finance') - 1) < 0.0001);
    }
  }

  check('officers leave no broken numbers', findBadNumber(state) === null, findBadNumber(state) ?? '');
}


heading('43. A board room is what lets you sell part of the company');
{
  const state = startGame({ companyName: 'Board Co', founderName: 'K', traitId: 'allrounder', scenarioId: 'empire', seed: 86 });

  check('you own all of it to begin with', ownersStake(state) === 1 && outsideStake(state) === 0);
  check('and without a board room nobody will buy any of it', !canRaise(state, 200_000).ok);

  if (state.headOffice) {
    state.headOffice.facilities = [...state.headOffice.facilities, 'executive', 'board'];

    // A company in trouble sells more of itself for the same money than a
    // company doing well. That is the whole point of the pricing.
    const trading = (profit: number): GameState => {
      const copy = startGame({ companyName: 'C', founderName: 'K', traitId: 'allrounder', scenarioId: 'empire', seed: 86 });
      if (copy.headOffice) copy.headOffice.facilities = ['executive', 'board'];
      copy.dayHistory = Array.from({ length: 120 }, (_, i) => ({
        day: i + 1, revenue: Math.max(0, profit) * 3, costs: Math.max(0, profit) * 2,
        profit, cash: 100_000, netWorth: 400_000, customers: 100,
      }));
      return copy;
    };

    const good = trading(3_000);
    const poor = trading(80);
    check('a company earning well is worth more', valuation(good) > valuation(poor),
      `${Math.round(valuation(good))} against ${Math.round(valuation(poor))}`);
    check('  so the same money buys less of it',
      stakeFor(good, 300_000) < stakeFor(poor, 300_000),
      `${(stakeFor(good, 300_000) * 100).toFixed(1)}% against ${(stakeFor(poor, 300_000) * 100).toFixed(1)}%`);
    check('the board is behind a company doing well', boardConfidence(good) > boardConfidence(poor));

    const cashBefore = playerCompany(good).cash;
    const raised = raiseEquity(good, 300_000);
    check('the raise goes through', raised.ok, raised.message);
    check('  and the cash arrives', playerCompany(good).cash - cashBefore === 300_000);
    check('  and it is not revenue — the company did not earn it',
      !isRevenue('equity') && !isOperatingCost('equity'));
    check('  and somebody else now owns part of the company',
      outsideStake(good) > 0 && ownersStake(good) < 1);
    check('  and it is written down as a decision that was taken',
      chronicle(good).some((e) => e.text.includes('Sold')));

    // Raising twice costs more of the company than raising once, because the
    // second slice comes out of what is left.
    const once = trading(3_000);
    raiseEquity(once, 600_000);
    const twice = trading(3_000);
    raiseEquity(twice, 300_000);
    raiseEquity(twice, 300_000);
    check('dilution compounds — raising twice costs more of the company',
      outsideStake(twice) >= outsideStake(once) - 0.0001,
      `${(outsideStake(twice) * 100).toFixed(1)}% against ${(outsideStake(once) * 100).toFixed(1)}%`);

    check('you cannot sell more of the company than is left',
      outsideStake(good) <= MAX_OUTSIDE_STAKE + 0.0001);
    const greedy = trading(3_000);
    for (let i = 0; i < 20; i += 1) raiseEquity(greedy, 500_000);
    check('  however many times you ask', outsideStake(greedy) <= MAX_OUTSIDE_STAKE + 0.0001,
      `${(outsideStake(greedy) * 100).toFixed(1)}%`);

    // And the ongoing cost: they take a share of profit, never of a loss.
    const holder = trading(3_000);
    raiseEquity(holder, 300_000);
    const before = playerCompany(holder).cash;
    boardDaily(holder);
    check('investors take a share of a profitable day', playerCompany(holder).cash < before);
    const losing = trading(3_000);
    raiseEquity(losing, 300_000);
    losing.dayHistory.push({ day: 200, revenue: 0, costs: 900, profit: -900, cash: 1, netWorth: 1, customers: 0 });
    const lost = playerCompany(losing).cash;
    boardDaily(losing);
    check('  and nothing at all of a day that lost money', playerCompany(losing).cash === lost);
    check('  and a company with no investors pays nothing',
      (() => { const solo = trading(3_000); const c = playerCompany(solo).cash; boardDaily(solo); return playerCompany(solo).cash === c; })());

    // Buying back is dearer than what came in, once the company has grown.
    const back = trading(3_000);
    raiseEquity(back, 300_000);
    const held = outsideStake(back);
    check('buying investors out is priced at what the company is worth now',
      buybackCost(back, held) > 0);
    playerCompany(back).cash += buybackCost(back, held);
    const bought = buyBack(back, held);
    check('  and it can be done', bought.ok, bought.message);
    check('  and then you own all of it again', ownersStake(back) > 0.9999);

    const broke = trading(80);
    check('a board that has lost confidence will not fund anything',
      boardConfidence(broke) >= 0 && (boardConfidence(broke) >= RAISE_FLOOR || !canRaise(broke, 100_000).ok));

    check('the board leaves no broken numbers', findBadNumber(good) === null, findBadNumber(good) ?? '');
  }
}


heading('44. The company has rules, and every one of them is a real trade');
{
  const state = startGame({ companyName: 'Rules Co', founderName: 'K', traitId: 'allrounder', scenarioId: 'empire', seed: 87 });

  check('every policy has a real choice in it', POLICIES.every((def) => def.options.length >= 2));
  check('and a setting it runs on before anybody decides',
    POLICIES.every((def) => def.options.some((option) => option.id === def.fallback)));
  check('a company starts on the fallbacks',
    POLICIES.every((def) => policy(state, def.id) === def.fallback));
  check('an unknown option is refused', !setPolicy(state, 'pay', 'lavish').ok);
  check('and a nonsense save falls back rather than breaking',
    (() => {
      const odd = JSON.parse(JSON.stringify(state)) as Record<string, unknown>;
      odd.policies = { pay: 'lavish', hours: 42 };
      const opened = migrate(odd);
      return policy(opened, 'pay') === 'market' && policy(opened, 'hours') === 'standard';
    })());

  // Pay: the policy moves wages, and everything downstream reads the wages.
  const wagesUnder = (option: string): number => {
    const copy = startGame({ companyName: 'P', founderName: 'K', traitId: 'allrounder', scenarioId: 'empire', seed: 87 });
    setPolicy(copy, 'pay', option);
    for (let i = 0; i < 400; i += 1) { copy.day += 1; policiesDaily(copy); }
    return sum(copy.employees.filter((e) => e.companyId === copy.playerCompanyId), (e) => e.salary);
  };
  const lean = wagesUnder('lean');
  const market = wagesUnder('market');
  const generous = wagesUnder('generous');
  check('a lean pay policy costs less than paying the rate', lean < market, `${lean} against ${market}`);
  check('and a generous one costs more', generous > market, `${generous} against ${market}`);
  check('and none of it happens overnight', PAY_DRIFT < 0.01);
  check('wages land near where the policy aimed, not past it',
    generous / Math.max(1, market) < 1.2, `${(generous / market).toFixed(3)}`);

  // Hours: more out of the same people, paid for in how they feel.
  const overtime = startGame({ companyName: 'H', founderName: 'K', traitId: 'allrounder', scenarioId: 'empire', seed: 88 });
  const plain = hoursFactor(overtime);
  setPolicy(overtime, 'hours', 'overtime');
  check('overtime gets more out of the same people', hoursFactor(overtime) > plain);
  check('  and it costs morale every day it is on', hoursMoraleDrag(overtime) > 0);
  check('  and people are ill more often', sicknessFactor(overtime) > 1);
  // Measured on workload rather than on throughput, because throughput rolls
  // attendance and a die is no way to prove a multiplier. Workload is the same
  // capacity figure read from the other end: more capacity for the same queue
  // means people are less stretched, and it is arithmetic all the way down.
  const shop = playerBusinesses(overtime).find((b) => b.status === 'open');
  const standard = startGame({ companyName: 'H2', founderName: 'K', traitId: 'allrounder', scenarioId: 'empire', seed: 88 });
  const other = playerBusinesses(standard).find((b) => b.status === 'open');
  if (shop && other) {
    shop.yesterday = { ...shop.yesterday, customers: 400, lostCustomers: 40 };
    other.yesterday = { ...other.yesterday, customers: 400, lostCustomers: 40 };
    check('  and the same people cover a busy day more easily',
      workloadOf(overtime, shop) < workloadOf(standard, other),
      `${workloadOf(overtime, shop).toFixed(1)} against ${workloadOf(standard, other).toFixed(1)}`);
    check('  and by exactly what the policy says, not more',
      Math.abs(workloadOf(standard, other) / Math.max(0.001, workloadOf(overtime, shop)) - 1.15) < 0.02);
  }

  // Hiring: a shorter list of better people, and a dearer recruiter.
  const careful = startGame({ companyName: 'F', founderName: 'K', traitId: 'allrounder', scenarioId: 'empire', seed: 89 });
  const quickFee = recruitmentFee(careful);
  const quickCount = careful.applicants.length;
  setPolicy(careful, 'hiring', 'careful');
  refreshApplicants(careful);
  check('holding out for the right person shortens the list',
    careful.applicants.length < quickCount, `${careful.applicants.length} against ${quickCount}`);
  check('  and costs more to do', recruitmentFee(careful) > quickFee,
    `${recruitmentFee(careful)} against ${quickFee}`);
  check('  and the people on it are better',
    applicantSkillBias(careful) > 0);

  // Buying: which supplier the shops actually order from.
  const buyer = startGame({ companyName: 'B', founderName: 'K', traitId: 'allrounder', scenarioId: 'empire', seed: 90 });
  const stocked = playerBusinesses(buyer).find((b) => b.status === 'open' && Object.keys(b.prices).some((k) => k !== 'service'));
  if (stocked) {
    setPolicy(buyer, 'buying', 'cheapest');
    const cheap = rankedSuppliers(buyer, stocked)[0];
    setPolicy(buyer, 'buying', 'best');
    const best = rankedSuppliers(buyer, stocked)[0];
    check('the buying policy changes who the shops order from', cheap !== best, `${cheap} then ${best}`);
    const of = (id: string) => SUPPLIERS.find((def) => def.id === id);
    check('  and cheapest really is the cheapest',
      (of(cheap)?.priceMultiplier ?? 9) <= (of(best)?.priceMultiplier ?? 0));
    check('  and best really is the best',
      (of(best)?.quality ?? 0) >= (of(cheap)?.quality ?? 9));
  }

  check('rules leave no broken numbers', findBadNumber(state) === null, findBadNumber(state) ?? '');
}


heading('45. A head office has to fit in the building it is in');
{
  const state = startGame({ companyName: 'Move Co', founderName: 'K', traitId: 'allrounder', scenarioId: 'empire', seed: 93 });
  playerCompany(state).cash += 4_000_000;

  check('every floor above the first needs more room than the one below',
    HQ_LEVELS.every((level, i) => i === 0 || level.needsArea > HQ_LEVELS[i - 1].needsArea));
  check('and the first needs none, so a company can always start somewhere',
    HQ_LEVELS[0].needsArea === 0);
  check('the city has buildings big enough for the largest of them',
    state.buildings.some((b) => b.size * b.floors >= HQ_LEVELS[HQ_LEVELS.length - 1].needsArea));
  check('and not many, so it is a decision',
    state.buildings.filter((b) => b.size * b.floors >= HQ_LEVELS[HQ_LEVELS.length - 1].needsArea).length
      < state.buildings.length / 3);

  if (state.headOffice) {
    const home = state.buildings.find((b) => b.id === state.headOffice?.buildingId);
    if (home) {
      // Shrink the building under the next floor's requirement: the upgrade is
      // refused, and the message says to move rather than to find more money.
      const next = nextHqLevel(state);
      if (next) {
        home.size = 40;
        home.floors = 1;
        const blocked = upgradeHeadOffice(state);
        check('a floor that will not fit is refused', !blocked.ok);
        check('  and it says so in square metres', blocked.message.includes('m²'), blocked.message);
        check('  and the level did not move', hqLevel(state).n < next.n);

        // A bigger building the company already occupies, and the move.
        const bigger = state.buildings.find(
          (b) => b.id !== home.id && b.status === 'available' && b.size * b.floors >= 700,
        );
        if (!bigger) {
          check('there is somewhere bigger to move to', false);
        } else {
          check('you cannot move into a building you do not occupy',
            !canRelocate(state, bigger.id).ok, canRelocate(state, bigger.id).message);
          bigger.status = 'owned';
          bigger.occupantCompanyId = state.playerCompanyId;
          check('and once you do, you can', canRelocate(state, bigger.id).ok,
            canRelocate(state, bigger.id).message);
          check('  and it is offered on the list of places to go',
            relocationOptions(state).some((row) => row.id === bigger.id && row.ok));

          const cash = playerCompany(state).cash;
          const staffBefore = centralStaff(state).length;
          const roomsBefore = [...(state.headOffice.facilities ?? [])];
          const levelBefore = hqLevel(state).n;
          const moved = relocateHeadOffice(state, bigger.id);
          check('the move goes through', moved.ok, moved.message);
          check('  and it costs what it costs', playerCompany(state).cash < cash);
          check('  and the address changed', state.headOffice.buildingId === bigger.id);
          check('  and everybody came with it', centralStaff(state).length === staffBefore);
          check('  and so did the rooms', state.headOffice.facilities.length === roomsBefore.length);
          check('  and so did the floor it had reached', hqLevel(state).n === levelBefore);
          check('  and the old premises are still yours to deal with',
            home.occupantCompanyId === state.playerCompanyId);

          // And now the upgrade that was refused is allowed.
          check('and the floor that would not fit before now does',
            hqArea(state) >= (nextHqLevel(state)?.needsArea ?? 0));
          const after = upgradeHeadOffice(state);
          check('  so the company can grow into it', after.ok, after.message);
        }
      }
    }
  }

  check('moving leaves no broken numbers', findBadNumber(state) === null, findBadNumber(state) ?? '');
}


console.log('\n' + '='.repeat(42));
console.log(`${checks - failures}/${checks} checks passed`);
if (failures > 0) {
  console.log(`${failures} FAILED`);
  process.exit(1);
}
