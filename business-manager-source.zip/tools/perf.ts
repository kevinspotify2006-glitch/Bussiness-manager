import { createNewGame } from '../src/sim/setup';
import { Engine } from '../src/sim/engine';
import { foundBusiness, openBusiness, rentBuilding } from '../src/sim/business';
import { generateApplicant, hire } from '../src/sim/employees';
import { playerBusinesses, playerCompany } from '../src/sim/state';
import { businessTypeOrThrow, BUSINESS_TYPES } from '../src/data/businessTypes';
import { staffingSummary, orgChart, findings, opportunities } from '../src/sim/staffing';
import { marketShare, groupShare } from '../src/sim/demand';
import { topProblems, topOpportunities } from '../src/sim/advice';
import { ownerAttention } from '../src/sim/holding';
import { forecast } from '../src/sim/cashflow';

const state = createNewGame('Perf Ltd', 42);
const engine = new Engine(state);
playerCompany(state).cash = 50_000_000;
// The location ceiling is a progression rule, not a performance one: this is
// asking whether the game stays quick at a size a real player can reach.
state.levelReached = 8;

// Twenty locations and a couple of hundred people: a company well past
// anything the level ladder lets you reach quickly.
let made = 0;
for (const building of state.buildings) {
  if (made >= Number(process.argv[3] ?? 20)) break;
  if (building.status !== 'available') continue;
  const type = BUSINESS_TYPES.find((t) => building.size >= t.minSize && building.suitableFor.includes(t.category));
  if (!type) continue;
  if (!rentBuilding(state, building.id).ok) continue;
  const res = foundBusiness(state, type.id, building.id, `Shop ${made + 1}`);
  if (!res.ok) continue;
  made += 1;
}
for (const business of playerBusinesses(state)) {
  const type = businessTypeOrThrow(business.typeId);
  for (let i = 0; i < Number(process.argv[2] ?? 11); i += 1) {
    const person = generateApplicant(state, type.roles[i % type.roles.length]);
    state.applicants.push(person);
    hire(state, person.id, business.id);
  }
  openBusiness(state, business.id);
}
for (let h = 0; h < 24 * 10; h += 1) engine.stepHour();

console.log(`${playerBusinesses(state).length} locations, ${state.employees.length} people, ${state.businesses.length} businesses in the city`);

const time = (label: string, runs: number, fn: () => void): void => {
  fn();
  const t0 = performance.now();
  for (let i = 0; i < runs; i += 1) fn();
  const each = (performance.now() - t0) / runs;
  const verdict = each < 16 ? 'ok' : each < 50 ? 'slow' : 'TOO SLOW';
  console.log(`  ${each.toFixed(2)} ms  ${label}  [${verdict}]`);
};

console.log('one full pass of everything a screen reads:');
time('staffing plan for every location', 20, () => {
  for (const b of playerBusinesses(state)) staffingSummary(state, b);
});
time('org chart for every location', 20, () => {
  for (const b of playerBusinesses(state)) orgChart(state, b);
});
time('findings and opportunities for every location', 20, () => {
  for (const b of playerBusinesses(state)) { findings(state, b); opportunities(state, b); }
});
time('market share for every location', 20, () => {
  for (const b of playerBusinesses(state)) marketShare(state, b);
});
time('group share', 20, () => { groupShare(state); });
time('the whole advisor', 20, () => { topProblems(state, 3); topOpportunities(state, 4); });
time('owner attention', 50, () => { ownerAttention(state); });
time('cash forecast', 50, () => { forecast(state, 14); });
time('one simulated hour', 24, () => { engine.stepHour(); });
