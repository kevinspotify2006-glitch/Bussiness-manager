/**
 * The scroll test.
 *
 * The game repaints a whole screen whenever a day passes and whenever the
 * player does something. That is fine, and it is how this game has always shown
 * new numbers — but it must never move the reader. Somebody halfway down the
 * employee list who trains somebody should still be halfway down the employee
 * list.
 *
 * This drives the real interface and checks the scroll position across every
 * kind of repaint there is: actions, dialogs, dropdowns, filters, sorting, and
 * the clock simply running — on a desktop, a tablet and a phone, because the
 * phone scrolls a different element and has always been the one that breaks.
 *
 *   node tools/scroll-test.mjs
 *
 * BM_URL, PLAYWRIGHT_MODULE and CHROMIUM_PATH override the defaults.
 *
 * A note for anybody changing the scroll handling in src/ui/app.ts: this suite
 * has been negative-controlled. Remove the restore in `mount` and it goes red
 * with six or more failures. If a change makes it pass trivially, check that
 * first.
 */
const pwModule = await import(process.env.PLAYWRIGHT_MODULE ?? 'playwright');
// A CJS build imported from ESM arrives under `default`; a real ESM one does not.
const { chromium } = pwModule.chromium ? pwModule : pwModule.default;
const BASE = process.env.BM_URL ?? 'http://127.0.0.1:4173/';
const launchOptions = process.env.CHROMIUM_PATH ? { executablePath: process.env.CHROMIUM_PATH } : {};

const problems = [];
const browser = await chromium.launch(launchOptions);

/**
 * Every viewport the game claims to work at. The windows are short on purpose,
 * so every screen is taller than the viewport and there is somewhere to scroll
 * to — a test that cannot scroll cannot catch a page that jumps.
 */
const VIEWPORTS = [
  { name: 'desktop', width: 1440, height: 660 },
  { name: 'tablet', width: 834, height: 700 },
  { name: 'phone', width: 390, height: 680 },
];

for (const viewport of VIEWPORTS) {
  await runAt(viewport);
}

console.log('\n--- problems ---');
console.log(problems.length ? [...new Set(problems)].join('\n') : 'none');
await browser.close();
if (problems.length > 0) process.exitCode = 1;

// ---------------------------------------------------------------- the run


/**
 * Walks the start screen the way a player does: title, scenario, founder,
 * names, go. Defaults to the entrepreneur start, which is the one with nothing
 * trading yet — the same blank slate these harnesses have always assumed.
 */
async function newGame(page, companyName, scenarioName = null) {
  await page.waitForSelector('.welcome-menu');
  await page.locator('.menu-item:has-text("New game")').click();
  await page.waitForSelector('.scenario-grid');
  if (scenarioName) {
    await page.locator(`.scenario-card:has-text("${scenarioName}")`).first().click();
    await page.waitForTimeout(150);
  }
  await page.locator('button:has-text("Next")').click();
  await page.waitForSelector('input[placeholder="Company name"]');
  await page.fill('input[placeholder="Company name"]', companyName);
  await page.locator('button:has-text("Start the company")').click();
  await page.waitForSelector('.shell', { timeout: 45000 });
  await page.locator('.tutorial button:has-text("Skip tutorial")').click().catch(() => {});
}

async function runAt({ name, width, height }) {
  console.log(`\n================= ${name} ${width}×${height} =================`);
  const context = await browser.newContext({ viewport: { width, height } });
  const page = await context.newPage();
  page.setDefaultTimeout(12000);
  page.on('pageerror', (e) => problems.push(`${name} PAGEERROR: ${e.message}`));
  page.on('console', (m) => {
    if (m.type() === 'error' && !m.text().includes('404')) problems.push(`${name} CONSOLE: ${m.text()}`);
  });

  const t = tools(page, name);
  await setUp(t);
  await checks(t);
  await context.close();
}

/** Everything a run needs, bound to one page. */
function tools(page, tag) {
  const scrollTop = () => page.evaluate(() => document.querySelector('.main')?.scrollTop ?? -1);
  const scrollable = () =>
    page.evaluate(() => {
      const main = document.querySelector('.main');
      return main ? main.scrollHeight - main.clientHeight : 0;
    });

  async function scrollDown(to = 400) {
    const room = await scrollable();
    const target = Math.min(to, Math.max(0, room - 10));
    await page.evaluate((value) => {
      const main = document.querySelector('.main');
      if (main) main.scrollTop = value;
    }, target);
    await page.waitForTimeout(120);
    return scrollTop();
  }

  async function dismissModal() {
    let guard = 0;
    while ((await page.locator('.modal-overlay').count()) > 0 && guard < 6) {
      guard += 1;
      const later = page.locator('.modal-footer .btn:has-text("Decide later")').last();
      if (await later.count()) await later.click().catch(() => {});
      else await page.locator('.modal-head button').last().click().catch(() => {});
      await page.waitForTimeout(200);
    }
  }

  /**
   * Does `action`, then reports whether the page stayed where it was.
   *
   * If the action clicks something, pass it as `target`: the browser scrolls a
   * control into view before clicking it, which is the browser doing its job,
   * not the game moving the page — so the position is recorded after that, from
   * where the player would actually be standing.
   */
  async function held(label, action, target = null) {
    let before = await scrollDown(340);
    if (before < 40) {
      console.log(`  skipped ${label} — nothing to scroll on this screen`);
      return;
    }
    if (target) {
      if ((await target.count()) === 0) {
        console.log(`  skipped ${label} — nothing to click`);
        return;
      }
      await target.scrollIntoViewIfNeeded().catch(() => {});
      await page.waitForTimeout(150);
      before = await scrollTop();
    }
    await action();
    await page.waitForTimeout(400);
    // A decision dialog can open by itself while the clock runs; that is by
    // design, and closing it must not move the page either, so it is closed
    // before the position is read.
    await dismissModal();
    await page.waitForTimeout(250);

    const after = await scrollTop();
    // Some actions genuinely make the page shorter — filtering a list down to
    // three rows, for instance. The browser then has no choice but to clamp,
    // and that is physics rather than the game moving the reader. So the bar is
    // "as far down as this page now goes", not a blanket tolerance: a real jump
    // to the top of a page that is still long fails, where a blanket tolerance
    // would have quietly let it through.
    const room = await scrollable();
    const expected = Math.min(before, room);
    const moved = Math.abs(after - expected);
    if (moved > 4) {
      problems.push(`${tag} — ${label}: the page jumped ${before} → ${after} (it can still reach ${room})`);
      console.log(`  ✗ ${label}: ${before} → ${after}, and the page still reaches ${room}`);
    } else if (room < before) {
      console.log(`  ✓ ${label}: held at ${after} — as far as the shorter page allows`);
    } else {
      console.log(`  ✓ ${label}: held at ${after}`);
    }
  }

  async function nav(label) {
    await dismissModal();
    // `:visible` rather than `.nav`, because the phone uses a different bar.
    await page.locator(`.nav-item:visible:has-text("${label}")`).first().click();
    await page.waitForTimeout(400);
  }

  const ff = (days) =>
    page.evaluate((d) => {
      const bm = window.__BM__;
      for (let i = 0; i < d * 24; i += 1) bm.engine.stepHour();
    }, days);

  return { page, tag, held, nav, ff, dismissModal, scrollDown, scrollTop };
}

/** A company with enough going on that every screen has something on it. */
async function setUp({ page, nav, ff, dismissModal }) {
  await page.goto(BASE, { waitUntil: 'load' });
  await newGame(page, 'Scroll Test Ltd');

  await page.evaluate(() => {
    const s = window.__BM__.state;
    s.companies.find((c) => c.isPlayer).cash += 400000;
  });

  await nav('Real estate');
  await page.locator('button:has-text("Rent")').first().click();
  await page.waitForSelector('.modal-card');
  await page.click('.modal-footer .btn.primary');
  await page.waitForSelector('.modal-overlay', { state: 'detached' });
  await nav('Real estate');
  await page.locator('table tr', { hasText: 'Empty' }).first().locator('button:has-text("Map")').first().click();
  await page.waitForTimeout(600);
  await page.locator('button:has-text("Create a business here")').click();
  await page.waitForSelector('.modal-card');
  await page.waitForTimeout(250);
  await page.click('.modal-footer .btn.primary');
  await page.waitForTimeout(500);
  await dismissModal();

  await nav('Employees');
  await page.waitForSelector('table');
  for (let i = 0; i < 5; i += 1) {
    await page.locator('button:has-text("Hire")').first().click().catch(() => {});
    await page.waitForTimeout(200);
  }
  await ff(4);
  await nav('Businesses');
  await page.waitForTimeout(300);
  const openBtn = page.locator('button:has-text("Open for business")');
  if (await openBtn.count()) {
    await openBtn.click();
    await page.waitForTimeout(300);
  }

  // A head office, so the stance cards and the systems buttons are reachable —
  // they are the newest interactive surfaces and therefore the likeliest to
  // have been wired up without thinking about the scroll position.
  await page.evaluate(() => {
    const bm = window.__BM__;
    const s = bm.state;
    const spare = s.buildings.find((b) => b.status === 'available' && b.size > 60);
    if (!spare) return;
    spare.status = 'rented';
    spare.occupantCompanyId = s.playerCompanyId;
  });
  await ff(14);
  await dismissModal();
  console.log('company set up');
}

/** Every repaint a player can cause, on every screen that can cause one. */
async function checks(t) {
  const { page, held, nav, ff, dismissModal, scrollDown, scrollTop } = t;

  console.log('\ndashboard');
  await nav('Dashboard');
  await held('the clock running a day', () => ff(1));
  await held('the clock running a week', () => ff(7));

  console.log('\nemployees screen');
  await nav('Employees');
  await held('the clock running a day', () => ff(1));
  const manage = page.locator('.view button:has-text("Manage")').last();
  await held(
    'opening and closing a dialog',
    async () => {
      await manage.click();
      await page.waitForSelector('.modal-card');
      await page.waitForTimeout(300);
      await dismissModal();
    },
    manage,
  );
  await held(
    'a dialog that changes something',
    async () => {
      await manage.click();
      await page.waitForSelector('.modal-card');
      await page.waitForTimeout(250);
      const bonus = page.locator('.modal-body button:has-text("bonus")').first();
      if (await bonus.count()) await bonus.click();
      await page.waitForTimeout(400);
      await dismissModal();
    },
    manage,
  );
  await held(
    'typing while a day passes',
    async () => {
      await manage.click();
      await page.waitForSelector('.modal-card');
      const field = page.locator('.modal-body input[type=number]').first();
      if (await field.count()) {
        await field.click();
        await field.fill('2500');
        await ff(2);
        await page.waitForTimeout(400);
        const stillThere = await field.inputValue().catch(() => '');
        if (stillThere !== '2500') problems.push(`${t.tag} — typing: the field was reset to "${stillThere}"`);
        else console.log('  ✓ a half-typed field survived a day passing');
      }
      await dismissModal();
    },
    manage,
  );
  const picker = page.locator('.view select').first();
  await held(
    'changing which location you are looking at',
    async () => {
      const options = await picker.locator('option').count();
      if (options > 1) await picker.selectOption({ index: 0 });
      await page.waitForTimeout(300);
    },
    picker,
  );

  console.log('\nbusinesses screen');
  await nav('Businesses');
  await held('the clock running', () => ff(2));
  const control = page.locator('.view .switch input[type=checkbox]').last();
  await held(
    'a control on the page',
    async () => {
      await control.click();
      await page.waitForTimeout(250);
    },
    control,
  );
  const priceField = page.locator('.view input[type=number]').first();
  await held(
    'changing a price',
    async () => {
      if (await priceField.count()) {
        await priceField.click();
        await priceField.fill('3.25');
        await priceField.press('Enter');
        await page.waitForTimeout(350);
      }
    },
    priceField,
  );

  console.log('\nholding screen');
  await nav('Holding');
  await held('the clock running', () => ff(2));
  const newDivision = page.locator('.view button:has-text("Start a new division")').first();
  await held(
    'creating a division from a dialog',
    async () => {
      if (await newDivision.count()) {
        await newDivision.click();
        await page.waitForSelector('.modal-card');
        await page.waitForTimeout(250);
        const save = page.locator('.modal-body button:has-text("Save")').first();
        if (await save.count()) await save.click();
        await page.waitForTimeout(400);
      }
      await dismissModal();
    },
    newDivision,
  );
  const divisionPicker = page.locator('.division-row select').first();
  await held(
    'moving a location into a division',
    async () => {
      if (await divisionPicker.count()) {
        const options = await divisionPicker.locator('option').count();
        if (options > 1) await divisionPicker.selectOption({ index: 1 });
        await page.waitForTimeout(350);
      }
    },
    divisionPicker,
  );

  console.log('\nhead office screen');
  await nav('Head office');
  await held('the clock running', () => ff(2));
  const openHq = page.locator('.view button:has-text("Open the head office")').first();
  if (await openHq.count()) {
    await openHq.click();
    await page.waitForTimeout(500);
    await dismissModal();
  }
  const stance = page.locator('.stance-card:not(.chosen)').first();
  await held(
    'changing how the company is run',
    async () => {
      if (await stance.count()) {
        await stance.click();
        await page.waitForTimeout(400);
      }
    },
    stance,
  );
  const buyIn = page.locator('.function-actions button:has-text("Buy it in")').first();
  await held(
    'buying a central function in',
    async () => {
      if (await buyIn.count()) {
        await buyIn.click();
        await page.waitForTimeout(400);
      }
    },
    buyIn,
  );
  const systems = page.locator('.function-actions button:has-text("systems")').first();
  await held(
    'investing in systems',
    async () => {
      if (await systems.count()) {
        await systems.click();
        await page.waitForTimeout(400);
      }
    },
    systems,
  );

  console.log('\nreal estate screen');
  await nav('Real estate');
  await held('the clock running', () => ff(2));
  const filter = page.locator('.view select').first();
  await held(
    'filtering the list',
    async () => {
      const options = await filter.locator('option').allTextContents();
      if (options.length > 1) await filter.selectOption({ index: 1 });
      await page.waitForTimeout(300);
    },
    filter,
  );

  console.log('\nnewsroom filters');
  await nav('Newsroom');
  await held('the clock running', () => ff(3));
  const tab = page.locator('.filter-row .map-mode').nth(1);
  await held(
    'switching a tab',
    async () => {
      if (await tab.count()) {
        await tab.click();
        await page.waitForTimeout(300);
      }
    },
    tab,
  );

  console.log('\ncompetition screen');
  await nav('Competition');
  await held('the clock running', () => ff(3));

  console.log('\nfinance and reports');
  await nav('Finance');
  await held('the clock running', () => ff(3));
  await nav('Reports');
  await held('the clock running', () => ff(3));

  console.log('\nprogress screen');
  await nav('Progress');
  await held('the clock running', () => ff(3));
  await held('several days at once', () => ff(20));

  console.log('\nnavigation still goes to the top');
  await nav('Employees');
  await scrollDown(300);
  await nav('Finance');
  const afterNav = await scrollTop();
  if (afterNav !== 0) problems.push(`${t.tag} — navigating to another screen left the page at ${afterNav}, not the top`);
  else console.log('  ✓ a new screen starts at the top');
}
