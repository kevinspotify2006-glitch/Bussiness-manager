# Business Manager — Asset Pack 1.0

This pack contains:
- `BM_Asset_Atlas_100.png` — 100-asset visual atlas
- `asset_manifest.json` — machine-readable asset/category inventory
- `CLAUDE_IMPLEMENTATION_PROMPT.md` — implementation instructions for Claude

The atlas is intended as a source/reference for integrating individual game assets into the existing Business Manager map.
