# BM ASSET PACK — IMPLEMENTATION INSTRUCTIONS

You are working on the Business Manager browser game.

The attached file `BM_Asset_Atlas_100.png` is the visual asset atlas for the map.
`asset_manifest.json` contains the complete category/asset list.

GOAL:
Make the existing game map substantially more alive and visually rich using this asset pack, without breaking gameplay or replacing existing systems.

REQUIRED:
1. Inspect the atlas and manifest before coding.
2. Identify the game's current map/rendering architecture and integrate assets into the existing system rather than creating a disconnected demo.
3. Add varied commercial, industrial, residential, logistics, infrastructure and service buildings.
4. Add environmental assets: trees, bushes, grass, parks, water, flowers, rocks and street furniture.
5. Add roads and road details where compatible with the current map.
6. Add decorative vehicles around roads, parking areas, logistics zones and businesses.
7. Create sensible density rules so industrial zones look different from city centers and residential areas.
8. Preserve all existing gameplay, save state, UI, economy and interactions.
9. Keep performance in mind by reusing assets/instances and avoiding unnecessary duplicate image data.
10. Make the result feel like a living business simulation rather than an empty grid.

IMPORTANT:
The atlas is a source/reference sheet, not a requirement to display the whole sheet inside the game. Extract or recreate individual assets from it as appropriate for the current renderer. Do not show the labels/panels from the atlas in the actual game unless they are intentionally part of the UI.

VISUAL TARGET:
Polished, modern, detailed isometric 3D business-management game. Consistent scale, clean European city/business environment, believable spacing, varied but controlled decoration.

COMPLETION CRITERIA:
- Map visibly contains many more buildings and environmental details.
- Different districts have distinct visual identities.
- Roads and surroundings no longer feel empty.
- Assets remain aligned to the game's existing perspective/grid.
- Existing game functionality continues to work.
- No obvious console/runtime errors.
- The game remains responsive.

After implementation, test the complete map and fix any visual or runtime problems you find.
